<G-vec00328-002-s057><touch.anfassen><de> Treffen Sie Ihre Auswahl mit allen Sinnen: bei Hanse Haus sehen Sie die Materialien nicht nur in natura, Sie können sie auch anfassen, schnell miteinander vergleichen und kombinieren.
<G-vec00328-002-s057><touch.anfassen><en> Choose with all your senses: at Hanse Haus, you will not only see the materials in their natural state but can also touch, compare and combine them quickly.
<G-vec00328-002-s058><touch.anfassen><de> Eine Programmiersprache zum Anfassen und Ausprobieren wie LEGO®.
<G-vec00328-002-s058><touch.anfassen><en> A coding language you can touch and manipulate like LEGO®.
<G-vec00328-002-s059><touch.anfassen><de> Begleitend zur Konferenz präsentieren die zehn europäischen Forschungspartner in einer Ausstellung rund 40 Exponate zur Interaktion von Mensch und angewandter Forschung zum Anfassen und Testen.
<G-vec00328-002-s059><touch.anfassen><en> Accompanying the conference, the ten European research partners will be presenting some 40 exhibits on the interaction between human and applied research to touch and try out.
<G-vec00328-002-s060><touch.anfassen><de> Kritikern dagegen ist es schlicht unheimlich, einem Asset zu vertrauen, das sie nicht „anfassen“ können und dessen Technologie sie nicht komplett verstehen.
<G-vec00328-002-s060><touch.anfassen><en> Critics, on the other hand, find it simply scary to trust an asset that they cannot "touch" and whose technology they do not fully understand.
<G-vec00328-002-s061><touch.anfassen><de> Struktur Fichte Relativ hoch, deswegen heiß zum Anfassen: Sie müssen auf einem Handtuch sitzen.
<G-vec00328-002-s061><touch.anfassen><en> Structure Spruce Relatively high, therefore hot to the touch: you have to sit on a towel.
<G-vec00328-002-s062><touch.anfassen><de> Beim Spielen von Spielen oder der Online-Wiedergabe von Videos wird berichtet, dass das Notebook zu heiß zum Anfassen ist.
<G-vec00328-002-s062><touch.anfassen><en> While playing games or watching online videos the notebook is reported to be too hot to touch.
<G-vec00328-002-s063><touch.anfassen><de> Helden, Prinzessinnen und Lieblingstiere sind zum Anfassen nahe und geleiten Ihr Kind in fantastische Traumwelten.
<G-vec00328-002-s063><touch.anfassen><en> Heroes, princesses and favourite animals are close enough to touch and accompany your child into fantastic dream worlds.
<G-vec00328-002-s064><touch.anfassen><de> Damit Ihre Karten nicht nur exklusiver aussehen, sondern sich auch besonders gut anfassen lassen, empfehlen wir eine Blindprägung oder Heißfolienreliefprägung.
<G-vec00328-002-s064><touch.anfassen><en> To make your cards not only look even more exclusive but also feel pleasant to touch, we recommend blind embossing or hot foil relief embossing.
<G-vec00328-002-s065><touch.anfassen><de> Vergewissern Sie sich, dass das Gerät abgekühlt ist, bevor Sie es anfassen.
<G-vec00328-002-s065><touch.anfassen><en> Make sure that the appliance is cool before you touch it.
<G-vec00328-002-s066><touch.anfassen><de> In gewisser Weise bin ich ein Geburtshelfer, denn hier entsteht die Form des Klaviers, so wie man es später sieht und anfassen kann.
<G-vec00328-002-s066><touch.anfassen><en> In a way, I’m a kind of mid-wife – I bring the piano, the actual shape you can later see and touch, into this world.
<G-vec00328-002-s067><touch.anfassen><de> Diese neue Eigenschaft ist ein wichtiges Metadatum in Zusammenhang mit Zusammenführungen, das Sie nicht anfassen sollten, da es von künftigen svn merge-Befehlen benötigt wird.
<G-vec00328-002-s067><touch.anfassen><en> This new property is important merge-related metadata that you should not touch, since it is needed by future svn merge commands.
<G-vec00328-002-s068><touch.anfassen><de> Wir können ihn nicht sehen und anfassen.
<G-vec00328-002-s068><touch.anfassen><en> We can't see and touch it.
<G-vec00328-002-s069><touch.anfassen><de> Seine seidige Textur, deren überraschende Farben die von natürlichem Perlmutt wiedergeben, lädt zum Anfassen ein.
<G-vec00328-002-s069><touch.anfassen><en> Its silky texture, whose surprising colours reproduce those of natural mother-of-pearl, invites the touch.
<G-vec00328-002-s070><touch.anfassen><de> Die Leute sind immer öfter von seinen Haaren fasziniert.– jeder scheint sie anfassen zu wollen.
<G-vec00328-002-s070><touch.anfassen><en> The people are much more often fascinated about his hair – everybody seems to want to touch it.
<G-vec00328-002-s071><touch.anfassen><de> Am Ende der Arbeit steht meist ein Produkt das man sehen und – oft – auch anfassen kann.
<G-vec00328-002-s071><touch.anfassen><en> At the end of a project there’s usually an actual product that you can see and – also quite often – that you can touch.
<G-vec00328-002-s072><touch.anfassen><de> Was sie anfassen und sehen können, was sie nachkontrollieren können, das können sie glauben.
<G-vec00328-002-s072><touch.anfassen><en> What they can touch and what they can see, what they can check is what they believe.
<G-vec00328-002-s073><touch.anfassen><de> Hauchzarte Stoffe und reiche Jacquarmuster verleihen ihr eine exklusive Optik und 3D-Stickereien verlocken zum Anfassen.
<G-vec00328-002-s073><touch.anfassen><en> Sheer fabrics and rich jacquards give an exclusive feel and 3D embroideries entice the touch.
<G-vec00328-002-s074><touch.anfassen><de> Tote oder kranke Vögel bitte nicht anfassen oder mitnehmen.
<G-vec00328-002-s074><touch.anfassen><en> Dead or sick birds do not touch or take.
<G-vec00328-002-s075><touch.anfassen><de> Die Kinder bauen das Modell einer römischen Villa nach und dürfen Originalfundstücke anfassen.
<G-vec00328-002-s075><touch.anfassen><en> The children will build a model of a Roman villa and will be allowed to touch original artifacts.
<G-vec00328-003-s057><touch_on.anfassen><de> Treffen Sie Ihre Auswahl mit allen Sinnen: bei Hanse Haus sehen Sie die Materialien nicht nur in natura, Sie können sie auch anfassen, schnell miteinander vergleichen und kombinieren.
<G-vec00328-003-s057><touch_on.anfassen><en> Choose with all your senses: at Hanse Haus, you will not only see the materials in their natural state but can also touch, compare and combine them quickly.
<G-vec00328-003-s058><touch_on.anfassen><de> Eine Programmiersprache zum Anfassen und Ausprobieren wie LEGO®.
<G-vec00328-003-s058><touch_on.anfassen><en> A coding language you can touch and manipulate like LEGO®.
<G-vec00328-003-s059><touch_on.anfassen><de> Begleitend zur Konferenz präsentieren die zehn europäischen Forschungspartner in einer Ausstellung rund 40 Exponate zur Interaktion von Mensch und angewandter Forschung zum Anfassen und Testen.
<G-vec00328-003-s059><touch_on.anfassen><en> Accompanying the conference, the ten European research partners will be presenting some 40 exhibits on the interaction between human and applied research to touch and try out.
<G-vec00328-003-s060><touch_on.anfassen><de> Kritikern dagegen ist es schlicht unheimlich, einem Asset zu vertrauen, das sie nicht „anfassen“ können und dessen Technologie sie nicht komplett verstehen.
<G-vec00328-003-s060><touch_on.anfassen><en> Critics, on the other hand, find it simply scary to trust an asset that they cannot "touch" and whose technology they do not fully understand.
<G-vec00328-003-s061><touch_on.anfassen><de> Struktur Fichte Relativ hoch, deswegen heiß zum Anfassen: Sie müssen auf einem Handtuch sitzen.
<G-vec00328-003-s061><touch_on.anfassen><en> Structure Spruce Relatively high, therefore hot to the touch: you have to sit on a towel.
<G-vec00328-003-s062><touch_on.anfassen><de> Beim Spielen von Spielen oder der Online-Wiedergabe von Videos wird berichtet, dass das Notebook zu heiß zum Anfassen ist.
<G-vec00328-003-s062><touch_on.anfassen><en> While playing games or watching online videos the notebook is reported to be too hot to touch.
<G-vec00328-003-s063><touch_on.anfassen><de> Helden, Prinzessinnen und Lieblingstiere sind zum Anfassen nahe und geleiten Ihr Kind in fantastische Traumwelten.
<G-vec00328-003-s063><touch_on.anfassen><en> Heroes, princesses and favourite animals are close enough to touch and accompany your child into fantastic dream worlds.
<G-vec00328-003-s064><touch_on.anfassen><de> Damit Ihre Karten nicht nur exklusiver aussehen, sondern sich auch besonders gut anfassen lassen, empfehlen wir eine Blindprägung oder Heißfolienreliefprägung.
<G-vec00328-003-s064><touch_on.anfassen><en> To make your cards not only look even more exclusive but also feel pleasant to touch, we recommend blind embossing or hot foil relief embossing.
<G-vec00328-003-s065><touch_on.anfassen><de> Vergewissern Sie sich, dass das Gerät abgekühlt ist, bevor Sie es anfassen.
<G-vec00328-003-s065><touch_on.anfassen><en> Make sure that the appliance is cool before you touch it.
<G-vec00328-003-s066><touch_on.anfassen><de> In gewisser Weise bin ich ein Geburtshelfer, denn hier entsteht die Form des Klaviers, so wie man es später sieht und anfassen kann.
<G-vec00328-003-s066><touch_on.anfassen><en> In a way, I’m a kind of mid-wife – I bring the piano, the actual shape you can later see and touch, into this world.
<G-vec00328-003-s067><touch_on.anfassen><de> Diese neue Eigenschaft ist ein wichtiges Metadatum in Zusammenhang mit Zusammenführungen, das Sie nicht anfassen sollten, da es von künftigen svn merge-Befehlen benötigt wird.
<G-vec00328-003-s067><touch_on.anfassen><en> This new property is important merge-related metadata that you should not touch, since it is needed by future svn merge commands.
<G-vec00328-003-s068><touch_on.anfassen><de> Wir können ihn nicht sehen und anfassen.
<G-vec00328-003-s068><touch_on.anfassen><en> We can't see and touch it.
<G-vec00328-003-s069><touch_on.anfassen><de> Seine seidige Textur, deren überraschende Farben die von natürlichem Perlmutt wiedergeben, lädt zum Anfassen ein.
<G-vec00328-003-s069><touch_on.anfassen><en> Its silky texture, whose surprising colours reproduce those of natural mother-of-pearl, invites the touch.
<G-vec00328-003-s070><touch_on.anfassen><de> Die Leute sind immer öfter von seinen Haaren fasziniert.– jeder scheint sie anfassen zu wollen.
<G-vec00328-003-s070><touch_on.anfassen><en> The people are much more often fascinated about his hair – everybody seems to want to touch it.
<G-vec00328-003-s071><touch_on.anfassen><de> Am Ende der Arbeit steht meist ein Produkt das man sehen und – oft – auch anfassen kann.
<G-vec00328-003-s071><touch_on.anfassen><en> At the end of a project there’s usually an actual product that you can see and – also quite often – that you can touch.
<G-vec00328-003-s072><touch_on.anfassen><de> Was sie anfassen und sehen können, was sie nachkontrollieren können, das können sie glauben.
<G-vec00328-003-s072><touch_on.anfassen><en> What they can touch and what they can see, what they can check is what they believe.
<G-vec00328-003-s073><touch_on.anfassen><de> Hauchzarte Stoffe und reiche Jacquarmuster verleihen ihr eine exklusive Optik und 3D-Stickereien verlocken zum Anfassen.
<G-vec00328-003-s073><touch_on.anfassen><en> Sheer fabrics and rich jacquards give an exclusive feel and 3D embroideries entice the touch.
<G-vec00328-003-s074><touch_on.anfassen><de> Tote oder kranke Vögel bitte nicht anfassen oder mitnehmen.
<G-vec00328-003-s074><touch_on.anfassen><en> Dead or sick birds do not touch or take.
<G-vec00328-003-s075><touch_on.anfassen><de> Die Kinder bauen das Modell einer römischen Villa nach und dürfen Originalfundstücke anfassen.
<G-vec00328-003-s075><touch_on.anfassen><en> The children will build a model of a Roman villa and will be allowed to touch original artifacts.
