<G-vec00372-002-s063><weigh.abwägen><de> Grünphasen, die aber nicht bedingungslos ist, sondern Umschaltverluste genau abwägt.
<G-vec00372-002-s063><weigh.abwägen><en> Green phases which is not unconditional but, but switching losses weigh accurately.
<G-vec00372-002-s064><weigh.abwägen><de> An besonders heissen Tagen im Sommer kann es jedoch in Sakko und langärmeligem Hemd etwas heiß werden, weshalb man im Hinblick auf den Anlass am besten selbst abwägt, was angebracht sein könnte.
<G-vec00372-002-s064><weigh.abwägen><en> However, on hot summer days a jacket and long-sleeved short may become rather warm, so you can weigh up the particular occasion to decide what would be appropriate.
<G-vec00149-002-s020><ponder.abwägen><de> Wenn Sie sich für einen Eingriff entscheiden, ist es wichtig, dass Sie die damit verbundenen Risiken genau kennen und diese auch abwägen können.
<G-vec00149-002-s020><ponder.abwägen><en> If you opt for surgery, it is important that you know exactly what the risks are and ponder them properly. (-> General information)
<G-vec00149-002-s021><ponder.abwägen><de> Er wird weniger trauern, seine Möglichkeiten mehr abwägen und Risiken eingehen, während die Wohlhabenden auf den Überresten ihrer Spielzeuge sitzen, bis der Tod über sie kommt.
<G-vec00149-002-s021><ponder.abwägen><en> He will grieve less and ponder his options more, and take risks where the wealthy sit on the remnants of their toys until death overtakes them.
<G-vec00149-002-s052><ponder.abwägen><de> Man wird stets zwischen Aufwand, Preis und Erfolgsaussichten abwägen müssen.
<G-vec00149-002-s052><ponder.abwägen><en> You’ll always have to ponder between price, effort and return of your listing.
<G-vec00149-002-s107><ponder.abwägen><de> Wir machen einen kurzen Stopp in Brighton und wägen ab, ob es sich lohnt in das algenüberflutete Meer zu springen oder ob wir doch einfach noch ein bisschen in der Hitze weiterfahren.
<G-vec00149-002-s107><ponder.abwägen><en> We quickly stop in Brighton and ponder whether to dive into the algae-infested sea or to continue riding in the heat.
<G-vec00149-002-s023><weigh.abwägen><de> In jedem Fall müssen jedoch alle Vorteile und Risiken des Verfahrens abgewogen werden.
<G-vec00149-002-s023><weigh.abwägen><en> However, in any case, it is necessary to weigh all the advantages and risks of the procedure.
<G-vec00149-002-s024><weigh.abwägen><de> In diesem Workshop werden die Optionen systematisch durch die Stakeholder anhand von drei ausgewählten Kriterien (Realisierbarkeit, Akzeptanz und Nachhaltigkeit) bewertet und abgewogen.
<G-vec00149-002-s024><weigh.abwägen><en> In this workshop, stakeholders systematically score and weigh out options against three selected criteria (feasibility, acceptability, and sustainability).
<G-vec00149-002-s025><weigh.abwägen><de> Die Ware wird aufgenommen, der EAN-Code wird scaniert, die Ware wird abgewogen, abgemessen, fotografiert.
<G-vec00149-002-s025><weigh.abwägen><en> We collect the goods, scan the EAN code, weigh and measure them and finally photograph them.
<G-vec00149-002-s044><weigh.abwägen><de> Das zuständige Disziplinarorgan oder die Anti-Doping-Organisation müsse dann eben abwägen, was im Vordergrund steht: der Schutzbedarf des Wettbewerbs oder der des Athleten.
<G-vec00149-002-s044><weigh.abwägen><en> The responsible disciplinary body or the anti-doping organisation would then have to weigh up what lay in the foreground: the need for protection of the competition or the athlete.
<G-vec00149-002-s045><weigh.abwägen><de> Die schrittweise Einstellung der kostenlosen Dienstleistung wird nicht vor Juli stattfinden, sodass Sie genügend Zeit zum Abwägen Ihrer Möglichkeiten haben.
<G-vec00149-002-s045><weigh.abwägen><en> This phasing out of free services won’t happen until July, so you’ll have plenty of time to weigh your options.
<G-vec00149-002-s046><weigh.abwägen><de> Während die meisten Einzelhändler ESL erst noch als Möglichkeit in Erwägung ziehen und die noch relativ hohen Anschaffungskosten mit den Vorteilen abwägen, setzen Media Markt und Saturn sogar schon Assistenzroboter und Indoor-Navigation ein, die sich mithilfe der Schilder im Store orientieren.
<G-vec00149-002-s046><weigh.abwägen><en> Whereas most retailers still consider ESLs as a potential option and weigh the relatively high initial costs against the benefits, Media Markt and Saturn have actually even started to use indoor navigation and assistant robots that get their bearings using the labels at the store.
<G-vec00149-002-s047><weigh.abwägen><de> Eine Vision zu entwickeln, verlangt vom Managementteam viele zusätzliche Stunden an Auseinandersetzung, Abwägen von Alternativen und letztlich eine verbindliche Entscheidungsfindung.
<G-vec00149-002-s047><weigh.abwägen><en> To develop a vision requires that the management team spend many additional hours to discuss it, weigh the alternatives and ultimately to make a binding decision.
<G-vec00149-002-s048><weigh.abwägen><de> Es gab viele Situationen, in denen wir Risiken abwägen mussten und in denen wir überlegt haben, ob wir jetzt noch weiter testen oder ob wir davon ausgehen können, dass die Sachen, so wie sie sind, funktionieren.
<G-vec00149-002-s048><weigh.abwägen><en> There were many situations in which we had to weigh up risks and in which we asked ourselves whether we should continue testing or if we could assume that things worked well as they were.
<G-vec00149-002-s049><weigh.abwägen><de> Mithilfe wissenschaftlicher Evidenz lassen sich Nutzen und Nebenwirkungen einer regelmäßigen Einnahme von Statinen abwägen.
<G-vec00149-002-s049><weigh.abwägen><en> Scientific evidence enables us to weigh up the effectiveness and side effects of regularly taking statins.
<G-vec00149-002-s050><weigh.abwägen><de> Was immer du sagst, aber die Geburt eines Kindes - es ist ein Ereignis im Leben jeder Familie.Und immer gibt es ein Problem - wie man einen Namen für das Baby zu wählen.Dies ist eine wichtige Frage, die Auswirkungen auf das Leben eines Menschen haben kann.Der Name kann die Natur und Bestimmung der menschlichen Gesundheit zu beeinflussen.Also, bevor Sie das Baby nennen, müssen Sie genau überlegen und abwägen alles.
<G-vec00149-002-s050><weigh.abwägen><en> Whatever you say, but the birth of a child - it's an event in the life of every family.And always there is a problem - how to choose a name for the baby.This is an important issue that may have an impact on an individual's life.The name can influence the nature and destiny of human health.So before you call the baby, you need to think carefully and carefully weigh everything.
<G-vec00149-002-s051><weigh.abwägen><de> Ob man das Öl versuchen möchte oder nicht muss man bei der wackeligen Forschungslage gut abwägen, es wäre, wie bei Methylphenidat, ein Medikamentenversuch.
<G-vec00149-002-s051><weigh.abwägen><en> Whether you want to try the oil or not you have to weigh well in the unclear research situation, it would, as with methylphenidate, an attempt.
<G-vec00149-002-s052><weigh.abwägen><de> Sie müssen abwägen und das Gleichgewicht der einzelnen Teile sicherstellen, dass sie zusammenarbeiten.
<G-vec00149-002-s052><weigh.abwägen><en> You have to weigh and balance the individual parts and make sure they work together.
<G-vec00149-002-s053><weigh.abwägen><de> Der Logik Filter möchte gesunden Menschenverstand gegen das abwägen was vor euch auf den Tisch kommt.
<G-vec00149-002-s053><weigh.abwägen><en> The logic filter wants to weigh common sense to what you are presented in front of you.
<G-vec00149-002-s054><weigh.abwägen><de> Im Herzen des Restaurant ist das riesige Buffet mit über 100 heißen und kalten vegetarischen und veganen Speisen aus der Schweiz und vielen anderen Ländern (all das ausgesuchte Essen, kann man danach an der Kasse abwägen und bezahlen).
<G-vec00149-002-s054><weigh.abwägen><en> In the heart of House Hiltl is the large buffet located with over 100 hot and cold vegetarian and vegan specialties from Switzerland and around the World. When you choose the buffet you have to weigh your food.
<G-vec00149-002-s055><weigh.abwägen><de> Wir können uns unsere Lasten genauer ansehen, sie abwägen und für Erleichterung sorgen.
<G-vec00149-002-s055><weigh.abwägen><en> We can look at our burdens precisely, they weigh and provide relief.
<G-vec00149-002-s056><weigh.abwägen><de> Die Spielerbewegungen sind nicht die schnellsten, das verlangsamt die Kämpfe ein wenig und scheint eine bewusste Designentscheidung gewesen zu sein, damit wir Situationen abwägen und nicht ausschließlich impulshaft reagieren.
<G-vec00149-002-s056><weigh.abwägen><en> Player movement isn't the fastest, which slows combat down a little, but that seems to be a conscious design choice, encouraging players to weigh up a situation before acting on impulse.
<G-vec00149-002-s057><weigh.abwägen><de> Dort können Sie die MT-50 Komponenten in Ruhe begutachten und dann abwägen.
<G-vec00149-002-s057><weigh.abwägen><en> There you can view the MT-50 components at rest and then weigh.
<G-vec00149-002-s058><weigh.abwägen><de> Sie müssen die Bedeutung dieser Leistungen für Ihr Projekt abwägen.
<G-vec00149-002-s058><weigh.abwägen><en> You must weigh up the importance of these services for your project.
<G-vec00149-002-s059><weigh.abwägen><de> Wenn Sie jedoch mehr als 500 mg Testosteron pro Woche anwenden, müssen Sie die Risikofaktoren in Absprache mit Ihrem privaten Arzt abwägen.
<G-vec00149-002-s059><weigh.abwägen><en> However, if you are going to use over 500 mg of testosterone per week, you must weigh the risk factors in consultation with your private clinician.
<G-vec00149-002-s060><weigh.abwägen><de> Ich würde Ihnen raten, sorgfältig das Für und Wider abwägen, bevor sie entscheidet.
<G-vec00149-002-s060><weigh.abwägen><en> I would advice you to carefully weigh the pros and cons before deciding.
<G-vec00149-002-s061><weigh.abwägen><de> Händler sollten ihr Verdienstpotenzial mit den involvierten Risiken abwägen und sich entsprechend verhalten.
<G-vec00149-002-s061><weigh.abwägen><en> Traders should weigh their earning potential against the risks involved and act accordingly.
<G-vec00149-002-s062><weigh.abwägen><de> Um festzustellen, ob eine Management-Karriere das Richtige für Sie ist, müssen Sie die Vor- und Nachteile, also die Argumente dafür und dagegen, abwägen.
<G-vec00149-002-s062><weigh.abwägen><en> To decide whether a career in management is right for you, you have to weigh the pros and cons, i.e. the arguments for or against.
<G-vec00149-002-s068><weigh.abwägen><de> Das Bundesverfassungsgericht stellt sich gegen das vorausgegangene Urteil des Europäischen Gerichtshofs und hält es für nicht nachvollziehbar, weil der Gerichtshof die wirtschaftlichen Auswirkungen des Programms in seiner Bewertung ausgeklammert und versäumt habe, die Verhältnismäßigkeit des Anleihekaufprogramms abzuwägen.
<G-vec00149-002-s068><weigh.abwägen><en> The Federal Constitutional Court challenges previous ruling of the European Court of Justice and considers it incomprehensible because the Court had excluded the economic effects of the programme in its assessment and failed to weigh up the proportionality of the bond purchase programme.
<G-vec00149-002-s069><weigh.abwägen><de> Beunruhigende Aussichten, die die Fed dazu veranlassen sollten, jeden weiteren Schritt genau abzuwägen.
<G-vec00149-002-s069><weigh.abwägen><en> A worrying panorama that should prompt the Fed to weigh any steps it plans to take extremely carefully.
<G-vec00149-002-s070><weigh.abwägen><de> Monitor Deloittes Digital Strategy Practice ermöglicht es Unternehmen, Kunden-, Geschäftsmodell-, Betriebsmodell- und Ökosystementscheidungen abzuwägen, durchzuführen und auszuführen.
<G-vec00149-002-s070><weigh.abwägen><en> Monitor Deloitte’s Digital Strategy practice enables organizations to weigh, make and execute customer, business model, operating model and ecosystem choices .
<G-vec00149-002-s071><weigh.abwägen><de> Spieler müssen anschließend die Anzahl der Gegner einkalkulieren (die jeweils zwei Karten erhalten), um die Stärke der eigenen Hand einzuschätzen und um von dort eine Wett-Strategie abzuwägen.
<G-vec00149-002-s071><weigh.abwägen><en> Players must then factor in the number of opponents being dealt in (as they each receive two cards) to weigh the strength of their own hand and gauge a betting strategy from there.
<G-vec00149-002-s072><weigh.abwägen><de> Es ist eine Aufgabe der Festivals, sich diesem Diskurs im Rahmen der gegebenen Möglichkeiten (die oft auch durch finanzielle Zwänge eingeschränkt werden) anzunehmen und situativ abzuwägen, ob dem Inhalt oder der Form Priorität zugesprochen wird.
<G-vec00149-002-s072><weigh.abwägen><en> It is the task and mission of the festival to take up this discourse within the scope of the possibilities available to it (which are also often limited by financial constraints) and situatively weigh up whether the content or the form is to be accorded priority.
<G-vec00149-002-s073><weigh.abwägen><de> Vergessen Sie auch nicht die Nutzungsmuster von Einzelpersonen und Teams abzuwägen, sobald Sie untersucht haben welche digitalen Tools und Dienstleistungen Ihr Unternehmen benutzt.
<G-vec00149-002-s073><weigh.abwägen><en> Once you have assessed what digital tools and services your business is using, don’t forget to weigh in the usage patterns of individuals and teams as well.
<G-vec00149-002-s074><weigh.abwägen><de> Obgleich es keine allgemeingültige Definition von Gerechtigkeit geben kann, ist es sinnvoll, sich mit den verschiedenen Gerechtigkeitstheorien der Philosophiegeschichte auseinanderzusetzen, sie zu vergleichen und ihre Stärken und Schwächen gegeneinander abzuwägen.
<G-vec00149-002-s074><weigh.abwägen><en> Although it’s not possible to come up with a universal definition of justice, it makes sense to deal with different theories of justice over the history of philosophy, compare them, and weigh their strengths and weaknesses against one another.
<G-vec00149-002-s075><weigh.abwägen><de> Ohne daher die Berücksichtigung noch jetzt vor- handener Zwischenglieder zwischen zwei Formen verwerfen zu wollen, werden wir veranlasst, den wirklichen Betrag der Ver- schiedenheit zwischen denselben sorgfältiger abzuwägen und höher zu schätzen.
<G-vec00149-002-s075><weigh.abwägen><en> Hence, without quite rejecting the consideration of the present existence of intermediate gradations between any two forms, we shall be led to weigh more carefully and to value higher the actual amount of difference between them.
<G-vec00149-002-s076><weigh.abwägen><de> Ein guter Maßstab bei der Entwicklung von Prozessen ist, die Arbeitsbelastung und zeitlichen Anforderungen gegen die Bedeutung und Qualität der resultierenden Entscheidungen abzuwägen und sicherzustellen, dass sie im Gleichgewicht sind.
<G-vec00149-002-s076><weigh.abwägen><en> A good benchmark when developing processes is to weigh workload and time requirements against the significance and quality of the resulting decisions and ensure they are in balance.
<G-vec00149-002-s077><weigh.abwägen><de> Hier gilt es einfach abzuwägen.
<G-vec00149-002-s077><weigh.abwägen><en> Here it is easy to weigh.
<G-vec00149-002-s078><weigh.abwägen><de> Denn wir sind überzeugt: Menschen brauchen Unterstützung und Freiräume, um Innovationen zu erkennen, Chancen und Risiken abzuwägen, gute Entscheidungen zu treffen und bessere Ergebnisse zu erzielen.
<G-vec00149-002-s078><weigh.abwägen><en> Because, we are convinced that people need support and the freedom to recognise innovations, weigh up opportunities and risks, make good decisions and achieve better results.
<G-vec00149-002-s079><weigh.abwägen><de> Lerne Menschen zuzuhören, das für und wider jeder Situation abzuwägen und in der Lage zu sein, die Situation aus der Sicht von Anderen zu betrachten.
<G-vec00149-002-s079><weigh.abwägen><en> Learn to listen to people, to weigh the pros and cons of any situation, and to be able to see the situation from another person's perspective.
<G-vec00149-002-s080><weigh.abwägen><de> Im Vergleich gilt es abzuwägen, alle relevanten Features direkt an Bord zu haben oder bei Bedarf diese über Dritte zuzukaufen.
<G-vec00149-002-s080><weigh.abwägen><en> In comparison, it is important to weigh all relevant features directly on board or, if necessary, to buy them through third parties.
<G-vec00149-002-s081><weigh.abwägen><de> Sie sind so in ihrem persönlichen Glauben oder Einstellungen verfangen, dass sie sich weigern ernsthaft den Nachweis abzuwägen.
<G-vec00149-002-s081><weigh.abwägen><en> They are so invested in their personal beliefs that they refuse to honestly weigh the evidence.
<G-vec00149-002-s082><weigh.abwägen><de> Im Falle einer individuellen Unverträglichkeit gegenüber den Bestandteilen des Arzneimittels ist es notwendig, das Risiko für den Körper und den potenziellen Nutzen abzuwägen.
<G-vec00149-002-s082><weigh.abwägen><en> In case of individual intolerance to the components of the drug, it is necessary to weigh the risk to the body and the potential benefit.
<G-vec00149-002-s083><weigh.abwägen><de> Aber gleichzeitig muss jeder Delegierte, der von einer lokalen Organisation gewählt wird, das Recht haben, alle Argumente zu einer Frage auf dem Parteitag abzuwägen und zu stimmen, wie es seine politische Ansicht von ihm verlangt.
<G-vec00149-002-s083><weigh.abwägen><en> But at the same time every delegate chosen by a local must have the right to weigh all the arguments relating to the question in the convention and to vote as his political judgment demands of him.
<G-vec00149-002-s084><weigh.abwägen><de> So weisen die ethischen Leitlinien des KIT auf die Problematik des „dual use“, also der vielfältigen und zum Teil nicht vorhersehbaren Nutzung von Forschungsergebnissen, hin und fordern Mitglieder und Angehörige des KIT auf, mit der notwendigen Sensibilität die potenziellen Anwendungsmöglichkeiten von Forschungsergebnissen abzuwägen und gegebenenfalls eine Technikfolgenabwägung vorzunehmen.
<G-vec00149-002-s084><weigh.abwägen><en> Among others, the ethical principles of KIT refer to the problem of “dual use” i.e. diverse and partly unforeseeable use of research results. Employees and members of KIT are requested to always weigh potential applications of research results with the required sensitivity and to make a technology assessment, if applicable.
<G-vec00149-002-s085><weigh.abwägen><de> In einer Zeit, die so schnelllebig ist wie die unsere, sind solche Anpassungsfähigkeiten elementar wichtig – gleichwohl werden wir von den Älteren nicht selten als «entscheidungsunfähig» taxiert, weil wir uns die Zeit nehmen müssen, auch Optionen abzuwägen, die es früher nicht gab.
<G-vec00149-002-s085><weigh.abwägen><en> In a rapidly evolving era such as ours, such adaptive capacities are indispensable. Yet, we are often described as “undecided” by older people as we must take time to weigh the pros and cons of different options that did not exist before.
<G-vec00149-002-s086><weigh.abwägen><de> Sie fordern jeden Bürger dazu auf, seine Rechte und seine Bequemlichkeit gegen seine Verpflichtung gegenüber dem Allgemeinwohl abzuwägen.
<G-vec00149-002-s086><weigh.abwägen><en> They call out to every citizen to weigh his rights and comforts against his obligations to the common good.
<G-vec00149-002-s166><weigh.abwägen><de> Andererseits müssen sie sich mit Gegenpositionen auseinander setzen, in der Rolle als Richter die Beweise gegeneinander abwägen sowie die Urteile entsprechend des rechtlich vorgegebenen Rahmens formulieren.
<G-vec00149-002-s166><weigh.abwägen><en> On the other hand, they have to deal with opposing positions, weigh evidence and formulate judgements within the given legal framework.
<G-vec00149-002-s167><weigh.abwägen><de> Die Märkte müssen einfach nur diese Erwägungen für sich gegeneinander abwägen, um der Kursbewegung des US-Dollar Form zu verleihen.
<G-vec00149-002-s167><weigh.abwägen><en> The markets need only to weigh these considerations for them to begin shaping US Dollar price action.
<G-vec00149-002-s168><weigh.abwägen><de> Der (spätere) Gesetzgeber wird allerdings verpflichtet, vor einer bewussten Abweichung von einem völkerrechtlichen Vertrag sorgfältig die einzelnen oben aufgeführten Aspekte gegeneinander abzuwägen.
<G-vec00149-002-s168><weigh.abwägen><en> However, it obliges the (later) legislature to diligently weigh the various aspects mentioned above before deliberately deviating from an international treaty.
<G-vec00149-002-s169><weigh.abwägen><de> Zudem lassen sich online Preise in Sekundenschnelle vergleichen und Beschreibungen und Rezensionen erleichtern es, die Vorteile bestimmter Produkte gegeneinander abzuwägen.
<G-vec00149-002-s169><weigh.abwägen><en> Furthermore, online prices can be compared in seconds, while product descriptions and reviews make it easier to weigh the advantages of certain products.
<G-vec00149-002-s170><weigh.abwägen><de> Letztendlich liegt es aber in der Eigenverantwortung jedes SLM-Aktionärs, die Vor- und Nachteile einer Annahme des von GE veröffentlichten Angebots gegeneinander abzuwägen.
<G-vec00149-002-s170><weigh.abwägen><en> Ultimately, however, it is the responsibility of each SLM shareholder to weigh up the advantages and disadvantages of accepting GE's published offer.
<G-vec00149-002-s171><weigh.abwägen><de> Da also jeder Besuch zwangsläufig sowohl positive als auch negative Konsequenzen hat, ist es von zentraler Bedeutung, beide gegeneinander abzuwägen und so eine informierte Entscheidung zu treffen, welche Folgen bei der jeweiligen Reise überwiegen.
<G-vec00149-002-s171><weigh.abwägen><en> So, given that every visit inevitably has both negative and positive consequences, the key is to weigh those up and so make an informed choice about which outweighs which for their particular trip.
<G-vec00149-002-s172><weigh.abwägen><de> Auch sollte sichergestellt sein, dass die zuständigen Gerichte über das Ermessen verfügen, die Interessen der an einem Rechtsstreit beteiligten Parteien und die Interessen Dritter, gegebenenfalls auch der Verbraucher, gegeneinander abzuwägen.
<G-vec00149-002-s172><weigh.abwägen><en> It should also be ensured that the competent judicial authorities have the discretion to weigh up the interests of the parties to the legal proceedings, as well as the interests of third parties including, where appropriate, consumers.
<G-vec00149-002-s173><weigh.abwägen><de> Wenn Seiten kein grünes Häkchen erhalten, liegt es bei Ihnen und dem Entwickler, die Kosten und Nutzen der Behebung des Problems gegeneinander abzuwägen.
<G-vec00149-002-s173><weigh.abwägen><en> (If pages don't receive a green checkmark, it's up to you and your developer to weigh the costs and benefits of correcting the issue.)
<G-vec00149-002-s339><weigh.abwägen><de> Kurse können teuer werden, wäge also die Vorteile ab.
<G-vec00149-002-s339><weigh.abwägen><en> Classes can get expensive, so weigh the benefits.
<G-vec00149-002-s340><weigh.abwägen><de> Ich wäge die Feinheiten der Welt in meinem Kopf ab.
<G-vec00149-002-s340><weigh.abwägen><en> I weigh the nuances of the word in my head.
<G-vec00149-002-s341><weigh.abwägen><de> Wenn die Gelegenheit für einen beruflichen Aufstieg in einer anderen Firma aufkommt, dann wäge die Vor- und Nachteile ab und beurteile, wie viel Risiko der Wechsel für dich in persönlicher als auch beruflicher Hinsicht mit sich bringen könnte.
<G-vec00149-002-s341><weigh.abwägen><en> When an opportunity for a promotion at another company comes up, weigh the advantages and disadvantages of taking the job and assess how much risk the switch could have on you personally and professionally.
<G-vec00149-002-s342><weigh.abwägen><de> Ich reibe mir übers Gesicht und wäge meine Optionen ab, die im Moment ja wohl eher mickrig sind.
<G-vec00149-002-s342><weigh.abwägen><en> Rubbing my hands over my face, I weigh my options, which are quite limited.
<G-vec00149-002-s343><weigh.abwägen><de> Wäge ab, wie die Entfernung zur Arbeit dein Leben - finanziell und anderweitig - beeinträchtigt, wenn du dich für deinen idealen Standort entscheidest.
<G-vec00149-002-s343><weigh.abwägen><en> Weigh how distance to work will affect your life, financially and otherwise, when deciding on your ideal location.
<G-vec00149-002-s344><weigh.abwägen><de> Nimm dir die Zeit, das Verhalten der Menschen um dich herum zu beobachten, wäge ab, ob das, was du sieht, das Potenzial für ein aussagekräftiges Bild hat.
<G-vec00149-002-s344><weigh.abwägen><en> Take time to observe the behaviour of people around you; weigh up whether there’s potential for a telling shot.
<G-vec00149-002-s351><weigh.abwägen><de> Wägen Sie die Vor- und Nachteile ab und entscheiden Sie selbst, ob Sie Zeit für solche Arbeiten aufwenden möchten.
<G-vec00149-002-s351><weigh.abwägen><en> Weigh the pros and cons, and decide yourself whether to spend time on such work.
<G-vec00149-002-s352><weigh.abwägen><de> • Zu Beginn einer typischen Produktionswoche rüsten Ysa und Fabian jeweils viel frischen Ingwer, mahlen ausgewählte Gewürze und pressen Limetten oder wägen Hibiskus-Blüten aus großen Säcken ab.
<G-vec00149-002-s352><weigh.abwägen><en> - At the beginning of a typical production week, Ysa and Fabian each prepare a lot of fresh ginger, grind selected spices and press limes or weigh hibiscus flowers from large bags.
<G-vec00149-002-s353><weigh.abwägen><de> Wir wägen das Portfolio nach fundamentaler Bewertung, Preismuster und Handelsstrategie ab.
<G-vec00149-002-s353><weigh.abwägen><en> We weigh the portfolio according to the fundamental valuation, price pattern and trading strategy.
<G-vec00149-002-s354><weigh.abwägen><de> Da es eine Notlage gibt, wägen andere in der Gruppe ihre laufenden Aktivitäten im Lichte der neuen Lage ab und diskutieren Alternativen.
<G-vec00149-002-s354><weigh.abwägen><en> As there is distress, others in the group weigh their current activities in light of the new need, and discuss alternatives.
<G-vec00149-002-s355><weigh.abwägen><de> Wir wägen jede Offenlegungspflicht sorgfältig ab und ziehen die Möglichkeit solcher Offenlegungsanfragen in Betracht, wenn wir darüber entscheiden, wo und wie wir Ihre persönlichen Daten speichern.
<G-vec00149-002-s355><weigh.abwägen><en> We weigh each disclosure requirement carefully and take the possibility of such disclosure requests into account when deciding where and how we store your personal data.
<G-vec00149-002-s356><weigh.abwägen><de> Sie wägen stets Kosten und Nutzen gegeneinander ab.
<G-vec00149-002-s356><weigh.abwägen><en> They always weigh costs and benefits against each other.
<G-vec00149-002-s357><weigh.abwägen><de> Wägen Sie also ab, was für Sie wichtig ist.
<G-vec00149-002-s357><weigh.abwägen><en> Therefore, it's best to weigh up what's important to you.
<G-vec00149-002-s358><weigh.abwägen><de> Wir hinterfragen, analysieren und wägen genau ab – und treffen erst dann eine Entscheidung.
<G-vec00149-002-s358><weigh.abwägen><en> We scrutinise, analyse and weigh everything up down to the last detail before making a decision.
<G-vec00149-002-s359><weigh.abwägen><de> Wägen Sie die Optionen ab, um das beste Skigebiet für sich zu finden.
<G-vec00149-002-s359><weigh.abwägen><en> You'll need to weigh up the options to find the best mountain resort to suit you.
