<G-vec00301-001-s247><address.ansprechen><de> Es mag offensichtlich erscheinen, daß jegliche Bemühung von KünstlerInnen und KuratorInnen, ihre Probleme praktischer Art zu lösen, voraussetzt, daß sie sich in Bezug auf die gemeinsamen Probleme praktischer Art, um deren Lösung sie sich bemühen, gegenseitig als ProduzentInnen ansprechen.
<G-vec00301-001-s247><address.ansprechen><en> It may seem obvious that any effort by artists and curators to resolve their practical problems would require that they address each other as producers according to the common practical problems they endeavor to resolve.
<G-vec00301-001-s248><address.ansprechen><de> In ihrer Antwort auf die Übergabe der Unterschriften bezeichnete die Vizepräsidentin des EU-Parlaments, die Belgierin Isabelle Durant, die Demonstranten als eine Avantgarde, die wichtige Themen ansprechen würden.
<G-vec00301-001-s248><address.ansprechen><en> In reply to the handover of the signatures, Vice President of the EU Parliament and Belgian MEP Isabelle Durant referred to the demonstrators as a vanguard that would continue to address important issues.
<G-vec00301-001-s249><address.ansprechen><de> In vier Sektionen vereint Time Present Werke, die sowohl die Entwicklung der Sammlung dokumentieren, als auch grundlegende Fragen des Mediums Fotografie ansprechen.
<G-vec00301-001-s249><address.ansprechen><en> "In four sections, ""Time Present"" unites works that document the development of the collection and at the same time address fundamental issues of the medium."
<G-vec00301-001-s250><address.ansprechen><de> """Mit dem neuen Fahrzeug wollen wir auch gezielt junge Familien ansprechen."
<G-vec00301-001-s250><address.ansprechen><en> """We also want to specifically address young families with the new model."
<G-vec00301-001-s251><address.ansprechen><de> Die gegenwärtigen Schalltechnologien können den Kunden bis zu 200 m von dem eigentlichen Inhalt der Mitteilung entfernt ansprechen.
<G-vec00301-001-s251><address.ansprechen><en> The current sound technologies are able to address the customers within the distance of as far as 200 m from the announcement itself.
<G-vec00301-001-s252><address.ansprechen><de> Wenn eine Frau dann dem Verkäufer nicht antwortet, kann er immer noch mögliche Begleiterinnen oder Begleiter ansprechen oder es auf anderen Sprachen oder mit Händen und Füßen probieren.
<G-vec00301-001-s252><address.ansprechen><en> If a woman does not respond to the seller, he can still address her companion or companions or try in other languages or with hands and feet.
<G-vec00301-001-s253><address.ansprechen><de> Anfang 2013 will der Medienkonzern einen neuen frei emfangbaren Sender mit einem Programmschwerpunkt auf Fiction-Formaten an den Start schicken: Sat.1 Gold soll vor allem die älteren Zielgruppen ansprechen.
<G-vec00301-001-s253><address.ansprechen><en> In early 2013, the media corporation plans to launch another free-to-air channel that will focus on fiction formats: Sat.1 Gold aims to address primarily the older target groups.
<G-vec00301-001-s254><address.ansprechen><de> Um alles aufzulösen, musste ich alle Punkte, die jeweils relevant waren, immer und immer wieder ansprechen.
<G-vec00301-001-s254><address.ansprechen><en> In order to dissolve all that I had to address all relevant points over and over again.
<G-vec00301-001-s255><address.ansprechen><de> Von ganzem Herzen hoffe nicht auf die Empfindlichkeiten von jemandem zu nahe treten, um dieses Problem zu diesem Zeitpunkt ansprechen.
<G-vec00301-001-s255><address.ansprechen><en> With all my heart hope not to offend the sensibilities of anyone to address this issue at this time.
<G-vec00301-001-s256><address.ansprechen><de> Ich könnte eine neue politische Partei finden, die Rennenpunkte ansprechen und den Wählern meinen Fall nehmen würde.
<G-vec00301-001-s256><address.ansprechen><en> I could found a new political party that would address race issues and take my case to the voters.
<G-vec00301-001-s257><address.ansprechen><de> Sie können bis zu 99 serielle Schnittstellen ansprechen (eine zur gleichen Zeit pro Prozess).
<G-vec00301-001-s257><address.ansprechen><en> You can address up to 99 serial ports (one at a time).
<G-vec00301-001-s258><address.ansprechen><de> """Mit dieser neuen Tour möchten wir gezielt die weltweiten Nachfahren der Auswanderer aus dem angelsächsischen Bereich England, Schottland und Irland ansprechen"", erklärt Hermann Reuther, Geschäftsführer von REUTHER-ENTERTAINMENTS."
<G-vec00301-001-s258><address.ansprechen><en> """With this new tour, we want to specifically address the global descendants of emigrants from the Anglo-Saxon region of England, Scotland and Ireland,"" says Hermann Reuther, President of REUTHER ENTERTAINMENTS."
<G-vec00301-001-s259><address.ansprechen><de> Infolge der Tatsache, dass Trenbolon für den einzelnen Einsatzzweck hergestellt, es gibt wenige Studien, die seine angeh Ergebnisse bei Patienten ansprechen.
<G-vec00301-001-s259><address.ansprechen><en> As a result of that trenbolone is produced for the sole purpose of use, there are a couple of studies that address its possible results in people.
<G-vec00301-001-s260><address.ansprechen><de> Eine neue Webpräsenz soll deshalb die Zielgruppen von LAAX emotional ansprechen und gleichzeitig mehr Umsatz generieren.
<G-vec00301-001-s260><address.ansprechen><en> A new website was required to address the LAAX target customers on an emotional level and increase turnover at the same time.
<G-vec00301-001-s261><address.ansprechen><de> Die angebotenen Audiobeiträge sollen alle ansprechen, die sich dieser Region in irgendeiner Art und Weise verbunden fühlen.
<G-vec00301-001-s261><address.ansprechen><en> The offered audio contributions are to address all, which feel connected this region in any way.
<G-vec00301-001-s262><address.ansprechen><de> Die Angabe weiterer, gesondert markierter Daten (Vorname, Nachname) ist freiwillig und wird verwendet, um Sie persönlich ansprechen zu können.
<G-vec00301-001-s262><address.ansprechen><en> The indication of further, separately marked data (first name, surname) is voluntary and is used to be able to address you personally.
<G-vec00301-001-s263><address.ansprechen><de> Das Verlieren eines Haustieres kann uns mit einem Durcheinander anderer Gefühle zusätzlich zur Traurigkeit lassen: verärgern Sie, Angst um andere Probleme, die, wir nicht ansprechen könnten, weil wir so beschäftigtes Interessieren für unser krankes Haustier waren, und sogar Schuld,...
<G-vec00301-001-s263><address.ansprechen><en> Losing a pet can leave us with a muddle of other feelings in addition to the sadness: anger, anxiety about other problems we couldn't address because we were so busy caring for our sick pet, and even guilt, especially if your pet died suddenly or of an unknown cause.
<G-vec00301-001-s264><address.ansprechen><de> Es gibt noch ein weit verbreitetes Missverständnis, das ich hier ansprechen möchte.
<G-vec00301-001-s264><address.ansprechen><en> There is another common misconception I would like to address here.
<G-vec00301-001-s265><address.ansprechen><de> Mit dem heutigen Newsletter möchte der Illarion-Staff euch auf dem Laufenden halten, was sich tut und zwei wichtige Dinge ansprechen.
<G-vec00301-001-s265><address.ansprechen><en> With today’s news, the Illarion staff wants to keep you up to date what is going on in Illarion and address two serious issues.
<G-vec00231-001-s057><attract.ansprechen><de> Speziell diese Vorstellung sollte das breite Karlsruher Publikum ansprechen, weshalb die deutsche Synchronfassung gespielt wurde, welche die Handlung sprachlich von London nach Berlin verlegt.
<G-vec00231-001-s057><attract.ansprechen><en> Especially this event intended to attract the broad audience of Karlsruhe. Therefore the German dubbed version was presented, which linguistically moves the plot from London to Berlin.
<G-vec00231-001-s058><attract.ansprechen><de> Darüber hinaus sagte eine hochrangige Quelle, dass der Bericht über die Arbeit einer Organisation, die junge Menschen und Bürger mit einer aktiven Position für den Machtwechsel im Land ansprechen sollte, den bulgarischen Sonderdiensten zur Verfügung stand.
<G-vec00231-001-s058><attract.ansprechen><en> In addition, a high-ranking source said that the report on the work of an organization that should attract young people and citizens with an active position for the change of power in the country turned out to be at the disposal of the Bulgarian special services.
<G-vec00231-001-s059><attract.ansprechen><de> Die richtige Zielgruppe ansprechen.
<G-vec00231-001-s059><attract.ansprechen><en> Attract the right audience.
<G-vec00231-001-s060><attract.ansprechen><de> Eine Content Marketing-Kampagne, die mit informierenden, beratenden und unterhaltenden Inhalten die Zielgruppe ansprechen soll, um sie vom eigenen Unternehmen, seinem Leistungsangebot oder einer eigenen Marke zu überzeugen, erfordert ein anderes Set an Erfolgsparametern als Display-Werbung oder der Social-Media-Auftritt einer Marke.
<G-vec00231-001-s060><attract.ansprechen><en> A content marketing campaign intended to attract the target group with informative, advisory and entertaining content to convince them of your own company, its service portfolio or your own brand, requires a different set of success parameters from display advertising or the social media presentation of a brand.
<G-vec00231-001-s061><attract.ansprechen><de> [BRT] Ein sympathischer Auftritt einer klasse Sängerin, deren Repertoire auch Freunde von Tori Amos und Nick Cave ansprechen dürfte.
<G-vec00231-001-s061><attract.ansprechen><en> [BRT] A much likable show of a great singer its repertoire should also attract fans of Tori Amos and Nick Cave.
<G-vec00231-001-s062><attract.ansprechen><de> Wählen Sie beim Hochladen von Videos benutzerdefinierte Thumbnails aus, die Ihre Videos gut repräsentieren und YouTube-Nutzer ansprechen.
<G-vec00231-001-s062><attract.ansprechen><en> When uploading videos, select customised thumbnails to represent your videos and attract viewers when they browse YouTube.
<G-vec00231-001-s063><attract.ansprechen><de> .mov-Dateien haben bewährte Qualitäten und Vorteile, die Unternehmen mit Bedürfnissen ansprechen sollten, die Videowerbung im Internet beinhalten.
<G-vec00231-001-s063><attract.ansprechen><en> .mov files have proven qualities and benefits that should attract companies with needs that include video advertisements on the internet.
<G-vec00231-001-s064><attract.ansprechen><de> Lass uns annehmen, dass Du ein Klempner in Kalifornien bist und potenzielle Kunden im Umkreis Deiner Stadt ansprechen willst.
<G-vec00231-001-s064><attract.ansprechen><en> Let's assume that you're a plumber in California and that you want to attract prospects in your city.
<G-vec00231-001-s065><attract.ansprechen><de> Da der Buchmacher den globalen Markt ansprechen möchte, sind die App und die mobile Website in fast 40 verschiedenen Sprachen verfügbar.
<G-vec00231-001-s065><attract.ansprechen><en> Since the bookmaker wants to attract the global market, the app and mobile site are available in almost 40 different languages.
<G-vec00231-001-s066><attract.ansprechen><de> TCA betreibt 4 Kletterhallen in zwei Städten und war vor 10 Jahren Initiator für die Umstellung von staubigen, alten Kletterwänden hin zu hochwertigen, einladenden Umgebungen, die ein deutlich breiteres Publikum ansprechen können.
<G-vec00231-001-s066><attract.ansprechen><en> TCA has 4 walls in two cities and 10 years ago was at the forefront of the change from providing dusty old walls for climbers to creating high quality, welcoming environments that are able to attract a much wider audience.
<G-vec00231-001-s067><attract.ansprechen><de> Impact scope Regional: Je nach Standort des Lehrpfads kann er auch Touristen und Besucher aus weiter entfernten Gebieten ansprechen.
<G-vec00231-001-s067><attract.ansprechen><en> Impact scope Regional: Depending on the location of the educational pathway, it may also attract tourists and visitors from other areas.
<G-vec00231-001-s068><attract.ansprechen><de> Du solltest eine Persona für jeden Kundentypen haben, den Du ansprechen willst.
<G-vec00231-001-s068><attract.ansprechen><en> You should have a persona for each type of customer you want to attract.
<G-vec00231-001-s069><attract.ansprechen><de> Es ist eine Darstellung eines spezifischen idealen Lesers, den Du ansprechen möchtest, damit er Deinen Blog oder Deine Webseite aufruft.
<G-vec00231-001-s069><attract.ansprechen><en> It’s a representation of a specific ideal reader that you’d like to attract to your blog or site.
<G-vec00231-001-s070><attract.ansprechen><de> Beschreiben Sie, wie Sie die Verpackung in eine Marketing-Strategie einbetten würden und wie Ihre Lösung die Konsumenten ansprechen könnte.
<G-vec00231-001-s070><attract.ansprechen><en> Describe how you would integrate the packaging into a marketing strategy and how your solution could attract consumers.
<G-vec00231-001-s071><attract.ansprechen><de> Regional: Je nach Standort des Lehrpfads kann er auch Touristen und Besucher aus weiter entfernten Gebieten ansprechen.
<G-vec00231-001-s071><attract.ansprechen><en> Regional: Depending on the location of the educational pathway, it may also attract tourists and visitors from other areas.
<G-vec00231-001-s073><attract.ansprechen><de> William Booth wollte bewusst ein Musikstil, welcher nicht der Kirchenmusik ähnlich war, sondern die Menschen auf den Strassen ansprechen würde.
<G-vec00231-001-s073><attract.ansprechen><en> The music style which should be played should not be the usual church music, because William Booth wanted to attract the people on the streets.
<G-vec00231-001-s074><attract.ansprechen><de> Das Hotel befindet sich in einem der neuen Geschäftszentren Kuala Lumpurs und möchte vor allem junge Leute mit stilvollen Zimmern ansprechen, die erschwinglicher sind als die der Luxushotels Hilton oder Le Meridien.
<G-vec00231-001-s074><attract.ansprechen><en> The hotel, which is located in one of Kuala Lumpur's new business centres, wants to attract especially young people with stylish rooms at more affordable prices than those of other luxury hotels such as the Hilton or Le Meridien.
<G-vec00231-001-s075><attract.ansprechen><de> FICO, ein Datenanalyse-Softwareunternehmen, wollte kleine und mittelgroße Kunden ansprechen, indem es seine On-Premise-Lösung in die Cloud expandierte.
<G-vec00231-001-s075><attract.ansprechen><en> FICO, a data analytics software company, wanted to attract small- and medium-sized customers by expanding its solution from on-premise to the cloud.
<G-vec00057-001-s019><speak.ansprechen><de> Die Freude der Kinder, mit der sie tagtäglich in das Camp gehen, die Art und Weise, wie sie ihre Betreuer ansprechen sowie die Berichte der Eltern über die positive Entwicklung der Kinder sind Zeugnis der erfolgreichen Arbeit im Child Friendly Space.
<G-vec00057-001-s019><speak.ansprechen><en> The joy of the children, with which they go into the camp every day, the way they speak to their carers as well as the reports of parents about their children’s positive development are testimonies to the success of the work in the Child Friendly Space.
<G-vec00057-001-s020><speak.ansprechen><de> Und es war der Wille jedes einzelnen Menschen entscheidend, ob er in den Segen Meiner Ansprache gekommen ist, aber Ich konnte ihn erst einmal ansprechen, was sonst nicht möglich gewesen wäre, weil Ich keinen Menschen zwinge, Mich anzuhören, wenn Ich zu ihm spreche, und weil auch kein Mensch die Stimme des Vaters erkennen würde, wenn er nicht dazu den Willen hätte, sich direkt ansprechen zu lassen von Mir.
<G-vec00057-001-s020><speak.ansprechen><en> The will of every single human being was decisive whether he derived a blessing from My Word but at least I was able to speak to him in the first place, which otherwise would not have been possible because I do not force anyone to listen to Me when I speak to him, and because no human being would know the voice of the Father if he did not want to be spoken to by Me directly.
<G-vec00057-001-s021><speak.ansprechen><de> Das Verfahren ist streng vertraulich und zweistufig aufgebaut, um die Hemmschwelle möglichst gering zu halten und Probleme frühzeitig und offen ansprechen zu können.
<G-vec00057-001-s021><speak.ansprechen><en> The process is strictly confidential and consists of two levels, making it as easy as possible for supervisors and doctoral candidates to overcome their inhibitions and speak openly about problems early on.
<G-vec00057-001-s022><speak.ansprechen><de> Und ihr sollet glauben, was euch durch Meine Ansprache kundgetan wird.... Ich will also euch Menschen alle ansprechen durch Meine Diener auf Erden, die Mir diese Ansprache ermöglichen.
<G-vec00057-001-s022><speak.ansprechen><en> And you should believe the information revealed to you through My Word.... I want to address all people through My servants on Earth who enable Me to speak through them.
<G-vec00057-001-s023><speak.ansprechen><de> Da jedoch Konstellationen denkbar sind, in denen Mitarbeiter selbst nicht eindeutig beurteilen können, ob ein bestimmtes Verhalten regelkonform ist, sollen sie im Zweifelsfall ihren Vorgesetzen oder den Compliance-Officer von DEUTZ ansprechen, um eine Klärung des Sachverhalts im Vorfeld zu ermöglichen.
<G-vec00057-001-s023><speak.ansprechen><en> However, because constellations are conceivable, in which employees can itself not clearly assess whether a particular behaviour conforms to the rules, they should speak to their superiors or the compliance officer at DEUTZ in case of doubt, to allow clarification of the facts of the case in advance.
<G-vec00057-001-s024><speak.ansprechen><de> Viele von denen, die mich ansprechen, wenn ich im Land unterwegs bin, haben ihr Schicksal bereits in die eigenen Hände genommen und gehen mit ihren Belangen an die Öffentlichkeit.
<G-vec00057-001-s024><speak.ansprechen><en> Many of those that speak to me when I'm travelling around the country have already taken matters into their own hands and are addressing their concerns to the public.
<G-vec00057-001-s025><speak.ansprechen><de> Und eure eigenen Anliegen sollet ihr selbst Mir anvertrauen, und Ich werde auch euch selbst dann ansprechen durch das Herz, und ihr werdet dann auch wissen, was ihr tun oder lassen sollt....
<G-vec00057-001-s025><speak.ansprechen><en> And you should entrust your own wishes to Me, and then I will also speak to you through your heart and you will subsequently know what you should or should not do....
<G-vec00057-001-s026><speak.ansprechen><de> Sie zeigt die Fähigkeit der visuellen Kunst, tief bewegende moralische und politische Botschaften zu vermitteln, die Menschen aus allen Schichten wirkungsvoll ansprechen.
<G-vec00057-001-s026><speak.ansprechen><en> It also proclaims the power of visual art to convey profoundly emotive and effective moral and political messages that can speak effectively to people of all walks of life.
<G-vec00057-001-s027><speak.ansprechen><de> Aber ihr könnt an Meiner Statt anklopfen, und wenn Ich Selbst dann komme und sie öffnen Mir ihre Tür, dann werde Ich sie auch Selbst ansprechen, und sie werden selig sein.
<G-vec00057-001-s027><speak.ansprechen><en> But you can knock at their heart's door on My behalf, and if I then come Myself and they open their door to Me I will also speak to them Myself and they will be very happy.
<G-vec00057-001-s028><speak.ansprechen><de> Wir können sie ansprechen, mit ihnen diskutieren, Aktionen starten.
<G-vec00057-001-s028><speak.ansprechen><en> We can speak to them, discuss with them, start actions.
<G-vec00057-001-s029><speak.ansprechen><de> In einer Kombination aus Kundenrelevanz, ermittelt über Produkte, die sich aktuell deutlich besser verkaufen als prognostiziert und deren Händlerrelevanz, ermittelt über den zu erwartenden Gesamtrohgewinn, gibt die prudsys RDE Empfehlungen aus, die nicht nur den Kunden ansprechen, sondern auch dem Händler nützen.
<G-vec00057-001-s029><speak.ansprechen><en> Using a combination of customer relevance, determined by products which are selling considerably better than predicted, and their relevance to the dealer, determined by the expected gross profit, the prudsys RDE generates recommendations that not only speak to the customer but also benefit the dealer.
<G-vec00057-001-s030><speak.ansprechen><de> Liebe dOCUMENTA(13)-Besucherin, lieber dOCUMENTA(13)-Besucher, wir schreiben, um Ihnen zu sagen, dass Künstlerinnen und Künstler in der Lage sind ihre eigenen Fragen zu formulieren, ihre eigene Forschung betreiben und ein vielfältiges Publikum direkt ansprechen und einbeziehen können.
<G-vec00057-001-s030><speak.ansprechen><en> Dear Visitor to d(13), We intend to say to you that artists are able to formulate their own questions, conduct their own research, and directly speak to and engage a multiplicity of publics at once.
<G-vec00057-001-s031><speak.ansprechen><de> Im Licht Christi also, des Bildes des unsichtbaren Gottes, des Erstgeborenen vor aller Schöpfung, will das Konzil alle Menschen ansprechen, um das Geheimnis des Menschen zu erhellen und mitzuwirken dabei, daß für die dringlichsten Fragen unserer Zeit eine Lösung gefunden wird“.
<G-vec00057-001-s031><speak.ansprechen><en> "Hence in the light of Christ, the image of the unseen God, the firstborn of every creature, the Council wishes to speak to all men in order to illuminate the mystery of man and to cooperate in finding the solution to the outstanding problems of our time""."
<G-vec00057-001-s032><speak.ansprechen><de> Die LBBW beispielsweise kann mehr als 600 potenzielle Investoren im In- und Ausland ansprechen.
<G-vec00057-001-s032><speak.ansprechen><en> For example, LBBW may speak to more than 600 potential investors in Germany and abroad.
<G-vec00057-001-s033><speak.ansprechen><de> Als Nächstes „trainierst“ Du die KI, indem Du fünf oder mehr Logos auswählst, die Dich ansprechen.
<G-vec00057-001-s033><speak.ansprechen><en> Next, you’ll help train the AI by selecting five or more logos that speak to you.
<G-vec00057-001-s034><speak.ansprechen><de> Das also ist dann eine wahre Vereinigung mit Mir, in der Ich ihn nun ansprechen kann, in der ihm Mein Fleisch und Mein Blut geboten wird, Mein Wort mit seiner Kraft.
<G-vec00057-001-s034><speak.ansprechen><en> This is a true union with Me in which I can speak to him, in which he is offered My flesh and My blood, My Word with its strength.
<G-vec00057-001-s035><speak.ansprechen><de> Die Objekte transportieren als kommerzielle Fotografie dabei nicht nur ein bestimmtes Gefühl – idyllische Intimität – die uns entweder ansprechen mag, oder die uns als abgeschmackt abstößt.
<G-vec00057-001-s035><speak.ansprechen><en> As commercial photography, the objects here go beyond conveying a certain feel—idyllic intimacy—that may either speak to us or else repel us as tasteless.
<G-vec00057-001-s036><speak.ansprechen><de> Es begann die Suche nach ihr und nach einer Möglichkeit, sie ansprechen zu dürfen.
<G-vec00057-001-s036><speak.ansprechen><en> He began searching for Elisabeth and to find an opportunity to speak to her.
<G-vec00057-001-s037><speak.ansprechen><de> Du hast eine Frage, willst aber nicht gleich den Ausbilder ansprechen.
<G-vec00057-001-s037><speak.ansprechen><en> You have a question, but you don't want to speak to the trainer right away.
<G-vec00301-001-s285><address.ansprechen><de> Es beinhaltet die Freiheit vom Gesetz und den Besitz des Adoptionsgeistes, der es uns ermöglicht, Gott als unseren Vater anzusprechen.
<G-vec00301-001-s285><address.ansprechen><en> It involves freedom from the Law, and the possession of the spirit of adoption, which enables us to address God as our Father.
<G-vec00301-001-s286><address.ansprechen><de> "Weil sie so viel zu verbergen, mÃ1⁄4ssen sie nach draußen gehen ""gespÃ1⁄4lt"" werden offen anzusprechen sein, so dass eine gesunde Portion Respektlosigkeit und einem Hauch von Arroganz sind Zutaten, die wir verwenden können, wenn wir diese Parasiten bewältigen."
<G-vec00301-001-s286><address.ansprechen><en> "Because they hide so much, they have to go outside to be ""flushed"" to address openly to be, so a healthy dose of disrespect and a touch of arrogance are ingredients that we can use if we these parasites cope."
<G-vec00301-001-s287><address.ansprechen><de> Ich habe nicht wirklich die Zeit, das Ausmaß des pädagogischen Desasters anzusprechen, das diese Antworten ans Licht bringen, und fahre darum tapfer fort: Diese Texte werden von SchriftstellerInnen geschrieben.
<G-vec00301-001-s287><address.ansprechen><en> I don’t have the time to seriously address the scope of the pedagogical disaster that brought about these answers so I’ll valiantly continue: these texts were written by writers, they are excerpts from books.
<G-vec00301-001-s288><address.ansprechen><de> """Den Massenexodus öffentlich anzusprechen und die Missstände unverblümt zu kritisieren, war ein mutiger Schritt in diesem diktatorisch geführten ostafrikanischen Land"", sagte Delius."
<G-vec00301-001-s288><address.ansprechen><en> """It was a brave move to publicly address the mass exodus and to criticize the abuses in the dictatorial country of East Africa,"" said Delius."
<G-vec00301-001-s289><address.ansprechen><de> Zu verstehen, Technologien in einer innovativen und eleganten Weise zugänglich zu machen, um neue Trends aufzugreifen und neu entstehende Bedürfnisse anzusprechen.
<G-vec00301-001-s289><address.ansprechen><en> Understanding how to apply technology in an innovative and elegant way in order to enable the market trends and address its emerging needs.
<G-vec00301-001-s290><address.ansprechen><de> Ein konkreter Schritt dazu wäre, unverzüglich die völlige Abwesenheit von Frauen in den Führungsgremien der Europäischen Zentralbank anzusprechen.
<G-vec00301-001-s290><address.ansprechen><en> One concrete step to this end would be to immediately address the total absence of female representation in the European Central Bank's governing bodies.
<G-vec00301-001-s291><address.ansprechen><de> Sie haben ausschließlich den Zweck, den Werbepartnern zu ermöglichen, Sie mit Werbung anzusprechen, die Sie auch tatsächlich interessieren könnte.
<G-vec00301-001-s291><address.ansprechen><en> Their exclusive purpose is to enable the advertising partners to address you with specific advertisements which might actually be of interest for you.
<G-vec00301-001-s292><address.ansprechen><de> Um die passenden Kandidaten optimal anzusprechen, wird es für die Unternehmen immer wichtiger werden, deren Nutzungsgewohnheiten und bevorzugten Kanäle zu kennen und ihr Recruiting darauf abzustimmen.
<G-vec00301-001-s292><address.ansprechen><en> In order to optimally address suitable candidates, it will become increasingly important for companies to know their usage habits and preferred channels and to coordinate their recruiting accordingly.
<G-vec00301-001-s293><address.ansprechen><de> Wir möchten interessierte junge Mitglieder ausdrücklich auffordern sich zu bewerben und bitten zudem alle betreuenden Mitglieder geeignete Promovierende direkt anzusprechen.
<G-vec00301-001-s293><address.ansprechen><en> We would like to express an invitation to interested young members to apply and also ask all supervising members to address suitable doctoral candidates directly.
<G-vec00301-001-s294><address.ansprechen><de> Die Science Days sind täglich von 9.00 bis 17.00 Uhr geöffnet und bieten Schülerinnen und Schülern die Gelegenheit, Experten aus Forschung und Lehre direkt anzusprechen und Lernen, Spaß und Faszination miteinander zu verbinden.
<G-vec00301-001-s294><address.ansprechen><en> The Science Days will be open daily from 9.00 to 17.00 hrs and give pupils the opportunity to directly address experts from research and education and to link learning, fun, and fascination.
<G-vec00301-001-s295><address.ansprechen><de> Den Mut aufbringen, die klassischen Käufergruppen von Männern und Frauen differenziert anzusprechen und sich über das Ergebnis freuen.
<G-vec00301-001-s295><address.ansprechen><en> Finding the courage to address classic male and female buying groups in a differentiated form and appreciate the result.
<G-vec00301-001-s296><address.ansprechen><de> Viele von ihnen drehen sich um einen oft ignorierten Zustand, den kaum einer anzusprechen wagt – »The elephant in the room«, wie es im Englischen so schön heißt.
<G-vec00301-001-s296><address.ansprechen><en> "Many of them revolve around an often ignored state that hardly anyone dares to address—""The elephant in the room,"" as it is called in English."
<G-vec00301-001-s297><address.ansprechen><de> "Also für die auf der ""Aquire"" Stufe des Funnels möchtest Du die lokalen Medien und Social Media sowie den Inhalt in Deinem Blog verwenden, um einige der üblichsten Fragen bezüglich Computern und vielleicht sogar ein How-to oder zwei anzusprechen."
<G-vec00301-001-s297><address.ansprechen><en> So, for those in the Acquire stage of the conversion funnel, you'd want to use your local media outlets and social media platform, as well as content in your blog posts, to address some of their most common computer concerns and perhaps even a how-to or two.
<G-vec00301-001-s298><address.ansprechen><de> Obwohl die meisten Kollegen des mittleren Managements von den Schmähungen wussten, die dieser Mann austeilte, gab es nie Gelegenheit, das Thema anzusprechen.
<G-vec00301-001-s298><address.ansprechen><en> While most mid-level managers were aware of the abuse this man meted out, there was no opportunity to address this.
<G-vec00301-001-s299><address.ansprechen><de> „Mit Jet2.com haben wir einen direkten Zugang zu einem wichtigen Markt, der es uns ermöglichen wird, noch mehr Liebhaber der schönen Stadt Wien in Nordengland anzusprechen” so Markus Penz, Wien Tourismus.
<G-vec00301-001-s299><address.ansprechen><en> Markus Penz, Head of strategic Destination Development at Vienna Tourist Board added: “Thanks to Jet2.com, we finally have direct access to an important market - helping us address even more Vienna lovers in Northern England.”
<G-vec00301-001-s300><address.ansprechen><de> iSafe Employee Monitor ist ein leistungsfähiges Werkzeug, um fehlende Produktivität der Mitarbeiter anzusprechen, während der Schutz Ihres Unternehmens vor Sicherheitslücken und illoyal Mitarbeiter.
<G-vec00301-001-s300><address.ansprechen><en> iSafe Employee Monitoring Software is a powerful tool to address lack of employee productivity while protecting your company against security breaches and disloyal employees.
<G-vec00301-001-s301><address.ansprechen><de> Um die Kunden mit maßgeschneiderten Informationen und Angeboten anzusprechen, benötigen Unternehmen eine 360°-Sicht auf den Kunden.
<G-vec00301-001-s301><address.ansprechen><en> To address the customers with tailored information and offers, companies need a 360° view of the customer.
<G-vec00301-001-s302><address.ansprechen><de> Dadurch können Sie die Kenntnis über Ihr Angebot fordern, das Sie auf der Messe präsentieren wollen und gewinnen Sie die Möglichkeit, Ihre Kunden noch bevor Sie zur Messe kommen, anzusprechen.
<G-vec00301-001-s302><address.ansprechen><en> You can use it to increase the awareness of the offer you intend to present at the fair and to address potential customers before they actually arrive to the exhibition site.
<G-vec00301-001-s303><address.ansprechen><de> Vor Jahren hatte die Kirche auf dem besten Weg zu Gott anzusprechen entscheiden, wer Vater, Sohn und Heiliger Geist.
<G-vec00301-001-s303><address.ansprechen><en> Years ago the church had to decide on the best way to address God who is Father, Son and Holy Spirit.
<G-vec00231-002-s163><appeal.ansprechen><de> Landingpages können helfen, Deine Zielgruppe anzusprechen, sodass sie auf Deiner Webseite bleiben und den Wandel vom Leser zum Kunden vollziehen.
<G-vec00231-002-s163><appeal.ansprechen><en> Landing pages can help you appeal to your audience, so that they will want to stick around and make the switch from reader to customer.
<G-vec00231-002-s164><appeal.ansprechen><de> "LA GALERIE DU VIN" ist sowohl Verkaufs- als auch Degustations- und Seminarraum und vermag Stammkunden und Passanten gleichermassen anzusprechen.
<G-vec00231-002-s164><appeal.ansprechen><en> "LA GALERIE DU VIN" is both a sales as well as a wine tasting and seminar venue and aims to appeal to regular customers and passers-by alike.
<G-vec00231-002-s165><appeal.ansprechen><de> Eine Online-Präsenz ist entscheidend für das Engagement der Mitglieder, denn sie ist ein wertvolles Instrument, um neue Generationen anzusprechen und den zukünftigen Erfolg jeder Organisation zu bestimmen.
<G-vec00231-002-s165><appeal.ansprechen><en> An online presence is crucial for membership engagement, as it is a valuable tool to appeal to new generations and can determine the future success of every organisation.
<G-vec00231-002-s166><appeal.ansprechen><de> Um möglichst viele Bewerber anzusprechen und die Hürden für die Einreichung einer Bewerbung zu senken, binden wir das Portal XING ein, welches einen hohen Verbreitungsgrad als Berufs- und Geschäftsnetzwerk hat.
<G-vec00231-002-s166><appeal.ansprechen><en> XING is a widely used career and business network and we include it in order to appeal to as many applicants as possible and to remove obstacles to submitting an application.
<G-vec00231-002-s167><appeal.ansprechen><de> Sehen Sie sich die relevanten Stellenangebote der 11 Millionen offenen Jobs von LinkedIn an und passen Sie Ihren Lebenslauf an, um Personalchefs anzusprechen.
<G-vec00231-002-s167><appeal.ansprechen><en> See relevant job listings from LinkedIn’s 11 million open jobs and customize your resume to appeal to recruiters.
<G-vec00231-002-s168><appeal.ansprechen><de> Diese Behandlungssoftware steht kostenlos zur Verfügung, um die eifrigsten Verteidiger von Word anzusprechen.
<G-vec00231-002-s168><appeal.ansprechen><en> This treatment software available for free to appeal to the most fervent defenders of Word.
<G-vec00231-002-s169><appeal.ansprechen><de> Retargeting über Cookies Wir verwenden auf unseren Seiten ebenfalls Retargeting-Technologien, die es uns ermöglichen, gezielt die Personen mit Online-Werbung anzusprechen, die sich bereits für unsere Webseiten, unsere Produkte und Dienstleistungen interessiert haben.
<G-vec00231-002-s169><appeal.ansprechen><en> We also use retargeting technology on our web pages, which enables us to appeal to people who are already interested in our websites, our products and services with online advertising in a targeted way.
<G-vec00231-002-s170><appeal.ansprechen><de> Nach einer sehr kurzen, aber intensiven Zeit entstand dabei ein berührendes und oft sehr humorvolles Skript, das zudem den Balance-Akt schafft, eine sehr breite Altersgruppe anzusprechen.
<G-vec00231-002-s170><appeal.ansprechen><en> Within a very short but intense period of time they came up with a touching and often humorous script which manages to balance broad appeal for all ages. 1st AD
<G-vec00231-002-s171><appeal.ansprechen><de> Das ermöglicht es, Spieler anzusprechen, die es vorziehen, auf ihrem Handy zu spielen.
<G-vec00231-002-s171><appeal.ansprechen><en> That allows it to appeal to players who prefer to play on their phones.
<G-vec00231-002-s172><appeal.ansprechen><de> Diese Technik ermöglicht es, durch Werbung auf Websites unserer Kooperationspartner Internet-Benutzer anzusprechen, die bereits Interesse an unserem Webshop und unseren Produkten gezeigt haben.
<G-vec00231-002-s172><appeal.ansprechen><en> This technology makes it possible to appeal to online users who have already shown interest in our webshop and our products via advertising on our partners’ websites.
<G-vec00231-002-s173><appeal.ansprechen><de> Vormals schossen seine Verkaufszahlen aufgrund seiner Beliebtheit als Firmenwagen in die Höhe, doch mit wachsender Konkurrenz durch asiatische Modelle sieht sich Audi gezwungen, erneut Einzelkunden anzusprechen.
<G-vec00231-002-s173><appeal.ansprechen><en> Formerly its sales were boosted because it was much in desire as a fleet car but as competition from Asian models has increased Audi has been forced to appeal once more to the common buyer.
<G-vec00231-002-s174><appeal.ansprechen><de> Um ein energiesparendes und kohlenstoffarmes Leben anzusprechen, sollten wir einen niedrigen Stromverbrauch, eine hohe Effizienz und eine umweltfreundliche LED-Lampe wählen.
<G-vec00231-002-s174><appeal.ansprechen><en> order to appeal to energy-saving and low-carbon life, we should choose low power consumption, high efficiency and environment protection LED bulb.
<G-vec00231-002-s175><appeal.ansprechen><de> Er verstand es auch, die europäischen und afrikanischen Gemeindemitglieder gleichermaßen anzusprechen.
<G-vec00231-002-s175><appeal.ansprechen><en> He also knew how to appeal to both European and African members alike.
<G-vec00231-002-s176><appeal.ansprechen><de> Entstanden ist ein vielschichtiges Musiktheater, das sowohl Kinder ab 8 Jahren als auch Erwachsene anzusprechen vermag.
<G-vec00231-002-s176><appeal.ansprechen><en> This is a complex piece of musical theatre that will appeal to children and adults alike.
<G-vec00231-002-s177><appeal.ansprechen><de> Um einen potenziellen Käufer anzusprechen, damit er Ihre Anwendung im MetaTrader-Terminal herunterlädt, muss sich Ihr Produkt von hunderten von anderen in der Vitrine des Markets absondern.
<G-vec00231-002-s177><appeal.ansprechen><en> To appeal to a potential buyer so they download your application to the MetaTrader terminal, your product has to stand out of hundreds of others on the Market showcase.
<G-vec00231-002-s178><appeal.ansprechen><de> Wenn Sie ein Fotograf sind, der für Hochzeitsfotografie bekannt ist, aber mit Ihrem Handwerk mehr künstlerische Möglichkeiten erkunden möchten, können Sie Ihre Marke optimieren, um mehr Menschen anzusprechen.
<G-vec00231-002-s178><appeal.ansprechen><en> If you’re a photographer that is known for wedding photography, but want to explore more artistic avenues with your craft, you can tweak your brand to appeal to more people.
<G-vec00231-002-s179><appeal.ansprechen><de> Außerdem sollten sich Eltern oder Erziehungsberechtigte von Kindern jeden Alters dessen bewusst sein, dass die Website dazu entworfen wurde, ein breites Publikum anzusprechen.
<G-vec00231-002-s179><appeal.ansprechen><en> In addition, parents or guardians of children at any age should be aware that the Site is designed to appeal to a broad audience.
<G-vec00231-002-s180><appeal.ansprechen><de> Die Wärterin Wang Yanhua erlaubte ihr nicht die Übungen anzusprechen oder gar zu praktizieren, fesselte sie mehrmals und knebelte ihren Mund.
<G-vec00231-002-s180><appeal.ansprechen><en> Guard Wang Yanhua (female) did not allow her to appeal or practise the exercises, tied her up multiple times and gagged her mouth.
<G-vec00231-002-s181><appeal.ansprechen><de> Anders als die Verkaufstische vom letzten Jahr ist diese Bühne besonders geeignet, Inhalte und Produkte „wie beim Kunden zu Hause“ im monatlichen Wechsel zu inszenieren und ihn emotional anzusprechen.
<G-vec00231-002-s181><appeal.ansprechen><en> In distinction to the sales tables at Paperworld 2015, this platform is particularly suitable for presenting ideas and products “as in the customer’s home” on a monthly basis and to appeal to customers on an emotional plane.
<G-vec00286-002-s058><attract.ansprechen><de> CAPRICE möchte die modebewusste Frau ansprechen, die Wert auf schöne Schuhe legt und sich gleichzeitig einen hohen Tragekomfort wünscht.
<G-vec00286-002-s058><attract.ansprechen><en> CAPRICE wants to attract the fashion conscious woman, who demands highly comfortable shoes at the same time.
<G-vec00286-002-s059><attract.ansprechen><de> Mit unserem Trainee-Programm wollen wir High Potentials ansprechen, die eine Karriere im industriellen Umfeld anstreben.
<G-vec00286-002-s059><attract.ansprechen><en> With our trainee program we want to attract high potentials who wish to pursue a career in industry.
<G-vec00286-002-s060><attract.ansprechen><de> Es geht nicht nur darum, einfach die Preise oder Belegung zu erhöhen, sondern vielmehr, Ihre verschiedenen Segmente zu analysieren, sodass Sie die richtigen Kunden zur richtig Zeit ansprechen können.
<G-vec00286-002-s060><attract.ansprechen><en> The idea isn’t to simply increase rates or occupancy but, rather, to analyse your different segments so you can attract the right customer at the right time
<G-vec00286-002-s061><attract.ansprechen><de> So kann beispielsweise der Vater seiner jungen Tochter, die nicht versteht, warum sie keine allzu freizügige Kleidung tragen soll, das ansprechen, was sie vielleicht noch nicht richtig versteht: sie zieht auf diese Weise die Blicke der Burschen auf sich, aber keineswegs deren Wertschätzung.
<G-vec00286-002-s061><attract.ansprechen><en> For example, if an adolescent daughter doesn’t understand why she shouldn’t use an outfit that reveals too much, her father can perhaps make clear what she has not yet realized: that this way of dressing attracts the eyes of the boys, but by no means does it attract their respect or admiration.
<G-vec00286-002-s062><attract.ansprechen><de> Bei Interesse können Sie mich gern ansprechen.
<G-vec00286-002-s062><attract.ansprechen><en> If you are interested, you can attract me like.
<G-vec00286-002-s063><attract.ansprechen><de> Vergessen Sie dabei nicht, dass auch andere Unterkünfte dieselben Gäste ansprechen wollen, wie Sie.
<G-vec00286-002-s063><attract.ansprechen><en> However, you can be sure other properties are looking to attract the same guests as you.
<G-vec00286-002-s064><attract.ansprechen><de> Wenn diese Ziele Sie ansprechen, dann machen Sie mit.
<G-vec00286-002-s064><attract.ansprechen><en> If these are the kind of goals that attract you, please join us.
<G-vec00286-002-s067><attract.ansprechen><de> So gewinnen Sie wertvolle Erkenntnisse darüber, wie Sie Studierende erfolgreich ansprechen und binden.
<G-vec00286-002-s067><attract.ansprechen><en> So you can gain new insight into exactly what works to attract and retain students.
<G-vec00301-002-s247><address.ansprechen><de> Außerdem erlaubt die neu auf den Markt gebrachte HAPTIC Drucktechnologie, diesen Markt mit der beispiellosen haptischen Druckqualität noch besser anzusprechen.
<G-vec00301-002-s247><address.ansprechen><en> In addition, the newly launched HAPTIC printing allows to even better address this market by enabling a unique tactile feel in print.
<G-vec00301-002-s248><address.ansprechen><de> Um Ihre Kunden im B2B Segment gezielt anzusprechen brauchen sie geeignete und qualifizierte Kontaktdaten für Ihren Erfolg, die sie über das Social Selling erhalten können.
<G-vec00301-002-s248><address.ansprechen><en> In order to specifically address your customers in the B2B segment, they need suitable and qualified contact data for your success, which they can obtain via social selling.
<G-vec00301-002-s249><address.ansprechen><de> Unten finden Sie die PowerPoint Präsentationen und Materialien, welche die Referenten nutzen, um das Problem anzusprechen.
<G-vec00301-002-s249><address.ansprechen><en> Below you will find the power point presentations and materials that speakers used to address the issue.
<G-vec00301-002-s250><address.ansprechen><de> Ein Workshop ermöglicht Teammitgliedern, ihre Stelle im Team zu finden und ihre Erwartungen und Ziele anzusprechen.
<G-vec00301-002-s250><address.ansprechen><en> The workshop allows members to find their place in the team and to address their expectations and goals.
<G-vec00301-002-s251><address.ansprechen><de> Dann ist es wichtig und richtig, dieses Gefühl offen anzusprechen, auch wenn es Mut erfordert.
<G-vec00301-002-s251><address.ansprechen><en> Then it is important and right to address this feeling openly, even if it requires courage.
<G-vec00301-002-s252><address.ansprechen><de> Entscheidend ist, jeden Influencer individuell mit eigenen Veranstaltungen und Inhalten anzusprechen.
<G-vec00301-002-s252><address.ansprechen><en> It is crucial to address each influencer individually with own events and content.
<G-vec00301-002-s253><address.ansprechen><de> Banken – Finanzinstitute haben die Möglichkeit, das „Ökosystem“ für ihre Zahlungsdienste zu erweitern und über die Plattformen von Drittanbietern neue Kundengruppen anzusprechen.
<G-vec00301-002-s253><address.ansprechen><en> Banks – Financial institutions have the opportunity to expand the ecosystem for their payment services and to address new customer groups via third-party platforms.
<G-vec00301-002-s254><address.ansprechen><de> An Messen nehmen wir regelmäßig teil, nicht nur in Brünn, um neue Kunden anzusprechen.
<G-vec00301-002-s254><address.ansprechen><en> We participate in fairs regularly, not only in Brno, with a goal to address new customers.
<G-vec00301-002-s255><address.ansprechen><de> Ziele des Netzwerks sind die theoretischen und methodischen Herausforderungen, die momentan die empirische Untersuchung von Erfahrungen, deren Relation zum Gehirn und Körper, und deren Potenzial zum Wohlbefinden behindern, konkret anzusprechen.
<G-vec00301-002-s255><address.ansprechen><en> The objective of the network is to address concrete theoretical and methodological challenges currently hampering the empirical investigation of experience, its relationship to brain and body and its potential for well-being.
<G-vec00301-002-s256><address.ansprechen><de> BIs für den industriellen Gebrauch, um die einzigartigen Anforderungen der Medizingeräte-Branche und der Pharmaindustrie anzusprechen.
<G-vec00301-002-s256><address.ansprechen><en> Industrial Use BIs to address the unique requirements of the medical device and pharmaceutical industries.
<G-vec00301-002-s257><address.ansprechen><de> Leider war sie dort mit verschiedenen Gefahren konfrontiert, weshalb sie sich letztendlich entschloss die Thematik anzusprechen.
<G-vec00301-002-s257><address.ansprechen><en> Unfortunately, she was confronted with various dangers there, which is why she finally decided to address the issue.
<G-vec00301-002-s258><address.ansprechen><de> Wir benötigen diese Angaben, um Ihre Anfrage zu bearbeiten, Sie korrekt anzusprechen und Ihnen eine Antwort zukommen zu lassen.
<G-vec00301-002-s258><address.ansprechen><en> We need this information to process your inquiry, to address you correctly and to send you a reply.
<G-vec00301-002-s259><address.ansprechen><de> Wenn wir eine Person grundlegend und vom Herzen her akzeptieren, ist es nicht mehr schwierig, Unterschiede anzusprechen.
<G-vec00301-002-s259><address.ansprechen><en> When we fundamentally accept a person from the heart, it is no more difficult to address differences.
<G-vec00301-002-s260><address.ansprechen><de> Sie haben ausschließlich den Zweck, unseren Werbepartnern zu ermöglichen, Sie mit Werbung anzusprechen, die Sie auch tatsächlich interessieren könnte.
<G-vec00301-002-s260><address.ansprechen><en> The sole purpose of these third-party cookies is to give third party providers the opportunity to address you with targeted advertising.
<G-vec00301-002-s261><address.ansprechen><de> Im Gegensatz zu einigen anderen Blähungen Behandlung Optionen, die wir diskutiert haben, ist es möglich, natürliche Produkte für die Behandlung von Blähungen zu verwenden, um die Ursachen von Blähungen und die Symptome von Blähungen direkt anzusprechen, ohne ein Rezept.
<G-vec00301-002-s261><address.ansprechen><en> Unlike some of the other flatulence treatment options that we discussed, it is possible to use natural products for flatulence treatment to directly address the causes of flatulence and the symptoms of flatulence without needing a prescription.
<G-vec00301-002-s262><address.ansprechen><de> Das aktive Management eines Produkts oder Service über den gesamten Lebenszyklus (von der Idee bis zur Einstellung des Produkts/Service), um Marktmöglichkeiten/Kundenbedürfnisse anzusprechen und den größtmöglichen Wert für das Unternehmen zu generieren.
<G-vec00301-002-s262><address.ansprechen><en> (unchanged) The active management of products or services throughout their lifecycle (inception through to retirement) in order to address market opportunities and customer/user needs and generate the greatest possible value for the business.
<G-vec00301-002-s263><address.ansprechen><de> Die darin gesammelten Informationen sollen sowohl auf einer Website als auch in Buchform bereitgestellt werden, um verschiedene Zielgruppen alters-, bildungs- und situationsgerecht anzusprechen.
<G-vec00301-002-s263><address.ansprechen><en> The aim is to publish the data as a website and in print. In this way the project intends to address target groups of different ages, with different educational levels and in different situations, in appropriate ways.
<G-vec00301-002-s264><address.ansprechen><de> Image-Banner, statisch oder animiert, sind eine gute Möglichkeit Besucher besser anzusprechen als mit einem simplen Text.
<G-vec00301-002-s264><address.ansprechen><en> Image banner, either static or animated, is a great opportunity to address a site visitor by something more visual than a plain text.
<G-vec00301-002-s265><address.ansprechen><de> Plan B war also die Kamera gleich laufen zu lassen, die Frauen direkt auf der Straße anzusprechen und dann mit der großen Karriere zu locken.
<G-vec00301-002-s265><address.ansprechen><en> So plan B was to let the camera go the same, to address the women directly on the street and then to entice them with their great careers.
<G-vec00369-002-s019><engage.ansprechen><de> DISPLAY/SIGNAGE Inhalt und Kontext verschmelzen auf einem integrierten Display: Mediaplayer und Vision/Sound-Produkte, die ansprechen und informieren.
<G-vec00369-002-s019><engage.ansprechen><en> DISPLAY / SIGNAGE Fuse content and context for integrated display, media player and vision/sound products that engage and inform.
<G-vec00369-002-s020><engage.ansprechen><de> Wenn Lehrer und Schüler im Lernprozess von Grund- und Sekundarschulen zusammenwirken und die Technologie sinnvoll nutzen, können die Lernerfahrungen alle Lernenden herausfordern, ansprechen und inspirieren.
<G-vec00369-002-s020><engage.ansprechen><en> When teachers and students become co-creators in the K-12 learning process and leverage technology in meaningful ways, the learning experiences can challenge, engage and inspire all learners.
<G-vec00369-002-s021><engage.ansprechen><de> Genau das Richtige für jeden, der alle Sinne mit etwas Neuem ansprechen möchte.
<G-vec00369-002-s021><engage.ansprechen><en> Just the thing for anyone looking to engage all the senses with something new.
<G-vec00369-002-s022><engage.ansprechen><de> Ob online oder offline – Ihr Unternehmen möchte Kunden auf einer emotionalen Ebene ansprechen und ausreichend Reiselust und Vorfreude wecken, um Ihren Service zu nutzen oder eine Buchung zu tätigen.
<G-vec00369-002-s022><engage.ansprechen><en> Online or in print – your business copy wants to engage potential customers on an emotional level that feeds their wanderlust and excitement enough to use your service or make a booking with you.
<G-vec00369-002-s023><engage.ansprechen><de> Das würde Kinder stärker ansprechen und ihnen helfen, mehr zu lernen.
<G-vec00369-002-s023><engage.ansprechen><en> That would engage children more deeply and help them learn more.
<G-vec00369-002-s024><engage.ansprechen><de> “Unser Fokus liegt zwar auf den Produktionsstätten, das System soll jedoch alle ansprechen...
<G-vec00369-002-s024><engage.ansprechen><en> “While the focus is on our manufacturing sites, the system is designed to engage everyone...
<G-vec00369-002-s025><engage.ansprechen><de> Wir bieten personalisierte, datengesteuerte Werbeerlebnisse, die Verbraucher - über Bildschirme, Plattformen und traditionelle Publisher hinweg - ansprechen und deren Kaufverhalten beeinflussen.
<G-vec00369-002-s025><engage.ansprechen><en> We deliver data-driven personalised ad experiences that engage consumers – across screens, platforms and traditional publishers – and influence them to purchase.
<G-vec00369-002-s026><engage.ansprechen><de> Der Anwender wird von Transportmitteln, Dienstleistungen, nützliche Telefonnummern, Unterkunft nach Ort, Strände, Sehenswürdigkeiten, Nachtleben, Veranstaltungen, lokalen Markt und Aktivitäten, die Besucher ansprechen werden informiert.
<G-vec00369-002-s026><engage.ansprechen><en> The user is informed of means of transport, services, useful phone numbers, accommodation by location, beaches, attractions, nightlife, events taking place on the island, local market and activities which will engage visitors.
<G-vec00369-002-s027><engage.ansprechen><de> Mit unserer Enterprise SMS Marketing-Plattform, die speziell für Ihr Unternehmen entwickelt wurde, können Marketingexperten sofort kommunizieren und Kunden von unterwegs ansprechen.
<G-vec00369-002-s027><engage.ansprechen><en> Our Enterprise SMS Marketing Platform designed for your business, allows marketers to instantly communicate and engage customers on the go.
<G-vec00369-002-s028><engage.ansprechen><de> Um auf diesem Gebiet koordiniertes öffentliches Handeln zu erreichen, muss man die Intuition und Emotionen der Menschen ansprechen, also das System 1.
<G-vec00369-002-s028><engage.ansprechen><en> To achieve coordinated public action in that domain, it will be necessary to engage people’s intuitions and emotions – System 1 – and that change is unlikely to be achieved by evidence alone.
<G-vec00369-002-s029><engage.ansprechen><de> Marketingfachleute können mithilfe unserer primären Standortdaten ihr Unternehmen besser analysieren, Kunden über präzises Standort- und Zielgruppen-Targeting aktiv ansprechen und die Effekte auf die Umsätze zeitabhängig messen.
<G-vec00369-002-s029><engage.ansprechen><en> Marketers can leverage our first party location data to learn more about their business, actively engage their consumers through precise location and audience targeting, and measure sales impact in the moment.
<G-vec00435-002-s019><speak.ansprechen><de> Bonuspunkte gibt es, wenn Sie ein Moodboard mit Farbfeldern und Schriften, die Sie ansprechen, sowie Beispielbildern anderer Marken, die Sie mögen, haben.
<G-vec00435-002-s019><speak.ansprechen><en> Bonus points if you include a mood board with colour swatches, fonts that speak to you, images with examples from other brands that you like helps a lot.
<G-vec00435-002-s021><speak.ansprechen><de> Zum Beispiel nenne ich immer wieder unseren Sohn mit dem Namen meines Kollegen und mein Kollege muss sich von mir mit dem Vornamen unseres Sohnes ansprechen lassen.
<G-vec00435-002-s021><speak.ansprechen><en> For example, I always call our son with the name of my colleague and my colleague must bear it that I speak to him with the first name of our son.
<G-vec00435-002-s023><speak.ansprechen><de> Bei Fragen könnt ihr uns gerne kontaktieren oder unsere Mitarbeiter im Park ansprechen.
<G-vec00435-002-s023><speak.ansprechen><en> If you have any questions, please feel free to contact us, or speak to a member of staff in the park.
<G-vec00435-002-s024><speak.ansprechen><de> Die Studenten haben Versammlungen in hervorragender Weise geleitet, und es war wunderbar mitzuerleben, wie die 9/10-Jährigen Yaacov und Jerry dezent daran erinnerten, dass sie immer den Versammlungsleiter ansprechen sollen und warten müssen, bis sie an der Reihe sind und bis andere ausgeredet hatten.
<G-vec00435-002-s024><speak.ansprechen><en> The students did a great job of chairing the meetings and it was wonderful to see the 9/10 year olds gently reminding Yaacov and Jerry to speak through the chair and wait their turn till others had spoken!!
<G-vec00435-002-s025><speak.ansprechen><de> Wenn Ihr Flug annulliert wird oder sich über 2 Stunden verspätet und Sie sich den ungenutzten Abschnitt Ihres Tickets erstatten lassen möchten (einschließlich einiger Gebühren und/oder bezahlter Reiseoptionen), können Sie sich telefonisch an die Air-Canada-Reservierung wenden oder einen Flughafenmitarbeiter von Air Canada ansprechen.
<G-vec00435-002-s025><speak.ansprechen><en> If your flight is cancelled or delayed by more than 2 hours and you'd like to obtain a refund for the unused portion of your ticket (including some fees and/or purchased travel options), you can call Air Canada Reservations or speak to an Air Canada agent at the airport.
<G-vec00435-002-s026><speak.ansprechen><de> Was wir gerne ansprechen würden, sind die Reaktionen, die Fans hatten, über das was in den Medien verbreitet wurde, über unser Buch.
<G-vec00435-002-s026><speak.ansprechen><en> What we would like to speak on is the reaction some fans have had based on that’s being said about the book in the tabloid media.
<G-vec00435-002-s027><speak.ansprechen><de> Da es manchmal an Zeit und Mitteln für effektive Drogenaufklärung mangelt und die verwendeten Materialen oft nicht mehr zeitgerecht sind, ganz zu schweigen davon, dass sie nicht wirklich die Kinder ansprechen, können wir helfen.
<G-vec00435-002-s027><speak.ansprechen><en> While time and resources for effective drug education are sometimes lacking, and the materials used are often outdated, not to mention that they don’t factually speak to the kids, we can help.
<G-vec00435-002-s028><speak.ansprechen><de> Fragen Sie nach Trainingsvideos, FAQs und spezialisierten und erfahrenen Shipper Consultants, die Sie jederzeit in Ihrer Zeitzone und in Ihrer Sprache ansprechen können.
<G-vec00435-002-s028><speak.ansprechen><en> As back up, ask for training videos, FAQs and 24/7 access to specialized, experienced shipping consultants able to speak in your time zones and your languages.
<G-vec00435-002-s029><speak.ansprechen><de> Wer an Jesus Christus, den Sohn Gottes glaubt, wird in sein Sohnesrecht hinein genommen und kann Gott auch als seinen Vater durch Jesus Christus ansprechen.
<G-vec00435-002-s029><speak.ansprechen><en> Whoever believes in Jesus Christ, the Son of God, will receive the full rights of sonship. As a result they, too, can speak to God as their Father, through Jesus Christ.
<G-vec00435-002-s030><speak.ansprechen><de> Dann lasset sie ziehen, aber nehmet euch derer an, die euch suchen, die Ich auch durch euch Selbst ansprechen will, denen Ich Mein Wort bringen will, auf daß in ihnen Licht werde nach der tiefen Dunkelheit zuvor.
<G-vec00435-002-s030><speak.ansprechen><en> Then let them go but take care of those who seek you, to whom I also want to speak through yourselves, to whom I want to bring my word so that light comes into them after the deep darkness before.
<G-vec00435-002-s031><speak.ansprechen><de> Lasset euch immer wieder von Mir ansprechen, und trachtet nur danach, in Meinen Willen einzugehen, und ihr werdet mit Mir die Bindung herstellen, ihr werdet euch Mir anschließen und nun auch zu den Meinen gezählt werden, die Ich erretten werde, bevor das Ende kommt.
<G-vec00435-002-s031><speak.ansprechen><en> Again and again let me speak to you, and only strive for entering into my will, and you will establish the union with me, you will join me and will now also be counted with the ones who are mine, whom I will rescue before the end comes.
<G-vec00435-002-s032><speak.ansprechen><de> Daß Ich ihn ansprechen kann, stempelt ihn auch zu einem Diener in Meinem Weinberg, und dann wird er auch alle Aufträge gewissenhaft ausführen, die Ich ihm nun zuweise....
<G-vec00435-002-s032><speak.ansprechen><en> The fact that I can speak to him will also signify him as a servant in My vineyard, for then he will conscientiously accomplish all tasks which I assign to him....
<G-vec00435-002-s033><speak.ansprechen><de> Ich muss hier sagen, dass ich wenige Seminare besuche, da mich wenige von diesen direkt ansprechen.
<G-vec00435-002-s033><speak.ansprechen><en> I must say here that I attend a few seminars, since few of them speak to me directly.
<G-vec00435-002-s034><speak.ansprechen><de> Ich aber kenne die einzelnen Menschenherzen, und diesen führe Ich auch die Gnadengaben zu, Ich führe sie mit Meinen Weinbergsarbeitern zusammen, um sie direkt durch diese ansprechen zu können....
<G-vec00435-002-s034><speak.ansprechen><en> But I know the individual human hearts and it is to these that I will convey the gifts of grace; I will bring them together with My vineyard labourers in order to speak through them directly....
<G-vec00435-002-s035><speak.ansprechen><de> Wenn Sie Ihre Zielgruppe nicht genau kennen, können Sie auch nicht wissen, mit welchen Keywords Sie eine einzelne Person direkt ansprechen und auf die durchgeführten Aktionen reagieren können.
<G-vec00435-002-s035><speak.ansprechen><en> If you don’t know specifics about your audience, you can’t know which keywords will help you create experiences that speak directly to an individual and the actions they’re taking.
<G-vec00057-002-s228><address.ansprechen><de> Die Angabe weiterer, gesondert markierter Daten ist freiwillig und wird verwendet, um Sie persönlich ansprechen zu können.
<G-vec00057-002-s228><address.ansprechen><en> The provision of further, separately marked data is voluntary and will be used to address you personally.
<G-vec00057-002-s229><address.ansprechen><de> In drei Tagen haben wir alles, was nicht zu sehen ist, dann werden wir wieder so schnell wie möglich kommen, und wir werden unsere Freunde ansprechen.
<G-vec00057-002-s229><address.ansprechen><en> In three days, we have not seen everything, then we will come back as soon as possible, and we will address to our friends.
<G-vec00057-002-s232><address.ansprechen><de> Ich will also euch Menschen alle ansprechen durch Meine Diener auf Erden, die Mir diese Ansprache ermöglichen.
<G-vec00057-002-s232><address.ansprechen><en> I want to address all people through My servants on Earth who enable Me to speak through them.
<G-vec00057-002-s233><address.ansprechen><de> Wir suchen Ideen und Lösungen, die gesellschaftlich relevante Themen, wie Gesundheit, Bildung, Mobilität oder Digitalisierung ansprechen und gesellschaftlichen Nutzen initiieren können.
<G-vec00057-002-s233><address.ansprechen><en> We are looking for ideas and solutions that can address socially relevant topics such as health, education, mobility or digitization and initiate social benefits.
<G-vec00057-002-s234><address.ansprechen><de> Gemäß dieser Richtlinie muss das Unternehmen den Ruf des vorgeschlagenen Vermittlers prüfen und jedwede Compliance-Bedenken analysieren und ansprechen, die sich dabei gegebenenfalls herausstellen.
<G-vec00057-002-s234><address.ansprechen><en> The procedure requires the company to check the reputation of the proposed intermediary and to analyse and address any compliance concerns which may come to light.
<G-vec00057-002-s235><address.ansprechen><de> Überlege, was Du persönlich an Hintergrundinformationen liefern möchtest, wie Du den Zuschauer ansprechen möchtest.
<G-vec00057-002-s235><address.ansprechen><en> Consider what background information you personally would like to provide, how you would like to address the viewer.
<G-vec00057-002-s236><address.ansprechen><de> Die Oberrichterin war sichtlich erleichtert, sie hatte sich wohl gedacht, dass ich sie mit Ursula ansprechen würde.
<G-vec00057-002-s236><address.ansprechen><en> The chief justice was visibly relieved; she probably thought I would address her as “Ursula.”
<G-vec00057-002-s237><address.ansprechen><de> Sie werden alle Interessierten ansprechen dort zu finden.
<G-vec00057-002-s237><address.ansprechen><en> You will find all interested to address there.
<G-vec00057-002-s238><address.ansprechen><de> Sowohl Licht als auch Klang sollen die entspannende Wirkung des Diffusors verstärken und neben dem Geruchssinn auch den Seh- sowie den Hörsinn ansprechen.
<G-vec00057-002-s238><address.ansprechen><en> Both light and sound are intended to enhance the relaxing effect of the diffuser and, in addition to the sense of smell, also address the sense of sight and hearing.
<G-vec00057-002-s239><address.ansprechen><de> Die Angabe Ihres Namens ist freiwillig und dient ausschließlich dazu, Sie im Newsletter persönlich ansprechen zu können.
<G-vec00057-002-s239><address.ansprechen><en> The indication of your name is voluntary and serves exclusively to be able to address you personally in the newsletter.
<G-vec00057-002-s240><address.ansprechen><de> Wenn wir also Amerikaner, Europäer und Israelis ansprechen und ihre Aktionen gegen die Palästinenser und die Araber im Irak mit den Nazis vergleichen, werden sie wegen der Monstrosität des Holocausts geistig wie gelähmt und es bereitet ihnen psychischen Druck, der zum Zusammenbruch führt.
<G-vec00057-002-s240><address.ansprechen><en> As a result, if we address Americans, Europeans and Israelis and compare their deeds against the Palestinians and the Arabs in Iraq with the Nazis, they, because of the monstrosity of the Holocaust, will become mentally paralyzed and it brings psychic pressure on them leading to a collapse.
<G-vec00057-002-s241><address.ansprechen><de> Das bedeutet, daß Sie bis zumn Ende Ihrer Amtszeit die Angeklegenheit in irgendeiner Form ansprechen müssen.
<G-vec00057-002-s241><address.ansprechen><en> And this means that before the end of your term you will somehow need to address this issue.
<G-vec00057-002-s242><address.ansprechen><de> Der Kampf beginnt, wenn Sie die soziale Ursache, die Mitarbeiter ansprechen lassen.
<G-vec00057-002-s242><address.ansprechen><en> The fight begins when you leave the social cause to address the staff.
<G-vec00057-002-s243><address.ansprechen><de> Da aber das Los der Neubannung erst jetzt für die Menschen das drohende Unheil ist.... da bisher immer noch die Möglichkeit bestand, im jenseitigen Reich auszureifen, wenn es auf Erden versäumt wurde, war es auch für die Menschen bisher nicht nötig, daß sie um den langen Entwicklungsgang zuvor wußten.... wenngleich Ich zuweilen auch Menschen direkt ansprechen konnte und sie in dieses Wissen einführte....
<G-vec00057-002-s243><address.ansprechen><en> But since the fate of a renewed banishment is only now becoming the imminent disaster.... since until now the opportunity still existed to mature in the kingdom of the beyond if it was neglected on earth, it was not necessary for people to know about the prior long process of development before.... although occasionally I was able to address people directly and so introduced them to this knowledge....
<G-vec00057-002-s244><address.ansprechen><de> Sie wollen Fachbesucher also noch gezielter ansprechen.
<G-vec00057-002-s244><address.ansprechen><en> So you want to address trade visitors even more specifically.
<G-vec00057-002-s245><address.ansprechen><de> Der geistig Strebende hat darum einen sicheren Wegweiser, denn ihn wird immer nur das ansprechen, was seiner Seele dienlich ist - während der Verstandesmensch oft nicht einmal den Verstand recht gebrauchet zur Prüfung und darum das Einschlüpfen von Irrtum leicht möglich ist.
<G-vec00057-002-s245><address.ansprechen><en> The spiritual striving therefore has for that reason a secure signpost, for always only that will address him, what serves his soul - while the intellectual man often not even really uses the intellect to the examination and for that reason the slipping in of error is easily possible.
<G-vec00057-002-s246><address.ansprechen><de> Robuste Gehäuse und die im gleichen Zuge wertige Verarbeitung soll die Käufergruppe ansprechen, die täglich mit dem Gerät arbeiten oder einfach dem Motto „weniger ist mehr“ folgen wollen.
<G-vec00057-002-s246><address.ansprechen><en> A robust case and the, at the same time, quality workmanship are to address the buyer group who work with the device on a daily basis or simply follow the motto "less is more".
<G-vec00057-002-s703><consult.ansprechen><de> Sollten Linien verzerrt oder verschwommen erscheinen, sprechen Sie mit Ihrem Augenarzt und schildern Sie Ihre Beobachtung.
<G-vec00057-002-s703><consult.ansprechen><en> If any of the lines appear distorted or blurred, please consult your eye care specialist and describe the results.
<G-vec00057-002-s704><consult.ansprechen><de> Falls du mindestens eine dieser Fragen mit Ja beantwortest, empfehlen wir dir, mit einem Arzt zu sprechen, bevor du ein Trainingsprogramm beginnst.
<G-vec00057-002-s704><consult.ansprechen><en> If you answer yes to any of these questions, we recommend that you consult a doctor before starting any training program.
<G-vec00057-002-s705><consult.ansprechen><de> Sie sollten mit Ihrem örtlichen Patentanwalt sprechen, um herauszufinden, ob dies eine Ihrer Situation angemessene Wahl ist.
<G-vec00057-002-s705><consult.ansprechen><en> You should consult with your local intellectual property attorney to find out whether this is a viable option for you in your particular state.
<G-vec00057-002-s706><consult.ansprechen><de> Klingen die Nebenwirkungen nach ein bis zwei Tagen nicht ab, sollte man mit seinem Arzt sprechen.
<G-vec00057-002-s706><consult.ansprechen><en> If the side effects do not ease after a day or two, you should consult your GP.
<G-vec00057-002-s707><consult.ansprechen><de> Wenn Sie Bedenken zu Ihrer Gesundheit oder Sicherheit haben, sprechen Sie bitte mit Ihrem Arzt oder rufen Sie unser Büro an, um die individuelle Situation zu klären.
<G-vec00057-002-s707><consult.ansprechen><en> If you are concerned with health or safety issues, please consult with your physician or call our office to discuss the individual situation.
<G-vec00057-002-s708><consult.ansprechen><de> Aber wir raten Ihnen, dass Sie vor der Zahnbehandlung mit Ihrem Versicherungsträger sprechen, und alle notwendigen Dokumente mitbringen.
<G-vec00057-002-s708><consult.ansprechen><en> However, we suggest that you consult your health insurance company prior to a dental treatment in Hungary, and bring along the documents required.
<G-vec00057-002-s709><consult.ansprechen><de> Da die Werte jedoch von Labor zu Labor unterschiedlich sind, sollten Patienten lieber mit ihrem Arzt über ihre Untersuchungsergebnisse sprechen, als sich an den Werten dieser Tabelle zu orientieren.
<G-vec00057-002-s709><consult.ansprechen><en> However, because values vary by laboratory, people should consult their doctor about the significance of their own test results rather than refer to this table.
<G-vec00057-002-s710><consult.ansprechen><de> Ebenso werde ich Ihnen raten, mit Ihrem Arzt zu sprechen, bevor Sie diese Pille nehmen.
<G-vec00057-002-s710><consult.ansprechen><en> Likewise, I'll advise you to consult with your physician prior to you take this tablet.
<G-vec00057-002-s711><consult.ansprechen><de> Bevor du diese Technik ausführst, solltest du mit deinem Arzt sprechen, um sicherzustellen, dass es keine gesundheitlichen Einschränkungen für dich gibt.
<G-vec00057-002-s711><consult.ansprechen><en> Before you perform this technique you should consult your doctor to make sure you are healthy enough to do so.
<G-vec00057-002-s712><consult.ansprechen><de> Sie bekommen auf der Messe die einmalige Gelegenheit, Innovationen im Markt als Erste zu testen, sich auf globaler Ebene auszutauschen, mit Experten zu sprechen und sich von Top-Trainern anleiten zu lassen.
<G-vec00057-002-s712><consult.ansprechen><en> They will be given the unique opportunity to be the first to put market innovations to the test at the trade show, to network on a global scale, to consult experts and be instructed by top trainers.
<G-vec00057-002-s713><consult.ansprechen><de> Oft kann die Katze das Fieber selber überwinden, aber es ist immer gut, mit dem Tierarzt zu sprechen.
<G-vec00057-002-s713><consult.ansprechen><en> In many cases, your cat will be able to overcome a fever on its own, but it is always a good idea to consult your vet.
<G-vec00057-002-s714><consult.ansprechen><de> Wer Bedenken hat, ob eine Teilnahme an einem Kunststoffkurs persönlich zu verantworten ist, sollte vor der Anmeldung mit dem Kursleiter sprechen, um eventuelle Risikofaktoren abzuklären, weiterführende Schutzmaßnahmen zu verabreden oder ein alternatives Arbeitsmaterial (Bsp.
<G-vec00057-002-s714><consult.ansprechen><en> If in doubt, whether oarticipating in a plastic course is advisable, consult the course supervisor before signing up, to clarify possible risks, discuss further protective measures or to choose an alternative material to work with (e.g.
<G-vec00057-002-s715><consult.ansprechen><de> Die Dosis hängt von der gewünschten Wirkung ab, aber nicht können Sie die Dosis oder den gleichzeitigen Gebrauch mit anderen Medikamenten falten, ohne mit einem Arzt zu sprechen.
<G-vec00057-002-s715><consult.ansprechen><en> The dose depends on of the effect desired, but not is can bend the dose or the use concomitantly with other drugs without consult to a medical.
<G-vec00057-002-s716><consult.ansprechen><de> Zu guter Letzt ist es das Wichtigste, mit Ihrem Optometristen zu sprechen, wenn es um Kontaktlinsen für Kinder geht.
<G-vec00057-002-s716><consult.ansprechen><en> Finally, the most important thing when it comes to contacts for kids is to consult your optometrist. Some benefits of contact lenses
<G-vec00057-002-s717><consult.ansprechen><de> Bei Fragen zur optimalen Tragedauer sprechen Sie bitte mit Ihrem Kontaktlinsenanpasser.
<G-vec00057-002-s717><consult.ansprechen><en> Please consult your eye care professional if you have any questions about the proper wearing schedule for your lenses.
<G-vec00057-002-s304><speak.ansprechen><de> Jedes Themenfeld ist so entworfen, dass dein Kind damit eine andere linguistische Kategorie lernt, zum Beispiel ‘sprechen’ für ‘Sprach’-Ziele.
<G-vec00057-002-s304><speak.ansprechen><en> Each type is designed to teach a different linguistic category, like ‘speaking’ for ‘Speak’ Goals.
<G-vec00057-002-s305><speak.ansprechen><de> Aber auch wenn er nicht sprach, verstand ihn ohnehin jeder.
<G-vec00057-002-s305><speak.ansprechen><en> But even if he did not speak, everyone understood him anyway.
<G-vec00057-002-s306><speak.ansprechen><de> Vom Himmel sprach er jetzt nicht mehr.
<G-vec00057-002-s306><speak.ansprechen><en> Of Heaven, he did not speak any more.
<G-vec00057-002-s307><speak.ansprechen><de> - Ich sprach recht gut Italienisch, aber das ist lange her und ich habe es schon lange nicht mehr praktiziert.
<G-vec00057-002-s307><speak.ansprechen><en> - I used to speak Italian pretty well, but it's been a long time since I've practised.
<G-vec00057-002-s308><speak.ansprechen><de> Der WM-Führende Dovizioso war der erste, der seine Gedanken über die für ihn und Ducati in der Vergangenheit notorisch schwierige Strecke sprach.
<G-vec00057-002-s308><speak.ansprechen><en> Championship leader Dovizioso was the first to speak about his thoughts ahead of what has been a notoriously difficult track for him and Ducati in the past.
<G-vec00057-002-s309><speak.ansprechen><de> Als Professor Michael Hudson, Chefberater der lettischen Regierung in Wirtschaftfragen, im Jahre 2010 als erster Europäer offiziell von einem sich abzeichnenden "Krieg um Schulden in Europa" sprach, da hatte man ihn nicht nur in Brüssel ausgelacht.
<G-vec00057-002-s309><speak.ansprechen><en> When in 2010 Professor Michael Hudson, chief advisor on economics to the Latvian government, became the first European officially to speak of the looming “Battle of European Debt”, he was widely mocked in Brussels and beyond.
<G-vec00057-002-s310><speak.ansprechen><de> Aber wenn L. Ron Hubbard auch nicht speziell von seinem eigenen Status sprach, so war dieser doch nicht weniger legendär.
<G-vec00057-002-s310><speak.ansprechen><en> But if Mr. Hubbard would not particularly speak of his own status, it was no less legendary.
<G-vec00057-002-s311><speak.ansprechen><de> Dann kamen sie für die Gewerkschafter, Und ich sprach nicht heraus – weil ich nicht ein Gewerkschafter war.
<G-vec00057-002-s311><speak.ansprechen><en> Then they came for the trade unionists, and I did not speak out— because I was not a trade unionist.
<G-vec00057-002-s312><speak.ansprechen><de> Englisch sprach er nicht.
<G-vec00057-002-s312><speak.ansprechen><en> He did not speak English.
<G-vec00057-002-s313><speak.ansprechen><de> •Trump initiierte nicht nur die meisten ihrer Interaktionen und war der erste, der mit den Medien sprach, er spielte auch die Rolle des Gastgebers, zeigte Kim den Weg und führte ihn.
<G-vec00057-002-s313><speak.ansprechen><en> •Not only did Trump initiate most of their interactions and was the first one to speak to the media, he also played the role of the host, showing Kim the way and directing him.
<G-vec00057-002-s314><speak.ansprechen><de> Leider sprach sie kaum Englisch.
<G-vec00057-002-s314><speak.ansprechen><en> But she could not speak any English.
<G-vec00057-002-s315><speak.ansprechen><de> Yann Le Cam, EURORDIS-Vorstandsvorsitzender, sprach auf der Konferenz über die Wichtigkeit, die Mission der Gesundheitssäule der EMA 'Wissenschaft, Arzneimittel, Gesundheit' durch eine verstärkte und verbesserte Patientenbeteiligung an der Entwicklung und Bewertung von Arzneimitteln zu untermauern.
<G-vec00057-002-s315><speak.ansprechen><en> The conference was the opportunity for Yann Le Cam, EURORDIS Chief Executive Officer, to speak on the importance of reinforcing the 'health' pillar of the EMA's 'Science, Medicines, Health' mission through increased and better engagement of patients in the medicines development and assessment journey.
<G-vec00057-002-s316><speak.ansprechen><de> Ansonsten sprach ich nicht darüber, weil die Leute es nicht glaubten.
<G-vec00057-002-s316><speak.ansprechen><en> Otherwise, I would not speak of it because people wouldn't believe it.
<G-vec00057-002-s317><speak.ansprechen><de> Die Sprachen italienisch, russisch, deutsch und französisch sprach er fliessend.
<G-vec00057-002-s317><speak.ansprechen><en> He could speak the languages Italian, Russian, German and French fluently.
<G-vec00057-002-s318><speak.ansprechen><de> Es schien, als wären sie nicht an der Botschaft Gottes interessiert, sondern sie wollten nur jemanden besuchen, der ihre Muttersprache sprach.
<G-vec00057-002-s318><speak.ansprechen><en> It seemed they weren't interested in God's message to them, but only in visiting with someone who could speak their mother tongue.
<G-vec00057-002-s319><speak.ansprechen><de> Glücklicherweise spricht mein Partner Französisch ganz gut, da die Dame sprach kein Englisch.
<G-vec00057-002-s319><speak.ansprechen><en> Fortunately, my partner speaks French quite well since the lady didn't speak English.
<G-vec00057-002-s320><speak.ansprechen><de> Er sprach zu mir durch Wolkenbilder, und Bilder in meinem Fenster von Ihm und anderen Bildern.
<G-vec00057-002-s320><speak.ansprechen><en> He would speak to me in pictures in the clouds and picture images on my window of Him and other images.
<G-vec00057-002-s321><speak.ansprechen><de> Ich sprach nicht, bewegte mich nicht oder reagierte sogar nicht auf das was um mich herum vorging, manchmal tagelang.
<G-vec00057-002-s321><speak.ansprechen><en> I did not speak, move, or even react to what was going on around me for days at a time.
<G-vec00057-002-s322><speak.ansprechen><de> Franziskus führte auch ein Beispiel unserer Tage an, indem er an die Gestalt Teresas von Kalkutta erinnerte, die »die Stimme des Herrn hörte: Sie sprach nicht, und sie verstand es, in der Stille zuzuhören« und danach zu handeln.
<G-vec00057-002-s322><speak.ansprechen><en> Pope Francis also drew a modern-day example in the figure of Teresa of Calcutta, who “heard the Lord’s voice: she didn’t speak, and in the silence she knew how to listen”, and therefore, how to act.
<G-vec00057-002-s342><speak.ansprechen><de> Ich spreche Italienisch, etwas Englisch und ein klein wenig Französisch, Deutsch.
<G-vec00057-002-s342><speak.ansprechen><en> I speak Dutch, some English, German, and a tiny bit of Spanish, Italian.
<G-vec00057-002-s343><speak.ansprechen><de> Sprachaustausch Schreibe oder spreche Schwedisch Online, um so deine Grammatik oder Konversation zu verbessern.
<G-vec00057-002-s343><speak.ansprechen><en> Write or speak Swedish online to improve grammar or conversation.
<G-vec00057-002-s344><speak.ansprechen><de> Ich spreche also aus Erfahrung, wenn ich sage, wie schwer es ist neue Räumlichkeiten wohnlich zu gestalten.
<G-vec00057-002-s344><speak.ansprechen><en> So I speak from experience when I say how difficult it is to make new spaces homely.
<G-vec00057-002-s345><speak.ansprechen><de> Ich spreche Französisch, Baskisch und Spanisch.
<G-vec00057-002-s345><speak.ansprechen><en> I speak French, Basque and Spanish.
<G-vec00057-002-s346><speak.ansprechen><de> So wie eben mit euch in der Kaffeebar: Mit den Leuten vom Büro spreche ich niederländisch oder englisch, mit euch englisch und dann dreht man sich zu dem Mädchen am Tresen und bestellt Espresso auf Französisch.
<G-vec00057-002-s346><speak.ansprechen><en> Like just now in the coffee bar. I speak Dutch or English with the staff at the office, I speak English with you and then I turn round to the girl behind the bar and I order my espresso in French.
<G-vec00057-002-s347><speak.ansprechen><de> Aber ich spreche auch als jemand, der viele Jahre lang sehr wenig verdient hat und der krank ist, und in diesen anderen Aspekten meines Lebens habe ich weniger Macht.
<G-vec00057-002-s347><speak.ansprechen><en> But I also speak as somebody who for many years has earned very little and who is ill, and in these other aspects of my life I have less power.
<G-vec00057-002-s348><speak.ansprechen><de> „Wenn ich in der Schule bin, bin ich fast eher wie eine Deutsche, aber wenn ich zuhause bin, spreche ich vietnamesisch und esse vietnamesisch.
<G-vec00057-002-s348><speak.ansprechen><en> At school, I am almost more German, but at home I speak Vietnamese and eat Vietnamese.
<G-vec00057-002-s349><speak.ansprechen><de> Ich spreche vom Sein im Moment, vom Bleiben des Geschenkes und vom Sorgen nicht.
<G-vec00057-002-s349><speak.ansprechen><en> I speak of being in the moment, staying present and not worrying.
<G-vec00057-002-s350><speak.ansprechen><de> 2 Denn siehe, ich spreche zu dir mit Deutlichkeit und mit Macht, denn mein Arm ist über der ganzen Erde.
<G-vec00057-002-s350><speak.ansprechen><en> 2 For behold, I speak unto you with sharpness and with power, for mine arm is over all the earth.
<G-vec00057-002-s351><speak.ansprechen><de> Denn Ich spreche immer durch den Mund eurer Mitmenschen, sei es in Rede und Gegenrede oder auch in direkter Anrede zu dem, der nach innen horchet auf Meine Stimme.
<G-vec00057-002-s351><speak.ansprechen><en> Because I always speak through the mouth of your fellowmen, may it be in speech and reply or also in direct address to him, who listens to the inside to my voice.
<G-vec00057-002-s352><speak.ansprechen><de> Ich wünsche dir einen guten Freitag, Türkisch spreche: Hayirli Cumalar.
<G-vec00057-002-s352><speak.ansprechen><en> have a good Friday Turkish Speak: Hayirli Cumalar.
<G-vec00057-002-s353><speak.ansprechen><de> Mittlerweile spreche ich fließend Englisch, Französisch und Spanisch.
<G-vec00057-002-s353><speak.ansprechen><en> In the meantime, I speak fluent English, French and Spanish.
<G-vec00057-002-s354><speak.ansprechen><de> Wenn ich über Webanwendungen in der Blockchain-Industrie spreche, schließe ich bewusst Tauschplattformen wie Kraken, Bitfinex oder ähnliches aus.
<G-vec00057-002-s354><speak.ansprechen><en> When I speak about web applications across the blockchain landscape, I purposely exclude exchange platforms like Kraken, Bitfinex or similar.
<G-vec00057-002-s355><speak.ansprechen><de> Ich spreche an vielen Veranstaltungsorten im ganzen Land, deshalb fliege ich eine Menge.
<G-vec00057-002-s355><speak.ansprechen><en> I speak in many venues around the country, so I fly a lot.
<G-vec00057-002-s356><speak.ansprechen><de> Spreche Bengalisch und fühle dich sicher bei deinen Geschäften im Ausland.
<G-vec00057-002-s356><speak.ansprechen><en> Speak Bengali and feel in control of your foreign business.
<G-vec00057-002-s357><speak.ansprechen><de> Arbeite daran, dein Vokabular zu erweitern und spreche deutlich.
<G-vec00057-002-s357><speak.ansprechen><en> Work on expanding your vocabulary and speak clearly.
<G-vec00057-002-s358><speak.ansprechen><de> Also bin ich mit diesem wunderwunderschönen Land im Herzen aufgewachsen, und auch, wenn ich nicht perfekt spreche, liebe ich die Sprache - sie zu hören, zu lesen und zu sprechen.
<G-vec00057-002-s358><speak.ansprechen><en> So I grew up with that beautiful beautiful country, and even if I don`t speak perfectly, I love the language - love to hear, read and speak it.
<G-vec00057-002-s359><speak.ansprechen><de> Seit ein paar Wochen arbeite ich nun bei einem großen Unternehmen der Elektronikbranche im Costumer Service und höre, lese, schreibe und spreche täglich Englisch, Französisch und vor allem Niederländisch.
<G-vec00057-002-s359><speak.ansprechen><en> A few weeks ago however, I began working in the customer service of a big electronics company where I hear, read, write and speak English, French and especially Dutch on a daily basis.
<G-vec00057-002-s360><speak.ansprechen><de> Meine Lieblings-Sprache ist Englisch, aber unsere Sprache ist Französisch, aber ich spreche Englisch sehr fließend.
<G-vec00057-002-s360><speak.ansprechen><en> My favorite language is English but our language is French but i speak English very fluently.
<G-vec00057-002-s361><speak.ansprechen><de> Sie zog ihre Schwester mit sich, und die beiden jungen Meermädchen ließen sich am Strand bei den anderen Kindern nieder, als die Älteste Misha gerade zu sprechen begann.
<G-vec00057-002-s361><speak.ansprechen><en> She pulled her sister along with her, and the two young merfolk sat down on the beach with the other youths just as Elder Misha began to speak.
<G-vec00057-002-s362><speak.ansprechen><de> Benni Elon und Avigdor Liebermann, die rechtsextremen Minister, sprechen offen darüber.
<G-vec00057-002-s362><speak.ansprechen><en> Benni Elon and Avigdor Liebermann, the extreme right ministers, speak about it openly.
<G-vec00057-002-s363><speak.ansprechen><de> Wenn Sie mit uns sprechen möchten, rufen Sie bitte unsere Reservierungszentrale unter + +84.4.3927 4120 an oder per Live-Chat während unserer Geschäftszeiten.
<G-vec00057-002-s363><speak.ansprechen><en> If you wish to speak to us, please call our Reservation Center at ++84.4.3927 4120 and live chat during our business office hours.
<G-vec00057-002-s364><speak.ansprechen><de> Ein erster Schritt in diese Richtung ist, fremde Sprachen zu sprechen und die damit verbundenen Kulturen zu verstehen.
<G-vec00057-002-s364><speak.ansprechen><en> A first step in this direction is to be able to speak a foreign language and therefore gain a better understanding of the underlying culture of a country.
<G-vec00057-002-s365><speak.ansprechen><de> Das Steigern des Selbstvertrauens um Türkisch in verschiedenartigen Situation sprechen zu können.
<G-vec00057-002-s365><speak.ansprechen><en> Building confidence to speak Turkish in different situations.
<G-vec00057-002-s366><speak.ansprechen><de> Etwas weniger als ein Jahr zuvor, begann Jesus offen mit Seinen Jüngern über Seinen Tod zu sprechen.
<G-vec00057-002-s366><speak.ansprechen><en> Then Jesus began to speak about His death openly with His disciples a little less than a year beforehand.
<G-vec00057-002-s367><speak.ansprechen><de> Kein Wort in Marathi, der Sprache, die die Menschen hier zumeist als einzige sprechen.
<G-vec00057-002-s367><speak.ansprechen><en> Not a single word is written in Marathi, the only language that most people here speak.
<G-vec00057-002-s368><speak.ansprechen><de> Naotaka Miyamoto, der in seinem Beruf hauptsächlich für Modezeitschriften und Werbung fotografiert, rückt seine Modelle mit dieser Serie in die Nähe ihrer Artgenossen auf der Kinoleinwand, die in Animationsfilmen oft sprechen, singen und tanzen können.
<G-vec00057-002-s368><speak.ansprechen><en> Naotaka Miyamoto, who as a photographer works primarily for fashion magazines and advertising, brings the models in this series close to their brethren on the big screen, who in animated films can often speak, sing and dance.
<G-vec00057-002-s369><speak.ansprechen><de> Das erste, was Sie tun müssen, ist zu lernen, das grundlegende Chinesisch zu sprechen, weil die Mehrheit der Menschen kein Englisch in China versteht.
<G-vec00057-002-s369><speak.ansprechen><en> Beijing The first of you want to do is learn to speak the basic Chinese because the majority of people does not understand English in China.
<G-vec00057-002-s370><speak.ansprechen><de> Sie können auch mit anderen sprechen, die auch Englisch lernen.
<G-vec00057-002-s370><speak.ansprechen><en> You can also speak with others who are learning English.
<G-vec00057-002-s371><speak.ansprechen><de> Es war wohl kaum damit gemeint so zu sprechen, dass niemand es verstehen kann.
<G-vec00057-002-s371><speak.ansprechen><en> It hardly meant to speak in a way that nobody can understand.
<G-vec00057-002-s372><speak.ansprechen><de> Bilder sollten für sich sprechen.
<G-vec00057-002-s372><speak.ansprechen><en> Pictures should speak for themselves.
<G-vec00057-002-s373><speak.ansprechen><de> Wir sprechen oft davon, welche Kraft vom Kreis der Schwestern in der Kirche Jesu Christi ausgeht.
<G-vec00057-002-s373><speak.ansprechen><en> We speak often of the strength of the circle of sisters in the Church of Jesus Christ.
<G-vec00057-002-s374><speak.ansprechen><de> Sprechen Sie in die Uhr, erhalten Sie eine Übersetzung, und zeigen Sie zur einfachen Kommunikation in der Sprache Ihrer Wahl Ihrem Gegenüber den Bildschirm.
<G-vec00057-002-s374><speak.ansprechen><en> Speak into the watch, receive a translation and show the screen to communicate easily in the language of your choice.
<G-vec00057-002-s375><speak.ansprechen><de> Frauen zeigen ihr Gesicht offen und sprechen bereitwillig mit Fremden.
<G-vec00057-002-s375><speak.ansprechen><en> The women don’t cover their faces and readily speak to foreigners.
<G-vec00057-002-s376><speak.ansprechen><de> Er wurde über die Ergebnisse des Referendums informiert, sagte das Weiße Haus und wurde am nächsten Tag zu Cameron zu sprechen erwartet.
<G-vec00057-002-s376><speak.ansprechen><en> He was briefed on the results of the referendum, the White House said, and was expected to speak to Cameron in the next day.
<G-vec00057-002-s377><speak.ansprechen><de> Es ist wichtig, dies für eure Zukunft zu wissen und um zu lernen, gut denken zu können, gut sprechen zu können, um nicht dauernd einen Lärm zu machen, sei es einen hörbaren oder nicht hörbaren Lärm.
<G-vec00057-002-s377><speak.ansprechen><en> It is important to know for your future and to learn to think well, to speak well, to not constantly make a deafening noise, whether this noise is audible or not.
<G-vec00057-002-s378><speak.ansprechen><de> Fortgeschrittenen-Spanischkurse in der Schweiz sind für Lernende, die Spanisch fließend und ohne Fehler sprechen können.
<G-vec00057-002-s378><speak.ansprechen><en> Advanced Spanish courses in Havana are for students who can speak Spanish fluently and without mistakes.
<G-vec00057-002-s379><speak.ansprechen><de> Wir respektieren Meinungsverschiedenheiten innerhalb der jüdischen Gemeinschaft über diese Angelegenheiten und erkennen an, dass Dabru Emet nicht für alle Juden sprechen kann und auch nicht behauptet, dies zu tun.
<G-vec00057-002-s379><speak.ansprechen><en> We respect disagreements within the Jewish community over these issues, and acknowledge that Dabru Emet cannot speak for all Jews and does not claim to do so.
<G-vec00057-002-s380><speak.ansprechen><de> Sprecht mit dem Ältesten des Arkanen (8,-430), welcher auf dem Turm im Süden von Jadeon sitzt.
<G-vec00057-002-s380><speak.ansprechen><en> Speak with the Elder of Arcaneness (8, -430) atop the spire in the southern end of Jadeon.
<G-vec00057-002-s381><speak.ansprechen><de> Ich als Mutter ersuche euch, dass ihr mit eurem Leben über die Herrlichkeit Gottes sprecht, denn auf diese Weise werdet ihr auch euch nach Seinem Willen verherrlichen.
<G-vec00057-002-s381><speak.ansprechen><en> As a mother I am asking you to speak about the glory of God with your life because, in that way, you will also glorify yourself in accordance to His will.
<G-vec00057-002-s382><speak.ansprechen><de> Sprecht Worte des Trostes zu Jerusalem und gebt bekannt, dass ihr Krieg zu Ende ist, dass ihre Ungerechtigkeit vergeben ist: Denn sie hat aus der Hand des Herrn das Doppelte für ihre Sünden empfangen.
<G-vec00057-002-s382><speak.ansprechen><en> Speak words of comfort to Jerusalem and announce to her that her warfare is finished, that her iniquity is pardoned: For she has received of the Lord's hand double for her sins.
<G-vec00057-002-s383><speak.ansprechen><de> Geht nach Drachenfall und sprecht mit Präfekt Ghazi.
<G-vec00057-002-s383><speak.ansprechen><en> Go to Dragonfall and speak to Prefect Ghazi.
<G-vec00057-002-s384><speak.ansprechen><de> Khem Val - Sprecht mit ihr.
<G-vec00057-002-s384><speak.ansprechen><en> Khem Val - Speak to her.
<G-vec00057-002-s385><speak.ansprechen><de> Ihr sprecht nur die Wahrheit, und habt es nur auf Wahrheit abgesehen.
<G-vec00057-002-s385><speak.ansprechen><en> You speak only the truth and are intent only on that which is true.
<G-vec00057-002-s386><speak.ansprechen><de> Seid vorsichtig, wenn ihr zum Geist sprecht und um Führung bittet.
<G-vec00057-002-s386><speak.ansprechen><en> Be wary when you speak to spirit and ask for guidance.
<G-vec00057-002-s387><speak.ansprechen><de> Sprecht mit Korgaz, wenn Ihr bereit seid, weitere Todesritter zu rekrutieren.
<G-vec00057-002-s387><speak.ansprechen><en> Speak with Korgaz when you are ready to recruit additional death knights.]
<G-vec00057-002-s388><speak.ansprechen><de> Sprecht nicht ohne das Bismillah.
<G-vec00057-002-s388><speak.ansprechen><en> Don't speak without the Bismillah.
<G-vec00057-002-s389><speak.ansprechen><de> Sprecht mit Sozia vor den Toren von Colchester.
<G-vec00057-002-s389><speak.ansprechen><en> Speak with Sozia on the outskirts of Colchester.
<G-vec00057-002-s390><speak.ansprechen><de> Sprecht erneut mit Kommandantin Fraya.
<G-vec00057-002-s390><speak.ansprechen><en> Speak with Commander Fraya again.
<G-vec00057-002-s391><speak.ansprechen><de> Sprich: Bringt eure Beweise darüber, so ihr die Wahrheit sprecht.
<G-vec00057-002-s391><speak.ansprechen><en> Say, produce your proof thereof, if ye speak truth.
<G-vec00057-002-s392><speak.ansprechen><de> Sprecht nur aus eurem Herzen.
<G-vec00057-002-s392><speak.ansprechen><en> Speak only from your heart.
<G-vec00057-002-s393><speak.ansprechen><de> Sprecht mit Namsa.
<G-vec00057-002-s393><speak.ansprechen><en> Speak with Namsa.
<G-vec00057-002-s394><speak.ansprechen><de> Geht und sprecht mit Lanric und seht, welche Hilfe Ihr ihm geben könnt.
<G-vec00057-002-s394><speak.ansprechen><en> Go speak with Lanric, and see what assistance you may be able to provide him.
<G-vec00057-002-s395><speak.ansprechen><de> Sprecht mit Jelena.
<G-vec00057-002-s395><speak.ansprechen><en> Speak to Jelena.
<G-vec00057-002-s396><speak.ansprechen><de> Nadia Grell - Ihr müsst wirklich nachdenken, bevor Ihr sprecht.
<G-vec00057-002-s396><speak.ansprechen><en> Nadia Grell - You really, really need to think before you speak.
<G-vec00057-002-s397><speak.ansprechen><de> Seht in den Spiegel und sprecht diese Worte.
<G-vec00057-002-s397><speak.ansprechen><en> Look in the mirror and speak these words.
<G-vec00057-002-s398><speak.ansprechen><de> Sprecht mit Lupus auf dem Ausblick des Vorarbeiters.
<G-vec00057-002-s398><speak.ansprechen><en> Speak with Lupus on the Foreman's Outlook.
<G-vec00057-002-s399><speak.ansprechen><de> Sprich in einem ruhigen Tonfall.
<G-vec00057-002-s399><speak.ansprechen><en> Speak in a calm tone of voice.
<G-vec00057-002-s400><speak.ansprechen><de> 2 So spricht der HERR, der Gott Israels: Geh hin und sprich mit Zedekia, dem König von Juda, und sage zu ihm: So spricht der HERR: Siehe, ich will diese Stadt in die Hände des Königs von Babel geben, und er soll sie mit Feuer verbrennen.
<G-vec00057-002-s400><speak.ansprechen><en> “Thus says the Lord, the God of Israel: Go, and speak to Zedekiah, the king of Judah. And you shall say to him: Thus says the Lord: Behold, I will deliver this city into the hands of the king of Babylon, and he will burn it with fire.
<G-vec00057-002-s401><speak.ansprechen><de> Sprich in einem respektvollen Ton und drücke dich positiv aus.
<G-vec00057-002-s401><speak.ansprechen><en> Try to speak in a respectful tone and phrase things in a positive manner.
<G-vec00057-002-s402><speak.ansprechen><de> Von der Freundschaft Und ein junger Mann sprach: Sprich uns von der Freundschaft.
<G-vec00057-002-s402><speak.ansprechen><en> On Friendship And a youth said, Speak to us of Friendship.
<G-vec00057-002-s403><speak.ansprechen><de> Sprich mit deinem Arzt über die Einnahme oraler Medikamente gegen Akne.
<G-vec00057-002-s403><speak.ansprechen><en> Speak to your doctor about taking oral medications for acne.
<G-vec00057-002-s404><speak.ansprechen><de> •"Sprich heute Abend nicht von deinem Weggehen", bat Diana.
<G-vec00057-002-s404><speak.ansprechen><en> •"Don't speak of your going away to-night," begged Diana.
<G-vec00057-002-s405><speak.ansprechen><de> Sprich mit Celio und er wird dir erklären, dass du einen Gegenstand für seine Maschine finden musst.
<G-vec00057-002-s405><speak.ansprechen><en> Speak to Celio and he will explain that you need to find an item for his machine.
<G-vec00057-002-s406><speak.ansprechen><de> Dieses Buch ist zu Beginn ähnlich wie ‚Sprich‘ von Anderson, nur viel, viel besser – meiner Meinung nach.
<G-vec00057-002-s406><speak.ansprechen><en> This book is at the beginning very similar to the book ‘Speak’ by Anderson, but it was written much better – in my opinion.
<G-vec00057-002-s407><speak.ansprechen><de> Sprich langsam und mit Bedacht.
<G-vec00057-002-s407><speak.ansprechen><en> Speak slowly and deliberately.
<G-vec00057-002-s408><speak.ansprechen><de> Sprich mit einer verführerischen Stimme.
<G-vec00057-002-s408><speak.ansprechen><en> Speak in a seductive voice.
<G-vec00057-002-s409><speak.ansprechen><de> 11Und nun sprich zu den Leuten in Juda und zu den Bürgern Jerusalems: So spricht der HERR: Siehe, ich bereite euch Unheil und habe gegen euch etwas im Sinn.
<G-vec00057-002-s409><speak.ansprechen><en> Now therefore go to, speak to the men of Judah, and to the inhabitants of Jerusalem, saying, Thus saith the LORD; Behold, I frame evil against you, and devise a device against you: return ye now every one from his evil way, and make your ways and your doings good.
<G-vec00057-002-s410><speak.ansprechen><de> Sprich mit mir, meine Geliebte.
<G-vec00057-002-s410><speak.ansprechen><en> Speak to me, my love!
<G-vec00057-002-s411><speak.ansprechen><de> Sprich mit deinem Arzt, bevor du sie einnimmst.
<G-vec00057-002-s411><speak.ansprechen><en> Speak with your doctor before incorporating supplements into your lifestyle.
<G-vec00057-002-s412><speak.ansprechen><de> Schließe die Prosperklippe ab und sprich mit der Sängerin in der Bastion.
<G-vec00057-002-s412><speak.ansprechen><en> Complete Prosper Bluff and speak with the Singer in the Bastion.
<G-vec00057-002-s413><speak.ansprechen><de> Sprich mit Moff Phennir im Besprechungsraum der White Nova.
<G-vec00057-002-s413><speak.ansprechen><en> Speak to Moff Phennir in the situation room of the White Nova.
<G-vec00057-002-s414><speak.ansprechen><de> Sprich wie ein Kind.
<G-vec00057-002-s414><speak.ansprechen><en> Speak like a kid.
<G-vec00057-002-s415><speak.ansprechen><de> Sprich & Übersetze Pro ist ein unverzichtbarer Stimmen- und Textübersetzer, mit dessen Hilfe Sie effektiv in allen Ecken der Erde kommunizieren können.
<G-vec00057-002-s415><speak.ansprechen><en> Free Speak & Translate is an indispensable voice and text translator that allows you to communicate effectively in any corner of the globe.
<G-vec00057-002-s416><speak.ansprechen><de> Sprich nicht zu laut, da es sonst wirken wird, als würdest du schreien.
<G-vec00057-002-s416><speak.ansprechen><en> Don't speak too loudly, or it will sound like you're shouting.
<G-vec00057-002-s417><speak.ansprechen><de> Sprich mit deinem Arzt oder einer Hebamme, bevor du dein Essverhalten in irgendeiner Weise einschränkst.
<G-vec00057-002-s417><speak.ansprechen><en> Speak to your doctor or midwife before restricting your diet or any specific food group.
<G-vec00057-002-s418><speak.ansprechen><de> Deine Gedanken sind positiv und du sprichst in einer positiven Art.
<G-vec00057-002-s418><speak.ansprechen><en> Your thoughts are positive and the way you speak is positive.
<G-vec00057-002-s419><speak.ansprechen><de> Du sprichst oft so grausam objektiv, wenn du Menschen und ihre Eigenschaften beschreibst.
<G-vec00057-002-s419><speak.ansprechen><en> You often speak so cruelly objectively when you describe human beings and their qualities.
<G-vec00057-002-s420><speak.ansprechen><de> Übe das projizieren von deinem Zwerchfell, indem du deinen Magen einziehst, um auszuatmen, während du sprichst.
<G-vec00057-002-s420><speak.ansprechen><en> Practice projecting from your diaphragm by pulling your stomach in to exhale as you speak.
<G-vec00057-002-s421><speak.ansprechen><de> Und wenn du besonders von Kraken sprichst, dann kann ich dir dazu erklären, dass es solche Riesenwesen in den Meeren tatsächlich gibt, nur dass sie in sehr großen Tiefen leben und nur selten an die Meeresoberfläche kommen.
<G-vec00057-002-s421><speak.ansprechen><en> Es And since you speak of squid in particular, I can tell you this, that there are actually such gigantic creatures in the oceans; it’s just that they live at very great depths and only rarely come to the surface of the ocean.
<G-vec00057-002-s422><speak.ansprechen><de> »Du sprichst von Gefahr.
<G-vec00057-002-s422><speak.ansprechen><en> — “You speak of danger.
<G-vec00057-002-s423><speak.ansprechen><de> Du sprichst für Mich.
<G-vec00057-002-s423><speak.ansprechen><en> You speak for Me.
<G-vec00057-002-s424><speak.ansprechen><de> Falls du Englisch nicht sehr gut sprichst oder falls Englisch nicht deine Muttersprache ist, könnte dies für dich frustrierend sein.
<G-vec00057-002-s424><speak.ansprechen><en> So, if you don't speak English very well, or even just if it's not your native tongue, you may find this frustrating at times.
<G-vec00057-002-s425><speak.ansprechen><de> Ich glaube, die Welten von denen du sprichst, sind jene, die für Dichter, phantasiebegabte Menschen und einige Künstler von besonderer Anziehung und besonderer Gefahr sind.
<G-vec00057-002-s425><speak.ansprechen><en> I think the worlds of which you speak are those which have a special attraction and a special danger for poets, imaginative people and some artists.
<G-vec00057-002-s426><speak.ansprechen><de> 21 Er antwortete ihm: Siehe, auch das will ich dir gewähren und die Stadt, von der du sprichst, nicht zum Einsturz bringen.
<G-vec00057-002-s426><speak.ansprechen><en> 21 He said to him, “Very well, I will grant this request too; I will not overthrow the town you speak of.
<G-vec00057-002-s427><speak.ansprechen><de> Eine Verengung der Luftwege aufgrund von Krebs kann ebenfalls die Art, wie du sprichst und die Qualität deiner Stimme beeinträchtigen.
<G-vec00057-002-s427><speak.ansprechen><en> An airway obstruction due to cancer can also change how you speak and the quality of your voice.
<G-vec00057-002-s428><speak.ansprechen><de> Frage -alles, was du willst, obwohl dein Vater genau weiß, was du benötigst, bevor du zu ihm sprichst.
<G-vec00057-002-s428><speak.ansprechen><en> Ask- for what you want, although your Father knows exactly what you need before you speak to him.
<G-vec00057-002-s429><speak.ansprechen><de> Wenn du kein Thai sprichst oder es in deiner Nähe keine englisch sprechenden Thais gibt, möchtest du dem Schaffner im Zug vielleicht dein Ziel sagen.
<G-vec00057-002-s429><speak.ansprechen><en> If you don't speak any Thai or there aren't English speaking Thais around you, you might want to tell the conductor or train attendant your destination.
<G-vec00057-002-s430><speak.ansprechen><de> Denke daran, gerade zu stehen, tief zu atmen und deinen Mund ganz zu öffnen, wenn du sprichst.
<G-vec00057-002-s430><speak.ansprechen><en> Remember to stand up straight, breathe deeply and open your mouth fully when you speak.
<G-vec00057-002-s431><speak.ansprechen><de> “Du wirst lernen, zu denken bevor du sprichst und handelst.
<G-vec00057-002-s431><speak.ansprechen><en> “You will learn to think before you speak and act.
<G-vec00057-002-s432><speak.ansprechen><de> In einem Büro wirst du keinen Tutor finden, der dafür bezahlt wird, sich deine Probleme anzuhören – du wirst sie also alleine lösen müssen, oder indem du mit deinem Chef oder deinen Kollegen sprichst.
<G-vec00057-002-s432><speak.ansprechen><en> In an office you will not find a tutor who is paid to listen to you difficulties, but you will have to face them without one (alone or trying to speak with your boss or colleagues).
<G-vec00057-002-s433><speak.ansprechen><de> Wie schön du sprichst, o Shah Mardan.
<G-vec00057-002-s433><speak.ansprechen><en> How beautifully you speak O Shah Mardan!
<G-vec00057-002-s434><speak.ansprechen><de> Du sprichst verhandlungssicher Deutsch, verhandlungssicheres Englisch ist ein Plus.
<G-vec00057-002-s434><speak.ansprechen><en> You speak fluent German, fluent English is a plus.
<G-vec00057-002-s435><speak.ansprechen><de> Wenn sie dir ihre volle Aufmerksamkeit schenkt, während du sprichst, dann kann das ein Zeichen sein.
<G-vec00057-002-s435><speak.ansprechen><en> If she gives you her full attention when you speak, this can sometimes be a sign.
<G-vec00057-002-s436><speak.ansprechen><de> Q: Du sprichst von deiner Leidenschaft und deinem Hunger, doch es gab letztes Jahr einige Tiefpunkte.
<G-vec00057-002-s436><speak.ansprechen><en> Q: (Unknown) You speak of your passion and your hunger but there were some really low moments last season.
<G-vec00057-002-s437><speak.ansprechen><de> Da sie gut englisch spricht und wir nur schlecht haben wir uns mit Händen und Füße unterhalten....geht aber auch.
<G-vec00057-002-s437><speak.ansprechen><en> As they speak English well and we only bad we talked with hands and feet.... but goes.
<G-vec00057-002-s438><speak.ansprechen><de> Im Büro des Hafenmeisters spricht man Deutsch und Englisch.
<G-vec00057-002-s438><speak.ansprechen><en> Harbour master’s staff speak German and English. Address Jachtcenter Elburg
<G-vec00057-002-s439><speak.ansprechen><de> Wann immer ich jemanden höre der mit einem persischen Akzent spricht,...
<G-vec00057-002-s439><speak.ansprechen><en> Whenever I hear someone speak with a Persian accent it makes my day."
<G-vec00057-002-s440><speak.ansprechen><de> Nick Bane, der eine neue Open-Hardware ARM-Plattform vorstellte - 'Balloon', die ungefähr 8 Sprachen mit 3 verschiedenen Synthesizern spricht.
<G-vec00057-002-s440><speak.ansprechen><en> Nick Bane, demonstrating a new open-hardware ARM platform - 'Balloon' which could speak about 8 languages using 3 different synthesisers.
<G-vec00057-002-s441><speak.ansprechen><de> Gespräche gab es keine, weil Van der Sloot kein Spanisch spricht, sondern er rauchte und schlief nur auf der Rückbank.
<G-vec00057-002-s441><speak.ansprechen><en> Van der Sloot does not speak Spanish and there was no conversation, only smoked and slept in the back of the back seat.
<G-vec00057-002-s442><speak.ansprechen><de> “Meine Großmutter, die kein Englisch spricht, tauchte mit einigen Luftballons zum Geburtstag meiner Schwester auf”, schreibt sie und lässt die Ballons sonst für sich selbst sprechen.
<G-vec00057-002-s442><speak.ansprechen><en> “My grandma who doesn’t speak English showed up with some birthday balloons for my sister…” Ariana tweeted, letting the words on the balloons speak for themselves.
<G-vec00057-002-s443><speak.ansprechen><de> Da Jaume nicht so gut Englisch spricht, hat Patricia alles mit uns geregelt, sie spricht perfekt Englisch und sogar Deutsch.
<G-vec00057-002-s443><speak.ansprechen><en> As Jaume not so good speak English, Patricia has arranged everything with us, she speaks perfect English and even German.
<G-vec00057-002-s444><speak.ansprechen><de> Keine dieser Gruppen spricht von einer anderen als dieser Welt.
<G-vec00057-002-s444><speak.ansprechen><en> Neither of these classes speak of any other world besides this one.
<G-vec00057-002-s445><speak.ansprechen><de> Die wenigen Begegnungen mit anderen Menschen finden in Sprachen statt, die er nicht spricht, und bringen ihn in Kontakt mit Körpern, die ihn faszinieren, und mit Liebesarten, die er ausprobiert und verliert.
<G-vec00057-002-s445><speak.ansprechen><en> The rare encounters with other people are in languages he does not speak, determined by bodies that fascinate him, and by types of love he explores and then loses.
<G-vec00057-002-s446><speak.ansprechen><de> Es ist sehr häufig, daß man auf das Verhältnis des Preises zwischen dem Gold und dem Silber verweist, man spricht manchmal über ihre Produktion.
<G-vec00057-002-s446><speak.ansprechen><en> It is very frequent that we made reference to the ratio of the price between the gold and the silver, sometimes we speak about their production.
<G-vec00057-002-s447><speak.ansprechen><de> Tendenz: Angebotsseitig spricht Vieles für einen weiteren Anstieg des europäischen Preisgefüges.
<G-vec00057-002-s447><speak.ansprechen><en> Trend: With regard to supply, many arguments speak for a further increase to be expected in the European price structure.
<G-vec00057-002-s448><speak.ansprechen><de> Da spricht eine Stimme zur Welt, in einer leichten, traurig-fröhlichen Sprache, die unsere Befindlichkeiten und Gefühle in ihrer ganzen Tragweite, aber auch ihrer ganzen unspektakulären Bekanntheit erzählt.
<G-vec00057-002-s448><speak.ansprechen><en> Their voices speak to the world in a light and happily sad language to describe not only the scope of our sensitivities and emotions, but also their commonplace normality. Impressum
<G-vec00057-002-s449><speak.ansprechen><de> Lou ist schwer und grau, sieht nicht gut, riecht nach Heu, isst wahnsinnig viel, spricht nicht, eckt ständig an, guckt manchmal böse und steht meistens einfach so da.
<G-vec00057-002-s449><speak.ansprechen><en> Loo is heavy and grey, has a bad eyesight, smells like hay, eats really a lot, does not speak, puts people`s backs up, sometimes looks angry and mostly he is just standing around.
<G-vec00057-002-s450><speak.ansprechen><de> Ungarn spricht in diesem ersten Halbjahr für die ganze Europäische Union, für uns alle.
<G-vec00057-002-s450><speak.ansprechen><en> In the first half of this year, Hungary will speak on behalf of the entire European Union, on behalf of us all.
<G-vec00057-002-s451><speak.ansprechen><de> Bei Dr. Hauschka spricht man deshalb von Hautbildern, die auftreten und wieder abklingen – statt von unveränderbaren Hauttypen.
<G-vec00057-002-s451><speak.ansprechen><en> When Dr. Hauschka therefore we speak of skin images that appear and disappear - instead of immutable skin types.
<G-vec00057-002-s452><speak.ansprechen><de> Wer Dialekt spricht, hat viele Vorteile.
<G-vec00057-002-s452><speak.ansprechen><en> Those who speak in dialect have many advantages.
<G-vec00057-002-s453><speak.ansprechen><de> Selbst wenn eine alleinerziehende Mutter nicht laut spricht, empfindet das Kind ihre Ablehnung.
<G-vec00057-002-s453><speak.ansprechen><en> Even if a single mother does not speak out loud about it, the child feels rejection on her part.
<G-vec00057-002-s454><speak.ansprechen><de> Man kann sehen, dass der Autor versuchte der Geschichte einen lustigen Aspekt hinzuzufügen, indem ein Charakter auf einer komischen Art und Weise spricht.
<G-vec00057-002-s454><speak.ansprechen><en> We can tell that the author tried to add a comical manga-like aspect to the story by making a character speak in a strange way.
<G-vec00057-002-s455><speak.ansprechen><de> Die Bilanz spricht für sich: 1938, in seiner ersten Saison, gewinnt der BMW Werksfahrer die Europameisterschaft.
<G-vec00057-002-s455><speak.ansprechen><en> The results speak for themselves: In 1938, his first season, the BMW factory driver won the European Championship.
<G-vec00161-002-s019><speak_out.ansprechen><de> Bonuspunkte gibt es, wenn Sie ein Moodboard mit Farbfeldern und Schriften, die Sie ansprechen, sowie Beispielbildern anderer Marken, die Sie mögen, haben.
<G-vec00161-002-s019><speak_out.ansprechen><en> Bonus points if you include a mood board with colour swatches, fonts that speak to you, images with examples from other brands that you like helps a lot.
<G-vec00161-002-s020><speak_out.ansprechen><de> Sie zeigt die Fähigkeit der visuellen Kunst, tief bewegende moralische und politische Botschaften zu vermitteln, die Menschen aus allen Schichten wirkungsvoll ansprechen.
<G-vec00161-002-s020><speak_out.ansprechen><en> It also proclaims the power of visual art to convey profoundly emotive and effective moral and political messages that can speak effectively to people of all walks of life.
<G-vec00161-002-s021><speak_out.ansprechen><de> Zum Beispiel nenne ich immer wieder unseren Sohn mit dem Namen meines Kollegen und mein Kollege muss sich von mir mit dem Vornamen unseres Sohnes ansprechen lassen.
<G-vec00161-002-s021><speak_out.ansprechen><en> For example, I always call our son with the name of my colleague and my colleague must bear it that I speak to him with the first name of our son.
<G-vec00161-002-s022><speak_out.ansprechen><de> Und es war der Wille jedes einzelnen Menschen entscheidend, ob er in den Segen Meiner Ansprache gekommen ist, aber Ich konnte ihn erst einmal ansprechen, was sonst nicht möglich gewesen wäre, weil Ich keinen Menschen zwinge, Mich anzuhören, wenn Ich zu ihm spreche, und weil auch kein Mensch die Stimme des Vaters erkennen würde, wenn er nicht dazu den Willen hätte, sich direkt ansprechen zu lassen von Mir.
<G-vec00161-002-s022><speak_out.ansprechen><en> The will of every single human being was decisive whether he derived a blessing from My Word but at least I was able to speak to him in the first place, which otherwise would not have been possible because I do not force anyone to listen to Me when I speak to him, and because no human being would know the voice of the Father if he did not want to be spoken to by Me directly.
<G-vec00161-002-s023><speak_out.ansprechen><de> Bei Fragen könnt ihr uns gerne kontaktieren oder unsere Mitarbeiter im Park ansprechen.
<G-vec00161-002-s023><speak_out.ansprechen><en> If you have any questions, please feel free to contact us, or speak to a member of staff in the park.
<G-vec00161-002-s024><speak_out.ansprechen><de> Die Studenten haben Versammlungen in hervorragender Weise geleitet, und es war wunderbar mitzuerleben, wie die 9/10-Jährigen Yaacov und Jerry dezent daran erinnerten, dass sie immer den Versammlungsleiter ansprechen sollen und warten müssen, bis sie an der Reihe sind und bis andere ausgeredet hatten.
<G-vec00161-002-s024><speak_out.ansprechen><en> The students did a great job of chairing the meetings and it was wonderful to see the 9/10 year olds gently reminding Yaacov and Jerry to speak through the chair and wait their turn till others had spoken!!
<G-vec00161-002-s025><speak_out.ansprechen><de> Wenn Ihr Flug annulliert wird oder sich über 2 Stunden verspätet und Sie sich den ungenutzten Abschnitt Ihres Tickets erstatten lassen möchten (einschließlich einiger Gebühren und/oder bezahlter Reiseoptionen), können Sie sich telefonisch an die Air-Canada-Reservierung wenden oder einen Flughafenmitarbeiter von Air Canada ansprechen.
<G-vec00161-002-s025><speak_out.ansprechen><en> If your flight is cancelled or delayed by more than 2 hours and you'd like to obtain a refund for the unused portion of your ticket (including some fees and/or purchased travel options), you can call Air Canada Reservations or speak to an Air Canada agent at the airport.
<G-vec00161-002-s026><speak_out.ansprechen><de> Was wir gerne ansprechen würden, sind die Reaktionen, die Fans hatten, über das was in den Medien verbreitet wurde, über unser Buch.
<G-vec00161-002-s026><speak_out.ansprechen><en> What we would like to speak on is the reaction some fans have had based on that’s being said about the book in the tabloid media.
<G-vec00161-002-s027><speak_out.ansprechen><de> Da es manchmal an Zeit und Mitteln für effektive Drogenaufklärung mangelt und die verwendeten Materialen oft nicht mehr zeitgerecht sind, ganz zu schweigen davon, dass sie nicht wirklich die Kinder ansprechen, können wir helfen.
<G-vec00161-002-s027><speak_out.ansprechen><en> While time and resources for effective drug education are sometimes lacking, and the materials used are often outdated, not to mention that they don’t factually speak to the kids, we can help.
<G-vec00161-002-s028><speak_out.ansprechen><de> Fragen Sie nach Trainingsvideos, FAQs und spezialisierten und erfahrenen Shipper Consultants, die Sie jederzeit in Ihrer Zeitzone und in Ihrer Sprache ansprechen können.
<G-vec00161-002-s028><speak_out.ansprechen><en> As back up, ask for training videos, FAQs and 24/7 access to specialized, experienced shipping consultants able to speak in your time zones and your languages.
<G-vec00161-002-s029><speak_out.ansprechen><de> Wer an Jesus Christus, den Sohn Gottes glaubt, wird in sein Sohnesrecht hinein genommen und kann Gott auch als seinen Vater durch Jesus Christus ansprechen.
<G-vec00161-002-s029><speak_out.ansprechen><en> Whoever believes in Jesus Christ, the Son of God, will receive the full rights of sonship. As a result they, too, can speak to God as their Father, through Jesus Christ.
<G-vec00161-002-s030><speak_out.ansprechen><de> Dann lasset sie ziehen, aber nehmet euch derer an, die euch suchen, die Ich auch durch euch Selbst ansprechen will, denen Ich Mein Wort bringen will, auf daß in ihnen Licht werde nach der tiefen Dunkelheit zuvor.
<G-vec00161-002-s030><speak_out.ansprechen><en> Then let them go but take care of those who seek you, to whom I also want to speak through yourselves, to whom I want to bring my word so that light comes into them after the deep darkness before.
<G-vec00161-002-s031><speak_out.ansprechen><de> Lasset euch immer wieder von Mir ansprechen, und trachtet nur danach, in Meinen Willen einzugehen, und ihr werdet mit Mir die Bindung herstellen, ihr werdet euch Mir anschließen und nun auch zu den Meinen gezählt werden, die Ich erretten werde, bevor das Ende kommt.
<G-vec00161-002-s031><speak_out.ansprechen><en> Again and again let me speak to you, and only strive for entering into my will, and you will establish the union with me, you will join me and will now also be counted with the ones who are mine, whom I will rescue before the end comes.
<G-vec00161-002-s032><speak_out.ansprechen><de> Daß Ich ihn ansprechen kann, stempelt ihn auch zu einem Diener in Meinem Weinberg, und dann wird er auch alle Aufträge gewissenhaft ausführen, die Ich ihm nun zuweise....
<G-vec00161-002-s032><speak_out.ansprechen><en> The fact that I can speak to him will also signify him as a servant in My vineyard, for then he will conscientiously accomplish all tasks which I assign to him....
<G-vec00161-002-s033><speak_out.ansprechen><de> Ich muss hier sagen, dass ich wenige Seminare besuche, da mich wenige von diesen direkt ansprechen.
<G-vec00161-002-s033><speak_out.ansprechen><en> I must say here that I attend a few seminars, since few of them speak to me directly.
<G-vec00161-002-s034><speak_out.ansprechen><de> Ich aber kenne die einzelnen Menschenherzen, und diesen führe Ich auch die Gnadengaben zu, Ich führe sie mit Meinen Weinbergsarbeitern zusammen, um sie direkt durch diese ansprechen zu können....
<G-vec00161-002-s034><speak_out.ansprechen><en> But I know the individual human hearts and it is to these that I will convey the gifts of grace; I will bring them together with My vineyard labourers in order to speak through them directly....
<G-vec00161-002-s035><speak_out.ansprechen><de> Wenn Sie Ihre Zielgruppe nicht genau kennen, können Sie auch nicht wissen, mit welchen Keywords Sie eine einzelne Person direkt ansprechen und auf die durchgeführten Aktionen reagieren können.
<G-vec00161-002-s035><speak_out.ansprechen><en> If you don’t know specifics about your audience, you can’t know which keywords will help you create experiences that speak directly to an individual and the actions they’re taking.
<G-vec00161-002-s036><speak_out.ansprechen><de> Wir können sie ansprechen, mit ihnen diskutieren, Aktionen starten.
<G-vec00161-002-s036><speak_out.ansprechen><en> We can speak to them, discuss with them, start actions.
<G-vec00161-002-s037><speak_out.ansprechen><de> Das Verfahren ist streng vertraulich und zweistufig aufgebaut, um die Hemmschwelle möglichst gering zu halten und Probleme frühzeitig und offen ansprechen zu können.
<G-vec00161-002-s037><speak_out.ansprechen><en> The process is strictly confidential and consists of two levels, making it as easy as possible for supervisors and doctoral candidates to overcome their inhibitions and speak openly about problems early on.
<G-vec00775-002-s030><engage.ansprechen><de> Verwerten Sie vorhandene Investitionen in SOAP-Dienste, um Kunden mithilfe von modernen Applikationen anzusprechen.
<G-vec00775-002-s030><engage.ansprechen><en> Leverage existing investments in SOAP services to engage with customers through modern apps.
<G-vec00775-002-s031><engage.ansprechen><de> Seit der Veröffentlichung von iOS 10 haben Sie nun die Möglichkeit Medien Dateien mit Ihren Push-Benachrichtigungen zu versenden, um Ihre App Nutzer mit noch reicherem Inhalt anzusprechen.
<G-vec00775-002-s031><engage.ansprechen><en> Since the release of iOS 10, you now have the possibility to attach media files to your Push Notifications in order to engage your app users with much richer content.
<G-vec00775-002-s032><engage.ansprechen><de> Ziel dieser neuen Initiative ist es, die Zukunftsentwürfe, neuen Logistikkonzepte, Angebote und Services der Aussteller noch deutlicher abzubilden, dem Besucher schneller kenntlich zu machen sowie neue Unternehmen und Besuchergruppen anzusprechen.
<G-vec00775-002-s032><engage.ansprechen><en> This new initiative aims to put a stronger focus on the future designs, new logistics concepts, offers and services from the exhibitors, to make them more recognizable to visitors, and to engage the interest of new companies and visitor groups.
<G-vec00775-002-s033><engage.ansprechen><de> Die persönliche Gestaltung ist eine der besten Möglichkeiten, um Ihre Zielgruppe mit einer Direktmarketingkampagne anzusprechen.
<G-vec00775-002-s033><engage.ansprechen><en> Personalisation is one of the best ways to engage your audience with your direct marketing campaign, and one company’s innovative invites ha…
<G-vec00775-002-s034><engage.ansprechen><de> Unser neuestes Global-Assessment-Barometer unterstrich die wachsende Notwendigkeit, die richtigen Bewerber mit der besten Passung für ein Unternehmen sehr früh während der Stellensuche oder im Karriereplan anzuziehen und anzusprechen.
<G-vec00775-002-s034><engage.ansprechen><en> Our latest Global Assessment Barometer highlighted the growth in the need to attract and engage with those with the best fit to an organisation very early on in a job search or career plan.
<G-vec00775-002-s035><engage.ansprechen><de> In-App-Messaging ermöglicht Ihnen, Mobile-App-Benutzer wirkungsvoller anzusprechen, da In-App-Messaging kontextuelle Interaktionen ermöglicht und Benutzer erreicht werden können, die sich von Push-Benachrichtigungen abgemeldet haben.
<G-vec00775-002-s035><engage.ansprechen><en> In-App messaging allows you to engage Mobile App users more effectively by providing contextual interaction and enabling you to reach users who may have opted out of Push notifications.
<G-vec00775-002-s036><engage.ansprechen><de> Auf der anderen Seite stellt der Kampf gegen Rassismus und Fremdenfeindlichkeit eine gute Organisierungsmöglichkeit dar, um eine breitere Mitgliederbasis auf der ganzen Welt anzusprechen.
<G-vec00775-002-s036><engage.ansprechen><en> On the other hand, fighting racism and xenophobia present a powerful organizing opportunity to engage a wider membership around the world.
<G-vec00775-002-s037><engage.ansprechen><de> Mit SAP Hybris Service Cloud integriert Bona seine Technologieplattform, um den Service zu verbessern und Kunden über neue Interaktionskanäle anzusprechen.
<G-vec00775-002-s037><engage.ansprechen><en> With SAP Service Cloud, Bona chose to integrate its technology platform to improve service and engage customers through new channels.
<G-vec00775-002-s038><engage.ansprechen><de> Im Falle der britischen Argos bedeutet dies in erster Linie, dass die Daten stärker genutzt werden, um die Kunden individueller anzusprechen.
<G-vec00775-002-s038><engage.ansprechen><en> In the case of the UK’s Argos, this means making greater use of data to engage shoppers in a more personalised way.
<G-vec00775-002-s039><engage.ansprechen><de> Ziel ist es, die Kunden an jeder Station der Consumer Journey anzusprechen – zu Hause, im Auto, an der Zapfsäule und im Store.
<G-vec00775-002-s039><engage.ansprechen><en> The aim is to engage customers at every point along their journey – at home, in the vehicle, on the forecourt and in the store.
<G-vec00775-002-s040><engage.ansprechen><de> Und auch mal aufs Emotionale setzen, zum Beispiel durch Humor und Spass – all das hilft dabei, Menschen anzusprechen, die von Politik sonst zu Tode gelangweilt sind … eine Sache, die Politiker ungern hören: dass Politik die meisten Menschen langweilt.
<G-vec00775-002-s040><engage.ansprechen><en> And focusing on the emotional argument, for example by using humour and fun – it helps to engage people who are otherwise bored to death by politics. Which is not something people who work in politics often want to hear: that politics is boring most people.
<G-vec00775-002-s041><engage.ansprechen><de> Nutzen Sie diese bekannten Präferenzen in Kombination mit Verhaltensmustern, um Ihre Zielgruppe effektiv über die Kanäle Telefon, E-Mail und SMS zu erreichen und anzusprechen.
<G-vec00775-002-s041><engage.ansprechen><en> Leveraging these known preferences, as well as prior behavior, allows you to orchestrate voice, email and text messages to effectively reach and engage the selected audience.
<G-vec00775-002-s042><engage.ansprechen><de> Analytische Prozeduren bestimmen, wann und wo personalisierte Inhalte auf Webseiten oder in mobilen Anwendungen platziert werden, um Kunden noch effektiver anzusprechen.
<G-vec00775-002-s042><engage.ansprechen><en> Analytical procedures determine when and where to place personalized content onto web pages or in mobile applications to more effectively engage customers.
<G-vec00775-002-s043><engage.ansprechen><de> Bona Mit SAP Hybris Service Cloud integriert Bona seine Technologieplattform, um den Service zu verbessern und Kunden über neue Interaktionskanäle anzusprechen.
<G-vec00775-002-s043><engage.ansprechen><en> Bona With SAP Hybris Cloud for Service, Bona chose to integrate its technology platform to improve service and engage customers through new channels.
