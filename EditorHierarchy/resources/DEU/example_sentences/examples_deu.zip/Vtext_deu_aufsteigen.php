<G-vec00510-001-s209><rise.aufsteigen><de> Ein Teil des Methans, ein starkes Treibhausgas, könnte dann in die Atmosphäre aufsteigen und den Klimawandel weiter anheizen – ein Teufelskreis.
<G-vec00510-001-s209><rise.aufsteigen><en> A portion of the methane, which is a powerful greenhouse gas, could then rise into the atmosphere and further accelerate the process of climate change – a vicious circle.
<G-vec00510-001-s210><rise.aufsteigen><de> Lasse so viele Tränen fließen, wie aufsteigen wollen und stoppe den Tränenfluss nicht.
<G-vec00510-001-s210><rise.aufsteigen><en> Let as many tears flow as want to rise and do not stop the flow of them.
<G-vec00510-001-s211><rise.aufsteigen><de> Dies mag der Grund sein, warum der Gedanke kaum zu glauben ist, dass wir unsere Sensitivität bis zu dem Punkt verfeinern könnten, an dem wir diese Welt mit dem intakten physischen Fahrzeug verlassenen könnten, aufsteigen zu höheren Ebenen und selbst so weit gehen, im Fleisch wieder zu erscheinen, wann und wenn es notwendig werden würde.
<G-vec00510-001-s211><rise.aufsteigen><en> This may be why the thought that we could refine our sensitivities to the point where we could leave this world with the physical vehicle intact, rise up to the higher levels, and even go so far as to reappear in the flesh, when and if it became necessary, is pretty hard to believe.
<G-vec00510-001-s212><rise.aufsteigen><de> Aber etwas in euch kann über die anderen aufsteigen, mit eurem Sinn für Würde, mit eurer vollständigen Selbstheit, wo ihr mit euch selbst dasteht.
<G-vec00510-001-s212><rise.aufsteigen><en> But something within you can rise above others with your sense of dignity, with your complete Selfhood, where you stand with yourself.
<G-vec00510-001-s213><rise.aufsteigen><de> Wenn einige Leute höher aufsteigen, werden andere mit ihnen wachsen.
<G-vec00510-001-s213><rise.aufsteigen><en> If some people rise higher, others will also start rising with them.
<G-vec00510-001-s214><rise.aufsteigen><de> Ach ja, ein weiteres erstes Mal im Mai – oder vielmehr viele: die kleinen Haufen der Wühlmäuse, die wie kleine Vulkane aufsteigen, unabhängig von Ort, Zeit und Raum.
<G-vec00510-001-s214><rise.aufsteigen><en> Oh yes, one more first in May –or really many: the little hills of the water voles that rise like volcanoes, regardless of place, time and space.
<G-vec00510-001-s215><rise.aufsteigen><de> Außerdem kann dadurch das Biogas besser aufsteigen.
<G-vec00510-001-s215><rise.aufsteigen><en> This also allows the biogas to rise more easily.
<G-vec00510-001-s216><rise.aufsteigen><de> Laßt ruhig euren Geist zur Wohnstätte des Schöpfers aufsteigen.
<G-vec00510-001-s216><rise.aufsteigen><en> Let thy spirit calmly rise to the Abode of the Creator.
<G-vec00510-001-s217><rise.aufsteigen><de> Wir flogen zuerst zu einer kleinen Einrichtungen, die aussah, als würde sie bis zur Mondoberfläche aufsteigen, mit Strukturen, die über dem Boden gebaut sind wie das LOC.
<G-vec00510-001-s217><rise.aufsteigen><en> We first flew up to a small facility that looked like it may rise up to the lunar surface, with structures built above ground like the LOC.
<G-vec00510-001-s218><rise.aufsteigen><de> Sein Maßnahmenpaket ist darauf ausgerichtet, die Universität als Ganzes weiterzuentwickeln, damit sie bis 2022 in den Kreis der 100 besten Universitäten weltweit aufsteigen kann.
<G-vec00510-001-s218><rise.aufsteigen><en> Its package of measures aims at the further development of the university as a whole, allowing it to rise to the level of the 100 best universities worldwide until 2022.
<G-vec00510-001-s219><rise.aufsteigen><de> "Nachdem Solvay zu einem globalen Unternehmen aufsteigen konnte, wurden Verträge mit der weltweiten Gewerkschaftsföderation ""IndustriALL "" geschlossen."
<G-vec00510-001-s219><rise.aufsteigen><en> "Subsequent to Solvay's rise to become a global company, contracts were concluded with the global union federation ""IndustriALL ""."
<G-vec00510-001-s220><rise.aufsteigen><de> Das geschieht nicht gleichmäßig, so dass riesige Magma-Tropfen aus der Schmelzzone aufsteigen.
<G-vec00510-001-s220><rise.aufsteigen><en> "This does not happen uniformly, so huge ""drops"" of magma rise from the melting zone."
<G-vec00510-001-s221><rise.aufsteigen><de> In der gleichen Weise... kann einer, der vielleicht bereits auf Ebene 8 oder 9 ist, auf die Stufe 18 – 20 aufsteigen... ebenfalls abhängig von IHREM Verständnis und der Bereitschaft des Herzens... was allerdings einen schnelleren Anstieg bedeutet als einer von der 3. oder der 4.
<G-vec00510-001-s221><rise.aufsteigen><en> In the same way too... one who is perhaps already on level 8 or 9 may rise to an 18 - 20 rung... depending also on THEIR level of understanding and willingness of heart... which will be of a more rapid increase than one of 3 or 4 .
<G-vec00510-001-s222><rise.aufsteigen><de> Āruhya kṛcchreṇa, durch schwere Entbehrungen und Buße, kann man zum unpersönlichen Brahman aufsteigen, doch man fällt wieder herunter.
<G-vec00510-001-s222><rise.aufsteigen><en> Āruhya kṛcchreṇa, by severe austerities and penances you can rise up to the impersonal Brahman, but you'll fall down again.
<G-vec00510-001-s223><rise.aufsteigen><de> Dann ist da noch die Anstrengung, um heilsame Eigenschaften aufsteigen zu lassen, und die Anstrengung, um sie zu erhalten, sobald sie einmal da sind.
<G-vec00510-001-s223><rise.aufsteigen><en> Then there's the effort to give rise to skillful qualities, and the effort to maintain them once they are there.
<G-vec00510-001-s224><rise.aufsteigen><de> Sie ist sehr lebhaft, wenn sie sich erhitzt, weil die Mineralien leicht schmelzen und Basalt bilden, der dann als Magma durch die darüber liegenden Schichten aufsteigen kann.
<G-vec00510-001-s224><rise.aufsteigen><en> This layer is dense when cold because of the garnet. It is buoyant when hot because these minerals melt easily to form basalt which can then rise through the upper layers as magma.
<G-vec00510-001-s225><rise.aufsteigen><de> Wenn ihr nicht kollektiv sein könnt, wird die Kundalini nie aufsteigen.
<G-vec00510-001-s225><rise.aufsteigen><en> If the collectivity is not there, your Kundalini will never rise.
<G-vec00510-001-s226><rise.aufsteigen><de> In diesen Zustand müsst ihr aufsteigen und erkennen, dass ihr in diesem Zustand seid.
<G-vec00510-001-s226><rise.aufsteigen><en> In that state you have to rise and you know that you are in that state.
<G-vec00510-001-s227><rise.aufsteigen><de> Während ich ich die volle Höhe des hinteren Teils vom Motorrad hinter mir aufsteigen fühlte, sah ich meinen Freund beginnen durch die Luft zu fliegen.
<G-vec00510-001-s227><rise.aufsteigen><en> As I felt the full height of the rear of the bike rise behind me, I saw my friend start to fly through the air.
<G-vec00510-001-s266><rise.aufsteigen><de> SONIC SYNDICATEs erstes Album, »Eden Fire« (2005) half der Band aus dem kühnen Schwedischen Underground aufzusteigen, doch es war ihr überwältigendes Nuclear Blast-Debüt »Only Inhuman« (2007), welches die Band vom vielversprechenden Newcomer zu einem der großen Kämpfer der Szene werden ließ.
<G-vec00510-001-s266><rise.aufsteigen><en> SONIC SYNDICATE's first album, »Eden Fire« (2005) saw the band rise from the intrepid Swedish underground, but it was their stunning debut under Nuclear Blast records with »Only Inhuman« (2007) that changed the band from promising contenders into one of the most revered heavy-weight fighters in the game.
<G-vec00510-001-s267><rise.aufsteigen><de> In der Praxis von Sahaja Yoga, um höher aufzusteigen, müssen wir unser eigenes Instrument verbessern, nicht das von anderen.
<G-vec00510-001-s267><rise.aufsteigen><en> In the practice of Sahaja Yoga, if you have to rise higher, you have to improve your own instrument, and not the instrument of others.
<G-vec00510-001-s268><rise.aufsteigen><de> Und er wurde Mitglied in der NSDAP, um in der Hierarchie der Jugendmusik (Bläsermusik) aufzusteigen.
<G-vec00510-001-s268><rise.aufsteigen><en> And he became a National socialist party member, to rise in the hierarchy of youth music (brass music).
<G-vec00510-001-s269><rise.aufsteigen><de> Als ich die Trennung zwischen Körper und Geist fühlte und eine Empfindung von Frieden mich überkam, und mein Geist aufzusteigen begann, es gab kein großartigeres Gefühl.
<G-vec00510-001-s269><rise.aufsteigen><en> When I felt the separation between body and spirit and a sense of peace came over me and my spirit began to rise there was no greater feeling.
<G-vec00510-001-s270><rise.aufsteigen><de> Und der Grund dafür, den Ich euch schon genannt habe, ist genau dort beschrieben: Die Kraft der Mutter, die weibliche Kraft wollte nicht, dass Ihre Kinder wie Tiere leben müssten, ohne das Wissen der höheren Regionen zu verstehen, ohne ihnen die Chance zu geben, durch ihre Freiheit aufzusteigen zu immer höherem Bewusstsein.
<G-vec00510-001-s270><rise.aufsteigen><en> The reason I gave you is exactly written there, that the Mother power, the feminine power, didn’t want Her children to live like animals without understanding what is the knowledge of the higher realms, not giving them chance to rise higher through their freedom and then to higher and higher awareness.
<G-vec00510-001-s271><rise.aufsteigen><de> Sie sollten in Entsprechung zu den verschiedenen Einteilungen der sozialen Ordnung entwickelt werden, denn wenn alle Klassen diese Eigenschaften durch Übung entwickeln, ist es trotz schlechter materieller Bedingungen möglich, allmählich bis zur höchsten Ebene transzendentaler Erkenntnis aufzusteigen.
<G-vec00510-001-s271><rise.aufsteigen><en> They should be cultivated according to the different statuses of the social order. The purport is that even though material conditions are miserable, if these qualities are developed by practice, by all classes of men, then gradually it is possible to rise to the highest platform of transcendental realization.
<G-vec00510-001-s272><rise.aufsteigen><de> Dein Körper beginnt sich zu entspannen, deine Schultern schwanken sanft, deine Arme beginnen aufzusteigen und dein Herz schlägt stärker.
<G-vec00510-001-s272><rise.aufsteigen><en> Your body starts to relax, your shoulders sway softly, your arms start to rise and your heart is pumping harder.
<G-vec00510-001-s273><rise.aufsteigen><de> Ich wurde mir meiner Umgebung voll bewusst, ich konnte die Hülle meines Körpers fühlen und mein Geist begann aufzusteigen; ein extremer Frieden überkam mich.
<G-vec00510-001-s273><rise.aufsteigen><en> I became fully aware of my surroundings I could feel the shell of my body and my spirit began to rise; an extreme peace came over me.
<G-vec00510-001-s274><rise.aufsteigen><de> Und gleichzeitig erreichen wir unsere schon längst überfällige Höherentwicklung.Die menschliche Rasse ist zum Fortschritt bereit Es ist höchste Zeit für das menschliche Geschlecht, zu einer höheren Bewusstseinsebene aufzusteigen.
<G-vec00510-001-s274><rise.aufsteigen><en> At the same time, we elevate ourselves, which has been long, long overdue. The Human Race is Ready to Advance It's the high time that the human race should rise to a higher level of consciousness.
<G-vec00510-001-s275><rise.aufsteigen><de> Eine Zivilisation ohne Wahnsinn, ohne Verbrecher und ohne Kriege, in welcher der Fähige erfolgreich sein kann und auch ehrliche Wesen Rechte haben können und in welcher der Mensch die Freiheit hat, zu größeren Höhen aufzusteigen - das sollten unsere Ziele sein.
<G-vec00510-001-s275><rise.aufsteigen><en> A civilization without insanity, without criminals, and without wars, where the skilled can be successful and where honest beings can have rights, and where man has the freedom to rise to greater heights – that should be our goals.
<G-vec00510-001-s276><rise.aufsteigen><de> Dies ist Teil einer umfassenderen strategischen Sichtweise und wir haben jetzt sieben Jahre Zeit, um an die Spitze der MotoGP-Klasse aufzusteigen.
<G-vec00510-001-s276><rise.aufsteigen><en> This is part of a wider strategic view and we now have seven years to rise towards the top of the MotoGP class; the same period of time we needed to conquer the Dakar Rally.
<G-vec00510-001-s277><rise.aufsteigen><de> Nun begann es aufzusteigen, euren Lebensraum loszulassen, alle eingelagerten dunklen Energien aus euren Körpern heraus zu saugen und mit sich zu nehmen – auch wenn es sich aus eurer menschlichen Sicht völlig anders anfühlte.
<G-vec00510-001-s277><rise.aufsteigen><en> Now it started to rise up leaving your living space and taking all inserted dark energies out of your bodies - even though you saw this so differently in your human view point.
<G-vec00510-001-s278><rise.aufsteigen><de> Da wurde euch aber auch verheißen, dass euch allezeit geholfen werden würde, wieder aufzusteigen, und dies hat sich jetzt erfüllt.
<G-vec00510-001-s278><rise.aufsteigen><en> However, you were promised that you would always be helped to rise up again, and now that has been fulfilled.
<G-vec00510-001-s279><rise.aufsteigen><de> Der Schmerz verging, Frieden kam über mich und mein Geist begann aus dem Körper aufzusteigen.
<G-vec00510-001-s279><rise.aufsteigen><en> The pain left peace came over me and my spirit began to rise from my body.
<G-vec00510-001-s280><rise.aufsteigen><de> Vor der Realisation sind die Leute, die Urteilsvermögen gehabt haben, die besten, um aufzusteigen.
<G-vec00510-001-s280><rise.aufsteigen><en> So before Realization, those people who have had discretion are the best people to rise.
<G-vec00510-001-s281><rise.aufsteigen><de> Unnötig zu erwähnen ist, dass die Amtsträger eines Landes, das weniger geneigt ist an höhere Prinzipien zu glauben, in Betracht ziehen, mit einem gottlosen und verbrecherischen Regime „zusammen aufzusteigen oder zusammen zu fallen“.
<G-vec00510-001-s281><rise.aufsteigen><en> "Needless to say, it is when a country is less inclined to believe in higher principles that its officials will consider to ""rise or fall together"" with a godless and criminal regime."
<G-vec00510-001-s282><rise.aufsteigen><de> Lasse mehr Propan heraus, um aufzusteigen.
<G-vec00510-001-s282><rise.aufsteigen><en> Let out more propane to rise.
<G-vec00510-001-s283><rise.aufsteigen><de> Ich begann über dem Wagen aufzusteigen, welcher mit guter Geschwindigkeit auf seinem Weg weiterfuhr.
<G-vec00510-001-s283><rise.aufsteigen><en> I began to rise above the car, which continued on its way at a good speed.
<G-vec00510-001-s284><rise.aufsteigen><de> Je höher ihr euch zugesteht aufzusteigen... desto mehr könnt ihr erkennen was möglich ist.
<G-vec00510-001-s284><rise.aufsteigen><en> The Higher you allow yourself to rise … the more you can recognise that which is possible.
