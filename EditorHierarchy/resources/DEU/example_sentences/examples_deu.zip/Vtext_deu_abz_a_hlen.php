<G-vec00206-001-s019><count.abzählen><de> Sie können an den Fingern abzählen.
<G-vec00206-001-s019><count.abzählen><en> They can count on the fingers.
<G-vec00206-001-s020><count.abzählen><de> In Zeile 16 ist ein Lineal zu sehen, das das Abzählen von Spalten erleichtern soll.
<G-vec00206-001-s020><count.abzählen><en> In line 16, there is a ruler, which is supposed to make it easier for you to count the columns.
<G-vec00206-001-s021><count.abzählen><de> "Die Firma Westinghouse präsentierte ""Elektro"" einen ""Moto-man"", 7 Fuß (2,13 Meter) gross und 130 Kilo schwer, der an den Fingern abzählen konnte [nicht wirklich]."
<G-vec00206-001-s021><count.abzählen><en> "The Westinghouse Company presented ""Elektro"", a ""moto-man"", 7 feet (2,13 meter) large and 130 kilo heavy, which was able to count by his fingers [not really]."
<G-vec00206-001-s022><count.abzählen><de> 9 Sieben Wochen sollst du dir abzählen; wenn man anfängt, die Sichel an die Saat zu legen, sollst du anfangen, sieben Wochen zu zählen.
<G-vec00206-001-s022><count.abzählen><en> "9 ""You shall count seven weeks for yourself; you shall begin to count seven weeks from the time you begin to put the sickle to the standing grain."
<G-vec00206-001-s023><count.abzählen><de> Bis 2012 konnten E-Bike-Experten die Anzahl der marktrelevanten Antriebssysteme noch relativ leicht mit einer Hand abzählen.
<G-vec00206-001-s023><count.abzählen><en> Until 2012, e-bike experts could still easily count the number of drive systems currently on the market on one hand.
<G-vec00206-001-s024><count.abzählen><de> Dazu werden ebenfalls wieder erst die vorhandenen Mittelachsen eingezeichnet und anschließend die Abstände der Mittelachsen nach rechts, links, vorne und hinten (einfach aus Seiten- und Frontansicht abzählen).
<G-vec00206-001-s024><count.abzählen><en> Once again, the middle lines are drawn and the distance from it to the front, back, left and right are plotted (simply count the studs based on the front and side view).
<G-vec00206-001-s025><count.abzählen><de> - Und ihr werdet die Auserwählten eines bedeutenden Ortes sehr leicht an den Fingern abzählen können.
<G-vec00206-001-s025><count.abzählen><en> And you will be able to count the chosen ones of even a prominent place, very easily on your fingers.
<G-vec00206-001-s026><count.abzählen><de> Ich erhielt auf einem Stuhl liegend zweimal 25 Hiebe mit einem Gummischlauch, die ich selbst abzählen musste.
<G-vec00206-001-s026><count.abzählen><en> On two occasions I was placed over a chair and received 25 strokes with a rubber hose, which they obliged me to count myself.
<G-vec00206-001-s027><count.abzählen><de> Ich kann wahrscheinlich an einer Hand abzählen die Unternehmen, die ich kenne, der eine Schneise Läufer machen etwas wert.
<G-vec00206-001-s027><count.abzählen><en> I can probably count on one hand the companies that I know who make an aisle runner worth anything.
<G-vec00206-001-s028><count.abzählen><de> Wir beschleunigten unsere Schritte und waren in der Zeit, in der man tausend Steine abzählen würde, an der ersten Abfallstelle des Nils.
<G-vec00206-001-s028><count.abzählen><en> We hurried onward and after the length of time it takes to count to a thousand, we came to the first cataract on the Nile.
<G-vec00206-001-s029><count.abzählen><de> Sieben Wochen sollst du dir abzählen.
<G-vec00206-001-s029><count.abzählen><en> You shall count seven weeks to yourselves;
<G-vec00206-001-s030><count.abzählen><de> Die Juden, ein praktisches Volk wie sie sind, mochten sich das einfache Rechenexempel an den Fingern abzählen, daß die „deutschen Fäuste“, die es nicht einmal fertiggebracht haben, ihre eigene preußische Reaktion, zum Beispiel das Dreiklassenwahlrecht, zu „zerschmettern“, wohl wenig tauglich sind, den russischen Absolutismus zu zerschmettern.
<G-vec00206-001-s030><count.abzählen><en> The Jews, practical people that they are, were able to count on their fingers that “German fists” which have been unable to overthrow their own Prussian reaction, can hardly be expected to smash Russian absolutism. The Poles, exposed to the triple-headed war, were not in a position to answer their “liberators” in audible language.
<G-vec00206-001-s031><count.abzählen><de> Du hast genau beobachtet und gesehen, dass sie kleine Mengen zwar intuitiv erfassen, aber noch nicht sicher abzählen kann.
<G-vec00206-001-s031><count.abzählen><en> You have closely observed and seen that she can intuitively capture small quantities, but not yet count them safely.
<G-vec00206-001-s032><count.abzählen><de> Ich kann wahrscheinlich an einer Hand abzählen die Unternehmen, die ich kenne, eine Schneise Läufer etwas wert zu machen.
<G-vec00206-001-s032><count.abzählen><en> I can probably count on one hand the companies that I know who make an aisle runner worth anything.
<G-vec00206-001-s033><count.abzählen><de> Aber das dürfte hierzulande wohl sowieso egal sein, denn die Käufer kann man wohl an einer Hand abzählen;) Fazit: nette Compilation, die jedoch stark auf den spanischen Markt zugeschnitten ist.
<G-vec00206-001-s033><count.abzählen><en> Anyway, in these parts it does not matter at all, since you can possibly count the buyers on one hand;) Bottom line: nice compilation, but far too much customized on the Spanish market.
<G-vec00206-001-s034><count.abzählen><de> "Wenn Sie ausschließen, die ""Besuche"", wenn sie nur darauf, meine Mom, mich zu sehen, oder sie abholen, Ich kann auf die Zehen einer Hand abzählen, wie oft meine Familie hat mich in jene besucht 21 Jahre."
<G-vec00206-001-s034><count.abzählen><en> If you rule out the “visits” when they were just bringing my Mom to see me, or pick her up, I can count on the toes of one hand how many times my family has visited me in those 21 years.
<G-vec00206-001-s035><count.abzählen><de> Unsere persönliche Erfahrung hat gezeigt, dass es im Juli zwar mehrheitlich bewölkt ist, richtige Regentage konnte man aber in den letzten 3 Jahren an einer Hand abzählen, meist gab es ab und zu einen kräftigen Guss, nach einer halben Stunde war aber alles wieder vorbei.
<G-vec00206-001-s035><count.abzählen><en> Our personal experience has shown that while it is mostly cloudy in July, but real rainy days you could count in the past 3 years on one hand, usually there was a heavy shower sometimes, but after half an hour it was all over.
<G-vec00206-001-s036><count.abzählen><de> Die Polo Clubs lassen sich an einer Hand abzählen und die Zahl der aktiven Polo Player bewegt sich im zweistelligen Bereich.
<G-vec00206-001-s036><count.abzählen><en> You can count the number of polo clubs on one hand, and there are fewer than a hundred active polo players.
<G-vec00206-001-s037><count.abzählen><de> Die Schmuckstücke, die ich jeden Tag trage, kann ich an einer Hand abzählen: Einige mir wertvolle Ringe, meine Uhr, ein paar Ketten, alles eher zurückhaltend als prunkvoll.
<G-vec00206-001-s037><count.abzählen><en> I can count the jewelry that I wear every day on one hand: a few precious rings, my watch, a couple of necklaces, all quite simple, nothing too loud.
