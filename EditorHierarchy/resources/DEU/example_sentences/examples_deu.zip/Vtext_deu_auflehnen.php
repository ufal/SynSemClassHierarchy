<G-vec00461-002-s279><rebel.auflehnen><de> Weisen Sie darauf hin, dass die gesamte Gruppe geschwächt wird, wenn auch nur einige murren und sich auflehnen.
<G-vec00461-002-s279><rebel.auflehnen><en> Point out that when even a few people murmur and rebel, the entire group is weakened.
<G-vec00461-002-s280><rebel.auflehnen><de> Nur die Menschen werden sich auflehnen, die, wenn auch gläubig zu nennen, noch nicht innerlich genug sind, um zu erkennen, daß nicht von menschlichen Einrichtungen die geistige Höherentwicklung abhängig ist.
<G-vec00461-002-s280><rebel.auflehnen><en> Only those people will rebel who, even so to be called believing, are still not inwardly enough to recognize that spiritual ascent development does not depend on human institutions.
<G-vec00461-002-s281><rebel.auflehnen><de> Die aufgebrachten Gedanken und Gefühle sowie die davon betroffene Psyche, die sich immer und immer wieder gegen die Realität und deren Wahrheit auflehnen, haben beruhigt zu werden.
<G-vec00461-002-s281><rebel.auflehnen><en> The upset thoughts and feelings, as well as the psyche which is affected by them, which rebel again and again against the reality and its truth, have to be soothed.
