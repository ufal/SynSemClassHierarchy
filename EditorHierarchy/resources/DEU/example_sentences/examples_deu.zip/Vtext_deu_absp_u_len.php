<G-vec00840-002-s037><wash.abspülen><de> Tabletts Mit feuchtem Tuch abwischen oder abspülen.
<G-vec00840-002-s037><wash.abspülen><en> Trays Wipe with a damp cloth or wash up by hand and then dry.
<G-vec00840-002-s038><wash.abspülen><de> Kopfsalat abspülen und 8 Blätter beiseitelegen.
<G-vec00840-002-s038><wash.abspülen><en> Wash the lettuce and put 8 leaves to one side.
<G-vec00840-002-s039><wash.abspülen><de> Das Hauptgerät nicht mit Wasser abspülen, um Beschädigungen durch Wasserkontakt zu vermeiden.
<G-vec00840-002-s039><wash.abspülen><en> Do not wash the main body of the device to avoid risk of damage caused by contact with water
<G-vec00840-002-s040><wash.abspülen><de> Die Applikationsspritze unter sauberem Wasser abspülen und gut abtrocknen.
<G-vec00840-002-s040><wash.abspülen><en> Wash the syringe with clean water and dry thoroughly.
<G-vec00840-002-s041><wash.abspülen><de> Herausziehbarer Auslauf für bequemes Abspülen Mehr Flexibilität in der Küche: Der herausziehbare Auslauf bietet Ihnen einen größeren Aktionsradius, um bequem Töpfe zu befüllen und Gemüse oder Geschirr abzuspülen.
<G-vec00840-002-s041><wash.abspülen><en> More flexibility in your kitchen: the pull-down spray head offers you a bigger operating radius, letting you fill pots, wash vegetables or rinse off dishes easily, and reaching into all corners of your basin.
<G-vec00840-002-s042><wash.abspülen><de> Nach Gebrauch sofort abspülen.
<G-vec00840-002-s042><wash.abspülen><en> Wash immediately after use.
<G-vec00840-002-s043><wash.abspülen><de> Nach dem Waschen mit klarem Wasser abspülen.
<G-vec00840-002-s043><wash.abspülen><en> After the washing, wash up with clear water.
<G-vec00840-002-s044><wash.abspülen><de> Die Variante mit Abtropffläche eignet sich besonders, wenn Sie hin und wieder von Hand abspülen.
<G-vec00840-002-s044><wash.abspülen><en> The variant with draining board is especially suitable if you wash up by hand every now and then.
<G-vec00840-002-s045><wash.abspülen><de> Auf die intimen Körperteile auftragen und mit Wasser abspülen.
<G-vec00840-002-s045><wash.abspülen><en> Apply to your intimate areas and wash off with water.
<G-vec00840-002-s046><wash.abspülen><de> Nach 10 bis 15 Minuten mit kaltem Wasser abspülen.
<G-vec00840-002-s046><wash.abspülen><en> Leave it overnight in the morning remove with face wash and cold water.
<G-vec00840-002-s047><wash.abspülen><de> Am Ende deines Urlaubs kannst du deine Kites in unserer Kite-Wasch-Straße mit Süßwasser abspülen und trocknen lassen.
<G-vec00840-002-s047><wash.abspülen><en> At the end of your holiday you can wash your kites with fresh water in our kite washing system and then let them dry.
<G-vec00840-002-s048><wash.abspülen><de> Sogar bei der Hausarbeit will ich nicht nur das Geschirr abspülen.
<G-vec00840-002-s048><wash.abspülen><en> Even at the housework, I don´t just want to wash the dishes.
<G-vec00840-002-s049><wash.abspülen><de> Diese Maske wird empfohlen, mit kaltem Wasser abspülen.
<G-vec00840-002-s049><wash.abspülen><en> This mask is recommended to wash with cool water.
<G-vec00840-002-s050><wash.abspülen><de> Ein paar Tropfen Reinigungsöl kurz ins gefeuchtete Gesichtshaut einmas- sieren und gründlich mit lauwarmem Wasser abspülen.
<G-vec00840-002-s050><wash.abspülen><en> Brie y rub in several drops of the hydrophilic washing oil to damp skin and wash thoroughly with tepid water.
<G-vec00840-002-s051><wash.abspülen><de> Nach der Rasur gründlich abspülen.
<G-vec00840-002-s051><wash.abspülen><en> After shaving wash carefully.
<G-vec00840-002-s052><wash.abspülen><de> Wenn Speisereste haften geblieben sind, sollten Sie das Kochgeschirr mit warmem Wasser füllen, 15-20 Minuten lang einweichen lassen und anschließend wie gewohnt abspülen.
<G-vec00840-002-s052><wash.abspülen><en> If there are food residues fill the pan with warm water and leave to soak for 15 – 20 minutes, then wash in the usual way.
<G-vec00840-002-s053><wash.abspülen><de> Bei der Fleckentfernung in der Werkstatt oder im Freien die Oberfläche zunächst immer mit klarem Wasser abspülen.
<G-vec00840-002-s053><wash.abspülen><en> When removing stains in a workshop or in the open, always first wash down the surface using clean water.
<G-vec00923-002-s037><wash_away.abspülen><de> Tabletts Mit feuchtem Tuch abwischen oder abspülen.
<G-vec00923-002-s037><wash_away.abspülen><en> Trays Wipe with a damp cloth or wash up by hand and then dry.
<G-vec00923-002-s038><wash_away.abspülen><de> Kopfsalat abspülen und 8 Blätter beiseitelegen.
<G-vec00923-002-s038><wash_away.abspülen><en> Wash the lettuce and put 8 leaves to one side.
<G-vec00923-002-s039><wash_away.abspülen><de> Das Hauptgerät nicht mit Wasser abspülen, um Beschädigungen durch Wasserkontakt zu vermeiden.
<G-vec00923-002-s039><wash_away.abspülen><en> Do not wash the main body of the device to avoid risk of damage caused by contact with water
<G-vec00923-002-s040><wash_away.abspülen><de> Die Applikationsspritze unter sauberem Wasser abspülen und gut abtrocknen.
<G-vec00923-002-s040><wash_away.abspülen><en> Wash the syringe with clean water and dry thoroughly.
<G-vec00923-002-s041><wash_away.abspülen><de> Herausziehbarer Auslauf für bequemes Abspülen Mehr Flexibilität in der Küche: Der herausziehbare Auslauf bietet Ihnen einen größeren Aktionsradius, um bequem Töpfe zu befüllen und Gemüse oder Geschirr abzuspülen.
<G-vec00923-002-s041><wash_away.abspülen><en> More flexibility in your kitchen: the pull-down spray head offers you a bigger operating radius, letting you fill pots, wash vegetables or rinse off dishes easily, and reaching into all corners of your basin.
<G-vec00923-002-s042><wash_away.abspülen><de> Nach Gebrauch sofort abspülen.
<G-vec00923-002-s042><wash_away.abspülen><en> Wash immediately after use.
<G-vec00923-002-s043><wash_away.abspülen><de> Nach dem Waschen mit klarem Wasser abspülen.
<G-vec00923-002-s043><wash_away.abspülen><en> After the washing, wash up with clear water.
<G-vec00923-002-s044><wash_away.abspülen><de> Die Variante mit Abtropffläche eignet sich besonders, wenn Sie hin und wieder von Hand abspülen.
<G-vec00923-002-s044><wash_away.abspülen><en> The variant with draining board is especially suitable if you wash up by hand every now and then.
<G-vec00923-002-s045><wash_away.abspülen><de> Auf die intimen Körperteile auftragen und mit Wasser abspülen.
<G-vec00923-002-s045><wash_away.abspülen><en> Apply to your intimate areas and wash off with water.
<G-vec00923-002-s046><wash_away.abspülen><de> Nach 10 bis 15 Minuten mit kaltem Wasser abspülen.
<G-vec00923-002-s046><wash_away.abspülen><en> Leave it overnight in the morning remove with face wash and cold water.
<G-vec00923-002-s047><wash_away.abspülen><de> Am Ende deines Urlaubs kannst du deine Kites in unserer Kite-Wasch-Straße mit Süßwasser abspülen und trocknen lassen.
<G-vec00923-002-s047><wash_away.abspülen><en> At the end of your holiday you can wash your kites with fresh water in our kite washing system and then let them dry.
<G-vec00923-002-s048><wash_away.abspülen><de> Sogar bei der Hausarbeit will ich nicht nur das Geschirr abspülen.
<G-vec00923-002-s048><wash_away.abspülen><en> Even at the housework, I don´t just want to wash the dishes.
<G-vec00923-002-s049><wash_away.abspülen><de> Diese Maske wird empfohlen, mit kaltem Wasser abspülen.
<G-vec00923-002-s049><wash_away.abspülen><en> This mask is recommended to wash with cool water.
<G-vec00923-002-s050><wash_away.abspülen><de> Ein paar Tropfen Reinigungsöl kurz ins gefeuchtete Gesichtshaut einmas- sieren und gründlich mit lauwarmem Wasser abspülen.
<G-vec00923-002-s050><wash_away.abspülen><en> Brie y rub in several drops of the hydrophilic washing oil to damp skin and wash thoroughly with tepid water.
<G-vec00923-002-s051><wash_away.abspülen><de> Nach der Rasur gründlich abspülen.
<G-vec00923-002-s051><wash_away.abspülen><en> After shaving wash carefully.
<G-vec00923-002-s052><wash_away.abspülen><de> Wenn Speisereste haften geblieben sind, sollten Sie das Kochgeschirr mit warmem Wasser füllen, 15-20 Minuten lang einweichen lassen und anschließend wie gewohnt abspülen.
<G-vec00923-002-s052><wash_away.abspülen><en> If there are food residues fill the pan with warm water and leave to soak for 15 – 20 minutes, then wash in the usual way.
<G-vec00923-002-s053><wash_away.abspülen><de> Bei der Fleckentfernung in der Werkstatt oder im Freien die Oberfläche zunächst immer mit klarem Wasser abspülen.
<G-vec00923-002-s053><wash_away.abspülen><en> When removing stains in a workshop or in the open, always first wash down the surface using clean water.
