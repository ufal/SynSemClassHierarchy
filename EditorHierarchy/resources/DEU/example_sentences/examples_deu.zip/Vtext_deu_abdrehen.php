<G-vec00931-002-s020><veer.abdrehen><de> Indem ihr es so macht, könnt ihr schnell Optionen korrigieren, die euch vom geraden und schmalen Weg des Aufstiegs abdrehen lassen.
<G-vec00931-002-s020><veer.abdrehen><en> By doing so, you can quickly rectify any actions that veer you off the straight and narrow Path of Ascension.
