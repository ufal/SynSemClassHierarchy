<G-vec00522-002-s160><tighten.anspannen><de> Sage "Ahh" und spanne die Muskeln an der Hinterseite deines Halses an.
<G-vec00522-002-s160><tighten.anspannen><en> Go "Ahh," and tighten the muscles in the back of your throat.
<G-vec00522-002-s161><tighten.anspannen><de> Spanne deine Bauchmuskeln an und drücke dich vom Boden ab, indem du deine Hüften und deinen Po so weit nach oben hebst bis deine Knie, Hüften und Schultern eine Linie bilden.
<G-vec00522-002-s161><tighten.anspannen><en> Tighten your abs and push yourself up from the floor, lifting your hips and butt until your knees, hips, and shoulders are all in line.
<G-vec00943-002-s023><tighten.anspannen><de> Die Sanitäter teilten mir mit, daß ich meine Arme nicht so anspannen solle, aber ich war mir dessen zu diesem Zeitpunkt nicht bewußt.
<G-vec00943-002-s023><tighten.anspannen><en> The emergency medical technicians were telling me to not tighten my arms so tight but I was unaware at the time.
<G-vec00943-002-s024><tighten.anspannen><de> Das Resultat ist, dass die Vagina sich nicht nur anspannen kann, sondern auch dauerhaft enger werden kann.
<G-vec00943-002-s024><tighten.anspannen><en> The result is that the vagina can not only tighten, but can also become permanently tighter.
