<G-vec00230-002-s231><condemn.ächten><de> Wir ächten Kinderarbeit und setzen Kinder und Jugendliche nicht zum Erreichen unserer wirtschaftlichen Ziele ein.
<G-vec00230-002-s231><condemn.ächten><en> We condemn child labour and do not use children or young people to achieve our economic targets.
