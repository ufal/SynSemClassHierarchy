<G-vec00081-001-s038><break.abbrechen><de> """Wenn wir bei der Hälfte eines Jobs abbrechen müssen, können wir die Einstellungen einfach speichern, einen anderen Job laufen lassen und später zu dem ursprünglichen Job zurückkehren."
<G-vec00081-001-s038><break.abbrechen><en> """If we need to break in the middle of a job, we can easily save the settings, run a different job and reset back to the previous job at a later time."
<G-vec00081-001-s039><break.abbrechen><de> Ich wollte schon abbrechen und hatte mir vorgenommen einen größeren Drachen zu bauen, da bemerkte ich, dass der Wind auffrischte.
<G-vec00081-001-s039><break.abbrechen><en> Also the kite was flying very bad and restless, too. I was ready to have a break and go home, as I felt that the wind was getting stronger.
<G-vec00081-001-s040><break.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00081-001-s040><break.abbrechen><en> 12 They will plunder your wealth and loot your merchandise; they will break down your walls and demolish your fine houses and throw your stones, timber and rubble into the sea.
<G-vec00081-001-s041><break.abbrechen><de> Oft kommt es auch vor, dass Aeste durch dieses enorme Gewicht abbrechen.
<G-vec00081-001-s041><break.abbrechen><en> It often happens that branches break under this enormous weight.
<G-vec00081-001-s042><break.abbrechen><de> Wenn Raubangriffe, die Eidechse sein eigenes Endstück als abbrechen können Mittel der Ablenkung.
<G-vec00081-001-s042><break.abbrechen><en> When a predator attacks, the lizard can break off its own tail as a means of distraction.
<G-vec00081-001-s043><break.abbrechen><de> Dann, beginnend an der Basis, biegen Sie die harten äußeren Blätter zurück, bis sie abbrechen.
<G-vec00081-001-s043><break.abbrechen><en> Then, starting at the base, bend the tough outer leaves back until they break off.
<G-vec00081-001-s044><break.abbrechen><de> Ohne Umstell-Rädchen, Lämpchen, Turbinen oder andere bewegliche Teile, die früher oder später abbrechen oder verkalken.
<G-vec00081-001-s044><break.abbrechen><en> No moving parts such as adjuster wheels, lights, turbines, or other components that will sooner or later break or calcify.
<G-vec00081-001-s045><break.abbrechen><de> Lucas Auer: Ich würde alle Teile, die leicht abbrechen können, vom Auto verbannen.
<G-vec00081-001-s045><break.abbrechen><en> Lucas Auer: I would ban all parts that can easily break off the car.
<G-vec00081-001-s046><break.abbrechen><de> 16:39 Und will dich in ihre Hände geben, daß sie deine Kapellen abbrechen und deine Altäre umreißen und dir deine Kleider ausziehen und dein schönes Gerät dir nehmen und dich nackt und bloß sitzen lassen.
<G-vec00081-001-s046><break.abbrechen><en> 16:39 I will also give you into their hand, and they shall throw down your vaulted place, and break down your lofty places; and they shall strip you of your clothes, and take your beautiful jewels; and they shall leave you naked and bare.
<G-vec00081-001-s047><break.abbrechen><de> Die For Each- Einstellung kann mit oder ohne die Schleife abbrechen, wenn -Einstellung definiert werden.
<G-vec00081-001-s047><break.abbrechen><en> The For Each setting can be specified with or without the Break Loop If setting.
<G-vec00081-001-s048><break.abbrechen><de> Ihren Deutschkurs sollten Sie auf keinen Fall vor dieser Stufe abbrechen, da Sie sonst das Gelernte schnell vergessen werden.
<G-vec00081-001-s048><break.abbrechen><en> Under no circumstances should you break off your German courses before this level, as otherwise you will quickly forget what you have learned.
<G-vec00081-001-s049><break.abbrechen><de> Als ich stehen blieb und eine Géanit des batailles betrachtete, die drei wundervolle Knospen trug, sah ich ganz deutlich, ganz nahe neben mir, einen der Stiele sich herumlegen, als ob eine unsichtbare Hand ihn gefaßt hätte, sah ihn abbrechen, wie wenn diese Hand ihn gepflückt.
<G-vec00081-001-s049><break.abbrechen><en> As I stopped to look at a Géant de Bataille, which had three splendid blooms, I distinctly saw the stalk of one of the roses bend, close to me, as if an invisible hand had bent it, and then break, as if that hand had picked it!
<G-vec00081-001-s050><break.abbrechen><de> Außerdem, ist es für die Frau die Nutzen für sie abbrechen, der Lage sein, einen Mann, der voll und ganz auf eine Beziehung begangen werden kann gerecht sein.
<G-vec00081-001-s050><break.abbrechen><en> In addition, it is for the woman's benefit to break it off, to be able to meet a man who can be fully committed to having a relationship.
<G-vec00081-001-s051><break.abbrechen><de> Der Sandsturm war so stark, dass wir auf halber Strecke abbrechen mussten.
<G-vec00081-001-s051><break.abbrechen><en> The sand storm was too strong so we had to break up the mission half way down.
<G-vec00081-001-s052><break.abbrechen><de> Jeden Tag Make-up zu tragen kann deine Wimpern austrocknen und deine Augen reizen, was bewirken kann, dass die Wimpern abbrechen oder sogar ausfallen.
<G-vec00081-001-s052><break.abbrechen><en> Wearing makeup every day can dry out your lashes and irritate your eyes, which can cause your lashes to break or even fall out.
<G-vec00081-001-s053><break.abbrechen><de> Nein (nervöses Gestammle), ich muss jetzt leider das Gespräch abbrechen.
<G-vec00081-001-s053><break.abbrechen><en> No (inaudible), I must unfortunately break the discussion off now, sorry.
<G-vec00081-001-s054><break.abbrechen><de> Diese Methode ist jedoch nicht so zuverlässig wie die Verwendung von Softwarelösungen, da der Download abbrechen kann oder der Dienst genau dann, wenn Sie ihn benötigen, ausfällt.
<G-vec00081-001-s054><break.abbrechen><en> This method is not as reliable as using software solutions though, as the download can break or the service may be down at exactly that moment when you need it.
<G-vec00081-001-s055><break.abbrechen><de> Großmutter würde ein Blatt von ihrem Aloe Vera Betrieb abbrechen und zu meiner Rettung kommen.
<G-vec00081-001-s055><break.abbrechen><en> Grandma would break off a leaf from her Aloe Vera plant and come to my rescue.
<G-vec00081-001-s056><break.abbrechen><de> "Klicken Sie im Dialogfeld ""Abbrechen"" auf das Symbol Alle Klicken Sie auf die Schaltfläche, um alle Mitglieder auszuwählen Ok Klicken Sie auf und dann auf Ja Schaltfläche im neuen Kutools für Outlook-Dialogfeld."
<G-vec00081-001-s056><break.abbrechen><en> In the Break dialog, click the All button to select all memebers, click the Ok button, and finally click the Yes button in the new Kutools for Outlook dialog.
<G-vec00081-001-s021><discontinue.abbrechen><de> Sie müssen möglicherweise ihre Ausbildung abbrechen, weil ihr Vater verfolgt wird und sie sich den Unterricht nicht mehr leisten können.
<G-vec00081-001-s021><discontinue.abbrechen><en> But they may have to discontinue their education because their father is being persecuted and they can't afford the tuition.
<G-vec00081-001-s022><discontinue.abbrechen><de> Sie sollten die Einnahme dieses Arzneimittels niemals abrupt abbrechen, wenn Sie mit der Einnahme begonnen haben, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s022><discontinue.abbrechen><en> You should never abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s023><discontinue.abbrechen><de> Nicht Behandlung abbrechen, es sei denn gesagt, so von Ihrem Arzt zu tun.
<G-vec00081-001-s023><discontinue.abbrechen><en> Do not discontinue treatment unless told to do so by your physician.
<G-vec00081-001-s024><discontinue.abbrechen><de> Bei Benchmark dürfen wir jegliche Produkte oder Dienste, teilweise oder ganz, entweder dauerhaft oder vorübergehend und ohne Ankündigung, überarbeiten, ändern, modifizieren oder abbrechen.
<G-vec00081-001-s024><discontinue.abbrechen><en> We at Benchmark can revise, change, modify, suspend or discontinue any of our products or services, in part or whole, either permanently or temporarily without any notice.
<G-vec00081-001-s025><discontinue.abbrechen><de> Patienten sollten die Einnahme dieses Medikaments niemals abrupt abbrechen, da dies zu Entzugssymptomen führen kann.
<G-vec00081-001-s025><discontinue.abbrechen><en> Patients should never abruptly discontinue taking this medication, as this may cause withdrawal symptoms.
<G-vec00081-001-s022><interrupt.abbrechen><de> Ein paarmal mussten wir zwischendurch abbrechen und eine Passage genauer durchgehen, aber im Grunde hab ich sie jetzt alle drauf.
<G-vec00081-001-s022><interrupt.abbrechen><en> Sometimes we had to interrupt and re-check a part, but basically I know them all by now.
<G-vec00081-001-s023><interrupt.abbrechen><de> Die Erhitzung abbrechen, sobald man den ganzen Kalk gut durcherhitzt hat und kaum noch Destillat übergeht.
<G-vec00081-001-s023><interrupt.abbrechen><en> Interrupt the heating as soon as all of the lime has been thoroughly heated and hardly any distillate develops.
<G-vec00081-001-s024><interrupt.abbrechen><de> Studien belegen auch, dass Männer eine Behandlung später als Frauen beginnen, diese abbrechen, oder sie nicht fortführen.
<G-vec00081-001-s024><interrupt.abbrechen><en> Studies show that men are more likely than women to start treatment late, to interrupt treatment and to be lost to treatment follow-up.
<G-vec00081-001-s025><interrupt.abbrechen><de> Während einer Verkehrsdurchsage können Sie die aktuelle Verkehrsdurchsage abbrechen, indem Sie kurz auf den Ein-/Ausschaltknopf drücken Abb.2.
<G-vec00081-001-s025><interrupt.abbrechen><en> While a traffic report is being played, you can interrupt the current traffic report by briefly pressing the ON/OFF button Fig.2.
<G-vec00081-001-s026><interrupt.abbrechen><de> Eine Unterbrechung der Dateiübertragung: Angenommen, Sie sind ein Bündel von Sony Vegas-Datei von Ihrer Festplatte auf USB-Laufwerk zu übertragen, dann, wenn Sie diesen Vorgang abbrechen, indem Sie Gerät trennen oder PC Absperren von Netzkabel abgetrennt wird, wird dies zu einem Verlust der Datei führt, die bei der Übertragung von Modus werden.
<G-vec00081-001-s026><interrupt.abbrechen><en> Interrupting file transfer process: Â Suppose you are transferring a bundle of Sony Vegas file from your hard disk to USB drive, then if you interrupt this process by disconnecting device or shutting PC off by unplugging power cable, this will leads to loss of file which are being in transferring mode.
<G-vec00081-001-s030><discontinue.abbrechen><de> Es ist wichtig, die Einnahme dieses Arzneimittels nach dem Beginn der Einnahme nicht abrupt abzubrechen, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s030><discontinue.abbrechen><en> It is important not to abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s031><discontinue.abbrechen><de> Nach dessen Erfolg beschloss er sein Studium abzubrechen und sich ausschließlich dem künstlerischen Schaffen zu widmen.
<G-vec00081-001-s031><discontinue.abbrechen><en> Following its success, he decided to discontinue his studies and concentrate fully on his artistic work.
<G-vec00081-001-s032><discontinue.abbrechen><de> Im Dezember 1273 rief er seinen Freund und Sekretär Reginald zu sich, um ihm seinen Entschluß mitzuteilen, alle Arbeiten abzubrechen, da er während der Feier der Messe infolge einer übernatürlichen Offenbarung verstanden hatte, daß alles, was er bisher geschrieben hatte, nichts weiter als »ein Haufen Spreu« war.
<G-vec00081-001-s032><discontinue.abbrechen><en> "In December 1273, he summoned his friend and secretary Reginald to inform him of his decision to discontinue all work because he had realized, during the celebration of Mass subsequent to a supernatural revelation, that everything he had written until then ""was worthless""."
<G-vec00081-001-s033><discontinue.abbrechen><de> Talk Online Panel behält sich das Recht vor, fristlos und nach alleinigem Ermessen oder vom Gesetz oder lokalen Autoritäten angeordnet, seine Geschäfte in einem speziellen Land oder überall abzubrechen oder zu beenden, womit auch individuelle Konten geschlossen werden, was zum jeweiligen Verfall der Punkte führt.
<G-vec00081-001-s033><discontinue.abbrechen><en> Talk Online Panel reserves the right, without notice and in its sole discretion, on its own volition or as dictated by law or local authorities, to discontinue or terminate its operation in a particular country or overall, thus also terminating individual accounts, leading to the forfeiture of points therein.
<G-vec00081-001-s034><discontinue.abbrechen><de> EnergyCasino behält sich das Recht vor, die Cash Rewards Aktion nach eigenem Ermessen der Firma zu verändern oder abzubrechen.
<G-vec00081-001-s034><discontinue.abbrechen><en> EnergyCasino reserves the right to alter or discontinue the Cash Rewards promotion at the company's sole discretion. English English
<G-vec00081-001-s035><discontinue.abbrechen><de> """Sie versuchten uns zu zwingen, das Programm abzubrechen."
<G-vec00081-001-s035><discontinue.abbrechen><en> """They attempted to force us to discontinue the programme."
<G-vec00081-001-s027><interrupt.abbrechen><de> Zürich Tourismus ist berechtigt, jederzeit Verbesserungen oder Änderungen an der Aktion vorzunehmen sowie die Aktion ohne Angabe von Gründen auszusetzen, abzubrechen oder zu beenden.
<G-vec00081-001-s027><interrupt.abbrechen><en> Zürich Tourism is entitled to improve or modify the terms and conditions of the competition at any time, as well as to abandon, interrupt or discontinue the competition without giving any reason.
<G-vec00081-001-s028><interrupt.abbrechen><de> Die Sandoz-Familienstiftung behält sich die Möglichkeit vor, das Programm abzubrechen, wobei bereits angestellte Begünstigte bis zum Ablauf ihres Arbeitsvertrags finanziert werden.
<G-vec00081-001-s028><interrupt.abbrechen><en> The Sandoz Family Foundation reserves the right to interrupt the programme, in which case beneficiaries already employed will continue to receive funding until their contracts expire.
<G-vec00081-001-s029><interrupt.abbrechen><de> Um den Update-Vorgang abzubrechen, klicken Sie auf Update abbrechen .
<G-vec00081-001-s029><interrupt.abbrechen><en> To interrupt the update click Cancel update .
<G-vec00081-001-s088><discontinue.abbrechen><de> Haben Sie dann immer noch Beschwerden, brechen Sie die Behandlung ab und sprechen Sie mit Ihrem Zahnarzt.
<G-vec00081-001-s088><discontinue.abbrechen><en> Again, if the discomfort continues, discontinue the treatment and consult your dental professional.
<G-vec00081-001-s106><discontinue.abbrechen><de> Wenn Sie die Übersetzung vor Abschluss der Übersetzung abbrechen, erstellen Sie die tmx-Dateien für die Übersetzungen, die Sie erstellt haben, und laden Sie sie in das Translation Memory-Repository hoch.
<G-vec00081-001-s106><discontinue.abbrechen><en> If you discontinue before completing the translation, please do create the tmx files for the you have done and upload them to the translation memory repository.
<G-vec00081-001-s107><discontinue.abbrechen><de> Bei starkem Brennen, die Anwendung abbrechen.
<G-vec00081-001-s107><discontinue.abbrechen><en> In thecase of excessive burning, discontinue use.
<G-vec00081-001-s108><discontinue.abbrechen><de> Aber halten Sie die Vorsichtsmaßnahmen im Auge - wenn die Haut erscheint gereizt oder sogar noch mehr, Wunden, die Behandlung abzubrechen und sofort mit Ihrem Hautarzt konsultieren.
<G-vec00081-001-s108><discontinue.abbrechen><en> But keep in mind the precautions - if the skin appears irritated or even more so, sores, discontinue treatment and immediately consult your dermatologist.
<G-vec00081-001-s186><discontinue.abbrechen><de> GPRO behält sich das Recht vor, von Zeit zu Zeit, zu jeder Zeit, ohne Benachrichtigung den Service (oder einen Teil davon), zu modifizieren oder, entweder kurzzeitig oder permanent, abzubrechen.
<G-vec00081-001-s186><discontinue.abbrechen><en> GPRO reserves the right from time to time, at any time, to modify or discontinue, temporarily or permanently, the Service (or any part thereof) with or without notice.
<G-vec00081-001-s192><discontinue.abbrechen><de> Wenn einer dieser Fälle passieren dann sollte man den Lauf abbrechen und einen Arzt sofort aufsuchen.
<G-vec00081-001-s192><discontinue.abbrechen><en> If any of these happen then one should discontinue the course and consult a medical professional immediately.
<G-vec00081-001-s206><discontinue.abbrechen><de> Er kann seine Daten bis zur Betätigung der Schaltfläche „Complete Registration“ jederzeit korrigieren oder die Registrierung durch Schließen seines Browserfensters oder Betätigung der Schaltfläche „Zurück“ seines Browsers abbrechen.
<G-vec00081-001-s206><discontinue.abbrechen><en> "It can correct its data at all times until the ""Complete Registration"" button is pressed or discontinue the registration by closing its browser window or pressing the ""Back"" button of its browser."
<G-vec00081-001-s270><discontinue.abbrechen><de> interVista behält sich das Recht vor, zu jeglicher Zeit und von Zeit zu Zeit die Services (oder Teile davon) mit oder ohne Ankündigung zu aktualisieren, vorübergehend oder dauerhaft zu unterbrechen oder abzubrechen.
<G-vec00081-001-s270><discontinue.abbrechen><en> Escapia Inc. reserves the right at any time and from time to time to modify or discontinue, temporarily or permanently, the Services (or any part thereof) with or without notice.
<G-vec00081-001-s282><discontinue.abbrechen><de> Eine Unverträglichkeit des Arzneimittels ist äußerst selten, aber wenn eine allergische Reaktion festgestellt wird, muss der Verlauf des Vitaminpräparats abgebrochen und ein Arzt konsultiert werden.
<G-vec00081-001-s282><discontinue.abbrechen><en> Intolerance of the drug is extremely rare, but if an allergic reaction is identified, it is necessary to discontinue the course of the vitamin preparation and consult a doctor.
<G-vec00218-002-s019><break.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00218-002-s019><break.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00218-002-s020><break.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00218-002-s020><break.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00218-002-s021><break.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00218-002-s021><break.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00218-002-s022><break.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00218-002-s022><break.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00218-002-s024><break.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00218-002-s024><break.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00218-002-s025><break.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00218-002-s025><break.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00218-002-s026><break.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00218-002-s026><break.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00218-002-s027><break.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00218-002-s027><break.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00218-002-s028><break.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00218-002-s028><break.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00218-002-s029><break.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00218-002-s029><break.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00218-002-s030><break.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00218-002-s030><break.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00218-002-s031><break.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00218-002-s031><break.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00218-002-s032><break.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00218-002-s032><break.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00218-002-s033><break.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00218-002-s033><break.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00218-002-s034><break.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00218-002-s034><break.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00218-002-s035><break.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00218-002-s035><break.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00218-002-s036><break.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00218-002-s036><break.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00218-002-s037><break.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00218-002-s037><break.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00376-002-s037><discontinue.abbrechen><de> Darüber hinaus könnte Gilead die strategische Entscheidung treffen, die Entwicklung dieser Substanz abzubrechen, wenn das Unternehmen zum Beispiel der Ansicht ist, dass eine Markteinführung im Vergleich zu anderen Produkten in der Pipeline schwierig sein wird.
<G-vec00376-002-s037><discontinue.abbrechen><en> In addition, Gilead may make a strategic decision to discontinue development of the compound if, for example, Gilead believes commercialization will be difficult relative to other opportunities in its pipeline.
<G-vec00376-002-s038><discontinue.abbrechen><de> ICB behält sich das Recht vor, die Aktion aufgrund unvorhersehbarer Umstände ohne Vorankündigung abzubrechen oder beenden zu können.
<G-vec00376-002-s038><discontinue.abbrechen><en> ICB reserves the right to discontinue or terminate the competition due to unforeseeable circumstances without prior notice.
<G-vec00376-002-s039><discontinue.abbrechen><de> Daher beschloss PAION im Februar 2016, die Studie abzubrechen, um eine langwierige und teure Fortführung mit diesem Studiendesign zu vermeiden.
<G-vec00376-002-s039><discontinue.abbrechen><en> Therefore, in February 2016, PAION decided to discontinue the trial in order to avoid a long and expensive study with the existing design.
<G-vec00376-002-s041><discontinue.abbrechen><de> EnergyCasino behält sich das Recht vor, die Teilnahmebedingungen dieser Aktion jederzeit ohne Grund und Vorwarnung zu ändern und/oder abzubrechen.
<G-vec00376-002-s041><discontinue.abbrechen><en> EnergyCasino reserves the right to change the Terms and Conditions and/or discontinue or withdraw the promotion, due to unforeseen circumstances (e.g.
<G-vec00389-002-s019><demolish.abbrechen><de> Mit über 325 Jahren gelebter Innovation und Leidenschaft bietet Husqvarna® Bauprofis Support, Service und ein breites Angebot an Maschinen, Diamantwerkzeugen und Zubehör, das Sie zum Schneiden, Sägen, Bohren, Abbrechen, Abschleifen und Polieren von Beton benötigen.
<G-vec00389-002-s019><demolish.abbrechen><en> Wire saws With over 325 years of innovation and passion, Husqvarna provides construction professionals with support, service and a wide range of machines, diamond tools and all accessories that you need to cut, saw, drill, demolish, grind and polish concrete.
<G-vec00389-002-s019><destroy.abbrechen><de> 57Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 58Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s019><destroy.abbrechen><en> 14:57 Some stood up and gave this false testimony against him: 5 14:58 “We heard him say, ‘I will destroy this temple made with hands and in three days build another not made with hands.’”
<G-vec00389-002-s020><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen, und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen, und in drei Tagen denselben bauen.
<G-vec00389-002-s020><destroy.abbrechen><en> But last of all 2 false witnesses came forward, 61 and said, "This Man said, 'I am able to destroy the Temple of God, and to rebuild it after 3 days.'
<G-vec00389-002-s021><destroy.abbrechen><de> 14:58 Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s021><destroy.abbrechen><en> 14:58 "We heard him say, 'I will destroy this man-made temple and in three days will build another, not made by man.' "
<G-vec00389-002-s022><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen und in drei Tagen ihn bauen.
<G-vec00389-002-s022><destroy.abbrechen><en> 58 We heard him say, I will destroy this temple that is made with hands, and within three days I will build another made without hands.
<G-vec00389-002-s023><destroy.abbrechen><de> Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s023><destroy.abbrechen><en> "We heard him say, 'I will destroy this temple that is made with hands, and in three days I will build another made without hands.'"
<G-vec00389-002-s024><destroy.abbrechen><de> Vor dem am Kreuz hängenden Christus beziehen sich Spötter auf das gleiche Wort und rufen ihm zu: „Der du den Tempel abbrechen und in drei Tagen wieder aufbauen kannst, rette dich selbst“ (Mt 27, 40).
<G-vec00389-002-s024><destroy.abbrechen><en> In front of Christ hanging on the Cross some people, taunting him, referred to these same words: "You who would destroy the temple and build it in three days, save yourself!" (Mt 27: 40).
<G-vec00389-002-s027><destroy.abbrechen><de> Und einige standen auf und gaben falsches Zeugnis ab gegen ihn und sprachen: Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s027><destroy.abbrechen><en> 57 And some stood up and bore false witness against him, saying, 58 “We heard him say, ‘I will destroy this temple that is made with hands, and in three days I will build another, not made with hands.’”
<G-vec00389-002-s028><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel GOttes abbrechen und in dreien Tagen denselben bauen.
<G-vec00389-002-s028><destroy.abbrechen><en> Finally, two men came forward 61 who declared, "This man said, 'I am able to destroy the Temple of God and rebuild it in three days.'"
<G-vec00389-002-s029><destroy.abbrechen><de> 14:57 Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 14:58 Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s029><destroy.abbrechen><en> 57Some stood up and began to give false testimony against Him, saying, 58“We heard Him say, ‘I will destroy this temple made with hands, and in three days I will build another made without hands.’”
<G-vec00389-002-s030><destroy.abbrechen><de> 58 Wir haben gehört, dass er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s030><destroy.abbrechen><en> 58 “We heard him say, ‘I will destroy this temple made with human hands and in three days will build another, not made with hands.’ ”
<G-vec00296-003-s019><break_down.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00296-003-s019><break_down.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00296-003-s020><break_down.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00296-003-s020><break_down.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00296-003-s021><break_down.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00296-003-s021><break_down.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00296-003-s022><break_down.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00296-003-s022><break_down.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00296-003-s023><break_down.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00296-003-s023><break_down.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00296-003-s024><break_down.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00296-003-s024><break_down.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00296-003-s025><break_down.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00296-003-s025><break_down.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00296-003-s026><break_down.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00296-003-s026><break_down.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00296-003-s027><break_down.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00296-003-s027><break_down.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00296-003-s028><break_down.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00296-003-s028><break_down.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00296-003-s029><break_down.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00296-003-s029><break_down.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00296-003-s030><break_down.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00296-003-s030><break_down.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00296-003-s031><break_down.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00296-003-s031><break_down.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00296-003-s032><break_down.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00296-003-s032><break_down.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00296-003-s033><break_down.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00296-003-s033><break_down.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00296-003-s034><break_down.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00296-003-s034><break_down.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00296-003-s035><break_down.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00296-003-s035><break_down.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00296-003-s036><break_down.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00296-003-s036><break_down.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00296-003-s037><break_down.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00296-003-s037><break_down.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00486-002-s019><suspend.abbrechen><de> Denn es ist einfach unmöglich durchzuführen und zu kontrollieren, daß die zu Übungen oder gar zu den Kontrollversammlungen einberufenen Mannschaften zum Beispiel ihr Verhältnis zu den Gewerkschaften und andren sogenannten revolutionären Organisationen für die Dauer ihrer Übung oder gar für die Dauer des Tags der Kontrollversammlung lösen, daß sie für diese Zeit die Abonnements auf die Arbeiterblätter abbrechen (eine technisch gar nicht durchführbare Sache) oder gar, daß sie in dieser Zeit die verpönte revolutionäre Literatur aus ihrer Wohnung verbannen und nicht lesen.
<G-vec00486-002-s019><suspend.abbrechen><en> It is simply impossible to control such persons, to enforce for example that they sever their connections with the trade unions and other so-called revolutionary organizations for the duration of their training or even on the day of the inspection, or that they should for the period in question suspend their subscriptions to the labour papers (a technical impossibility), or even that they should for this period cease to read the forbidden revolutionary literature and banish it from their homes.
<G-vec00486-002-s020><suspend.abbrechen><de> - Bei allergischen Reaktionen auf das Gel der Elektroden die Behandlung abbrechen und einen Arzt aufsuchen.
<G-vec00486-002-s020><suspend.abbrechen><en> - Patients allergic to the gel of the electrodes should suspend treatment and see a doctor.
<G-vec00486-002-s021><suspend.abbrechen><de> • Bei allergischen Reaktionen auf das Gel der Elektroden die Behandlung abbrechen und einen Arzt aufsuchen.
<G-vec00486-002-s021><suspend.abbrechen><en> • In case of allergy to the electrode gel, suspend treatment and see a doctor.
<G-vec00198-002-s019><break_off.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00198-002-s019><break_off.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00198-002-s020><break_off.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00198-002-s020><break_off.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00198-002-s021><break_off.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00198-002-s021><break_off.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00198-002-s022><break_off.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00198-002-s022><break_off.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00198-002-s023><break_off.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00198-002-s023><break_off.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00198-002-s024><break_off.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00198-002-s024><break_off.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00198-002-s025><break_off.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00198-002-s025><break_off.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00198-002-s026><break_off.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00198-002-s026><break_off.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00198-002-s027><break_off.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00198-002-s027><break_off.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00198-002-s028><break_off.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00198-002-s028><break_off.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00198-002-s029><break_off.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00198-002-s029><break_off.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00198-002-s030><break_off.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00198-002-s030><break_off.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00198-002-s031><break_off.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00198-002-s031><break_off.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00198-002-s032><break_off.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00198-002-s032><break_off.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00198-002-s033><break_off.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00198-002-s033><break_off.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00198-002-s034><break_off.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00198-002-s034><break_off.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00198-002-s035><break_off.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00198-002-s035><break_off.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00198-002-s036><break_off.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00198-002-s036><break_off.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00198-002-s037><break_off.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00198-002-s037><break_off.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00198-002-s019><break_up.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00198-002-s019><break_up.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00198-002-s020><break_up.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00198-002-s020><break_up.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00198-002-s021><break_up.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00198-002-s021><break_up.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00198-002-s022><break_up.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00198-002-s022><break_up.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00198-002-s023><break_up.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00198-002-s023><break_up.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00198-002-s024><break_up.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00198-002-s024><break_up.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00198-002-s025><break_up.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00198-002-s025><break_up.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00198-002-s026><break_up.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00198-002-s026><break_up.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00198-002-s027><break_up.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00198-002-s027><break_up.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00198-002-s028><break_up.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00198-002-s028><break_up.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00198-002-s029><break_up.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00198-002-s029><break_up.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00198-002-s030><break_up.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00198-002-s030><break_up.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00198-002-s031><break_up.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00198-002-s031><break_up.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00198-002-s032><break_up.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00198-002-s032><break_up.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00198-002-s033><break_up.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00198-002-s033><break_up.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00198-002-s034><break_up.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00198-002-s034><break_up.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00198-002-s035><break_up.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00198-002-s035><break_up.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00198-002-s036><break_up.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00198-002-s036><break_up.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00198-002-s037><break_up.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00198-002-s037><break_up.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00198-002-s152><break_up.abbrechen><de> Sie verbleiben entweder vom Knochen bedeckt im Kiefer (Retention) oder brechen teilweise durch (Teilretention).
<G-vec00198-002-s152><break_up.abbrechen><en> They remain in the jaw covered by bone (referred to as impaction) or break through only partially (partial impaction).
<G-vec00198-002-s153><break_up.abbrechen><de> Wer nicht dazu geneigt ist oder gar widersteht, macht den schmerzhaften Prozess durch, gebrochen zu werden, denn „biegen oder brechen“ ist die Schlüsselnote der Wassermann-Energie.
<G-vec00198-002-s153><break_up.abbrechen><en> Those who are not ready or who resist, are put through the painful process of breaking, for „bend or break” is the keynote of the Aquarian energy.
<G-vec00198-002-s154><break_up.abbrechen><de> Sie sorgen sich um uns, vertrauen uns und so werden wir unser Versprechen nicht brechen.
<G-vec00198-002-s154><break_up.abbrechen><en> You cared about us, trust us, and we will not break our promise.
<G-vec00198-002-s155><break_up.abbrechen><de> Wenn du ein Carbonfaser-Teil beschädigst, könnte es brechen oder die Beschädigung nicht auf den ersten Blick zu erkennen sein.
<G-vec00198-002-s155><break_up.abbrechen><en> When you damage a carbon fiber part, it could break or it could conceal damage from the naked eye.
<G-vec00198-002-s156><break_up.abbrechen><de> 31,16 Und der HERR sprach zu Mose: Siehe, du wirst schlafen bei deinen Vätern, und dies Volk wird sich erheben und nachlaufen den fremden Göttern des Landes, in das sie kommen, und wird mich verlassen und den Bund brechen, den ich mit ihm geschlossen habe.
<G-vec00198-002-s156><break_up.abbrechen><en> Behold, thou shalt sleep with thy fathers; and this people will rise up, and go a whoring after the gods of the strangers of the land, whither they go to be among them, and will forsake me, and break my covenant which I have made with them.
<G-vec00198-002-s157><break_up.abbrechen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00198-002-s157><break_up.abbrechen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00198-002-s159><break_up.abbrechen><de> Der Versuch geht nicht darum, Burts Rekord zu brechen, sondern darum sein Erbe zu würdigen.
<G-vec00198-002-s159><break_up.abbrechen><en> The attempt is not to break Burt’s record, but to appreciate his legacy.
<G-vec00198-002-s160><break_up.abbrechen><de> Die Schlaghämmer leiten die Energie in das Bauteil und brechen den Kern.
<G-vec00198-002-s160><break_up.abbrechen><en> The impact hammers conduct energy into the component and break up the core.
<G-vec00198-002-s161><break_up.abbrechen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00198-002-s161><break_up.abbrechen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00198-002-s162><break_up.abbrechen><de> Sie deutet darauf hin, dass die Installation eines Paketes ein anderes Paket (oder bestimmte Versionen davon) „brechen“ wird.
<G-vec00198-002-s162><break_up.abbrechen><en> It signals that the installation of a package will “break” another package (or particular versions of it).
<G-vec00198-002-s163><break_up.abbrechen><de> Zerquetschen Sie es, kauen Sie es, oder brechen Sie die Pillen nicht.
<G-vec00198-002-s163><break_up.abbrechen><en> Do not crush, chew, or break the tablet.
<G-vec00198-002-s164><break_up.abbrechen><de> Hazem Kassem, ein Sprecher im Namen der Hamas, sagte, dass das palästinensische Volk vor dem ersten Jahrestag der “Prozessionen” vorhatte, anlässlich des “Tag der Erde” mit der “Prozession der Millionen” an Land zu brechen, um die Hauptziele der “Prozessionen der großen Rückkehr” zu erfüllen.
<G-vec00198-002-s164><break_up.abbrechen><en> Hamas spokesman Hazem Qassem said that with the approach of the first anniversary of the “return marches,” the Palestinian people were planning to break [into Israeli territory] with the “million-man march” on Land Day to stress the main objectives of the marches.
<G-vec00198-002-s165><break_up.abbrechen><de> Zeitgleich wird die in das Bauteil eingebrachte Hammerenergie dazu verwendet, den Kernsand im Bauteil zu brechen, um diesen anschließend herausrütteln zu können.
<G-vec00198-002-s165><break_up.abbrechen><en> At the same time, the hammer energy introduced into the component is used to break up the core sand in the component, so this can subsequently be shaken out.
<G-vec00198-002-s166><break_up.abbrechen><de> Sie ist in mehr oder minder radikalmarxistischen Bewegungen zusammengefaßt, entschlossen, jeden geistigen Widerstand durch die Macht der Gewalt zu brechen.
<G-vec00198-002-s166><break_up.abbrechen><en> It is organized in more or less radical Marxist movements, determined to break all spiritual resistance by the power of violence.
<G-vec00198-002-s167><break_up.abbrechen><de> Nur zu schauen sei er gekommen, antwortet Wotan, nicht zu schaffen – und Alberich erinnert seinerseits daran, daß er den Vertrag mit Fafner nicht brechen dürfe, der ja den Ring und den gesamten Schatz als Bezahlung für die Errichtung Walhalls und die Freilassung der Göttin Freia erhalten habe.
<G-vec00198-002-s167><break_up.abbrechen><en> Wotan tells him that he comes only to watch, since he cannot, as Alberich reminds him, break his agreement with Fafner, who had been given the ring and other treasure in return for the release of the goddess Freia.
<G-vec00198-002-s168><break_up.abbrechen><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00198-002-s168><break_up.abbrechen><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00198-002-s169><break_up.abbrechen><de> Er würde alles tun, alles, um das zu brechen, was er den Aberglauben des Kreuzes nennt.
<G-vec00198-002-s169><break_up.abbrechen><en> He would do anything, anything, to break what he calls the superstition of the Cross.
<G-vec00198-002-s170><break_up.abbrechen><de> Zerquetschen Sie nicht, kauen Sie, brechen Sie, oder öffnen Sie eine Kapsel der verlängerten Ausgabe.
<G-vec00198-002-s170><break_up.abbrechen><en> Do not crush, chew, break, or open an extended-release capsule.
<G-vec00198-002-s171><break_up.abbrechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00198-002-s171><break_up.abbrechen><en> HSL break the body fat shops within your cells.
<G-vec00198-002-s172><break_up.abbrechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00198-002-s172><break_up.abbrechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00198-002-s173><break_up.abbrechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00198-002-s173><break_up.abbrechen><en> Q Right – but you don’t break his nose.
<G-vec00198-002-s174><break_up.abbrechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00198-002-s174><break_up.abbrechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00198-002-s175><break_up.abbrechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00198-002-s175><break_up.abbrechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00198-002-s176><break_up.abbrechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00198-002-s176><break_up.abbrechen><en> The part could break without warning (see figure 80).
<G-vec00198-002-s177><break_up.abbrechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00198-002-s177><break_up.abbrechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00198-002-s178><break_up.abbrechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00198-002-s178><break_up.abbrechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00198-002-s179><break_up.abbrechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00198-002-s179><break_up.abbrechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00198-002-s180><break_up.abbrechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00198-002-s180><break_up.abbrechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00198-002-s181><break_up.abbrechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00198-002-s181><break_up.abbrechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00198-002-s182><break_up.abbrechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00198-002-s182><break_up.abbrechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00198-002-s183><break_up.abbrechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00198-002-s183><break_up.abbrechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00198-002-s184><break_up.abbrechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00198-002-s184><break_up.abbrechen><en> HSL break the fat stores within your cells.
<G-vec00198-002-s185><break_up.abbrechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00198-002-s185><break_up.abbrechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00198-002-s186><break_up.abbrechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00198-002-s186><break_up.abbrechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00198-002-s187><break_up.abbrechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00198-002-s187><break_up.abbrechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00198-002-s188><break_up.abbrechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00198-002-s188><break_up.abbrechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00198-002-s189><break_up.abbrechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00198-002-s189><break_up.abbrechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00198-002-s057><cancel.abbrechen><de> Dies wird den Transfer abbrechen und eure Credits sind verloren.
<G-vec00198-002-s057><cancel.abbrechen><en> This will cancel the transfer and your Offerings will be lost.
<G-vec00198-002-s058><cancel.abbrechen><de> Klicken Sie den Abbrechen Butto, um den Charakterisierungsmodus zu verlassen.
<G-vec00198-002-s058><cancel.abbrechen><en> Click the Cancel button to exit the characterization mode.
<G-vec00198-002-s059><cancel.abbrechen><de> Sie können auf „Abbrechen“ klicken, um die Anwendung des Effekts auf den Clip abzubrechen.
<G-vec00198-002-s059><cancel.abbrechen><en> You can click Cancel to cancel the effect from being applied on the clip.
<G-vec00198-002-s060><cancel.abbrechen><de> Klicken Sie im Uploadfenster auf Abbrechen.
<G-vec00198-002-s060><cancel.abbrechen><en> In the download window, click Cancel.
<G-vec00198-002-s061><cancel.abbrechen><de> Um die Verknüpfung mit der Quelldatei abzubrechen und die Audiospur in allen Instanzen des Offlineclips beizubehalten, klicken Sie auf „Abbrechen“.
<G-vec00198-002-s061><cancel.abbrechen><en> To cancel linking to the source file, and retain the audio track in all instances of the offline clip, click Cancel.
<G-vec00198-002-s062><cancel.abbrechen><de> Stattdessen können Sie Ihre Meinung und Bewertung ändern oder Ihre Neubewertung abbrechen.
<G-vec00198-002-s062><cancel.abbrechen><en> What you can do is to: change your mind and your vote or cancel your vote.
<G-vec00198-002-s063><cancel.abbrechen><de> Sie drücken F9 und klicken auf "Abbrechen".
<G-vec00198-002-s063><cancel.abbrechen><en> Press F9 and select the Cancel button.
<G-vec00198-002-s064><cancel.abbrechen><de> Den Bestellvorgang können Sie jederzeit abbrechen oder durch Anklicken des Buttons [BESTELLEN oder KAUFEN-BUTTONS] abschließen.
<G-vec00198-002-s064><cancel.abbrechen><en> The ordering process you can cancel at any time or [order or purchase-BUTTONS] by clicking the button to complete.
<G-vec00198-002-s065><cancel.abbrechen><de> Wenn Sie „Synchronisieren“ nicht auswählen (indem Sie nicht innerhalb einer bestimmten Zeit reagieren) oder „Abbrechen“ wählen, wird die Synchronisierung nicht durchgeführt und Sie müssen „Telefon synchronisieren“ in ELEMNT erneut auswählen.
<G-vec00198-002-s065><cancel.abbrechen><en> If you do not select Pair (by allowing a timeout) or you select Cancel, pairing will not proceed and you will need to select Pair Phone again on the ELEMNT BOLT.
<G-vec00198-002-s066><cancel.abbrechen><de> Abbrechen Kunden, die diesen Artikel gekauft haben, kauften auch...
<G-vec00198-002-s066><cancel.abbrechen><en> Submit or Cancel Customers who bought this product also bought:
<G-vec00198-002-s067><cancel.abbrechen><de> Vor Abschicken der Bestellung kann der Kunde die Daten jederzeit ändern und einsehen sowie mithilfe der Browserfunktion „zurück“ zum Warenkorb zurückgehen oder den Bestellvorgang insgesamt abbrechen.
<G-vec00198-002-s067><cancel.abbrechen><en> Before submitting the order, the customer can always change and view the data, as wall as using the bbrowser function “back” to return to the shopping cart or cancel the entire order process.
<G-vec00198-002-s068><cancel.abbrechen><de> Sie können sie jederzeit abbrechen, indem Sie die Esc-Taste drücken.
<G-vec00198-002-s068><cancel.abbrechen><en> You can cancel at any time by pressing the Escape (Esc) key.
<G-vec00198-002-s069><cancel.abbrechen><de> Wiederholen Sie Schritt 5 bis 6, wenn Sie weitere Druckaufträge abbrechen möchten.
<G-vec00198-002-s069><cancel.abbrechen><en> Repeat steps 5 through 6 if you want to cancel other print jobs.
<G-vec00198-002-s070><cancel.abbrechen><de> Die Schaltflächen „Anwenden und Abbrechen“ für Filter wurden weiterhin angezeigt, auch wenn im Filter keine Elemente ausgewählt waren.
<G-vec00198-002-s070><cancel.abbrechen><en> Apply and Cancel buttons for filters were still displayed even when there were no items to select in the filter.
<G-vec00198-002-s071><cancel.abbrechen><de> Abbrechen: Kehren Sie zurück zum SMS-Interface.
<G-vec00198-002-s071><cancel.abbrechen><en> Cancel: Return to the SMS interface.
<G-vec00198-002-s072><cancel.abbrechen><de> •Zum Abbrechen des laufenden Spülprogramms oder einer laufenden Zeitvorwahl.
<G-vec00198-002-s072><cancel.abbrechen><en> •To cancel the washing programme in progress or a delay start in progress.
<G-vec00198-002-s073><cancel.abbrechen><de> Klicken Sie auf "Rückerstattung erteilen" (Vorgang abschließen) oder "Abbrechen" (neu versuchen).
<G-vec00198-002-s073><cancel.abbrechen><en> Click "Issue Refund" to finish or "Cancel" to restart.
<G-vec00198-002-s074><cancel.abbrechen><de> Falls es Probleme gibt, können Sie den Download-Vorgang abbrechen und erneut laden.
<G-vec00198-002-s074><cancel.abbrechen><en> In case there is any problem, you can cancel the download process and reload it again.
<G-vec00198-002-s075><cancel.abbrechen><de> Die Zeichenfolge „Abbrechen“ in der Taste zum Abbrechen ist nun auch auf der Anmeldeseite vorhanden.
<G-vec00198-002-s075><cancel.abbrechen><en> String "Cancel" in cancel button now includes the sign-in page.
<G-vec00198-002-s092><cancel.abbrechen><de> Die Spieler können entweder den Knopf „Start” drücken, um die Walzen handbetätigt zu drehen, oder „Autoplay” auswählen, um die Maschine allein zu arbeiten lassen, bis das Feature abgebrochen wird oder bis es kein Spielgeld mehr gibt.
<G-vec00198-002-s092><cancel.abbrechen><en> Players can either click the ‘Start’ button to spin the reels manually, or choose ‘Autoplay’ to leave the machine to its own devices until they either cancel the feature or run out of credits.
<G-vec00198-002-s093><cancel.abbrechen><de> Wenn Ihr 'Gottesschild' oder 'Segen des Schutzes' auf Euch selbst wirkt, wird dieser Effekt abgebrochen.
<G-vec00198-002-s093><cancel.abbrechen><en> Using Divine Shield or Blessing of Protection on yourself will cancel this effect. Adaptation Adaptation
<G-vec00198-002-s094><cancel.abbrechen><de> Beispielsweise werden dieselben visuellen Signale angezeigt, wenn ein Steuerelement aktiviert wird, um dessen Art anzugeben, und wenn die Aktivierung abgebrochen wird, falls der Benutzer es sich anders überlegt.
<G-vec00198-002-s094><cancel.abbrechen><en> For example, the user will see the same visuals to let them know what was activated and again when they successfully cancel the activation if they change their mind.
<G-vec00198-002-s095><cancel.abbrechen><de> Wenn die Passwortabfrage abgebrochen wird, wird das Laufwerk "sicher entfernt" oder dessen Datenträger ausgeworfen.
<G-vec00198-002-s095><cancel.abbrechen><en> When the user presses "Cancel" or closes the dialog then the drive is prepared for safe removal or it's media is ejected.
<G-vec00198-002-s096><cancel.abbrechen><de> Abbruch Nach Aktivierung der Schaltfläche " " (während des Verschiebevorgangs) erscheint eine Abfrage, ob der Verschiebevorgang wirklich abgebrochen werden soll.
<G-vec00198-002-s096><cancel.abbrechen><en> Cancel After activating the button (during the copy process) the request "Do you really want to cancel the operation?" is shown.
<G-vec00198-002-s097><cancel.abbrechen><de> Klicken Sie im Warteschlangenfenster auf den Druckauftrag, der abgebrochen werden soll.
<G-vec00198-002-s097><cancel.abbrechen><en> From the queue window, select the job you want to cancel.
<G-vec00198-002-s098><cancel.abbrechen><de> Um eine endlose Schleife der „Bestätigung“-Dialogfelder zu vermeiden, kann anstatt des aktuellen Kapselungsvorgangs ein neuer Kapselungsvorgang ausgewählt und der Assistent abgebrochen werden.
<G-vec00198-002-s098><cancel.abbrechen><en> To prevent the loop of confirmation dialog boxes, select a new capture process rather than the current capture process and cancel the wizard.
<G-vec00198-002-s099><cancel.abbrechen><de> Ein Abonnement kann jederzeit abgebrochen werden.
<G-vec00198-002-s099><cancel.abbrechen><en> You can cancel your subscription at any time.
<G-vec00198-002-s100><cancel.abbrechen><de> Durch erneutes Drücken wird die Timer-Aufzeichnung abgebrochen.
<G-vec00198-002-s100><cancel.abbrechen><en> Press again to cancel the timer recording function.
<G-vec00198-002-s101><cancel.abbrechen><de> Das Kanalisieren von Zaubern wird nicht mehr vorzeitig abgebrochen, wenn ein Spieler auf den Lichtbrunnen klickt.
<G-vec00198-002-s101><cancel.abbrechen><en> Priest Bug Fixes Players will no longer prematurely cancel a channeled spell when clicking on the Lightwell.
<G-vec00198-002-s102><cancel.abbrechen><de> Fahrt abgebrochen Wenn der Nutzer noch vor Antritt die Fahrt abbrechen will, kann er/sie auf den Fahrt abgebrochen Button klicken.
<G-vec00198-002-s102><cancel.abbrechen><en> If any user wants to cancel his/her ride before it is started then he/she can click on cancel ride button .
<G-vec00198-002-s152><cancel.abbrechen><de> Der Veranstalter behält sich vor, das Gewinnspiel zu jedem Zeitpunkt ohne Vorankündigung und ohne Angabe von Gründen abzubrechen oder zu beenden.
<G-vec00198-002-s152><cancel.abbrechen><en> Metoshop reserves the right to cancel or terminate the Contest at any time without notice and without giving reasons. 2.
<G-vec00198-002-s153><cancel.abbrechen><de> Der Wunsch, die Erneuerung abzubrechen, muss per E-Mail an info@nvrm.ch bekannt gegeben werden.
<G-vec00198-002-s153><cancel.abbrechen><en> Desire to cancel one's renewal must be announced per email to info@nvrm.ch.
<G-vec00198-002-s156><cancel.abbrechen><de> Recht auf Abbruch: PokerStars Live, gemeinsam mit dem veranstaltenden Casino, in dem das Event stattfindet, behält sich das Recht vor, jegliches Event oder Turnier nach unserem alleinigen und uneingeschränkten Ermessen abzubrechen oder zu ändern.
<G-vec00198-002-s156><cancel.abbrechen><en> Right to Cancel: PokerStars Live, together with the organising casino in which the Event will be held, reserve the right to cancel or alter any Event or Tournament at our sole and absolute discretion.
<G-vec00198-002-s157><cancel.abbrechen><de> An jedem beliebigen Punkt der Journey kann sich der Kunde entscheiden, abzubrechen und auszusteigen – aus welchem Grund auch immer.
<G-vec00198-002-s157><cancel.abbrechen><en> At any point on the journey, the customer can decide to cancel and exit – for whatever reason.
<G-vec00198-002-s158><cancel.abbrechen><de> Vor Absenden der Bestellung haben Sie die Möglichkeit, alle Angaben nochmals zu überprüfen, zu ändern – dies auch über die "Zurück"-Funktion Ihres Internetbrowsers – oder den Kauf abzubrechen.
<G-vec00198-002-s158><cancel.abbrechen><en> Before submitting the order you have the opportunity to review all information again, to change - this also via the "back" function of your Internet browser - or cancel the purchase.
<G-vec00198-002-s159><cancel.abbrechen><de> Ein perfektes Argument um jede Debatte abzubrechen: Diejenigen, die kritisieren, tun es nur, weil sie nichts tun und Angst haben.
<G-vec00198-002-s159><cancel.abbrechen><en> A perfect argument to cancel all debate: those who criticize do it only because they don’t do anything and are afraid.
<G-vec00198-002-s160><cancel.abbrechen><de> EroDolls.com ist dazu berechtigt, nach eigenem Ermessen die Kampagne abzubrechen und die Teilnehmer erklären sich damit einverstanden, dass sie im Falle eines Abbruchs der Kampagne kein Anrecht auf Schadenersatz haben.
<G-vec00198-002-s160><cancel.abbrechen><en> highheelscrush.com is entitled at its sole discretion to cancel the campaign; the participants agree that they shall not be entitled to any compensation in case of cancellation.
<G-vec00198-002-s161><cancel.abbrechen><de> smutcam.com ist dazu berechtigt, nach eigenem Ermessen die Kampagne abzubrechen und die Teilnehmer erklären sich damit einverstanden, dass sie im Falle eines Abbruchs der Kampagne kein Anrecht auf Schadenersatz haben.
<G-vec00198-002-s161><cancel.abbrechen><en> smutcam.com is entitled at its sole discretion to cancel the campaign; the participants agree that they shall not be entitled to any compensation in case of cancellation.
<G-vec00198-002-s162><cancel.abbrechen><de> Toluna behält sich das Recht vor, die Verlosungen abzubrechen, zeitweise auszusetzen und/oder zu ändern, wenn Betrug, technische Fehler oder andere Faktoren, die jenseits der Kontrolle von Toluna liegen, die Integrität der Verlosungen beeinträchtigen könnten.
<G-vec00198-002-s162><cancel.abbrechen><en> Toluna reserves the right to cancel, suspend and/or modify the sweepstakes if fraud, technical failures or any other factors beyond the reasonable control of Toluna may impair the integrity of the sweepstakes.
<G-vec00198-002-s163><cancel.abbrechen><de> Um den Versand einer aktiven Anmeldebestätigung (im Status Senden) abzubrechen, wählen Sie diese in der Liste aus und klicken Sie anschließend auf Abbrechen.
<G-vec00198-002-s163><cancel.abbrechen><en> To cancel the sending of an active registration confirmation (in Sending status), select the registration confirmation from the list and then click Cancel.
<G-vec00198-002-s164><cancel.abbrechen><de> Um die Codierung anzuhalten oder abzubrechen, klicken Sie auf die entsprechenden Schaltflächen in der Fortschrittsleiste.
<G-vec00198-002-s164><cancel.abbrechen><en> To pause or cancel transcoding, use the corresponding buttons in the progress bar.
<G-vec00198-002-s165><cancel.abbrechen><de> Hinterlasse ein Kommentar Klicke hier um den Kommentar abzubrechen.
<G-vec00198-002-s165><cancel.abbrechen><en> Post comment Click here to cancel reply.
<G-vec00198-002-s166><cancel.abbrechen><de> Um diese Registration abzubrechen, klick bitte einfach auf den "Zurück" Button deines Browsers.
<G-vec00198-002-s166><cancel.abbrechen><en> To cancel this registration, simply hit the 'back' button on your browser
<G-vec00198-002-s167><cancel.abbrechen><de> Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s167><cancel.abbrechen><en> Leave a Comment Click here to cancel reply.
<G-vec00198-002-s168><cancel.abbrechen><de> Um einen aktuellen Druckauftrag abzubrechen, wählen Sie den gewünschten Auftrag in der Liste Name aus, und klicken Sie anschließend auf Löschen (Delete).
<G-vec00198-002-s168><cancel.abbrechen><en> To cancel a print job in progress, select the desired job in the Name list and click Delete.
<G-vec00198-002-s169><cancel.abbrechen><de> Um die Kommunikation zu stoppen oder abzubrechen, sollten Sie im Mac-System auswerfen und in Windows die Option zum sicheren Entfernen verwenden, die sich in der rechten Ecke der Taskleiste befindet.
<G-vec00198-002-s169><cancel.abbrechen><en> In order to stop or cancel communication, you should use eject in Mac system and in Windows use Safe remove option that is located at right most corner of the taskbar.
<G-vec00198-002-s170><cancel.abbrechen><de> Um alle Vorgänge abzubrechen, die auf dem lokalen Computer geplant sind, geben Sie at/deleteund drücken Sie die EINGABETASTE.
<G-vec00198-002-s170><cancel.abbrechen><en> To cancel all tasks that are scheduled on the local computer, type at /delete, and then press ENTER.
<G-vec00198-002-s172><cancel.abbrechen><de> Einen Kommentar hinterlassen Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s172><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s174><cancel.abbrechen><de> Schreibe einen Kommentar Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s174><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s175><cancel.abbrechen><de> Leave a Reply Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s175><cancel.abbrechen><en> Leave a Reply Click here to cancel reply
<G-vec00198-002-s176><cancel.abbrechen><de> Comments Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s176><cancel.abbrechen><en> Leave your thought Click here to cancel the reply
<G-vec00198-002-s177><cancel.abbrechen><de> Hinterlasse eine Antwort Hier klicken, um das Kommentieren abzubrechen.
<G-vec00198-002-s177><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s178><cancel.abbrechen><de> 777 behält sich das Recht vor, diese Aktion jederzeit ohne vorherige Ankündigung abzubrechen.
<G-vec00198-002-s178><cancel.abbrechen><en> 777 reserves the right to cancel this promotion at any time and without prior notice
<G-vec00198-002-s179><cancel.abbrechen><de> Online: Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s179><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s180><cancel.abbrechen><de> Schreibe einen Kommentar Hier klicken, um das Kommentieren abzubrechen.
<G-vec00198-002-s180><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s181><cancel.abbrechen><de> Leave a Comment Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s181><cancel.abbrechen><en> Leave Comment Click here to cancel the reply
<G-vec00198-002-s182><cancel.abbrechen><de> Hinterlasse einen Kommentar Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s182><cancel.abbrechen><en> Comment Leave a reply Click here to cancel the reply
<G-vec00198-002-s019><terminate.abbrechen><de> Während der Berechnung erhalten Sie eine exakte Kostenaufstellung und können selbst entscheiden, ob Sie eine Berechnung abbrechen oder weiterführen möchten.
<G-vec00198-002-s019><terminate.abbrechen><en> During the simulation, you will receive an exact cost trend, so that you can freely decide whether you want to terminate or to continue the simulation.
<G-vec00198-002-s020><terminate.abbrechen><de> Klicken Sie zum Abbrechen des Scanvorgangs auf die Schaltfläche Abbrechen unter der Fortschrittsanzeige.
<G-vec00198-002-s020><terminate.abbrechen><en> To terminate the scanning process, click Cancel button below the progress indicator.
<G-vec00198-002-s021><terminate.abbrechen><de> In den Gewässern der Arktis gibt es viele Eisberge, die von den Gletschern abbrechen, sowie Meereis, das weitgehend das ganze Jahr den arktischen Ozean bedeckt, jedoch um die arktischen Inseln herum saisonabhängig ist.
<G-vec00198-002-s021><terminate.abbrechen><en> The waters around our Arctic islands are influenced both by icebergs that discharge from the many glaciers that terminate in the sea, and by sea ice that is largely permanent over the Arctic Ocean, but seasonal around the islands.
<G-vec00198-002-s022><terminate.abbrechen><de> Die Entscheidung, ob Sie die Schwangerschaft abbrechen lassen oder fortführen, liegt allein bei Ihnen.
<G-vec00198-002-s022><terminate.abbrechen><en> It is up to you to decide whether you want to terminate or continue the pregnancy.
<G-vec00198-002-s023><terminate.abbrechen><de> Sollte die Server-Anwendung unplanmäßig abbrechen, wird der Guardian versuchen, sie erneut zu starten.
<G-vec00198-002-s023><terminate.abbrechen><en> Should the server application terminate abnormally, the Guardian will attempt to restart it.
<G-vec00198-002-s029><terminate.abbrechen><de> Der Kunde nimmt zur Kenntnis, dass im Verlaufe der Dauer der Geschäftsbeziehung Umstände eintreten können, die die TWINT AG gesetzlich verpflichten, Vermögenswerte zu sperren, die Geschäftsbeziehung einer zuständigen Behörde zu melden oder abzubrechen.
<G-vec00198-002-s029><terminate.abbrechen><en> Customers shall acknowledge that circumstances may arise during the term of the business relationship that may legally obligate TWINT AG to block assets, report the business relationship to a responsible authority or terminate the business relationship.
<G-vec00198-002-s030><terminate.abbrechen><de> Im Verlauf des Versuchs muss der Versuchsleiter jederzeit darauf vorbereitet sein, den Versuch abzubrechen, wenn er bei Anwendung der von ihm geforderten besonderen Redlichkeit und Erfahrung sowie seines sorgfältigen Urteils Grund hat anzunehmen, dass eine Fortsetzung des Versuches zu einer Verletzung, bleibenden gesundheitlichen Schädigung oder dem Tod der Versuchsperson führen könnte.
<G-vec00198-002-s030><terminate.abbrechen><en> During the course of the experiment the scientist in charge must be prepared to terminate the experiment at any stage, if he has probably cause to believe, in the exercise of the good faith, superior skill and careful judgment required of him that a continuation of the experiment is likely to result in injury, disability, or death to the experimental subject.
<G-vec00198-002-s031><terminate.abbrechen><de> Frauen haben seine Zweige benutzt um ihre ungewollten Schwangerschaften abzubrechen und sind viel zu oft dabei gestorben.
<G-vec00198-002-s031><terminate.abbrechen><en> Women have used his branches to terminate their unwanted pregnancies and have died far too often.
<G-vec00198-002-s032><terminate.abbrechen><de> Tektronix behält sich das Recht vor, das Gewinnspiel im eigenen Ermessen zu annullieren, abzubrechen, zu ändern oder auszusetzen.
<G-vec00198-002-s032><terminate.abbrechen><en> Tektronix reserves the right in its sole discretion to cancel, terminate, modify or suspend the Sweepstakes.
<G-vec00198-002-s033><terminate.abbrechen><de> ?> Der Umgang mit Returns: Es ist möglich eine return() -Anweisung innerhalb einer eingebunden Datei anzugeben, um die Ausführung innerhalb dieser Datei abzubrechen und zum aufrufenden Skript zurückzukehren.
<G-vec00198-002-s033><terminate.abbrechen><en> ?> Handling Returns: It is possible to execute a return() statement inside an included file in order to terminate processing in that file and return to the script which called it.
<G-vec00198-002-s034><terminate.abbrechen><de> Ebenso behalten wir uns vor, eine Reise aus oben angeführten Gründen abzubrechen.
<G-vec00198-002-s034><terminate.abbrechen><en> We also reserve the right to terminate a tour for the reasons listed above.
<G-vec00198-002-s035><terminate.abbrechen><de> (6) Das besondere Verhandlungsgremium kann mit der nachstehend festgelegten Mehrheit beschließen, keine Verhandlungen aufzunehmen oder bereits aufgenommene Verhandlungen abzubrechen und die Vorschriften für die Unterrichtung und Anhörung der Arbeitnehmer zur Anwendung gelangen zu lassen, die in den Mitgliedstaaten gelten, in denen die SE Arbeitnehmer beschäftigt.
<G-vec00198-002-s035><terminate.abbrechen><en> The special negotiating body may decide by the majority set out in the second subparagraph not to open negotiations or to terminate negotiations already opened, and to rely on the rules on information and consultation of employees in force in the Member States where the SCE has employees.
<G-vec00942-002-s029><abandon.abbrechen><de> Auf der zweitägigen Tagung werden am ersten Tag die Projektergebnisse sowie konkrete Handlungsempfehlungen präsentiert, Studiengänge so zu gestalten, dass mehr Frauen sich für sie entscheiden und diese auch nicht abbrechen.
<G-vec00942-002-s029><abandon.abbrechen><en> On the first day of the two-day conference, the project results and concrete recommendations for action will be presented, with the aim of designing study programmes in such a way that more women decide in favour of them and do not abandon them.
<G-vec00942-002-s030><abandon.abbrechen><de> Sie studierte von 1988 bis 1993 in Tiflis, musste das Studium wegen des Bürgerkriegs abbrechen, kam nach Deutschland an die Düsseldorfer Kunstakademie, die sie als Meisterschülerin von Rosemarie Trockel abschloss.
<G-vec00942-002-s030><abandon.abbrechen><en> She studied in Tbilisi between 1988 and 1993, but had to abandon her studies due to the civil war and therefore headed for Germany, where she attended the Kunstakademie Düsseldorf, graduating from Rosemarie Trockel’s master class.
<G-vec00942-002-s031><abandon.abbrechen><de> Dies kann sogar so weit gehen, dass Kunden den Bestellvorgang abbrechen, wenn ihnen die gewünschten Zahlungs- oder Lieferoptionen nicht zur Verfügung stehen.
<G-vec00942-002-s031><abandon.abbrechen><en> This can even go so far that customers abandon the order process if the desired payment or delivery options are not available to them.
<G-vec00942-002-s032><abandon.abbrechen><de> Ziel-Prozesse zeigen, an welchen Stellen Besucher auf dem Weg zur jeweiligen Konversion abbrechen.
<G-vec00942-002-s032><abandon.abbrechen><en> Target processes show at which points on the way to the corresponding conversions visitors abandon the process.
<G-vec00942-002-s033><abandon.abbrechen><de> Vorteile Targeting Wir gewährleisten, dass Live-Chat den richtigen Kunden zur richtigen Zeit angeboten wird, bevor diese ihren Besuch abbrechen.
<G-vec00942-002-s033><abandon.abbrechen><en> Benefits Targeting We ensure that live chat is offered to the right customer at the right time, before they abandon their visit.
<G-vec00942-002-s034><abandon.abbrechen><de> Das heißt, sie kommen an einen Punkt, an dem sie sagen: „Darf ich jetzt noch riskieren, ohne einen zweiten Unfall zu bauen oder muss ich abbrechen?“ Das sind Erlebnisse, die tiefer gehen.
<G-vec00942-002-s034><abandon.abbrechen><en> This means they come to a point where they say, “Can I now take a risk without causing a second accident, or will I have to abandon the mission?” These are experiences which go deeper.
<G-vec00942-002-s035><abandon.abbrechen><de> Der schnelle Erfolg als Unternehmer ließ ihn das Studium vor dem Vordiplom abbrechen.
<G-vec00942-002-s035><abandon.abbrechen><en> His rapid success as an entrepreneur led him to abandon his studies before obtaining the preliminary diploma.
<G-vec00942-002-s036><abandon.abbrechen><de> Auch wenn Rot und Braun diesen Angriff abgewendet hätten und Grün den Angriff abbrechen hätte müssen, wären alle drei Boote nach diesem Manöver weiter in Lee gewesen und Grün wäre nicht mehr oberhalb der Layline positioniert.
<G-vec00942-002-s036><abandon.abbrechen><en> Even if red and brown had averted this attack, and green had to abandon it, all three boats would have been further leeward after this manoeuvre, and green would no longer have been positioned above the starboard lay line.
<G-vec00942-002-s045><abandon.abbrechen><de> Setzen Sie diesen Parameter auf TRUE (aktiviert), um die weitere Ausführung des Auftrags abzubrechen, wenn der aktuelle Ausführungsschritt fehlschlägt.
<G-vec00942-002-s045><abandon.abbrechen><en> Set this parameter to TRUE (enabled) to abandon further job execution if the current execution step fails.
<G-vec00942-002-s046><abandon.abbrechen><de> Dieses von ihrem Komponisten als »Singspiel« bezeichnete Bühnenstück aus dem Jahre 1704 war der erste Opernversuch des jungen Händel, der damit für Reinhard Keiser, den Pächter und Direktor der Hamburger Oper am Gänsemarkt, einsprang: Dieser war gezwungen gewesen, ein geplantes Werk abzubrechen, als er sich vor seinen Gläubigern in Sicherheit brachte.
<G-vec00942-002-s046><abandon.abbrechen><en> Almira, described as a Singspiel, was Handel’s first attempt at opera, written in Hamburg to replace a work that, seemingly, Reinhard Keiser, the lessee and director of the Hamburg Goosemarket Opera, had been forced to abandon, while he took refuge from his creditors. It was staged in Hamburg in 1704.
<G-vec00942-002-s047><abandon.abbrechen><de> Falls die Entscheidung, den Lauf abzubrechen, zwischen 2 Kontrollposten getroffen wird, muss sich der Läufer zu dem am nächsten gelegenen Kontrollposten begeben und dort den Abbruch bekanntgeben.
<G-vec00942-002-s047><abandon.abbrechen><en> In the case of the decision to abandon between two check points, the runner must go to the nearest check point where they announce their abandonment.
<G-vec00942-002-s048><abandon.abbrechen><de> Als die Subraumwesen ihren Angriff auf die beiden Schiffe verstärken, entscheidet Captain Janeway, die Reparatur der Equinox abzubrechen und sie als schwächeres Schiff zugunsten der Voyager zurückzulassen.
<G-vec00942-002-s048><abandon.abbrechen><en> When the subspace beings expand their attacks on both ships, Captain Janeway decides to stop repairing the Equinox and abandon it as the weaker ship in favor of Voyager.
<G-vec00942-002-s049><abandon.abbrechen><de> Februar 2012 versuchten sie ein siebtes Mal, Dr. Zhang ins Arbeitslager einzuweisen, waren aber wegen ihres hohen Blutdruckes gezwungen, diesen Versuch abzubrechen.
<G-vec00942-002-s049><abandon.abbrechen><en> The seventh attempt to take Dr. Zhang to the labour camp was to be on February 1st, 2012, but they were forced to abandon this attempt due to her hypertension.
<G-vec00942-002-s050><abandon.abbrechen><de> Aus diesem Grund war Google gezwungen, die Anfrage abzubrechen.
<G-vec00942-002-s050><abandon.abbrechen><en> As a result, Google is forced to abandon the request.
