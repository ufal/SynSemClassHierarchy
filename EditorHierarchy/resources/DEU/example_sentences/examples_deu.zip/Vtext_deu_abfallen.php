<G-vec00418-001-s038><drop.abfallen><de> Wenn Du feststellst, das Deine Impressionen und die Lead-Qualität im Zeitraum von drei bis vier Tagen (oder wie lang es auch immer dauert, jemanden durch Deinen Trichter zu leiten) entscheidend abfallen, dann erhöh Dein Gebot schrittweise.
<G-vec00418-001-s038><drop.abfallen><en> If you find that your impressions and lead quality drop significantly, over a three to four-day period (or however long it takes for someone to go through your funnel), gradually increase your bid.
<G-vec00418-001-s039><drop.abfallen><de> Vom diffusen Haarausfall (diffuse Alopezie) spricht man, wenn die Haare vom gesamten Kopf abfallen.
<G-vec00418-001-s039><drop.abfallen><en> One speaks of the diffuse alopecia (diffuse alopecia) if the hairs drop from the whole head.
<G-vec00418-001-s040><drop.abfallen><de> Super-Kalt Chemikalien, wie flüssiger Stickstoff, werden auf Warzen in einer Sammlung von Therapien setzen und sie abfallen schließlich.
<G-vec00418-001-s040><drop.abfallen><en> Super-cold chemicals, such as liquid nitrogen, are put on warts in a collection of therapies and they eventually drop off.
<G-vec00418-001-s041><drop.abfallen><de> Der Name, „Roter Strand“ kommt von den einmaligen roten Lavaklippen, die auf den Strand abfallen, der mit rotem und schwarzem Kiesel und grobem Sand übersät ist.
<G-vec00418-001-s041><drop.abfallen><en> The name ‘red beach’ comes from the unique red lava cliffs which drop down to the beach which is comprised of red and black pebbles and coarse sand.
<G-vec00418-001-s042><drop.abfallen><de> Wenn Sie dann zurück nach Athen segeln, werden Sie die Pistazienhaine an der West- und Nordküste von Aegina sehen, wo die Klippen steil ins Meer abfallen.
<G-vec00418-001-s042><drop.abfallen><en> Sailing back to Athens from Aegina at the end of your sailing holiday in Greece, you will see the pistachio orchards along the west and north coast of the island, where cliffs drop steeply down to the sea.
<G-vec00418-001-s043><drop.abfallen><de> Zugluft und Temperaturextreme können bewirken, dass die Blütenknospen abfallen, noch bevor sie sich öffnen konnten.
<G-vec00418-001-s043><drop.abfallen><en> Drafts and temperature extremes can cause the flower buds to drop from the plant before they have a chance to open.
<G-vec00418-001-s044><drop.abfallen><de> Selbst wenn wir darum kämpfen, ihn zu behalten, wird er dennoch wieder von uns abfallen und seine Elemente zerstreuen.
<G-vec00418-001-s044><drop.abfallen><en> Even if we struggle to keep it, it will nevertheless drop off from us and disperse its elements.
<G-vec00418-001-s045><drop.abfallen><de> "Sind hier einige interessante Tatsachen, die dir zeigen, warum du wie nah an der Birne erhalten möchtest, wie du kannst - bei 2“ von der Birne, welche die Fußkerzen auf 700 abfallen, 4 "" =500, 8 "" =320, 16 "" =200."
<G-vec00418-001-s045><drop.abfallen><en> "Here are some interesting facts that will show you why you want to get as close to the bulb as you can - at 2"" from the bulb the foot candles drop to 700, 4""=500, 8""=320, 16""=200."
<G-vec00418-001-s046><drop.abfallen><de> Die langen rötlich orangefarbenen, röhrenförmigen Blüten erscheinen zu Beginn des Sommers jedes Jahr, gerade dann wenn die Blätter gelb werden und abfallen.
<G-vec00418-001-s046><drop.abfallen><en> The long reddish orange, tubular flowers are borne in upright racemes at the onset of summer each year, just as the leaves turn yellow and drop off.
<G-vec00418-001-s047><drop.abfallen><de> Das niedrige Eisenglas ist niedrigste Selbstexplosion, mit hoher Lichtdurchlässigkeit, gut transparent, ist sehr sicher und haltbar, Ursache von gehärtetes Glas Nach dem Bruch ist kleine Partikel, ist nicht schädlich und der PVB / SGP-Film wird zusammen laminiert das kleine Teilchen, ist nicht abfallen.
<G-vec00418-001-s047><drop.abfallen><en> The low iron glass is lowest self-explosion, with highly light transmittance, good transparent,is very safety and durable, cause of tempered glass after broken is been small particle, is not harmful and the PVB/SGP film will laminated together the small particle, is not drop off.
<G-vec00418-001-s048><drop.abfallen><de> Die Intensität und Dichte wird abfallen, und ihr werdet gewichtslos, und ihr werdet zu hoher Musik widerhallen, die jetzt immerzu präsent ist, die ihr aber zur Zeit nicht hört.
<G-vec00418-001-s048><drop.abfallen><en> The intensity and density will drop off, and you will be weightless, and you will reverberate to high music that is ever-present now but which you do not presently hear.
<G-vec00418-001-s049><drop.abfallen><de> Sobald die Geschwindigkeit abfallen, verringert die Vorderseite des Pedals den Winkel des Aufzugs.
<G-vec00418-001-s049><drop.abfallen><en> As soon as the speed drop off, the front of the pedal will reduce the angle of the lift.
<G-vec00418-001-s050><drop.abfallen><de> Kein Anschluß des großen vale sollte von diesem Punkt, für travel Schluchtwinde ungefähr unter den Felsspitzen gesehen werden, travel stark oben steigen und weit unten auf die Unterseite des felsigen Glen abfallen.
<G-vec00418-001-s050><drop.abfallen><en> No outlet of the great vale was to be seen from this point, for the gorge winds about among the crags which rise high above and drop far below to the base of the rocky glen.
<G-vec00418-001-s051><drop.abfallen><de> Natürlich, wenn Bergeron und Marchand sind auseinander, ihre Zahl deutlich abfallen, obwohl Bergeron ist weniger, weil er ist erstaunlich.
<G-vec00418-001-s051><drop.abfallen><en> Of course, when Bergeron and Marchand are apart, their numbers drop off considerably, though Bergeron’s less so because he is amazing.
<G-vec00418-001-s052><drop.abfallen><de> Ein Abfallen der Batteriespannung, das Fehldiagnosen verursachen kann oder zum Abbruch eines Software-Updates führt, wird somit vermieden.
<G-vec00418-001-s052><drop.abfallen><en> This prevents a drop in the battery voltage, which may cause a misdiagnosis or abortion of a software update.
<G-vec00418-001-s053><drop.abfallen><de> Diese anderen Knospen hier werden keine Früchte ansetzen und abfallen.
<G-vec00418-001-s053><drop.abfallen><en> These other buds over here will drop and not begin growing any fruit.
<G-vec00418-001-s054><drop.abfallen><de> Allerdings kann die Sicht unter Wasser nach heftigen Regenfällen auch manchmal auf 4 Meter abfallen.
<G-vec00418-001-s054><drop.abfallen><en> However, this can sometimes drop to as low as 13 feet (4 m) after heavy rains.
<G-vec00418-001-s055><drop.abfallen><de> All der Schmutz mag abfallen, aber die Lüge liegt darunter.
<G-vec00418-001-s055><drop.abfallen><en> All the dirt may drop off, yet the lie lies within.
<G-vec00418-001-s056><drop.abfallen><de> Eine Ernte wird daher im späten Herbst empfohlen, kurz bevor die Blätter abfallen.
<G-vec00418-001-s056><drop.abfallen><en> Harvesting therefore is recommended to be done in late fall, shortly before the leaves drop.
<G-vec00275-002-s019><fall.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00275-002-s019><fall.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00275-002-s020><fall.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00275-002-s020><fall.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00275-002-s021><fall.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00275-002-s021><fall.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00275-002-s022><fall.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00275-002-s022><fall.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00275-002-s023><fall.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00275-002-s023><fall.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00275-002-s024><fall.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00275-002-s024><fall.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00275-002-s025><fall.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00275-002-s025><fall.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00275-002-s026><fall.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00275-002-s026><fall.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00275-002-s027><fall.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00275-002-s027><fall.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00275-002-s028><fall.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00275-002-s028><fall.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00275-002-s029><fall.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00275-002-s029><fall.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00275-002-s030><fall.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00275-002-s030><fall.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00275-002-s031><fall.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00275-002-s031><fall.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00275-002-s032><fall.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00275-002-s032><fall.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00275-002-s033><fall.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00275-002-s033><fall.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00275-002-s034><fall.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00275-002-s034><fall.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00275-002-s035><fall.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00275-002-s035><fall.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00275-002-s036><fall.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00275-002-s036><fall.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00275-002-s037><fall.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00275-002-s037><fall.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00370-003-s019><fall_behind.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00370-003-s019><fall_behind.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00370-003-s020><fall_behind.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00370-003-s020><fall_behind.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00370-003-s021><fall_behind.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00370-003-s021><fall_behind.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00370-003-s022><fall_behind.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00370-003-s022><fall_behind.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00370-003-s023><fall_behind.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00370-003-s023><fall_behind.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00370-003-s024><fall_behind.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00370-003-s024><fall_behind.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00370-003-s025><fall_behind.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00370-003-s025><fall_behind.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00370-003-s026><fall_behind.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00370-003-s026><fall_behind.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00370-003-s027><fall_behind.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00370-003-s027><fall_behind.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00370-003-s028><fall_behind.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00370-003-s028><fall_behind.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00370-003-s029><fall_behind.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00370-003-s029><fall_behind.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00370-003-s030><fall_behind.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00370-003-s030><fall_behind.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00370-003-s031><fall_behind.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00370-003-s031><fall_behind.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00370-003-s032><fall_behind.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00370-003-s032><fall_behind.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00370-003-s033><fall_behind.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00370-003-s033><fall_behind.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00370-003-s034><fall_behind.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00370-003-s034><fall_behind.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00370-003-s035><fall_behind.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00370-003-s035><fall_behind.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00370-003-s036><fall_behind.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00370-003-s036><fall_behind.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00370-003-s037><fall_behind.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00370-003-s037><fall_behind.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00467-002-s019><fall_out.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00467-002-s019><fall_out.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00467-002-s020><fall_out.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00467-002-s020><fall_out.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00467-002-s021><fall_out.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00467-002-s021><fall_out.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00467-002-s022><fall_out.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00467-002-s022><fall_out.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00467-002-s023><fall_out.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00467-002-s023><fall_out.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00467-002-s024><fall_out.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00467-002-s024><fall_out.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00467-002-s025><fall_out.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00467-002-s025><fall_out.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00467-002-s026><fall_out.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00467-002-s026><fall_out.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00467-002-s027><fall_out.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00467-002-s027><fall_out.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00467-002-s028><fall_out.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00467-002-s028><fall_out.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00467-002-s029><fall_out.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00467-002-s029><fall_out.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00467-002-s030><fall_out.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00467-002-s030><fall_out.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00467-002-s031><fall_out.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00467-002-s031><fall_out.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00467-002-s032><fall_out.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00467-002-s032><fall_out.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00467-002-s033><fall_out.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00467-002-s033><fall_out.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00467-002-s034><fall_out.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00467-002-s034><fall_out.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00467-002-s035><fall_out.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00467-002-s035><fall_out.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00467-002-s036><fall_out.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00467-002-s036><fall_out.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00467-002-s037><fall_out.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00467-002-s037><fall_out.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00599-002-s019><fall_apart.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00599-002-s019><fall_apart.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00599-002-s020><fall_apart.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00599-002-s020><fall_apart.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00599-002-s021><fall_apart.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00599-002-s021><fall_apart.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00599-002-s022><fall_apart.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00599-002-s022><fall_apart.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00599-002-s023><fall_apart.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00599-002-s023><fall_apart.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00599-002-s024><fall_apart.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00599-002-s024><fall_apart.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00599-002-s025><fall_apart.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00599-002-s025><fall_apart.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00599-002-s026><fall_apart.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00599-002-s026><fall_apart.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00599-002-s027><fall_apart.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00599-002-s027><fall_apart.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00599-002-s028><fall_apart.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00599-002-s028><fall_apart.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00599-002-s029><fall_apart.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00599-002-s029><fall_apart.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00599-002-s030><fall_apart.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00599-002-s030><fall_apart.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00599-002-s031><fall_apart.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00599-002-s031><fall_apart.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00599-002-s032><fall_apart.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00599-002-s032><fall_apart.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00599-002-s033><fall_apart.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00599-002-s033><fall_apart.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00599-002-s034><fall_apart.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00599-002-s034><fall_apart.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00599-002-s035><fall_apart.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00599-002-s035><fall_apart.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00599-002-s036><fall_apart.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00599-002-s036><fall_apart.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00599-002-s037><fall_apart.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00599-002-s037><fall_apart.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00599-002-s019><fall_through.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00599-002-s019><fall_through.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00599-002-s020><fall_through.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00599-002-s020><fall_through.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00599-002-s021><fall_through.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00599-002-s021><fall_through.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00599-002-s022><fall_through.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00599-002-s022><fall_through.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00599-002-s023><fall_through.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00599-002-s023><fall_through.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00599-002-s024><fall_through.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00599-002-s024><fall_through.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00599-002-s025><fall_through.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00599-002-s025><fall_through.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00599-002-s026><fall_through.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00599-002-s026><fall_through.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00599-002-s027><fall_through.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00599-002-s027><fall_through.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00599-002-s028><fall_through.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00599-002-s028><fall_through.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00599-002-s029><fall_through.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00599-002-s029><fall_through.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00599-002-s030><fall_through.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00599-002-s030><fall_through.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00599-002-s031><fall_through.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00599-002-s031><fall_through.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00599-002-s032><fall_through.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00599-002-s032><fall_through.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00599-002-s033><fall_through.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00599-002-s033><fall_through.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00599-002-s034><fall_through.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00599-002-s034><fall_through.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00599-002-s035><fall_through.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00599-002-s035><fall_through.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00599-002-s036><fall_through.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00599-002-s036><fall_through.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00599-002-s037><fall_through.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00599-002-s037><fall_through.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00028-002-s019><fall_back.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00028-002-s019><fall_back.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00028-002-s020><fall_back.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00028-002-s020><fall_back.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00028-002-s021><fall_back.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00028-002-s021><fall_back.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00028-002-s022><fall_back.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00028-002-s022><fall_back.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00028-002-s023><fall_back.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00028-002-s023><fall_back.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00028-002-s024><fall_back.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00028-002-s024><fall_back.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00028-002-s025><fall_back.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00028-002-s025><fall_back.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00028-002-s026><fall_back.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00028-002-s026><fall_back.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00028-002-s027><fall_back.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00028-002-s027><fall_back.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00028-002-s028><fall_back.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00028-002-s028><fall_back.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00028-002-s029><fall_back.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00028-002-s029><fall_back.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00028-002-s030><fall_back.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00028-002-s030><fall_back.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00028-002-s031><fall_back.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00028-002-s031><fall_back.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00028-002-s032><fall_back.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00028-002-s032><fall_back.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00028-002-s033><fall_back.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00028-002-s033><fall_back.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00028-002-s034><fall_back.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00028-002-s034><fall_back.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00028-002-s035><fall_back.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00028-002-s035><fall_back.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00028-002-s036><fall_back.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00028-002-s036><fall_back.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00028-002-s037><fall_back.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00028-002-s037><fall_back.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00028-002-s019><fall_off.abfallen><de> Sobald die Dämpfe in Kontakt mit den Füllungsmaterialien kommen, werden die weniger flüchtigen Materialien, die auch einen niedrigeren Siedepunkt haben, kondensieren und abfallen.
<G-vec00028-002-s019><fall_off.abfallen><en> As the vapours come in contact with the cooler packed material, the less volatile compounds which have a lower boiling point will condense and fall back.
<G-vec00028-002-s020><fall_off.abfallen><de> Sie lehnten diese neuen Mitglieder ab, weil sie meinten, wenn deren zeitliche Bedürfnisse einmal gestillt seien, würden sie von der Kirche abfallen.
<G-vec00028-002-s020><fall_off.abfallen><en> They resented these new members because they believed that once their temporal needs had been met, they would fall away.
<G-vec00028-002-s021><fall_off.abfallen><de> Glaubet nur an Meine Liebe, und jede Sorge wird von euch abfallen.
<G-vec00028-002-s021><fall_off.abfallen><en> Just believe in my love, and all worry will fall off you.
<G-vec00028-002-s022><fall_off.abfallen><de> Es wird ganz natürlich abfallen und zu versuchen, es selbst zu entfernen könnte dem Cannabis in dieser sehr verwundbaren Phase seines Lebens schaden.
<G-vec00028-002-s022><fall_off.abfallen><en> It will naturally fall off, and trying to do it yourself could damage the cannabis at a very vulnerable stage of its life.
<G-vec00028-002-s023><fall_off.abfallen><de> Nach etwa einem Monat wird sich das Gummiband am Wurzelstock lösen und abfallen.
<G-vec00028-002-s023><fall_off.abfallen><en> In about a month, the rubber you wrapped around the rootstock may loosen and fall off.
<G-vec00028-002-s024><fall_off.abfallen><de> Auswärtige Anleihen sind wie Blutegel, die man vom Staatskörper nicht entfernen kann, es wäre dann, daß sie von selbst abfallen oder daß der Staat sie mit Gewalt abschüttelt.
<G-vec00028-002-s024><fall_off.abfallen><en> Foreign loans are leeches which there is no possibility of removing from the body of the State until they fall off of themselves or the State flings them off.
<G-vec00028-002-s025><fall_off.abfallen><de> Neben der Insel (Hvar), die bekannt ist als eine der sonnigsten in ganz Europa mit durchschnittlich 2718 Sonnenstunden erwartet Sie in Dalmatien auch eines der größten Geheimnisse des europäischen Tourismus – Süddalmatien, wo die Sonne immer noch scheint und es warm ist, wo das Meer immer noch einladend ist, während der Rest des Kontinents schon nach der Winterkleidung greift und beobachtet, wie die ersten Blätter abfallen.
<G-vec00028-002-s025><fall_off.abfallen><en> With an island (Hvar) known as the sunniest in all Europe with an average of 2718 hours of the good stuff every year, here is one of the great secrets of European tourism – southern Dalmatia in Europe is still glowing with sunshine and warm, inviting seas while the rest of the continent is reaching for its winter wear and watching the first leaves fall.
<G-vec00028-002-s026><fall_off.abfallen><de> Wenn die Angst abfallen soll wie eine alte Hülle, dann musst du zunächst den zerschlissenen Mantel der Inkarnation ablegen.
<G-vec00028-002-s026><fall_off.abfallen><en> If fear should fall off like an old shell, you have to take off the worn out coat of incarnations first.
<G-vec00028-002-s027><fall_off.abfallen><de> Dann werden die äußeren Riten und Glaubenssätze der alten Religionen entweder ganz abfallen oder eine neue, tiefere Bedeutung annehmen.
<G-vec00028-002-s027><fall_off.abfallen><en> In a sense. Then the outer ritual and the beliefs of the old religions will either fall way.
<G-vec00028-002-s028><fall_off.abfallen><de> Einige Hunde haben eine abgefallene Hüfte, wodurch der obere Gurt der Kniebandage hinten rutschen und abfallen kann.
<G-vec00028-002-s028><fall_off.abfallen><en> 15.74 - 17.32" inches Some dogs have a fallen hip and the upper belt may slide back and fall off.
<G-vec00028-002-s029><fall_off.abfallen><de> Brillen, die sofort abfallen, haben wahrscheinlich nicht die richtige Form für Dein Gesicht.
<G-vec00028-002-s029><fall_off.abfallen><en> Goggles that fall off immediately are most likely the wrong shape for your face.
<G-vec00028-002-s030><fall_off.abfallen><de> Wenn du hier dran hängst schüttelt sich der Koloss ganz fies, greife einfach fest zu, dann kannst du nicht abfallen.
<G-vec00028-002-s030><fall_off.abfallen><en> While you are hanging around here the colossus shakes really bad so hold on tight to not fall off.
<G-vec00028-002-s031><fall_off.abfallen><de> Seine Blätter sehen wie Flügel aus – sobald sie vom Baum abfallen, falten sie sich zusammen, um im Wind davon zu fliegen.
<G-vec00028-002-s031><fall_off.abfallen><en> Their leaves look like wings – as soon as they fall from the tree, they fold together and fly on the wind.
<G-vec00028-002-s032><fall_off.abfallen><de> Durch die Unterbrechung der Blutzufuhr werden die Hoden und das Skrotum absterben und von allein abfallen.
<G-vec00028-002-s032><fall_off.abfallen><en> Cutting off blood supply enables the testes and scrotum to gangrene and fall off on their own Disadvantages to banding:
<G-vec00028-002-s033><fall_off.abfallen><de> Nur die Idee war, dass man ein bisschen unzufireden mit seinem Ford-, GM – oder Chryslerprodukt – oder was auch immer – werden würde, weil kleine Dinge wie die Fenstergriffe abfallen würden und Plastikteile zerbrechen würden, welche gehalten hätten, hätte man sie aus Metall gemacht.
<G-vec00028-002-s033><fall_off.abfallen><en> But the idea was you could get a little bit disgusted with your Ford, GM or Chrysler product or whatever because little things like window handles would fall off more and plastic parts would break which had they been made of metal would hold up.
<G-vec00028-002-s034><fall_off.abfallen><de> Mögen die Faulbeerbäume trocknen wie Wäsche im Wind, Mögen die Fliederblüten vom Regen abfallen, Trotzdem werde ich dich von hier mitnehmen In ein Schloß, wo die Hirtenflöten spielen.
<G-vec00028-002-s034><fall_off.abfallen><en> Let the cherries dry out like laundry in the wind, Let the lilacs fall down like raindrops. But still, I will take you away from here To the castle where the reed - pipes are playing.
<G-vec00028-002-s035><fall_off.abfallen><de> 13Die aber auf dem Felsen sind die, welche, wenn sie hören, das Wort mit Freuden aufnehmen; und diese haben keine Wurzel, welche für eine Zeit glauben und in der Zeit der Versuchung abfallen.
<G-vec00028-002-s035><fall_off.abfallen><en> 13Those on rocky ground are the ones who, when they hear, receive the word with joy, but they have no root; they believe only for a time and fall away in time of trial.
<G-vec00028-002-s036><fall_off.abfallen><de> Dann wird jegliche Mangelhaftigkeit von euch abfallen, jeglicher Unseligkeit seid ihr entflohen, die geistige Blindheit wird hellstem Licht weichen, ihr werdet wieder in der Erkenntnis stehen, denn die Liebe selbst ist das Licht, das euch nun durchleuchtet und jegliche Finsternis verjagt....
<G-vec00028-002-s036><fall_off.abfallen><en> Then all imperfection will fall away from you, you will have escaped all unhappiness, spiritual blindness will give way to brilliant light, you will know everything again, for love itself is the light which will illuminate you and dispel all darkness....
<G-vec00028-002-s037><fall_off.abfallen><de> Nach 7-10 Tage warten (bis zu 3 Wochen ist bei großen oder komplizierten Warzen normal) sollte der Schorf natürlich abfallen.
<G-vec00028-002-s037><fall_off.abfallen><en> 8 Wait 1-3 weeks (up to 5 weeks is normal for large or complex warts) for scab to fall off naturally.
<G-vec00028-002-s019><plunge.abfallen><de> Im Kontrast dazu wird die brasilianische Produktion wahrscheinlich um mindestens 46% im Vergleich zum Vorjahr abfallen.
<G-vec00028-002-s019><plunge.abfallen><en> Conversely, Brazil nut global production (kernel basis) is expected to plunge at least 46% compared to the previous year.
<G-vec00028-002-s020><plunge.abfallen><de> BESCHREIBUNG Im Küstenabschnitt von San Vito lo Capo in Castellammare del Golfo erstreckt sich die Riserva Naturale dello Zingaro (die erste, die 1981 von der Region Sizilien gegründet wurde), eine abwechslungsreiche Landschaft – hohe Klippen, die in die blauen und erodierten Buchten zum Meer hin abfallen.
<G-vec00028-002-s020><plunge.abfallen><en> In the stretch of coast from San Vito lo Capo in Castellammare del Golfo, extends the Riserva Naturale dello Zingaro (the first established in 1981 by the region of Sicily), a varied landscape – high cliffs that plunge into the blue and eroded coves toward the sea.
