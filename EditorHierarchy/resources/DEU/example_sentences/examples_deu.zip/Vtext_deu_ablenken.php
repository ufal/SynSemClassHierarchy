<G-vec00854-002-s023><detract.ablenken><de> Doch nachts, wenn man alleine in seinem Bett liegt und von nichts abgelenkt wird, überkommt einen die Einsamkeit und sie klammert sich ganz fest an dein Herz.
<G-vec00854-002-s023><detract.ablenken><en> Yet at night, when you lay alone in your bed, without anything to detract your mind, the loneliness would creep onto you, clutch onto your heart as powerful as possible.
<G-vec00854-002-s024><detract.ablenken><de> Diese Ressourcenzuordnung werden nicht über die Verfügbarkeit der Ressource für die Arbeit an anderen Projekten ablenken.
<G-vec00854-002-s024><detract.ablenken><en> This resource assignment does not detract from the availability of the resource to work on other projects.
<G-vec00854-002-s025><detract.ablenken><de> Dies sollte jedoch nicht von der Tatsache ablenken, dass die internationalen Finanzinstitutionen zu den führenden Investoren in der Region sind.
<G-vec00854-002-s025><detract.ablenken><en> However this should not detract from the fact that the international financial institutions are among the leading investors in the region.
<G-vec00854-002-s026><detract.ablenken><de> Dies kann von einer guten Passform ablenken, und passt eher zu „Modejeans“; nicht zu alltagstauglichen Schnitten.
<G-vec00854-002-s026><detract.ablenken><en> They can detract from a good fit, and they are more indicative of “fashion” jeans, not everyday styles.
<G-vec00854-002-s044><detract.ablenken><de> Wenngleich sich Hoeneß und Schwarzer selbst anzeigten, so bleiben die Summen erschreckend, die sie hinterzogen und der gute Wille, etwas wieder gut zu machen, sollte nicht davon ablenken, dass sie an sich eine Straftat begingen und dies vermutlich mit Absicht.
<G-vec00854-002-s044><detract.ablenken><en> Even though Hoeneß and Schwarzer have confessed to their wrongdoings, the amounts which they have withheld remain appalling, and the good intentions to make amends should not detract from the fact that they committed a crime, and most likely with full intent.
<G-vec00854-002-s045><detract.ablenken><de> Nutzen Sie das Internet, um das Lernen zu verbessern, anstatt davon abzulenken.
<G-vec00854-002-s045><detract.ablenken><en> Use the internet to enhance learning, rather than detract from it.
<G-vec00854-002-s022><distract.ablenken><de> Unser Gehirn ist je nachdem wie wir unseren Alltag verbringen geübt sich zu konzentrieren oder aber sich abzulenken.
<G-vec00854-002-s022><distract.ablenken><en> Depending on how we spend our everyday lives, our brain is trained to concentrate or to distract itself.
<G-vec00854-002-s023><distract.ablenken><de> Vielleicht wollte Dumbledore auch verhindern, dass Harry durch irgendetwas von ihrem Unterricht abgelenkt wurde oder von seiner Aufgabe, Slughorn diese Erinnerung zu entlocken.
<G-vec00854-002-s023><distract.ablenken><en> It might even be that Dumbledore did not want anything to distract Harry from their lessons, or from procuring that memory from Slughorn.
<G-vec00854-002-s026><distract.ablenken><de> Sich darum Sorgen zu machen, welche Abbiegung man jetzt nehmen muss oder auf welche Fahrspur man wechseln sollte, lässt einen angespannter sein und wird dich vom guten Fahren ablenken.
<G-vec00854-002-s026><distract.ablenken><en> Worrying about which turn to take and which lane to get in will make you more tense and will also distract you from good driving techniques.
<G-vec00854-002-s027><distract.ablenken><de> Andererseits können sie vom Verkehr ablenken oder mit falschen Informationen für Verwirrung sorgen.
<G-vec00854-002-s027><distract.ablenken><en> But they can also distract the driver from traffic or confuse them with wrong information.
<G-vec00854-002-s028><distract.ablenken><de> Vielleicht ein wenig unnötige Verspieltheit undNeugier des Welpen in der ersten Phase wird ihn von der Durchführung der Mannschaft auf dem Gericht ablenken.
<G-vec00854-002-s028><distract.ablenken><en> Maybe a little unnecessary playfulness andThe curiosity of the puppy in the first stage will distract him from performing the team on the court.
<G-vec00854-002-s029><distract.ablenken><de> Wenn die fleckigen Hände das Kind weiterhin belästigen und vom künstlerischen Ausdruck ablenken, versuchen Sie es beim nächsten Mal mit einer speziellen Schürze aus wasserdichtem Stoff (es gibt sogar Modelle mit langen Ärmeln).
<G-vec00854-002-s029><distract.ablenken><en> If the stained hands continue to bother the child and distract from artistic expression, try next time to put on it a special apron of waterproof fabric (there are even models with long sleeves).
<G-vec00854-002-s030><distract.ablenken><de> „Bei der Gestaltung der ILBAGNOALESSI dOt-Kollektion wurde besonderes Augenmerk darauf gelegt, dass die einzelnen Teile nicht vom Wunsch ablenken, den Körper von Unreinheiten zu reinigen… Die Zusammenstellung des Ensembles basiert auf der individuellen Stärke seiner Einzelteile.
<G-vec00854-002-s030><distract.ablenken><en> “In designing the ILBAGNOALESSI dOt collection particular attention was devoted to assuring that the individual elements did not distract from the original intention of cleansing the body … The composition of the whole is based on the individual strength of its parts.
<G-vec00854-002-s031><distract.ablenken><de> Lasset euch nicht von der Welt betören, denn sie kann euch nicht ewig beglücken, jedoch völlig ablenken von Mir; setzet Mich an erste Stelle, und ihr werdet erkennen, wie leicht ihr auch das Erdenleben meistert, wie Mein Segen euch begleitet und euch Meine Hilfe sichtbar wird.
<G-vec00854-002-s031><distract.ablenken><en> Do not let yourselves be captivated by the world, because it cannot make you happy for ever, however completely distract you from me; put me in the first place, and you will recognize how easy you also master earth life, how my blessings accompany you and my help becomes visible to you.
<G-vec00854-002-s032><distract.ablenken><de> „Beim Autofahren kann zum Beispiel das gleichzeitige Klingeln, Vibrieren und Blinken des Handys zu sehr vom Straßenverkehr ablenken.
<G-vec00854-002-s032><distract.ablenken><en> “For example, when driving an automobile, the simultaneous ringing, vibrating, and flashing produced by a smartphone can significantly distract drivers from concentrating on the traffic.
<G-vec00854-002-s033><distract.ablenken><de> Ein Konflikt kann Einzelpersonen und Gruppen von ihren primären Zielen ablenken und dazu bringen, die Umgebung, in der es Konflikte gibt, zu verlassen.
<G-vec00854-002-s033><distract.ablenken><en> Conflict can distract individuals and groups from their primary purposes and desire to leave the environment that there is conflict in.
<G-vec00854-002-s034><distract.ablenken><de> Die ausgefallenen Sevenfriday Zeitmesser gibt es in ganz unterschiedlichen Farben, die aber nicht vom Design ablenken, sondern dies sogar noch unterstützen.
<G-vec00854-002-s034><distract.ablenken><en> The fancy timepieces by Sevenfriday are available in different colours, which however do not distract attention from the design, but even draw attention to it.
<G-vec00854-002-s035><distract.ablenken><de> Wir werden sie ablenken mit UNZUCHT, äußeren Genüssen und Spielen, so daß sie nie mögen eins sein mit der Einheit des Ganzen.
<G-vec00854-002-s035><distract.ablenken><en> We will distract them with fornication, external pleasures and games so they may never be one with the oneness of it all.
<G-vec00854-002-s036><distract.ablenken><de> Junge Kunden werden auf spezielle Stühle in Form vonMaschinen, wo es viele Knöpfe gibt, die Kinder ablenken, und sie bemerken nicht und stören nicht die Arbeit von Stylisten.
<G-vec00854-002-s036><distract.ablenken><en> Young clients are put on special chairs in the form ofmachines, where there are many buttons that distract children, and they do not notice and do not interfere with the work of stylists.
<G-vec00854-002-s037><distract.ablenken><de> Wenn man den Infernoturm verwendet, sollte man zuerst alle Einheiten, die den Riesen unterstützen ausschalten, da sie den Infernoturm ablenken können.
<G-vec00854-002-s037><distract.ablenken><en> When using the Inferno Tower, the player must first destroy small troops surrounding the Giant, as they will distract the Inferno Tower.
<G-vec00854-002-s038><distract.ablenken><de> Gschichten und Bilder können die Verbindung herstellen, aber sie können auch ablenken - und das kann beim Unterrichten und Spielen bedenklich werden.
<G-vec00854-002-s038><distract.ablenken><en> Stories and images can help to make the connection, but they can also distract - and that's when it becomes questionable in teaching and performing.
<G-vec00854-002-s039><distract.ablenken><de> Hiedurch würde für jeden Traum ein überlanger Vorbericht und ein Eindringen in das Wesen und die ätiologischen Bedingungen der Psychoneurosen erforderlich, Dinge, die an und für sich neu und im höchsten Grade befremdlich sind und so die Aufmerksamkeit vom Traumproblem ablenken würden.
<G-vec00854-002-s039><distract.ablenken><en> For this purpose there would be required a very long introduction and an investiga- tion into the nature and logical conditions of psychoneuroses, things which are in themselves novel and unfamiliar in the highest degree, and which would thus distract attention from the dream problem.
<G-vec00854-002-s040><distract.ablenken><de> Lassen Sie nichts ablenken.
<G-vec00854-002-s040><distract.ablenken><en> Don’t let anything distract you.
<G-vec00854-002-s041><distract.ablenken><de> Dieses andere Team kann dein Team mit Zaubern, Schergen und riesigen Bossen ablenken, wodurch du Spaltpunkte verlierst.
<G-vec00854-002-s041><distract.ablenken><en> These other players can distract your team with spells, minions, and huge bosses to make you lose rift points.
<G-vec00854-002-s042><distract.ablenken><de> Aber schießen Sie nicht über das Ziel hinaus: Verrückte Farben und Schriftarten sowie übermäßiges Unterstreichen oder Kursivmachen können von der Botschaft ablenken.
<G-vec00854-002-s042><distract.ablenken><en> But don’t go overboard: Wacky colors and fonts, as well as excessive underlining or italicizing, can distract from the message.
<G-vec00854-002-s043><distract.ablenken><de> Nichts sollte von der Treppe ablenken, auch nicht die Lichtquellen.
<G-vec00854-002-s043><distract.ablenken><en> Nothing was to distract from the staircase per se, not even the light sources.
<G-vec00854-002-s044><distract.ablenken><de> Diese kreative Umgebung wird den Raum visuell entlasten und vom kleinen Wohnbereich ablenken.
<G-vec00854-002-s044><distract.ablenken><en> This trick and creative environment will visually relieve the space and distract from the small living area.
<G-vec00854-002-s045><distract.ablenken><de> Grafiken können jedoch auch von Ihrer Aussage ablenken, wenn sie keinen direkten Bezug zur Aussage besitzen.
<G-vec00854-002-s045><distract.ablenken><en> But they can also distract from your message if pictures don't relate closely to the message.
<G-vec00854-002-s046><distract.ablenken><de> Minimiere Elemente, die von deiner Kernbotschaft ablenken, um so einen Fokuspunkt zu kreieren.
<G-vec00854-002-s046><distract.ablenken><en> You want to keep their focus, so minimize elements that distract from your core message.
<G-vec00854-002-s047><distract.ablenken><de> Wenn ihr das erste Mal miteinander auf persönlicher Ebene interagiert, sollte dies in einer ungezwungenen Situation und ohne viele Leute um euch herum sein, die euch ablenken könnten.
<G-vec00854-002-s047><distract.ablenken><en> The first time you interact on a personal level should be in a casual situation without too many other people around to distract you.
<G-vec00854-002-s048><distract.ablenken><de> Mayer Rothschild ließ Mentmore Towers bauen, einen dekadenten Protzbau, der ablenken sollte von den etablierten Adeligen.
<G-vec00854-002-s048><distract.ablenken><en> Mayer Rothschild had Mentmore Towers built, a decadent showpiece to distract from the established nobility.
<G-vec00854-002-s049><distract.ablenken><de> egal wie ihre Brüder sie ablenken wollen...
<G-vec00854-002-s049><distract.ablenken><en> no matter how her brothers try to distract her...
<G-vec00854-002-s050><distract.ablenken><de> Am besten ablenken kann sich die schnellste Frau Deutschlands übrigens mit ihrem „Therapiepferd“ Picasso.
<G-vec00854-002-s050><distract.ablenken><en> The fastest woman in Germany can best distract herself with her "therapy horse" Picasso.
<G-vec00854-002-s051><distract.ablenken><de> Die Bedienung der App ist sehr einfach gehalten, damit diese während der Fahrt nicht unnötig ablenkt.
<G-vec00854-002-s051><distract.ablenken><en> The use of the app is very simple, so it won’t distract you unnecessarily while driving.
<G-vec00854-002-s052><distract.ablenken><de> Vergessen Sie nicht, die Kerze zu löschen, damit ihr Licht Sie nicht vom Schlaf ablenkt.
<G-vec00854-002-s052><distract.ablenken><en> Do not forget to put out the candle, so that its light does not distract you from sleep.
<G-vec00854-002-s053><distract.ablenken><de> Im Automobilbereich wäre es möglich, bei eingeschränktem Blickwinkel auf dem Zentral-Display einen Film zur Unterhaltung des Beifahrers laufen zu lassen, der den Fahrer während der Fahrt nicht ablenkt.
<G-vec00854-002-s053><distract.ablenken><en> In the automotive sector, it would be possible, with a limited viewing angle on the central display, to run a film to entertain the passenger that would not distract the driver while driving.
<G-vec00854-002-s054><distract.ablenken><de> Sehr diskret aufgebaut, so dass Ihre unaufdringliche Dashcam nicht ablenkt.
<G-vec00854-002-s054><distract.ablenken><en> Very discrete design so your unobtrusive dashcam doesn't distract.
<G-vec00854-002-s055><distract.ablenken><de> Es ist besser, eine Arbeitsstation für das Schulkind in der Nähe des Fensters zu organisieren, jedoch nicht gegenüber, so dass der Blick auf die Straße das Kind nicht ablenkt.
<G-vec00854-002-s055><distract.ablenken><en> It is better to organize a workstation for the schoolchild near the window, but not opposite, so that the view of the street does not distract the child.
<G-vec00854-002-s056><distract.ablenken><de> Deshalb habe ich mich für einen modellhaften Low-Poly-Look entschieden, der nicht vom Thema ablenkt.
<G-vec00854-002-s056><distract.ablenken><en> That’s the reason I chose a model-like low-poly look, which doesn’t distract from the theme.
<G-vec00854-002-s057><distract.ablenken><de> Um trotzdem weiter im Auto funken zu können benötigt man eine Freisprecheinrichtung, die einen nicht ablenkt und die Hände frei lässt.
<G-vec00854-002-s057><distract.ablenken><en> To be able to still use an amateur radio transceiver while driving, a hands-feee kit is required which does not distract the driver and leaves the hands free for driving.
<G-vec00854-002-s058><distract.ablenken><de> Verwenden Sie diese Dienste in keiner Weise, die Sie ablenkt und an der Einhaltung von Verkehrsregeln oder Sicherheitsvorschriften hindert.
<G-vec00854-002-s058><distract.ablenken><en> Do not use the Platform in a way that will distract your users and prevent them from obeying traffic or safety laws.
<G-vec00854-002-s059><distract.ablenken><de> Seien es die sinnlichen Kurven des weiblichen Körpers oder der klar gezeichnete Schatten einer Wüstenpalme: Christoph mag es schlicht und einfach, sodass nichts vom Wesentlichen ablenkt.
<G-vec00854-002-s059><distract.ablenken><en> Be it the sensuous curves of a woman’s body or the crisp shade of a desert palm, Christoph likes to keep things simple, so as not to distract from the main message.
<G-vec00854-002-s060><distract.ablenken><de> Das Design des A1 macht deshalb sichtbare Standfüße oder Lautsprecher überflüssig, sodass nichts vom beeindruckenden Bild in 4K-Auflösung ablenkt.
<G-vec00854-002-s060><distract.ablenken><en> The A1E's design eliminates any visible stand or speakers, leaving nothing to distract from the superior image.
<G-vec00854-002-s061><distract.ablenken><de> Gleichzeitig bringt die Sufi-Bewegung der Menschheit die Religion, die in Wirklichkeit alle Religionen ist....Es ist die Weltbotschaft und die Religion, die die Religion der ganzen Menschheit sein wird, eine Religion, die den Menschen nicht von seiner eigenen Religion ablenkt.
<G-vec00854-002-s061><distract.ablenken><en> At the same time the Sufi Movement provides humanity with the religion which is in reality all religions. It is the world message and that religion which will be the religion of the whole humanity, a religion which does not distract the mind of any person from his own religion.
<G-vec00854-002-s062><distract.ablenken><de> Bevor Sie zu Bett gehen, bitten Sie Ihren Partner, das gleiche zu tun, so dass der Ton Sie nicht ablenkt.
<G-vec00854-002-s062><distract.ablenken><en> Ask your partner to do the same, so that the ringer does not distract you or tempt you to check your phone.
<G-vec00854-002-s063><distract.ablenken><de> Hätte ich wenigstens 1 oder 2 mehr Tops wie dieses, dass von der Hose ablenkt, würde ich sie für immer und ewig behalten, weil ich das Accessorizen immer ändern könnte.
<G-vec00854-002-s063><distract.ablenken><en> If I had atleast 1 o 2 more tops of this sort, that distract from the pants, I’d keep it forever and ever, because I could always change the way I’d accessorize it.
<G-vec00854-002-s064><distract.ablenken><de> Die Pflege von Zimmerpflanzen ist eine ruhige, friedliche Aktivität, die uns Zeit und Raum zum Nachdenken geben kann oder uns von der ständigen Hektik unserer Arbeit oder unseres sozialen Lebens ablenkt.
<G-vec00854-002-s064><distract.ablenken><en> Caring for house plants is a quiet, peaceful activity that can give us time and space to think, or distract us from the constant hustle and bustle of our work or social lives.
<G-vec00854-002-s073><distract.ablenken><de> Der Konflikt zwischen Arabern und Israelis sollte nicht länger dazu verwendet werden, die Bürger in arabischen Nationen von anderen Problemen abzulenken.
<G-vec00854-002-s073><distract.ablenken><en> The Arab-Israeli conflict should no longer be used to distract the people of Arab nations from other problems.
<G-vec00854-002-s074><distract.ablenken><de> Ich lenke die Aufmerksamkeit des Menschen auf sich selbst, um ihn abzulenken von dem, was der Gegner ihm verlockend vor Augen stellt....
<G-vec00854-002-s074><distract.ablenken><en> I draw the person's attention on himself in order to distract him from what the adversary alluringly presents to him....
<G-vec00854-002-s075><distract.ablenken><de> Einige Katzenbesitzer haben herausgefunden, dass das Einreiben der Körper und Köpfe der Katzen mit Thunfischsaft helfen kann, die Katzen von ihrem Kampf abzulenken.
<G-vec00854-002-s075><distract.ablenken><en> Some cat owners have found rubbing tuna juice on their cats’ bodies and heads can help to distract the cats from fighting.
<G-vec00854-002-s076><distract.ablenken><de> Dieser Raum soll nicht nur helfen, die verlorene Energie abzulenken und wiederherzustellen, sondern sich auch an die Arbeitsstimmung anzupassen.
<G-vec00854-002-s076><distract.ablenken><en> This room should help not only to distract and restore the lost energy, but also to adjust to the working mood.
<G-vec00854-002-s077><distract.ablenken><de> Und so ist es für uns eine Art finsteres Wesen, das versucht, Sie von den Dingen abzulenken, die eigentlich Ihrer Aufmerksamkeit bedürfen, aber es könnte auch eine Figur sein, die viel Hilfe braucht.
<G-vec00854-002-s077><distract.ablenken><en> And so to us this is a kind of sinister being which is trying to distract you from the things that actually need your attention, but it could also be a figure that needs a lot of help.
<G-vec00854-002-s078><distract.ablenken><de> Geben Sie ungeduldig Besucher Süßigkeiten oder ein Soda, um sie abzulenken.
<G-vec00854-002-s078><distract.ablenken><en> Give impatient visitors candy or a soda to distract them.
<G-vec00854-002-s079><distract.ablenken><de> Ich versuche das weinende Kind abzulenken, indem ich ihm andere Dinge zeige, mit denen es spielen kann.
<G-vec00854-002-s079><distract.ablenken><en> Try to distract the crying girl by showing her some other things she could play with.
<G-vec00854-002-s080><distract.ablenken><de> Um die Grenzposten abzulenken, wurde einige hundert Meter von der Bernauer Straße entfernt im Gleimtunnel ein kleiner Sprengsatz gezündet.
<G-vec00854-002-s080><distract.ablenken><en> To distract the border guards, a small explosive was set off in the Gleim Tunnel, a few hundred meters away from Bernauer Strasse.
<G-vec00854-002-s081><distract.ablenken><de> „Also, Aspen“, sage ich, um sie von diesem Thema abzulenken.
<G-vec00854-002-s081><distract.ablenken><en> “So, Aspen,” I say trying to distract her from the topic at hand.
<G-vec00854-002-s082><distract.ablenken><de> Zur gleichen Zeit haben diese reaktionären Kräfte die Absicht, die Arbeiterklasse mit chauvinistischen und anti-muslimischen Hass vom Widerstand gegen die laufenden Sparpakete der Bosse und kapitalistischen Regierungen abzulenken.
<G-vec00854-002-s082><distract.ablenken><en> At the same time, these forces of reaction aim at demoralizing backward sectors of the working class using chauvinistic, anti-Muslim hatred to distract them from resisting the ongoing austerity offensive of the bosses and the capitalist governments.
<G-vec00854-002-s083><distract.ablenken><de> 18 Die Affen tun ihr Bestes, zu bezaubern und abzulenken bevor Sie mit der Beute verschwinden.
<G-vec00854-002-s083><distract.ablenken><en> 19 The monkeys do their best to charm and distract before making off with the loot.
<G-vec00854-002-s084><distract.ablenken><de> Und dieser Ausdruck kommt von langer Zeit, undDie Geschichte seines Auftretens ist sehr einfach: Heiler flüsterten der Person, die mit Zahnschmerzen ins Ohr kam, verschiedene Worte zu, versuchten, Zahnschmerzen "abzulenken".
<G-vec00854-002-s084><distract.ablenken><en> And this expression comes from a long time, andthe story of his appearance is very simple: healers whispered to the person who came with a toothache in the ear different words, trying to distract, "talk" toothache.
<G-vec00854-002-s085><distract.ablenken><de> Versuche, ihn eine Weile von seinen Problemen abzulenken.
<G-vec00854-002-s085><distract.ablenken><en> Try to find ways to distract them from the issue for awhile.
<G-vec00854-002-s086><distract.ablenken><de> Stimmen erheben sich aus den Sümpfen, um mich abzulenken und mein Herzlicht zu überschatten.
<G-vec00854-002-s086><distract.ablenken><en> Voices rise from the swamps to distract me and overshadow my heart-light.
<G-vec00854-002-s087><distract.ablenken><de> 9- Die U-Bahn-Mitarbeiter von ihrer Arbeit abzulenken.
<G-vec00854-002-s087><distract.ablenken><en> 9- Prohibited to distract the staff from their operations.
<G-vec00854-002-s088><distract.ablenken><de> Sie erklärten auch, wie die Kommunistische Partei vor kurzem diese inszenierte Selbstverbrennung bei weiteren Versuchen verwendet hatte, um Falun Gong schlecht zu machen und die öffentliche Aufmerksamkeit von den schweren Menschenrechtsverletzungen und der Korruption abzulenken, welche das Land überziehen.
<G-vec00854-002-s088><distract.ablenken><en> They also explained how Jiang and his communist party have recently used this staged self-immolation in further attempts to slander Falun Gong and distract public attention from the widespread human rights abuses and corruption that is affecting the country.
<G-vec00854-002-s089><distract.ablenken><de> Das Wetter ist kontrolliert und wird dazu benutzt, euch von den wirklich wichtigen Problemen abzulenken.
<G-vec00854-002-s089><distract.ablenken><en> The weather is controlled and is used to distract you from the real issues.
<G-vec00854-002-s090><distract.ablenken><de> F: (L) Wir haben hier nun einen Haufen Leute, die mit Mathematik und höherem Wissen spielen, und das im Wesentlichen deshalb, damit sie sich mit etwas beschäftigen, um sich auf menschlicher Ebene von der Tatsache abzulenken, dass sie von einer höheren Stufe aus manipuliert werden.
<G-vec00854-002-s090><distract.ablenken><en> Q: (L) So, we have a bunch of people who are playing with mathematics, and playing with higher knowledge, basically as a keep-busy activity to distract them at the human level from the fact that they are being manipulated at a higher level.
<G-vec00854-002-s091><distract.ablenken><de> Zu diesem Zeitpunkt hatte ich schon die Zeit vergessen, konnte nicht herausfinden, wie viel ich unter der Dusche war, versuchte während des Kampfes etwas zu zählen, mich abzulenken, aber ich konnte nicht mal 3 mal 3 multiplizieren.
<G-vec00854-002-s091><distract.ablenken><en> By this point, I had already lost track of time, could not figure out how much I was in the shower, tried to count something during the fight, to distract myself, but I could not even multiply 3 by 3.
<G-vec00854-002-s092><distract.ablenken><de> Versuche nicht, dich durch Essen abzulenken, dann wirst du dich schon bald krank und fett fühlen.
<G-vec00854-002-s092><distract.ablenken><en> Don't try to multitask and move away from anything that might distract you. Thanks!
<G-vec00854-002-s093><distract.ablenken><de> Es wäre besser, das Kind abzulenken und es als etwas geeigneteres als Gespräche für Erwachsene anzusehen.
<G-vec00854-002-s093><distract.ablenken><en> It would be better just to distract the child, taking it to be something more suitable than adult conversations.
<G-vec00854-002-s094><distract.ablenken><de> Im Falle eines Scheiterns ist es am besten zu versuchen, das Kind von traurigen Gedanken abzulenken und die Aufmerksamkeit auf etwas Interessantes zu lenken.
<G-vec00854-002-s094><distract.ablenken><en> In case of failure, it is best to try to distract the child from sad thoughts and shift attention to something interesting.
<G-vec00854-002-s095><distract.ablenken><de> Ein Helfer, der in der Lage ist, die Aufmerksamkeit des Publikums abzulenken, eignet sich sogar noch besser, um diese Spielvariante umzusetzen.
<G-vec00854-002-s095><distract.ablenken><en> An assistant who can distract the audience's attention is even better for pulling off this version of the game.
<G-vec00854-002-s096><distract.ablenken><de> Wieder andere glaubten, die Visionen wären ihnen von ihren Feinden gesandt worden um sie abzulenken und zu verwirren.
<G-vec00854-002-s096><distract.ablenken><en> Still others thought that false visions had been sent by their enemies to distract and deceive them.
<G-vec00854-002-s097><distract.ablenken><de> Es ist viel einfacher uns abzulenken und einfach ein wenig da zu sitzen und in den Himmel zu starren, den Fernseher, ein Buch oder die Wand.
<G-vec00854-002-s097><distract.ablenken><en> It is much easier to distract ourselves and to just sit and stare at the sky, the television, a book or the wall.
<G-vec00854-002-s098><distract.ablenken><de> Es ist wirklich wichtig während des Hundetraining, weil nichts von dieser Aktivität Ihren Hund ablenken soll.
<G-vec00854-002-s098><distract.ablenken><en> This is really important during the dog training, because nothing must distract the attention of the dog during training.
<G-vec00854-002-s099><distract.ablenken><de> Kate ist eine selbstbewusste und liebevolle Frau, die im Dschungel bereits viele Projekte angestoßen hat, um die Flüchtlinge ein wenig von ihrer Situation abzulenken.
<G-vec00854-002-s099><distract.ablenken><en> Kate is a confident and caring woman who already started off several projects in the Jungle in order to distract the refugees here a little from their stressful situation.
<G-vec00854-002-s101><distract.ablenken><de> Ich erklärte ihm, dass es manchmal hilft, sich von einer Anstrengung abzulenken, so dass man sein Ziel erreicht, ohne es zu merken.
<G-vec00854-002-s101><distract.ablenken><en> I explained to him once again that it sometimes helps to distract yourself from a hard task so that you reach your goal without even noticing, and how our talking had helped him get through the toughest part of our swim.
<G-vec00854-002-s102><distract.ablenken><de> Ihr lernt hier, wie man mit aufgehobenen Gegenständen Gegner ablenkt.
<G-vec00854-002-s102><distract.ablenken><en> You will learn how to pick up items and throw them to distract enemies.
<G-vec00854-002-s103><distract.ablenken><de> Sie werden immer deinen Wunsch nach etwas ausnutzen – das ist der einfachste Weg, um dich abzulenken.
<G-vec00854-002-s103><distract.ablenken><en> They will always play on your desire for something–that’s the easiest way to distract you.
<G-vec00854-002-s104><distract.ablenken><de> Ein schmissiges Zitat, das nicht hilft, um dein Thema aufzubereiten oder das mit dem Rest deines Textes nichts zu tun hat, wird von der beabsichtigten Aussage deines Aufsatzes ablenken.
<G-vec00854-002-s104><distract.ablenken><en> A snappy quotation that doesn't help to set up your topic, or that is unrelated to the rest of your essay, will distract from the essay's focus.
<G-vec00854-002-s105><distract.ablenken><de> Jetzt können Sie sehr viel mehr Objekte hacken, um Ihre Feinde auszuschalten oder abzulenken.
<G-vec00854-002-s105><distract.ablenken><en> Now you’ll be able to hack many more objects, in order to take out or distract enemies.
<G-vec00854-002-s107><distract.ablenken><de> Ihr Zuschauer haben sie abonniert, weil sie an ihrem scheinbar perfekten Leben teilhaben wollen und wahrscheinlich auch, um sich selbst ein bisschen abzulenken.
<G-vec00854-002-s107><distract.ablenken><en> Their viewers subscribed to their channels because they want to take part in this „perfect“ life and maybe to distract themselves from their own everyday life.
<G-vec00854-002-s111><distract.ablenken><de> Nichts sollte davon ablenken.
<G-vec00854-002-s111><distract.ablenken><en> Nothing should distract from that.
<G-vec00854-002-s112><distract.ablenken><de> Denn die einzige Chance, die wir haben, besteht doch darin, planvoll davon abzulenken, daß wir ohne Wände gar keine Oper besäßen.
<G-vec00854-002-s112><distract.ablenken><en> After all: the only chance we have is to distract systematically from the fact that without walls, we would not have any opera.
<G-vec00854-002-s113><distract.ablenken><de> Das Philadelphia-Experiment, das so sehr in den Medien war, ist ein Schwindel, der begangen wurde, um die Leute davon abzulenken, dem wirklichen Philadelphia-Experiment nachzugehen, das nirgendwo nahe Philadelphia stattfand.
<G-vec00854-002-s113><distract.ablenken><en> The Philadelphia experiment much in the media is a fraud perpetrated to distract people from pursuing the real Philadelphia experiment, which didn't take place anywhere near Philadelphia.
<G-vec00854-002-s114><distract.ablenken><de> Nichts wird dich von deiner meditativen Spielerfahrung ablenken.
<G-vec00854-002-s114><distract.ablenken><en> Nothing will distract you from pure meditative gameplay.
<G-vec00854-002-s115><distract.ablenken><de> Ein starkes, unterstützendes soziales System kann mehr für dich tun, als dich einfach nur von deiner Nervosität ablenken.
<G-vec00854-002-s115><distract.ablenken><en> Having a strong support system that you don't hesitate to use can do more than just distract you from nervousness.
<G-vec00854-002-s116><distract.ablenken><de> Oder du kannst dich ablenken, indem du etwas anderes machst, das dir Spaß macht.
<G-vec00854-002-s116><distract.ablenken><en> Or, you can distract yourself by doing something else that you enjoy.
<G-vec00854-002-s117><distract.ablenken><de> Du willst hoch hinaus mit dem Ziel schnell und steil wieder hinab zu biken, keiner darf Dich Ablenken oder im Weg stehen.
<G-vec00854-002-s117><distract.ablenken><en> You want to ride high up with the goal of descending quickly and steeply, nobody may distract you or stand in your way.
<G-vec00854-002-s118><distract.ablenken><de> Einen Freund zu haben kann dich kurzfristig von der Langeweile des Unterrichts ablenken.
<G-vec00854-002-s118><distract.ablenken><en> Having a buddy can help momentarily distract you from the boredom of a class.
<G-vec00854-002-s119><distract.ablenken><de> Übe Meditation, indem du dich in eine bequeme Position setzt, weg von allem, was dich ablenken könnte.
<G-vec00854-002-s119><distract.ablenken><en> Practice meditation by sitting in a comfortable position away from anything that might distract you.
<G-vec00854-002-s120><distract.ablenken><de> Bevor du dich auf Gott konzentrieren kannst, musst du alle weltlichen Dinge loslassen, die dich von deiner Beziehung zu Gott ablenken.
<G-vec00854-002-s120><distract.ablenken><en> Before you can focus on God, you need to let go of all the worldly things that distract you from your relationship with God.
<G-vec00854-002-s121><distract.ablenken><de> Viele Dinge passieren, um dich abzulenken oder dich von deinem Kurs abzubringen.
<G-vec00854-002-s121><distract.ablenken><en> Many things happen to try to distract you, or to put you off- course.
<G-vec00854-002-s122><distract.ablenken><de> Versuche, dich abzulenken.
<G-vec00854-002-s122><distract.ablenken><en> Try to distract yourself.
<G-vec00854-002-s123><distract.ablenken><de> Das würde wahrscheinlich tatsächlich vom eigentlichen Lebensziel ablenken und weder wesentlich zum Wachsen der Community noch des eigenen Glückes beitragen.
<G-vec00854-002-s123><distract.ablenken><en> This would be very likely to distract from your life’s purpose and will not really expand your community, influence or happiness.
<G-vec00854-002-s125><distract.ablenken><de> Ihre Kunden werden auf diesen Seiten die Versand- und Zahlungsinformationen für ihre Bestellungen eingeben und es ist nicht empfehlenswert, sie abzulenken oder Informationen schwer lesbar zu machen.
<G-vec00854-002-s125><distract.ablenken><en> Your customers will use these pages to set up shipping and payment information for their orders, and you don't want to distract them or make the information hard to read.
<G-vec00854-002-s128><distract.ablenken><de> Der Hintergrund ist unscharf gehalten, um nur nicht abzulenken von der Hauptsache: dem Liebespaar.
<G-vec00854-002-s128><distract.ablenken><en> The background is out of focus, so as not to distract from the main motif: the couple.
<G-vec00854-002-s130><distract.ablenken><de> Bei der Trauung halten wir uns diskret im Hintergrund und versuchen, so gut es geht, die Hochzeitsgäste nicht von der eigentlichen Zeremonie abzulenken.
<G-vec00854-002-s130><distract.ablenken><en> We discreetly stay in the background and give our best not to distract the wedding guests from the actual marriage ceremony.
<G-vec00854-002-s133><distract.ablenken><de> Wenn Ihre Pikmin beispielsweise Beute zurück zur Basis tragen, sollten Sie sich auf jeden Fall in das Blickfeld des Gegners stellen und ihn ablenken, damit diese sich auf Sie konzentrieren und nicht auf Ihre Pikmin und deren wertvolle Fracht.
<G-vec00854-002-s133><distract.ablenken><en> For example, whenever your Pikmin are carrying items back to base, ensure you put yourself in the firing line and distract enemies so that they focus their attention on you instead of those precious Pikmin.
<G-vec00854-002-s135><distract.ablenken><de> Darüber hinaus ist er still und leise, sodass du andere Kollegen nicht abgelenken wirst.
<G-vec00854-002-s135><distract.ablenken><en> On top of this, it is also still and quiet so it won’t distract you or anyone else.
<G-vec00854-002-s136><distract.ablenken><de> Aktuelle Ergebnisse zeigten sogar, „dass durchschnittlich fitte Heranwachsende auch bei einem Tragegewicht von 20 % ihres Körpergewichtes keine Anzeichen von Überlastung zeigen (Kid-Check Studie der Universität des Saarlandes 2008), wohingegen körperlich schwächliche Kinder durchaus schon bei 12 % Tragegewicht Anzeichen einer Überbelastung aufweisen.“ Darauf verweist der Verein Aktion gesunder Rücken auf seiner Homepage [7] ohne vergessen zu bemerken, dass Normwerte leicht zu irreführenden Kaufentscheidungen führen und den Blick von eigentlich komplexeren Problemen ablenken können.
<G-vec00854-002-s136><distract.ablenken><en> The latest findings have even shown “that adolescents of average fitness display no signs of excessive strain even when the weight carried corresponds to 20% of their body weight (‘kid check’ study carried out by Saarland University in 2008), whereas physically weak children may well show signs of excessive strain when carrying only 12% of their weight”. The association Verein Aktion gesunder Rücken points this out on its website, without adding that standard figures can easily lead to misleading purchasing decisions and distract from problems that are in actual fact more complex.
<G-vec00854-002-s137><distract.ablenken><de> Die Bergbahn bringt Sie und Ihr Bike fast direkt vom Hotel weg bis zur Mittelstation der Zwölferkogelbahn, wo die fabelhafte Aussicht kurz vom eigentlichen Vorhaben ablenkt.
<G-vec00854-002-s137><distract.ablenken><en> The gondola lift will take you and your bike to the middle station almost directly from the hotel. But be careful - the fabulous view may distract you from your actual plans!
<G-vec00854-002-s139><distract.ablenken><de> Lenk den Jungen ab, den du nicht küssen willst, und klick dann auf Bella, um deinen auserwählten Twilight-Schwarm zu küssen.
<G-vec00854-002-s139><distract.ablenken><en> Distract the boy you don’t want to kiss, then click Bella to start kissing your chosen Twilight hunk.
<G-vec00854-002-s140><distract.ablenken><de> Lenk den Welpen ab, wenn er sich zu sehr auf die Katze fixiert.
<G-vec00854-002-s140><distract.ablenken><en> 2 Distract the puppy if she becomes fixated on the cat.
<G-vec00854-002-s142><distract.ablenken><de> Aber mit meinen neuen Aufgaben lenke ich mich ab und komme täglich mehr an.
<G-vec00854-002-s142><distract.ablenken><en> But I distract myself with my new tasks, and with every day I settle in more.
<G-vec00854-002-s143><distract.ablenken><de> Lenke deinen Verstand mit produktiven Aktivitäten ab.
<G-vec00854-002-s143><distract.ablenken><en> Distract your mind with productive activities.
<G-vec00854-002-s144><distract.ablenken><de> Dann lenke dich sofort mit etwas anderem ab.
<G-vec00854-002-s144><distract.ablenken><en> Then, immediately distract yourself with another activity.
<G-vec00854-002-s145><distract.ablenken><de> Lenke dich selbst mit deinen Händen ab.
<G-vec00854-002-s145><distract.ablenken><en> Distract yourself with your hands.
<G-vec00854-002-s146><distract.ablenken><de> Lenke dich mit Gedanken ab.
<G-vec00854-002-s146><distract.ablenken><en> Distract yourself with thoughts.
<G-vec00854-002-s147><distract.ablenken><de> Lenke dich von alten Denkmustern ab, indem du dich zu neuen Routinen zwingst.
<G-vec00854-002-s147><distract.ablenken><en> Distract yourself from old patterns of thinking by forcing yourself to try new routines.
<G-vec00854-002-s148><distract.ablenken><de> Lenke dein bewusstes Selbst ab, damit dein intuitives Selbst Gelegenheit bekommt zu wirken.
<G-vec00854-002-s148><distract.ablenken><en> Distract your conscious mind so your intuitive mind has a chance to do its work.
<G-vec00854-002-s149><distract.ablenken><de> Lenke dein Kind ab.
<G-vec00854-002-s149><distract.ablenken><en> Distract your child.
<G-vec00854-002-s150><distract.ablenken><de> "Tu etwas, wechsle, lenke von der Situation ab", sagen wir zu einer Person, die in Schwierigkeiten ist.
<G-vec00854-002-s150><distract.ablenken><en> "Do something, switch, distract from the situation," we say to a person who is in trouble.
<G-vec00854-002-s153><distract.ablenken><de> Einige lenken sich selbst ab, indem sie singen oder dumme Witze erzählen oder einfach nur laute Babygeräusche von sich geben.
<G-vec00854-002-s153><distract.ablenken><en> Some people distract themselves by singing or yelling stupid jokes or simply making loud baby sounds, whatever works.
<G-vec00854-002-s154><distract.ablenken><de> Gedanken lenken uns von der Wirklichkeit, der Gegenwart ab.
<G-vec00854-002-s154><distract.ablenken><en> Thoughts distract us from reality, the present.
<G-vec00854-002-s155><distract.ablenken><de> Wir sind permanent on, lenken uns ab, definieren uns über Aktivität.
<G-vec00854-002-s155><distract.ablenken><en> We are permanently “on”, distract ourselves, define ourselves via activity.
<G-vec00854-002-s156><distract.ablenken><de> Die Männer lenken ab, die Frau schafft raus.
<G-vec00854-002-s156><distract.ablenken><en> The men distract, the woman gets out.
<G-vec00854-002-s157><distract.ablenken><de> Sie verwandeln nicht nur die Räumlichkeiten, sondern lenken auch die Aufmerksamkeit von Familienmitgliedern und Gästen von einem bescheidenen Platz ab.
<G-vec00854-002-s157><distract.ablenken><en> They not only transform the premises, but also distract the attention of family members and guests from a modest square.
<G-vec00854-002-s158><distract.ablenken><de> Kurz gesagt lenken sie ab.
<G-vec00854-002-s158><distract.ablenken><en> In short, they distract.
<G-vec00854-002-s159><distract.ablenken><de> Die störenden Geräusche lenken den Maulwurf ab und machen ihn unvorsichtiger.
<G-vec00854-002-s159><distract.ablenken><en> The disturbing noises distract the mole and make it more careless.
<G-vec00854-002-s160><distract.ablenken><de> Intuitive Bedienung und optimal im Blickfeld platzierte Informationen wie beispielsweise beim Head-up-Display lenken den Fahrer nicht ab.
<G-vec00854-002-s160><distract.ablenken><en> Intuitive operation and information that is optimally positioned in the field of vision, such as the head-up display, do not distract the driver.
<G-vec00854-002-s161><distract.ablenken><de> Diese lenken nur vom eigentlichen Motiv ab, machen den gesamten Feed unruhig und machen es euch schwer, die Bilder später für etwas anderes weiter zu verwenden.
<G-vec00854-002-s161><distract.ablenken><en> They only distract from the actual subject, unsettle the whole feed, and make it difficult for you to use the pictures again later for something else.
<G-vec00854-002-s162><distract.ablenken><de> Die Geräusche und jeder neue visuelle Reiz lenken sie so sehr ab, dass sie stehen bleibt und nicht mehr weitergehen kann.
<G-vec00854-002-s162><distract.ablenken><en> Sounds and any visual stimulation distract her so much that she stops I her tracks and can't continue.
<G-vec00854-002-s163><distract.ablenken><de> Drei junge, stationierte Soldaten lenken sich von ihrem Kriegsalltag ab.
<G-vec00854-002-s163><distract.ablenken><en> Three young stationed soldiers try to distract themselves from everyday wartime existence.
<G-vec00854-002-s166><distract.ablenken><de> Die helle, schlichte Einrichtung und viel Licht sorgt dabei für vielfältige Gestaltungsmöglichkeiten und lenkt nicht von deinen Produkten ab.
<G-vec00854-002-s166><distract.ablenken><en> The bright, simple setup and plenty of light provides for a wide range of design possibilities and does not distract from your products.
<G-vec00854-002-s167><distract.ablenken><de> Das verwackelte Video lenkt den Betrachter von der Botschaft oder Geschichte in Ihrem Video ab.
<G-vec00854-002-s167><distract.ablenken><en> The shaky video will distract the viewer from the message or story in your video.
<G-vec00854-002-s168><distract.ablenken><de> QuattroPod vereinfacht das Procedere erheblich, dank plattform- und herstellerübergreifender Kompatibilität, und lenkt so nicht von der eigentlichen Arbeit ab.
<G-vec00854-002-s168><distract.ablenken><en> QuattroPod simplifies the procedure considerably thanks to cross-platform and cross-manufacturer compatibility and so does not distract from the actual work!
<G-vec00854-002-s169><distract.ablenken><de> Wenn wir allerdings dieses Manifest als unser Ziel annehmen, lenkt es uns von dem ab, wofür wir wirklich kämpfen müssen.
<G-vec00854-002-s169><distract.ablenken><en> However, if we adopt this " "manifesto as our goal, it will distract us from what we really need to fight " "for." type: Content of:
<G-vec00854-002-s170><distract.ablenken><de> Infolgedessen destabilisiert dieser Prozess oftmals Operationen der Firma, lenkt die strategischen Ressourcen (wie Teamleaders, CFO) von den Produktionshandeln ab und generiert Verluste.
<G-vec00854-002-s170><distract.ablenken><en> As a result this process often destabilizes the functioning of the company, distract key resources (such as team leaders, CFOs) from productive/ service activities / or strategic management and at the end generate losses.
<G-vec00854-002-s171><distract.ablenken><de> Anfangs lenkt uns der Dienst am Nächsten vielleicht einfach von unseren eigenen Problemen ab, dann entwickelt sich jedoch schnell etwas viel Höheres und Schöneres daraus.
<G-vec00854-002-s171><distract.ablenken><en> At first, serving others may simply distract us from our own problems, but that swiftly grows into something much higher and more beautiful.
<G-vec00854-002-s172><distract.ablenken><de> Mit dem einzigartigen Design und der grünen Farbe steht Ihr Hängemattenstandplatz nicht heraus oder lenkt von der Schönheit Ihres Hinterhofes oder der Hängematte selbst ab.
<G-vec00854-002-s172><distract.ablenken><en> With the unique design and green color, your hammock stand will not stand out or distract from the beauty of your backyard or the hammock itself.
<G-vec00854-002-s173><distract.ablenken><de> Der vorhandene Platz wird optimal ausgenutzt, und die notwendige Technik lenkt nicht von der Ware ab.
<G-vec00854-002-s173><distract.ablenken><en> The available space is optimally used and the necessary technology does not distract from the product.
<G-vec00854-002-s174><distract.ablenken><de> Eine saubere Benutzeroberfläche fällt nicht auf und lenkt nicht ab.
<G-vec00854-002-s174><distract.ablenken><en> A clean interface gets out of the way and doesn’t distract.
<G-vec00854-002-s175><distract.ablenken><de> Diese monochrome Dekoration lenkt nicht ab und ermöglicht Ihnen eine gemütliche und fesselnde Atmosphäre im Raum.
<G-vec00854-002-s175><distract.ablenken><en> This monochrome decoration does not distract attention and allows you to create a cozy and captivating atmosphere in the room.
<G-vec00854-002-s179><distract.ablenken><de> LilyPond kümmert sich vor allem darum, Noten in bester Qualität zu setzen – das Programmieren einer graphischen Benutzeroberfläche (GUI) würde uns nur von dieser Aufgabe ablenken.
<G-vec00854-002-s179><distract.ablenken><en> LilyPond is primarily concerned with producing top-quality engraved sheet music; creating a Graphical User Interface (GUI) would distract us from this goal.
<G-vec00854-002-s180><distract.ablenken><de> Es ist darum nicht verwunderlich, dass besonders in der Adventszeit alles Mögliche in der Gesellschaft, in unserer eigenen Umgebung und in uns selbst passiert, dass uns ablenkt von der Verbindung zu dem Heiligen, was da kommen wird.
<G-vec00854-002-s180><distract.ablenken><en> It is therefore not surprising that, especially during Advent, everything in our society, in our environment and in ourselves, seems to distract from opening up to the holiness that is approaching us.
<G-vec00854-002-s184><distract.ablenken><de> Das minimalistische Dekor soll wohl nicht von der wunderbaren Aussicht auf die beleuchtete Kathedrale gegenüber ablenken.
<G-vec00854-002-s184><distract.ablenken><en> Distinctly minimalist, perhaps so as not to distract from the perfect view of the illuminated Cathedral, just opposite.
<G-vec00854-002-s189><distract.ablenken><de> Der Regen vermochte von der Botschaft nicht abzulenken.
<G-vec00854-002-s189><distract.ablenken><en> The rain did not distract from the message one bit.
<G-vec00854-002-s190><distract.ablenken><de> Versuchen Sie, sich von den Schmerzen abzulenken; Freizeitbeschäftigungen, Arbeit oder andere Sachen, woran Sie Spass haben, helfen Ihnen dabei die Schmerzen zu vergessen.
<G-vec00854-002-s190><distract.ablenken><en> Distract yourself from the pain; leisure activities, work or things you enjoy help to take your mind off the pain and fewer painkillers may then be required.
<G-vec00854-002-s192><distract.ablenken><de> Es gibt auch Anzeichen dafür, dass dabei ein besonderer “Zeitfaktor” eine Rolle spielt und dass all die Kräfte der Dunkelheit versuchen auf nie zuvor dagewesene Weise zu täuschen und zu verwirren, damit die Fähigkeiten jener, die die Träger der “Schaltkreise der Veränderung” für die ganze Menschheit sein könnten, abgelenkt, durcheinander gebracht, geschwächt und entschärft werden.
<G-vec00854-002-s192><distract.ablenken><en> There are also indications that a particular time element is involved and all the forces of darkness seek to deceive and obfuscate at levels never before achieved in order to distract, confuse, dilute and defuse the abilities of those who may be the bearers of the circuits of change for all humanity.
<G-vec00854-002-s194><distract.ablenken><de> Urlaub auf See, aufregende Mondnächte, nichts, was von der bevorstehenden Reise ablenkt.
<G-vec00854-002-s194><distract.ablenken><en> Leisure days at sea, exciting moonlit nights, nothing to distract from the journey ahead.
<G-vec00854-002-s195><distract.ablenken><de> Keinerlei Flipsnack-Branding mehr, nichts, was Ihre Leser von Ihren Inhalten ablenkt.
<G-vec00854-002-s195><distract.ablenken><en> No Flipsnack branding, and nothing to distract your readers from your content.
<G-vec00854-002-s199><distract.ablenken><de> Das Ziel dieses Dialoges ist nicht –wie manche kommentiert haben— abzulenken von den Enthüllungen von Edward Snowden– sondern im Gegenteil: eine konstruktive Debatte darüber zu führen, was meiner Ansicht nach hinter all der NSA-Empörung steht: nämlich die schwierige Frage, wie wir Freiheit, Privatsphäre und Sicherheit im digitalen Zeitalter in die richtige Balance bringen.
<G-vec00854-002-s199><distract.ablenken><en> The aim of this dialogue is not, as some commentators have said, to distract from Edward Snowden’s revelations, but to engage in a constructive debate on what, in my opinion, is at the root of all the outrage about the NSA’s activities – namely the difficult question of finding the right balance between freedom, privacy and security in the digital age.
