<G-vec01153-002-s025><cough_up.abhusten><de> Heißer Tee kann Halsschmerzen beruhigen, Schleim leichter abgehustet werden lassen, und der Dampf kann dabei helfen, Entzündungen zu lindern.
<G-vec01153-002-s025><cough_up.abhusten><en> Hot tea can be soothing to a sore throat, make mucus easier to cough up, and the steam can help ease inflammation.
<G-vec01153-002-s026><cough_up.abhusten><de> Die Operation kann auch bei Patienten erwogen werden, die trotz Behandlung an wiederkehrenden Infektionen leiden oder viel Blut abhusten.
<G-vec01153-002-s026><cough_up.abhusten><en> Surgery may be considered for people who have recurrent infections despite treatment or who cough up large amounts of blood.
