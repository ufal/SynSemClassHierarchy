<G-vec00599-002-s031><unravel.auseinanderhalten><de> Es ist zwar bekannt, dass genetische Faktoren Alkoholabhängigkeit beeinflussen, aber es ist schwierig, die verschiedenen Ursachen auseinanderzuhalten.
<G-vec00599-002-s031><unravel.auseinanderhalten><en> It is well known that genetic factors influence addiction to alcohol, but it is difficult to unravel the different causes.
