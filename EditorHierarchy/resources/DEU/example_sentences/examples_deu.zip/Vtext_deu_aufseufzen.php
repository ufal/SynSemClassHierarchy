<G-vec00959-002-s042><sigh.aufseufzen><de> Vor knapp einem Jahr hat man dieses kollektive Aufseufzen als „Sonntagspost“ (oder wahlweise auch einen anderen Wochentag) getarnt.
<G-vec00959-002-s042><sigh.aufseufzen><en> About one year ago this collective sigh was camouflaged as “sunday post” (or any other day of the week you’d like to choose).
<G-vec00959-002-s062><sigh.aufseufzen><de> Die Mitglieder von Odd Squad waren im Restaurant versammelt, mit einer gewaltigen Anzahl von Gerichten auf dem Tisch vor ihnen, und… sahen hilflos zu, wie ich ein weiteres Mal aufseufzte.
<G-vec00959-002-s062><sigh.aufseufzen><en> Gathered in the restaurant with a huge number of dishes on the table in front of them, the members of Odd Squad…watched helplessly as I heaved yet another sigh.
