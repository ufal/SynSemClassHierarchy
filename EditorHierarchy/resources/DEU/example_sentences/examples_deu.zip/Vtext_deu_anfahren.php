<G-vec00639-002-s038><hit.anfahren><de> Die Menschen im Krankenhaus sagten zu Frau Yang: „Der junge Mann, der Ihre Tochter angefahren hat, hat einen reichen Vater, der Beamter ist.
<G-vec00639-002-s038><hit.anfahren><en> People in the hospital said to Ms. Yang, "That young man who hit her has a rich father that is an official, you should ask him for some money, since your child was hit pretty hard."
<G-vec00639-002-s039><hit.anfahren><de> Ich wurde von einem Auto angefahren und sieben bis acht Meter weit fortgeschleudert.
<G-vec00639-002-s039><hit.anfahren><en> I was hit by a car and thrown about seven or eight meters.
<G-vec00639-002-s040><hit.anfahren><de> Ein anderes Mal wurde ich auf dem Fahrrad von einem Auto angefahren und in die Luft geschleudert.
<G-vec00639-002-s040><hit.anfahren><en> Another time a car hit me and threw me into the air as I was riding a bicycle.
<G-vec00639-002-s041><hit.anfahren><de> Ich hielt das Auto an und dachte zuerst, dass es vielleicht ein schwarzes Kätzchen ist, das von einem Auto angefahren wurde.
<G-vec00639-002-s041><hit.anfahren><en> I stopped the car to see what it was first thinking it may be a black kitty which got hit by a car.
<G-vec00639-002-s042><hit.anfahren><de> Pol wegen Fahrlässigkeit und Inkompetenz auf Bewährung für seine Behandlung und Pflege eines Boston-Terriers, der im Mai von einem Auto angefahren wurde und an einer Augenproptose und einem gebrochenen Becken litt, wo die Besitzer des Hundes glücklich waren mit der Sorgfalt, die es gegeben hatte, aber Pols Behandlung eines Hundes, wie in der Show dargestellt, brachte die Beschwerde eines tierärztlichen Betrachters hervor, nicht des Besitzers des Haustieres.
<G-vec00639-002-s042><hit.anfahren><en> In, a disciplinary board placed Dr. Pol on probation for negligence and incompetence for his treatment and care of a Boston terrier that was hit by a car and suffered an eye proptosis and broken pelvis in May where the owners of the dog were happy with the care it had been given but Pol's treatment of a dog, as depicted on the show, spawned the complaint from a veterinarian viewer, not the pet's owner.
<G-vec00639-002-s043><hit.anfahren><de> Wirklich zufrieden bin ich mit meiner Karte nicht, aber nachdem unsere Katze von einem Auto angefahren wurde, nicht sicher war ob sie überhaupt überlebt und wir jetzt einen 100%igen Pflegefall zu Hause haben war an Basteln wie gewohnt nicht zu denken.
<G-vec00639-002-s043><hit.anfahren><en> I am not really happy with how my card turned out but our cat was hit by a car last friday, for several days we were unsure if she'll survive and now we have her home but she needs 24/7 care - so crafting like usual wasn't possible.
<G-vec00639-002-s044><hit.anfahren><de> Keine Welpen mit noch geschlossenen Augen, die verzweifelt nach ihrer Mutter suchen, die angefahren wurde beim Versuch ihren Wurf zusammenzuhalten.
<G-vec00639-002-s044><hit.anfahren><en> No more puppies with closed eyes desperately searching for their mom that was hit by a car trying to keep her litter together.
<G-vec00639-002-s045><hit.anfahren><de> Als ich vom Auto angefahren wurde, realisierte ich jeden Moment des Erlebnisses einschließlich angefahren zu werden, mein Bein hochzuziehen, durch die Luft zu fliegen, auf dem Belag aufzutreffen dann darüber zu rutschen und zu fühlen dass mein Körper nur ein Gefäß war.
<G-vec00639-002-s045><hit.anfahren><en> When being hit by the car, I realized every moment of the experience including being hit, pulling my leg up, flying through the air, hitting then sliding on the pavement and feeling that my body was just a vessel.
<G-vec00639-002-s047><hit.anfahren><de> Einer kann von einem Auto angefahren werden, kann von einem hohen Gebäude herunterfallen, oder er kann in eine andere Gefahr geraten.
<G-vec00639-002-s047><hit.anfahren><en> Perhaps you will be hit by a car upon stepping out the door, or you might fall from a building or run into other dangers.
<G-vec00639-002-s048><hit.anfahren><de> Ich wurde zweimal beinahe von einem Motorrad angefahren, doch unter dem Schutz des Meisters es gab keine Gefahr.
<G-vec00639-002-s048><hit.anfahren><en> I was almost hit by a motorcycle twice but there was no danger under Master's protection.
<G-vec00639-002-s049><hit.anfahren><de> An diesem Tag wurde ich auf dem Weg zur Arbeit auf einem Fußgängerüberweg von einem Auto angefahren.
<G-vec00639-002-s049><hit.anfahren><en> That day on my way to work, I was hit by a car in a pedestrian crossing.
<G-vec00639-002-s050><hit.anfahren><de> Auf der Fahrt von Vietnam, auf der Wissam von einem Guide begleitet werden musste – was in vielen Ländern auf seiner Reise der Fall war – wurde der Biker auf einer engen Bergstraße von einem Lastwagen angefahren.
<G-vec00639-002-s050><hit.anfahren><en> During the journey from Vietnam, where Wissam had to be escorted by a guide – typical of many countries in this area – the biker was hit by a truck on a tight mountain road.
<G-vec00639-002-s051><hit.anfahren><de> Nach einem hitzigen Telefongespräch geht Michael ohne sich umzusehen über die Straße und wird von einem Auto angefahren.
<G-vec00639-002-s051><hit.anfahren><en> After one heated phone call from a pay phone, Michael walked into the street without looking, and was hit by a car.
<G-vec00639-002-s052><hit.anfahren><de> Der Hund war völlig desorientiert und es war nicht klar, ob der Hund von einem Auto angefahren oder durch einen Hieb mit einer Machete verletzt worden war.
<G-vec00639-002-s052><hit.anfahren><en> The dog was totally disorientated and it wasn’t obvious if it had been hit by a car or cut up with a machete.
<G-vec00639-002-s053><hit.anfahren><de> Schließlich bekommt ihn Claire, aber nicht bevor Lyle auch noch das Video sieht, auf dem Claire von einem Auto angefahren wird.
<G-vec00639-002-s053><hit.anfahren><en> Claire finally gets it, but not before Lyle also sees video of Claire getting hit by a car.
<G-vec00639-002-s054><hit.anfahren><de> Wurde beim Training von einem Auto angefahren.
<G-vec00639-002-s054><hit.anfahren><en> Died immediately when hit by a speeding car during bicycle training, the car left the scene.
<G-vec00639-002-s055><hit.anfahren><de> 1965 wurde er von einem Auto tödlich angefahren, er verstarb im Alter von 66 Jahren.
<G-vec00639-002-s055><hit.anfahren><en> In 1965 he was hit by a car and died at the age of 66.
