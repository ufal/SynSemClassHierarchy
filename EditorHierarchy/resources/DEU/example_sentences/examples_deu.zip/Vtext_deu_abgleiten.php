<G-vec00626-002-s045><drift.abgleiten><de> Das gefällige Interieur vermittelt ein Gefühl aufdringlicher Vertrautheit und lässt den Betrachter unmerklich in eine lethargische Stimmung abgleiten.
<G-vec00626-002-s045><drift.abgleiten><en> A pleasing interior conveys a sense of obtrusive familiarity and makes one drift imperceptibly into a lethargic mood.
<G-vec00626-002-s046><drift.abgleiten><de> 1 Darum sollten wir desto mehr auf das achten, was wir gehört haben, damit wir nicht etwa abgleiten.
<G-vec00626-002-s046><drift.abgleiten><en> 1 Therefore we must pay much closer attention to what we have heard, lest we drift away from it.
<G-vec00626-002-s047><drift.abgleiten><de> 1Deswegen sollen wir um so mehr auf das achten, was wir gehört haben, damit wir nicht etwa abgleiten.
<G-vec00626-002-s047><drift.abgleiten><en> 2:1 Therefore we must pay closer attention to what we have heard, so that we do not drift away.
