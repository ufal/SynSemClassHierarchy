<G-vec00505-002-s019><borrow.abborgen><de> 42 Gib dem, der dich bittet, und wende dich nicht von dem, der dir abborgen will.
<G-vec00505-002-s019><borrow.abborgen><en> Give to everyone who begs from you, and do not refuse anyone who wants to borrow from you.”
