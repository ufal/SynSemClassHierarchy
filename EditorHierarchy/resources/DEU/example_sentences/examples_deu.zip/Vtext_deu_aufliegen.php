<G-vec00519-002-s171><peg.aufliegen><de> Auch zu lange Saiten, die mit Druck an der seitlichen Wirbelkastenwand aufliegen, können unter Umständen schneller reißen.
<G-vec00519-002-s171><peg.aufliegen><en> Violin strings which are too long can put pressure on the side wall of the peg box, and this too may cause them to tear.
