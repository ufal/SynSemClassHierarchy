<G-vec00899-002-s031><fasten.anschnallen><de> »Wir werden zwei Fahrten machen müssen«, sagte Trelig.»Wenn die ersten acht von Ihnen sich bitte setzen und anschnallen wollen.
<G-vec00899-002-s031><fasten.anschnallen><en> “We will have to make two trips,” Trelig apologized. “The first eight of you, here, please take the seats and fasten the straps.
<G-vec00899-002-s032><fasten.anschnallen><de> Jetzt bitte anschnallen: Schon zweimal innerhalb von 100 Jahren griffen die verursachenden Herrscher zu einem weiteren unfassbaren Mittel, wir sprechen gerade von den Jahren 1914 und 1939.
<G-vec00899-002-s032><fasten.anschnallen><en> Now please fasten your seat belts: Twice already within 100 years, the causing rulers have used another unconceivable instrument: We are talking about the years 1914 and 1939.
<G-vec00899-002-s172><fasten.anschnallen><de> So kannst du für den Einstieg den Sitz einfach zur Tür drehen, dein Kind bequem reinsetzen und anschnallen.
<G-vec00899-002-s172><fasten.anschnallen><en> This allows you to simply turn the seat to the door for easy access, insert and fasten your child comfortably.
<G-vec00899-002-s181><fasten.anschnallen><de> Sie steigen durch einen Tunnel in die Kugel, schnallen sich an und rollen danach einfach hangabwärts.
<G-vec00899-002-s181><fasten.anschnallen><en> You get in through a manhole, fasten the safety belts and roll down the hill.
