<G-vec00227-002-s019><wander.abirren><de> Ich suche dich von ganzem Herzen; laß mich nicht abirren von deinen Geboten.
<G-vec00227-002-s019><wander.abirren><en> With my whole heart have I sought thee: O let me not wander from thy commandments.
<G-vec00227-002-s020><wander.abirren><de> 119:21 Gescholten hast du die Übermütigen, die Verfluchten, welche abirren von deinen Geboten.
<G-vec00227-002-s020><wander.abirren><en> 119:21 Thou hast rebuked the proud that are cursed, That do wander from thy commandments.
<G-vec00839-002-s025><err.abirren><de> Du zertrittst alle, die von deinen Rechten abirren; denn ihre Truegerei ist eitel Luege.
<G-vec00839-002-s025><err.abirren><en> Thou hast trodden down all them that err from thy statutes: for their deceit is falsehood.
<G-vec00839-002-s026><err.abirren><de> Meister, die falsch lehren, und Schüler, die in der Meditation abirren.
<G-vec00839-002-s026><err.abirren><en> Masters who teach incorrectly and students who err in meditation.
<G-vec00839-002-s027><err.abirren><de> 119:21 Gescholten hast du die Übermütigen, die Verfluchten, welche abirren von deinen Geboten.
<G-vec00839-002-s027><err.abirren><en> 119:21 Thou hast rebuked the proud that are cursed, which do err from thy commandments.
<G-vec00839-002-s028><err.abirren><de> 21 Gescholten hast du die Übermütigen, die Verfluchten, die abirren von deinen Geboten.
<G-vec00839-002-s028><err.abirren><en> You have rebuked the proud that are cursed, who do err from your commandments.
<G-vec00849-002-s024><stray.abirren><de> Sie sind nur wie das Vieh – nein, sie sind noch weiter vom Weg abgeirrt.
<G-vec00849-002-s024><stray.abirren><en> They are no other than like the brute cattle; yea, they stray more widely from the true path.
<G-vec00849-002-s025><stray.abirren><de> 110 Die Gottlosen haben mir eine SchlingeSchlinge gelegt, aber von deinen Vorschriften bin ich nicht abgeirrt.
<G-vec00849-002-s025><stray.abirren><en> 110 The wicked have laid a snare for me, but I do not stray from your precepts.
<G-vec00849-002-s026><stray.abirren><de> Du zertrittst alle, die von deinen Rechten abirren; denn ihre Trügerei ist eitel Lüge.
<G-vec00849-002-s026><stray.abirren><en> 118 You reject all those who stray from Your statutes, For their deceit is falsehood.
<G-vec00849-002-s027><stray.abirren><de> 118Verworfen hast du alle, die von deinen Satzungen abirren; denn Lüge ist ihr Trug.
<G-vec00849-002-s027><stray.abirren><en> Then I will focus on your statutes continually. 118 You despise all who stray from your statutes,
<G-vec00849-002-s028><stray.abirren><de> 21 Du hast die Frechen gescholten, die Verfluchten, die abirren von deinen Geboten.
<G-vec00849-002-s028><stray.abirren><en> 21 You rebuke the arrogant, who are accursed, those who stray from your commands.
<G-vec00849-002-s029><stray.abirren><de> Daneben lebt der Mensch, gewiß in seiner Art ein höheres Wesen, aber durchtränkt von Trieben, Instinkten, Leidenschaften, durch die er von seiner strengen Gesetzmäßigkeit abirren kann.
<G-vec00849-002-s029><stray.abirren><en> On the other side, the human being lives, indeed, in his way a higher being but impregnated with desires, instincts, passions by which he can stray from his strict lawfulness.
