<G-vec00748-002-s019><brew.aufbrühen><de> Für einen hochwertigen Tee wie "Gunpowder"-Sorten kann die Dauer beim ersten Aufbrühen nur 10 Sekunden betragen.
<G-vec00748-002-s019><brew.aufbrühen><en> For high grade tea such as "gunpowder" types, steeping time may be as few as 10 seconds on first brew.
<G-vec00748-002-s020><brew.aufbrühen><de> Die mühsame endende Suche nach qualitativ hochwertigem Buchu und die Zeit zum Aufbrühen und anschließend Abseihen der Blätter brachten sie auf die Idee, den ersten 100%igen Buchu-Tee in Südafrika und wohl auch weltweit anzubieten.
<G-vec00748-002-s020><brew.aufbrühen><en> The never ending search for quality buchu as well as the time it took to brew and strain the leaves, gave her the idea to produce the first 100% pure buchu teabags in South Africa and probably the world.
<G-vec00748-002-s021><brew.aufbrühen><de> Verwenden Sie nicht zu viel Wasser zum Aufbrühen und vermeiden Sie übermäßigen Druck in der Flasche.
<G-vec00748-002-s021><brew.aufbrühen><en> Do not use too much water to brew, avoiding excessive pressure inside the bottle.
<G-vec00748-002-s022><brew.aufbrühen><de> Zubereitung: Zwei Teelöffel der Mischung wird für 15-20 min in 200-300 ml kochendem Wasser aufgebrüht.
<G-vec00748-002-s022><brew.aufbrühen><en> Method of Preparation:Pour one filter bag with 200-300 ml of boiling water and brew for 3-5 minutes.
<G-vec00748-002-s023><brew.aufbrühen><de> Rohe, grüne Bohnen müssen geröstet werden, bevor sie aufgebrüht werden können.
<G-vec00748-002-s023><brew.aufbrühen><en> Raw, green beans need to be roasted before they can make a brew.
