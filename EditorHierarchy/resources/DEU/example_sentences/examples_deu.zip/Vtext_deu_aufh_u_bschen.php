<G-vec00972-002-s021><embellish.aufhübschen><de> Ich überlege mir schon tausend Sachen, die man mit den süßen Muscheln aufhübschen könnte.
<G-vec00972-002-s021><embellish.aufhübschen><en> I’m already thinking of thousands of things that I could embellish with those cute shells.
<G-vec00972-002-s077><embellish.aufhübschen><de> Unsere kleinen Äpfel aus dem Garten haben wir ebenfalls genutzt, um der Serviette noch das gewisse Etwas zu verleihen und den Teller auf ganz außergewöhnliche Weise aufzuhübschen.
<G-vec00972-002-s077><embellish.aufhübschen><en> We also used our small apples from the garden, that give the napkins that certain something and embellish the plate in an extraordinary way.
