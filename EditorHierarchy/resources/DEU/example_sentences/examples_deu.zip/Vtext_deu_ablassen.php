<G-vec00081-001-s425><cease.ablassen><de> Laß ab, mein Sohn, zu hören die Zucht, und doch abzuirren von vernünftiger Lehre.
<G-vec00081-001-s425><cease.ablassen><en> Cease, my son, to hear the instruction which causeth to stray from the words of knowledge.
<G-vec00081-001-s426><cease.ablassen><de> 19:27 Laß ab, mein Sohn, zu hören die Zucht, und doch abzuirren von vernünftiger Lehre.
<G-vec00081-001-s426><cease.ablassen><en> 27 Cease listening, my son, to discipline, And you will stray from the words of knowledge .
<G-vec00081-001-s428><cease.ablassen><de> 27 Laß ab, mein Sohn, auf Unterweisung (O. Zucht) zu hören, die abirren macht von den Worten der Erkenntnis.
<G-vec00081-001-s428><cease.ablassen><en> 27 Cease, my son, to hear the instruction which causeth to stray from the words of knowledge.
<G-vec00081-001-s429><cease.ablassen><de> 7:8 und sprachen zu Samuel: Laß nicht ab, für uns zu schreien zu dem HERRN, unserm Gott, daß er uns helfe aus der Philister Hand.
<G-vec00081-001-s429><cease.ablassen><en> 7:8 And they said to Samuel: Cease not to cry to the Lord our God for us, that he may save us out of the hand of the Philistines.
<G-vec00847-002-s088><drain.ablassen><de> Unsere Grow-Bags können bei der Bewässerung zusätzliches Wasser ablassen und viele Probleme wie Bewurzelungen effektiv verhindern.
<G-vec00847-002-s088><drain.ablassen><en> Our grow bags could drain off extra water when watering, and effectively prevent many problems related to over-watering, like root rot.
<G-vec00847-002-s089><drain.ablassen><de> (3) Den Ausgleichsbehälter ausbauen und das Motorkühlmittel ablassen.
<G-vec00847-002-s089><drain.ablassen><en> 5. Remove the reserve tank and drain the coolant.
<G-vec00847-002-s090><drain.ablassen><de> Hier können Sie Trinkwasser auffüllen und Grauwasser bequem ablassen.
<G-vec00847-002-s090><drain.ablassen><en> Here you can fill up on drinking water and drain gray water comfortably.
<G-vec00847-002-s091><drain.ablassen><de> In Salzwasser kochen und weitere 15-20 Minuten kochen (bis sie weich sind), Wasser ablassen.
<G-vec00847-002-s091><drain.ablassen><en> Boil in salt water and cook for another 15-20 minutes (until soft), drain water.
<G-vec00847-002-s092><drain.ablassen><de> Ablassen auch bei geringerer Handkraft wird durch die Bremsrippen ermöglicht.
<G-vec00847-002-s092><drain.ablassen><en> Drain even at lower manual force is made possible by the braking ribs.
<G-vec00847-002-s093><drain.ablassen><de> Zudem müssen Sie das Wasser ablassen.
<G-vec00847-002-s093><drain.ablassen><en> You also need to drain all the water.
<G-vec00847-002-s094><drain.ablassen><de> Einfache Montage ohne Ablassen von Wasser, ohne Spezialwerkzeug und ohne Eingriff in das Heizungssystem.
<G-vec00847-002-s094><drain.ablassen><en> Easy to mount without having to drain any water or intervene in the heating system; no special tools required
<G-vec00847-002-s095><drain.ablassen><de> Auch die Kombination verschiedener Massagetechniken gehört zu unserem Portfolio und eignet sich besonders für Menschen, die neue Energie tanken und vom Stress des Alltags ablassen möchten.
<G-vec00847-002-s095><drain.ablassen><en> The combination of different massage techniques that are a part of our portfolio are especially suitable for people who want to recharge their batteries and drain the stress of everyday life.
<G-vec00847-002-s096><drain.ablassen><de> Dann das Wasser ablassen und dann den Flaum quetschen.
<G-vec00847-002-s096><drain.ablassen><en> Then drain the water, and then squeeze the fluff.
<G-vec00847-002-s097><drain.ablassen><de> Wenn Sie nicht die überschüssige Feuchtigkeit von der Palette ablassen - es kann die Dampfer, aufgrund von Feuchtigkeit in das Heizelement beschädigen.
<G-vec00847-002-s097><drain.ablassen><en> If you do not drain the excess moisture from the pallet - it can damage the steamers, due to moisture in the heating element.
<G-vec00847-002-s098><drain.ablassen><de> Durch den eingebauten Abfluss und einen mitgelieferten Schlauch können Sie das Wasser einfach in der Duschwanne ablassen.
<G-vec00847-002-s098><drain.ablassen><en> By using the built-in plug and provided draining tube you can easily and evenly drain the water via, for example, the shower drain.
<G-vec00847-002-s099><drain.ablassen><de> Wir möchten unser Teichwasser über den Winter nicht ablassen.
<G-vec00847-002-s099><drain.ablassen><en> We do not want to drain the pond for the winter.
<G-vec00847-002-s100><drain.ablassen><de> Heizleistung: 2 kW / 230 V. Heiztemperatur: bis + 85 ° C. Kugelhahn 1/2 ” zum Ablassen von Wachs.
<G-vec00847-002-s100><drain.ablassen><en> Heating power: 2 kW / 230 V. Heating temperature: up to + 85ºC. Ball valve 1/2” for wax drain.
<G-vec00847-002-s101><drain.ablassen><de> Bedenklich ist dabei, dass sie sehr blasenschwach sind und ständig ihren Urin ablassen.
<G-vec00847-002-s101><drain.ablassen><en> It is problematic that they are very bladder weak and constantly drain their urine.
<G-vec00847-002-s102><drain.ablassen><de> Um die Reinigung abzuschließen, sollten Sie das System immer ablassen oder spülen, um alle Verunreinigungen zu entfernen, die die Sentinel X400 Schlammentferner gesammelt oder entfernt hat.
<G-vec00847-002-s102><drain.ablassen><en> To complete the cleaning process, you should always drain or flush the system fully to remove all of the debris that Sentinel X400 High Performance Cleaner has collected or dislodged.
<G-vec00847-002-s103><drain.ablassen><de> Die Flüssigkeit ablassen und filtern.
<G-vec00847-002-s103><drain.ablassen><en> Drain and filter the liquid.
<G-vec00847-002-s104><drain.ablassen><de> Ablassen und mit reichlich Trinkwasser spülen.
<G-vec00847-002-s104><drain.ablassen><en> Drain and rinse thoroughly with drinking water.
<G-vec00847-002-s105><drain.ablassen><de> Besonders clever: Löcher an der Unterseite dienen zum Ablassen von Wasser, falls das Behältnis in der Dusche genutzt wird.
<G-vec00847-002-s105><drain.ablassen><en> Holes on the underside serve to drain water if the bucket is used in the shower.
<G-vec00847-002-s106><drain.ablassen><de> Schlauch mit Rückschlagventil ablassen.
<G-vec00847-002-s106><drain.ablassen><en> Drain hose with check valve.
<G-vec00847-002-s298><drain.ablassen><de> Hilft Ihrem Körper, die Lymphflüssigkeit richtig abzulassen, um eine Ansammlung von Flüssigkeit zu verhindern.
<G-vec00847-002-s298><drain.ablassen><en> Helping your body to drain lymphatic fluid properly to prevent fluid accumulation.
<G-vec00847-002-s299><drain.ablassen><de> Die kurze Seite wird draußen gesetzt, und das kleine Loch wird in der kurzen Seite gelocht, um das Regenwasser abzulassen und zu verhindern, dass das Regenwasser in den Raum gießt.
<G-vec00847-002-s299><drain.ablassen><en> The short side is placed outside, and the small hole is punched in the short side, so as to drain the rainwater and prevent the rainwater from pouring into the room.
<G-vec00847-002-s300><drain.ablassen><de> Schiebe die Ölwanne unter die Ablassschraube, so dass diese das Öl auffängt, wenn du anfängst, es abzulassen.
<G-vec00847-002-s300><drain.ablassen><en> Slide the oil drain pan beneath the drain plug so that it catches the oil when you start to drain it.
<G-vec00847-002-s301><drain.ablassen><de> Spezielle Unterlegscheiben ermöglichen es Ihnen, das Wohnmobil in den Sanitärblock abzulassen, wenn Sie organische Toiletten (ausschließlich) benutzen.
<G-vec00847-002-s301><drain.ablassen><en> Special washers allow you to drain to the sanitary block if you use organic toilets (exclusively).
<G-vec00847-002-s302><drain.ablassen><de> Es ist bequem, Wasser abzulassen.
<G-vec00847-002-s302><drain.ablassen><en> It is convenient to drain water.
<G-vec00847-002-s303><drain.ablassen><de> Der Wasserfilter des Bewässerungssystems wird leicht instand gehalten, und das Abflussrohr ist im kleinen Tor, das bequem ist, das Wasser im Winter abzulassen.
<G-vec00847-002-s303><drain.ablassen><en> The water filter of the watering system is maintained easily, and the drain pipe is in the small gate, which is convenient to drain the water in winter.
<G-vec00847-002-s304><drain.ablassen><de> Um den Sirup bequem aus den Dosen abzulassen, können Sie spezielle Kunststoffkappen mit Löchern verwenden.
<G-vec00847-002-s304><drain.ablassen><en> To conveniently drain the syrup from the cans, you can use special plastic caps with holes.
<G-vec00847-002-s305><drain.ablassen><de> Kühlschlangen setzen auch Eliminatorplatten ein, um Kondensat zu entfernen und abzulassen.
<G-vec00847-002-s305><drain.ablassen><en> Cooling coils will also employ eliminator plates to remove and drain condensate.
<G-vec00847-002-s306><drain.ablassen><de> Schrauben Sie einfach die Anodenstange vom Behälter ab, um ihn abzulassen und ihn alle 3 Monate zu kontrollieren.
<G-vec00847-002-s306><drain.ablassen><en> Just unscrew the anode rod from the tank to drain it and inspect it every 3 months.
<G-vec00847-002-s307><drain.ablassen><de> Zentralisierte Schläuche und Ventilsystemabläufe erlauben es dem Betreiber einfach Flüssigkeiten vom Kühlsystem sowie den Öl- und Kraftstofftanks an eine zentrale Stelle abzulassen, ohne sich unterhalb die Maschine zu begeben.
<G-vec00847-002-s307><drain.ablassen><en> Centralized tubing and valve system drains allow operators to easily drain fluids from the radiator and oil and fuel tanks to a central location, without having to crawl under the machine.
<G-vec00847-002-s308><drain.ablassen><de> Edelstahl-Probenahmeventil wird hauptsächlich angewandt, um Probe vom Behälter oder von der Rohrleitung zu extrahieren, es kann auch am Boden des Behälters oder der Rohrleitung zusammengesetzt werden, um die Überreste weg abzulassen.
<G-vec00847-002-s308><drain.ablassen><en> Stainless Steel Sanitary Sample Valve is mainly applied to extract sample from tank or pipeline,it is also can be assembled at the bottom of the tank or pipeline to drain away the remains.
<G-vec00847-002-s309><drain.ablassen><de> Jetzt entfernen sie die Schale von den Auberginen und legen sie in ein Sieb, um die Flüssigkeit zusammen mit der Bitterkeit abzulassen.
<G-vec00847-002-s309><drain.ablassen><en> Now they remove the peel from the eggplants and put them in a colander to drain the liquid along with the bitterness.
<G-vec00847-002-s310><drain.ablassen><de> Dazu die Möglichkeit dosiert Öl abzulassen um zum Beispiel eine Probe zu entnehmen oder einfach zuviel eingefülltes Öl zu entnehmen.
<G-vec00847-002-s310><drain.ablassen><en> Including the possibility metered oil drain or to take a sample, or simply to drain too much filled in oil.
<G-vec00942-002-s039><abandon.ablassen><de> Um Moldau in die Einflusszone Russlands zurückzubringen, muss man vom veralteten Paradigma des gesellschaftlichen Konsens ablassen.
<G-vec00942-002-s039><abandon.ablassen><en> “To return Moldova to the sphere of direct influence of Russia it is necessary to abandon the outdated paradigm of public consensus.
<G-vec00942-002-s040><abandon.ablassen><de> Ihr klammert euch beharrlich an den Glauben, ich sei der Messias, und ihr wollt nicht von der Idee ablassen, dass der Messias auf einem Thron in Jerusalem sitzen müsse; deshalb sage ich euch beharrlich, dass der Menschensohn bald nach Jerusalem gehen und dort viel erdulden muss, von den Schriftgelehrten, den Ältesten und Hohenpriestern abgelehnt, schließlich getötet und von den Toten auferweckt werden muss.
<G-vec00942-002-s040><abandon.ablassen><en> You insist on clinging to the belief that I am the Messiah, and you will not abandon the idea that the Messiah must sit upon a throne in Jerusalem; wherefore do I persist in telling you that the Son of Man must presently go to Jerusalem, suffer many things, be rejected by the scribes, the elders, and the chief priests, and after all this be killed and raised from the dead.
