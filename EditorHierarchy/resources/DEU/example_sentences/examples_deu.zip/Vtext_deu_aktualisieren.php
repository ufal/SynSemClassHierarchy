<G-vec00386-002-s057><upgrade.aktualisieren><de> Probieren Sie das kostenlose Header Slideshow noch heute aus und aktualisieren Sie es jederzeit, um zusätzliche Funktionen zu erhalten.
<G-vec00386-002-s057><upgrade.aktualisieren><en> Try the free RSS Feed today and upgrade at any time to unlock advanced features.
<G-vec00386-002-s058><upgrade.aktualisieren><de> Wählen Sie die besten Foto-Momente, finden Sie seltene Tiere zu und aktualisieren Sie Ihre Parks mit neuen Fahrzeuge, größere touristische Einrichtungen, Restaurants und mehr.
<G-vec00386-002-s058><upgrade.aktualisieren><en> Choose the best photo moments, find rare animals and upgrade your parks with new vehicles, bigger tourist facilities, restaurants and more.
<G-vec00386-002-s059><upgrade.aktualisieren><de> Aktualisieren Sie die Server auf .NET Framework 4.6.2, bevor Sie Exchange 2016 CU5 installieren, oder Sie erhalten eine Fehlermeldung.
<G-vec00386-002-s059><upgrade.aktualisieren><en> Upgrade your servers to .NET Framework 4.6.2 before you install Exchange 2016 CU5 or you'll receive an error.
<G-vec00386-002-s060><upgrade.aktualisieren><de> Aktualisieren Sie Ihr Gerät auf die neueste OS-Version.
<G-vec00386-002-s060><upgrade.aktualisieren><en> Upgrade your device to the latest OS release.
<G-vec00386-002-s062><upgrade.aktualisieren><de> Aktualisieren Sie das Betriebssystem auf Microsoft Windows 7 oder Windows 8.x.
<G-vec00386-002-s062><upgrade.aktualisieren><en> Upgrade the operating system to Microsoft Windows 7 or Microsoft Windows 8.x.
<G-vec00386-002-s063><upgrade.aktualisieren><de> Aktualisieren Sie Ihr Trainingsmodell von Resusci Anne QCPR mit diesem Kit schnell und einfach.
<G-vec00386-002-s063><upgrade.aktualisieren><en> Upgrade your Resusci Anne QCPR manikin quickly and easily with this kit.
<G-vec00386-002-s064><upgrade.aktualisieren><de> Aktualisieren Sie Ihren Shop mit neuen Toppings und Ausrüstung, um gegen Ihre Pizza Rivalen,...
<G-vec00386-002-s064><upgrade.aktualisieren><en> Upgrade your shop with new toppings and equipment to compete against your pizza rival, Alicante!GAME HIGHLIGHTS* Featuring Pizza...
<G-vec00386-002-s065><upgrade.aktualisieren><de> Aktualisieren Sie Ihre Stärken besser zu verrichten.
<G-vec00386-002-s065><upgrade.aktualisieren><en> Upgrade your strengths to perform better.
<G-vec00386-002-s066><upgrade.aktualisieren><de> Laden Sie SyncMate herunter und aktualisieren Sie auf die Expert Edition, um Musik zu synchronisieren.
<G-vec00386-002-s066><upgrade.aktualisieren><en> Download SyncMate and upgrade to the Expert edition in order to sync music.
<G-vec00386-002-s067><upgrade.aktualisieren><de> Wenn .NET Framework 4.5.2 auf Ihren Exchange-Servern installiert ist, aktualisieren Sie Ihre Server vor der Installation von .NET Framework 4.6.2 auf Die erforderlichen Komponenten für die Installation von Exchange 2016 auf Computern mit Windows Server 2016 hängen von der Exchange-Rolle ab, die Sie installieren möchten.
<G-vec00386-002-s067><upgrade.aktualisieren><en> If .NET Framework 4.5.2 is installed on your Exchange servers, upgrade your servers to Exchange 2016 CU4 before installing .NET Framework 4.6.2. Voraussetzungen für Windows Server 2016Windows Server 2016 prerequisites The prerequisites that are needed to install Exchange 2016 on computers running Windows Server 2016 depends on which Exchange role you want to install.
<G-vec00386-002-s068><upgrade.aktualisieren><de> Aktualisieren Sie Ihre Spieltagausrüstung mit dieser luxuriösen Netzballpfosten.
<G-vec00386-002-s068><upgrade.aktualisieren><en> Upgrade your match day equipment with these luxury netball posts.
<G-vec00386-002-s069><upgrade.aktualisieren><de> Stunts ausführen, Hindernissen ausweichen, sammeln und aktualisieren Sie alle Motorboote und fahren zum Sieg in einem Rennspiel Power-Boot.
<G-vec00386-002-s069><upgrade.aktualisieren><en> Perform stunts, avoid obstacles, collect and upgrade all the power boats and drive to victory in a power boat racing game.
<G-vec00386-002-s070><upgrade.aktualisieren><de> Probieren Sie das kostenlose Online Registration Form noch heute aus und aktualisieren Sie es jederzeit, um zusätzliche Funktionen zu erhalten.
<G-vec00386-002-s070><upgrade.aktualisieren><en> Try the free File Embed today and upgrade at any time to unlock advanced features.
<G-vec00386-002-s071><upgrade.aktualisieren><de> Probieren Sie das kostenlose Paypal Donate Button noch heute aus und aktualisieren Sie es jederzeit, um zusätzliche Funktionen zu erhalten.
<G-vec00386-002-s071><upgrade.aktualisieren><en> Try the free Ecommerce today and upgrade at any time to unlock advanced features.
<G-vec00386-002-s072><upgrade.aktualisieren><de> Thunderbolt Typ-C-Anschluss: Aktualisieren Sie auf mehrere Port-Optionen mit einem vielfach nutzbaren Port, der als USB 3.1-Port verwendet werden kann und eine Datenübertragung von 10 Gbit/s bietet, als Thunderbolt-Anschluss mit 40 Gbit/s oder als DisplayPort verwendet werden kann und Unterstützung für mehrere Monitore mit DP-Protokollunterstützung bietet.
<G-vec00386-002-s072><upgrade.aktualisieren><en> Thunderbolt Type-C port: Upgrade to multiple port options with a multi-use port ready to be used as a USB 3.1 port offering 10Gbps of data transfer, a Thunderbolt connection capable of 40Gbps, or a Display Port enabling various monitors supporting the DP protocol.
<G-vec00386-002-s073><upgrade.aktualisieren><de> Probieren Sie das kostenlose About Us noch heute aus und aktualisieren Sie es jederzeit, um zusätzliche Funktionen zu erhalten.
<G-vec00386-002-s073><upgrade.aktualisieren><en> Try the free Holiday Countdown today and upgrade at any time to unlock advanced features.
<G-vec00386-002-s074><upgrade.aktualisieren><de> Wenn Sie XenDesktop 5.6 und XenDesktop 7.x-Sites parallel ausführen und für beide Provisioning Services verwenden möchten, stellen Sie entweder eine neue Version von Provisioning Services für die Verwendung mit der 7.x-Site bereit oder aktualisieren Sie die aktuelle Version von Provisioning Services.
<G-vec00386-002-s074><upgrade.aktualisieren><en> If you plan to run XenDesktop 5.6 and 7.x Sites simultaneously and use Provisioning Services for both, either deploy a new Provisioning Services for use with the 7.x Site, or upgrade the current Provisioning Services and be unable to provision new workloads in the XenDesktop 5.6 Site.
<G-vec00386-002-s075><upgrade.aktualisieren><de> Probieren Sie das kostenlose Banner Maker noch heute aus und aktualisieren Sie es jederzeit, um zusätzliche Funktionen zu erhalten.
<G-vec00386-002-s075><upgrade.aktualisieren><en> Try the free Form Maker today and upgrade at any time to unlock advanced features.
<G-vec00436-002-s019><update.aktualisieren><de> Speichere deinen Code und/oder aktualisiere die Seite, um deine Änderungen zu speichern.
<G-vec00436-002-s019><update.aktualisieren><en> Be sure to save your code and/or update the page to save your changes.
<G-vec00436-002-s020><update.aktualisieren><de> Wichtig: Aktualisiere dein Passwort in vertrauenswürdigen Drittapplikationen.
<G-vec00436-002-s020><update.aktualisieren><en> 4. Update your password in your trusted third-party applications
<G-vec00436-002-s021><update.aktualisieren><de> Frage Ich plane, mindestens einen Monat zu warten, bis ich mein iPhone auf iOS 11.4 aktualisiere.
<G-vec00436-002-s021><update.aktualisieren><en> Question I plan on waiting at least a month until I update my iPhone to iOS 11.4.
<G-vec00436-002-s022><update.aktualisieren><de> Aktualisiere deine Garderobe für den Herbst und Winter mit dieser Bikerjacke aus Teddyfell.
<G-vec00436-002-s022><update.aktualisieren><en> Size guide Product details Update your wardrobe this autumn winter with this borg biker jacket.
<G-vec00436-002-s023><update.aktualisieren><de> Suche nach erfassten Golfplätzen, oder aktualisiere die Golfplatzkarten auf deinem Gerät.
<G-vec00436-002-s023><update.aktualisieren><en> Search for golf course coverage, or update the existing golf course maps on your device.
<G-vec00436-002-s024><update.aktualisieren><de> Aktualisiere dort deine Angaben mit der neuen Kartennummer.
<G-vec00436-002-s024><update.aktualisieren><en> Update the new card number to any online services you may be using.
<G-vec00436-002-s025><update.aktualisieren><de> Aktualisiere deinen Feed.
<G-vec00436-002-s025><update.aktualisieren><en> Update your feed.
<G-vec00436-002-s026><update.aktualisieren><de> Genaue Informationen findest du in unserer Aktualisiere deinen Standort, um in Österreich erhältliche Produkte kaufen zu können.
<G-vec00436-002-s026><update.aktualisieren><en> United Arab Emirates English Update your location to shop products available in Egypt
<G-vec00436-002-s027><update.aktualisieren><de> Aktualisiere deine Webseite regelmäßig.
<G-vec00436-002-s027><update.aktualisieren><en> Update your website regularly.
<G-vec00436-002-s028><update.aktualisieren><de> Aktualisiere deinen Standort, um in Österreich erhältliche Produkte kaufen zu können.
<G-vec00436-002-s028><update.aktualisieren><en> Update your location to shop products available in South Africa
<G-vec00436-002-s029><update.aktualisieren><de> Aktualisiere die Website, einschließlich eines Termin-Tools und eines Onlineshops.
<G-vec00436-002-s029><update.aktualisieren><en> Update website, including adding online appointments and/or an online store
<G-vec00436-002-s030><update.aktualisieren><de> Aktualisiere die Wx/xyz-Infoseite hier, indem du den Parameter „meta“ in | meta = yes abänderst.
<G-vec00436-002-s030><update.aktualisieren><en> Update the Wx/xyz info page here by changing the parameter "meta" to | meta = yes
<G-vec00436-002-s031><update.aktualisieren><de> aktualisiere Word-/PowerPoint-Inhalte (Text, Tabellen und Diagramme) auf der Grundlage von Excel-Daten und -Berechnungen mit dem Office-365- und Windows-Online-Add-in.
<G-vec00436-002-s031><update.aktualisieren><en> Easily link/update Word/PowerPoint content (text, tables, and charts) based on Excel data and calculations with our Office 365 and Windows Online add-in.
<G-vec00436-002-s032><update.aktualisieren><de> Teile deine Fotos mit Facebook Freunden oder aktualisiere dein Profilbild – direkt aus iPhoto.
<G-vec00436-002-s032><update.aktualisieren><en> Share your photos with Facebook friends or update your profile picture — right from iPhoto.
<G-vec00436-002-s033><update.aktualisieren><de> Wenn du deine iTunes-Playliste(n) änderst, beende iTunes und aktualisiere den Sonos Musikindex, damit die Änderungen angezeigt werden.
<G-vec00436-002-s033><update.aktualisieren><en> When you change your iTunes playlist(s), exit iTunes, and update your Sonos music index to see the changes.
<G-vec00436-002-s034><update.aktualisieren><de> Pflege und aktualisiere dein Profil regelmäßig.
<G-vec00436-002-s034><update.aktualisieren><en> Maintain and update your profile on a regular basis.
<G-vec00436-002-s035><update.aktualisieren><de> Aktualisiere auf iOS 9 oder neuer.
<G-vec00436-002-s035><update.aktualisieren><en> Update to iOS 9 or later.
<G-vec00436-002-s036><update.aktualisieren><de> Aktualisiere deinen Standort, um in Luxemburg erhältliche Produkte kaufen zu können.
<G-vec00436-002-s036><update.aktualisieren><en> Update your location to shop products available in Switzerland
<G-vec00436-002-s037><update.aktualisieren><de> Bitte aktualisiere deine Bookmarks und berichte uns jeden ungültigen Link.
<G-vec00436-002-s037><update.aktualisieren><en> Please update your bookmarks and report any broken links.
<G-vec00891-002-s038><upgrade.aktualisieren><de> Wir empfehlen Ihnen, Ihre xinetd-Pakete zu aktualisieren.
<G-vec00891-002-s038><upgrade.aktualisieren><en> We recommend that you upgrade your xinetd packages.
<G-vec00891-002-s039><upgrade.aktualisieren><de> Wir empfehlen Ihnen, Ihr Pound-Paket zu aktualisieren.
<G-vec00891-002-s039><upgrade.aktualisieren><en> We recommend that you upgrade your pound package.
<G-vec00891-002-s040><upgrade.aktualisieren><de> Wir können Ihre I-Shift-Software einfach aktualisieren, damit sie Ihren Anforderungen entspricht.
<G-vec00891-002-s040><upgrade.aktualisieren><en> We can simply upgrade your I-Shift software to match your needs.
<G-vec00891-002-s041><upgrade.aktualisieren><de> Lösung Um Ihr Programm mit der Programmkomponentenaktualisierung (PCU) auf die neueste Version zu aktualisieren, klicken Sie auf Jetzt aktualisieren.
<G-vec00891-002-s041><upgrade.aktualisieren><en> Solution To upgrade your program to the latest version using the Program component upgrade (PCU), click Upgrade now.
<G-vec00891-002-s043><upgrade.aktualisieren><de> Mit unserem Service decken wir aber nicht nur Soft- und Hardware ab, wir stehen Ihnen auch bei Entscheidungen zur Seite – zum Beispiel ob Sie Ihr System durch ein neues ersetzen sollten oder ob es reicht, vorhandene Anwendungen zu aktualisieren.
<G-vec00891-002-s043><upgrade.aktualisieren><en> Our services not only include hardware and software. We also help you decide if it is time to replace your system with a new one or simply upgrade existing applications.
<G-vec00891-002-s044><upgrade.aktualisieren><de> Während du diese Mädchen einstellst, kannst du sie aktualisieren, was sie dazu bringt, automatisch mehr Geld zu generieren, ohne dass du auf sie klicken musst.
<G-vec00891-002-s044><upgrade.aktualisieren><en> As you’re hiring these girls, you can upgrade them, which will make them generate more money automatically without you having to click on them.
<G-vec00891-002-s045><upgrade.aktualisieren><de> Sammeln Sie Geld, um Ihre Ausrüstung im Shop zu aktualisieren.
<G-vec00891-002-s045><upgrade.aktualisieren><en> Gain money to upgrade or buy more cannons.
<G-vec00891-002-s046><upgrade.aktualisieren><de> Informationen zum Konfigurieren eines Systems mit einem ZFS-Root-Dateisystem, das mithilfe von Live Upgrade migriert oder gepatcht werden soll, finden Sie unter Verwenden von Live Upgrade zum Migrieren oder Aktualisieren eines Systems mit Zonen (Solaris 10 10/08) oder Verwenden des Oracle Solaris Live Upgrade zum Migrieren oder Aktualisieren eines Systems mit Zonen (ab Solaris 10 5/09).
<G-vec00891-002-s046><upgrade.aktualisieren><en> For information about configuring zones on a system with a ZFS root file system that will be migrated or patched with Oracle Solaris Live Upgrade, see Using Oracle Solaris Live Upgrade to Migrate or Upgrade a System With Zones (Solaris 10 10/08) or Using Oracle Solaris Live Upgrade to Migrate or Upgrade a System With Zones (at Least Solaris 10 5/09).
<G-vec00891-002-s048><upgrade.aktualisieren><de> Selbst Nutzer mit mobilen Geräten, die sich in einem lokalen Netzwerk oder in einer Umgebung mit mehreren Routern befinden, müssen lediglich ihre Apps auf die neueste Version mit Unterstützung von ADM 3.0 aktualisieren, um eine Verbindung mit ihrem NAS herstellen und auf das Surveillance Center zugreifen zu können – von überall und zu jeder Zeit.
<G-vec00891-002-s048><upgrade.aktualisieren><en> Even if users with mobile devices are under local network or multi-router environments, all they need to do is upgrade their apps to the latest version supporting ADM 3.0 and they will be able to easily connect to their NAS to access Surveillance Center from anywhere and at any time.
<G-vec00891-002-s049><upgrade.aktualisieren><de> Ob Sie den Energieverbrauch senken, existierende Systeme aktualisieren oder die generierten Daten besser nutzen möchten –wir haben die Öl- und Gasanlagen und ‑ressourcen, die Sie zum Erreichen Ihrer Ziele benötigen.
<G-vec00891-002-s049><upgrade.aktualisieren><en> Whether you would like to reduce your energy consumption, upgrade legacy systems or make better use of the data you generate, we have the oil and gas equipment and resources you need to meet your goals.
<G-vec00891-002-s050><upgrade.aktualisieren><de> Approx spart Zeit und Netzwerkbandbreite, wenn Sie .deb-Pakete auf mehreren Rechnern eines lokalen Netzwerks installieren oder aktualisieren (»upgraden«).
<G-vec00891-002-s050><upgrade.aktualisieren><en> Approx saves time and network bandwidth if you need to install or upgrade .deb packages for a number of machines on a local network.
<G-vec00891-002-s051><upgrade.aktualisieren><de> Wenn Sie derzeit ein 32-Bit-Windows-System verwenden, werden Sie nicht auf Alteryx Analytics 11.0 aktualisieren können, da wir nur Alteryx Analytics Installationsprogramme für 64-Bit-Windows-Systeme bereitstellen.
<G-vec00891-002-s051><upgrade.aktualisieren><en> If you are currently using a 32-bit Windows system, you will be unable to upgrade to the Alteryx Analytics 11.0 release as we will only be providing Alteryx Analytics installers for 64-bit Windows systems.
<G-vec00891-002-s052><upgrade.aktualisieren><de> Diese Werkzeuge sind bei der Installation der FARO Software enthalten und werden aktualisiert, wenn Sie die Software aktualisieren.
<G-vec00891-002-s052><upgrade.aktualisieren><en> These tools are included when you install FARO software and are upgraded when you upgrade the software.
<G-vec00891-002-s053><upgrade.aktualisieren><de> Nachdem die Zeit abgelaufen ist, können Sie immer noch die Software mit Ihrer Lizenz benutzen, nicht aber auf die neue Programmversion kostenlos aktualisieren.
<G-vec00891-002-s053><upgrade.aktualisieren><en> After the free updates period is expired, you still can use the software with your license, but you can't upgrade to a new version for free.
<G-vec00891-002-s054><upgrade.aktualisieren><de> Wir empfehlen Ihnen, Ihr xpdf-Paket zu aktualisieren.
<G-vec00891-002-s054><upgrade.aktualisieren><en> We recommend that you upgrade your xpdf package.
<G-vec00891-002-s055><upgrade.aktualisieren><de> Sie fügen zu wenig Eigenschaften hinzu und dürfen nur verwendet werden, wenn du nichts anderes zu aktualisieren hast.
<G-vec00891-002-s055><upgrade.aktualisieren><en> They add too small amount of characteristics and must be used only if you have nothing else to upgrade.
