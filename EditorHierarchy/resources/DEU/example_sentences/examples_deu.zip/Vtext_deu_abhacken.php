<G-vec00903-002-s019><chop.abhacken><de> GG: Ich würde mir beide Arme abhacken um mit Mike Leigh zu Arbeiten - Ich liebe seine Filme und sein Verfahren vom erstellen der Filme.
<G-vec00903-002-s019><chop.abhacken><en> GG: I would chop off both my arms to work with Mike Leigh - I love his films and the process of making and rehearsing his films.
<G-vec00903-002-s020><chop.abhacken><de> Sie sagten mir, dass sie kommen würden, aber dass sie meinen Kopf nachher abhacken würden.
<G-vec00903-002-s020><chop.abhacken><en> They told me they would come, but that they would chop my head off afterwards.
