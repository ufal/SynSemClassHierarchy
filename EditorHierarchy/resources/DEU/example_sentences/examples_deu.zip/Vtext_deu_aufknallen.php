<G-vec00728-002-s022><slam.aufknallen><de> Wenn Dich jemand anruft und Dir eklige Dinge erzählt, dann darfst Du einfach den Hörer aufknallen.
<G-vec00728-002-s022><slam.aufknallen><en> If someone calls and tells you disgusting things you can just slam down the phone.
