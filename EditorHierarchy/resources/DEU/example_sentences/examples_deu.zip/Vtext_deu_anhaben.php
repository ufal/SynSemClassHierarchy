<G-vec00372-002-s021><disrupt.anhaben><de> Soll Ihnen der Wind nichts anhaben können, suchen Sie nach Produkten mit diesem Piktogramm, für einen höheren Tragekomfort.
<G-vec00372-002-s021><disrupt.anhaben><en> Choose products with this symbol when you don’t want the wind to disrupt your everyday comfort.
