<G-vec00847-002-s251><drain.abtropfen><de> Die Salbeiblätter in einem kleinen Topf, in stehendem, heißem Öl portionsweise sekundenschnell frittieren, auf Küchenpapier abtropfen und salzen.
<G-vec00847-002-s251><drain.abtropfen><en> Deep fry the sage leaves in small portions for a few seconds in hot oil in a saucepan. Drain on kitchen paper and add salt.
<G-vec00847-002-s252><drain.abtropfen><de> Die Linsen durch ein Sieb abtropfen und beiseite stellen.
<G-vec00847-002-s252><drain.abtropfen><en> Once the lentils are soft, but not mouchy, drain the water and set aside.
<G-vec00847-002-s253><drain.abtropfen><de> In einem Sieb salzen und 15 Minuten abtropfen lassen.
<G-vec00847-002-s253><drain.abtropfen><en> Salt cucumber slices and let them drain about 15 minutes.
<G-vec00847-002-s254><drain.abtropfen><de> Öffnen Sie die Hühnerdose, lassen Sie sie abtropfen und geben Sie sie in eine Schüssel.
<G-vec00847-002-s254><drain.abtropfen><en> Open the chicken can and let it drain and then put it in a bowl.
<G-vec00847-002-s255><drain.abtropfen><de> Mais abtropfen, den Koriander fein hacken.
<G-vec00847-002-s255><drain.abtropfen><en> Drain the corn, finely chop the coriander.
<G-vec00847-002-s256><drain.abtropfen><de> Abtropfen und abkühlen lassen.
<G-vec00847-002-s256><drain.abtropfen><en> Drain and let it cool.
<G-vec00847-002-s257><drain.abtropfen><de> Öffnen Sie die Dose mit dem Huhn und lassen Sie es gut abtropfen.
<G-vec00847-002-s257><drain.abtropfen><en> Open the can with the chicken and let it drain well.
<G-vec00847-002-s258><drain.abtropfen><de> Dann abtropfen und wäscht.
<G-vec00847-002-s258><drain.abtropfen><en> Then drain and wash.
<G-vec00847-002-s259><drain.abtropfen><de> Die Fischstücke gut abtropfen und abwechselnd mit dem Gemüse auf die Spieße stecken.
<G-vec00847-002-s259><drain.abtropfen><en> Drain the fish well and string it on the skewer alternating with vegetables.
<G-vec00847-002-s260><drain.abtropfen><de> Pochiertes Ei mit einem Schöpflöffel entnehmen und zum Abtropfen auf Küchenpapier geben.
<G-vec00847-002-s260><drain.abtropfen><en> Remove the poached egg with a skimmer and place on paper towel to drain.
<G-vec00847-002-s261><drain.abtropfen><de> Bevor Sie den Tofu verarbeiten, tupfen Sie ihn mit einem Küchenpapier ab oder lassen Sie ihn längere Zeit abtropfen.
<G-vec00847-002-s261><drain.abtropfen><en> Before processing the tofu, dab it with a paper towel or leave it to drain well.
<G-vec00847-002-s262><drain.abtropfen><de> Lassen Sie die gebratenen Buletten auf saugfähigem Papier abtropfen und servieren Sie diese heiß oder kalt mit Joghurt-Dip.
<G-vec00847-002-s262><drain.abtropfen><en> Leave them on absorbent paper to drain and then serve hot or cold with yogurt dip.
<G-vec00847-002-s263><drain.abtropfen><de> Zutaten: Halbes Kilo abgetropfter Joghurt 2 große Gurken 3 Knoblauchzehen 1 Teelöffel Salz 4-5 Eßlöffel Olivenöl 2 Eßlöffel Essig 1 Eßlöffel grüne Minze oder Dill (nach Wunsch) Wir schälen die Gurken, schneiden sie klein und lassen sie für einige Zeit abtropfen.
<G-vec00847-002-s263><drain.abtropfen><en> Ingredients Half a kilo of strained yogurt 2 large cucumbers 3 cloves of garlic 1 teaspoon of salt 4-5 tablespoons of olive oil 2 tablespoons of vinegar 1 tablespoon mint or dill (optional) Peel and finely chop the cucumbers, and let the liquids drain from them for a while.
<G-vec00847-002-s264><drain.abtropfen><de> Waschen Sie die Blätter, lassen Sie sie abtropfen und reißen Sie diese anschließend in mundgerechte Stücke.
<G-vec00847-002-s264><drain.abtropfen><en> Wash the leaves, let them drain and then tear them into bite-sized pieces.
<G-vec00847-002-s265><drain.abtropfen><de> Schließen Sie das Geschirr mit einem Deckel, lassen Sie es 8 Stunden ziehen und lassen Sie es abtropfen.
<G-vec00847-002-s265><drain.abtropfen><en> Close the dishes with a lid, let it brew for 8 hours, then drain.
<G-vec00847-002-s266><drain.abtropfen><de> 5) Ziehen Sie den De-Calc-Verschluss heraus und lassen Sie das Wasser abtropfen.
<G-vec00847-002-s266><drain.abtropfen><en> 5) Pull the de-calc knob out and let the water drain.
<G-vec00847-002-s267><drain.abtropfen><de> Fusilli und Broccoli im Salzwasser knapp al dente kochen, abtropfen, auskühlen.
<G-vec00847-002-s267><drain.abtropfen><en> Cook the fusilli and broccoli in salted water until just al dente, drain, cool.
<G-vec00847-002-s268><drain.abtropfen><de> Weiche die Löwenzahnblätter etwa zehn Minuten ein und lasse sie dann abtropfen.
<G-vec00847-002-s268><drain.abtropfen><en> Soak the greens for about 10 minutes, then drain them.
<G-vec00847-002-s269><drain.abtropfen><de> 6 Lege das Fleisch zum Abtropfen 24 Stunden lang in einem gut belüfteten Bereich auf ein Drahtgeflecht.
<G-vec00847-002-s269><drain.abtropfen><en> Set the meat on a wire mesh screen to drain for 24 hours in a well ventilated area and store in the refrigerator for up to 30 days.
<G-vec00847-002-s270><drain.abtropfen><de> Die Amarenakirschen abtropfen lassen (den Saft auffangen, ich sage Ihnen, wie er in einem anderen Rezept verwendet werden kann:-)).
<G-vec00847-002-s270><drain.abtropfen><en> Drain the amarenas from the syrup (but don’t throw the syrup away, as you can use it for another recipe).
<G-vec00847-002-s271><drain.abtropfen><de> Abtropfen lassen und in die Pfanne geben.
<G-vec00847-002-s271><drain.abtropfen><en> Drain and return to the pan.
<G-vec00847-002-s272><drain.abtropfen><de> ZUBEREITUNG Hasen waschen, portionieren und abtropfen lassen.
<G-vec00847-002-s272><drain.abtropfen><en> PREPARATION Wash the rabbit, cut into portions and leave to drain.
<G-vec00847-002-s273><drain.abtropfen><de> Dadurch wird die Lebensdauer der Turbine deutlich erhöht, so dass sich das Öl abkühlen und abkühlen lassen und vor dem Abschalten vom Turbolader abtropfen lassen.
<G-vec00847-002-s273><drain.abtropfen><en> This will significantly increase the service life of the turbine, allowing the oil to cool and cool, and drain from the turbocharger before shutting down.
<G-vec00847-002-s274><drain.abtropfen><de> Ananas abtropfen lassen, Saft auffangen und Ananas in Stücke schneiden.
<G-vec00847-002-s274><drain.abtropfen><en> Drain the pineapple, collect the juice and chop the pineapples.
<G-vec00847-002-s275><drain.abtropfen><de> Auf Küchenpapier abtropfen lassen.
<G-vec00847-002-s275><drain.abtropfen><en> Drain on paper and serve hot.
<G-vec00847-002-s276><drain.abtropfen><de> Abtropfen lassen.
<G-vec00847-002-s276><drain.abtropfen><en> Wash & drain.
<G-vec00847-002-s277><drain.abtropfen><de> Fleisch und Garnitur abtropfen lassen und Jus beiseite stellen.
<G-vec00847-002-s277><drain.abtropfen><en> Drain the meat and garnish, keep the marinade aside.
<G-vec00847-002-s278><drain.abtropfen><de> Die Nudeln abtropfen lassen.
<G-vec00847-002-s278><drain.abtropfen><en> Drain the radishes.
<G-vec00847-002-s279><drain.abtropfen><de> Abtropfen lassen und mit genügend Wasser abspülen, um sie abzukühlen.
<G-vec00847-002-s279><drain.abtropfen><en> Drain and rinse with plenty of cold water.
<G-vec00847-002-s280><drain.abtropfen><de> Anschließend abtropfen lassen und in einem Container im Kühlschrank aufbewahren.
<G-vec00847-002-s280><drain.abtropfen><en> Then drain and keep in a container in the refrigerator.
<G-vec00847-002-s281><drain.abtropfen><de> Blätter und Stiele in feine Streifen schneiden, in eine Schüssel mit kaltem Wasser geben, waschen und in ein Sieb geben, abtropfen lassen.
<G-vec00847-002-s281><drain.abtropfen><en> Remove the stems from the stalk and cut leaves and stalks into thin strips, place in a bowl with cold water, wash and put into a colander, drain.
<G-vec00847-002-s282><drain.abtropfen><de> Fertigbohnen abtropfen lassen (am besten in ein Sieb geben, um das Glas zum Wasser zu machen).
<G-vec00847-002-s282><drain.abtropfen><en> Ready beans drain (best to throw in a colander, to make the glass all the water).
<G-vec00847-002-s283><drain.abtropfen><de> Spinat waschen und abtropfen lassen.
<G-vec00847-002-s283><drain.abtropfen><en> Drain the corn and the pickles.
<G-vec00847-002-s284><drain.abtropfen><de> Wenn die Pasta fertig ist, abtropfen lassen und Pesto, Mozzarella, Brokkoli und Tomaten dazugeben.
<G-vec00847-002-s284><drain.abtropfen><en> When the pasta is ready, drain and add the pesto, mozzarella, broccoli and Toma’Dor tomatoes.
<G-vec00847-002-s285><drain.abtropfen><de> Mozzarella abtropfen lassen und in Hälften schneiden.
<G-vec00847-002-s285><drain.abtropfen><en> Drain the mozzarella balls and cut in half.
<G-vec00847-002-s286><drain.abtropfen><de> Linsen in einem Sieb abspülen und abtropfen lassen.
<G-vec00847-002-s286><drain.abtropfen><en> Rinse and drain lentils in a sieve.
<G-vec00847-002-s287><drain.abtropfen><de> Kichererbsen in einem Sieb abtropfen lassen.
<G-vec00847-002-s287><drain.abtropfen><en> Drain the chickpeas in a sieve.
<G-vec00847-002-s288><drain.abtropfen><de> Auf einem Gitterrost abtropfen lassen.
<G-vec00847-002-s288><drain.abtropfen><en> Drain on a wire rack.
<G-vec00847-002-s463><drain.abtropfen><de> Lasse sie abtropfen und gib sie in eine große Schüssel.
<G-vec00847-002-s463><drain.abtropfen><en> Drain the water well and put the lentils in a large bowl.
<G-vec00847-002-s464><drain.abtropfen><de> Lasse mit einem Schaumlöffel das Öl abtropfen, wenn du die Karipap aus dem Topf hebst.
<G-vec00847-002-s464><drain.abtropfen><en> Use a slotted or sieve spoon to drain off the oil as you lift the puffs from the pot.
<G-vec00847-002-s465><drain.abtropfen><de> Nimm sie von der Platte und lasse sie gut abtropfen.
<G-vec00847-002-s465><drain.abtropfen><en> Remove from the heat and drain well.
<G-vec00847-002-s466><drain.abtropfen><de> Mache die Dose auf und lasse die Sauce abtropfen.
<G-vec00847-002-s466><drain.abtropfen><en> Open the canned peas and drain the sauce.
<G-vec00847-002-s467><drain.abtropfen><de> Lasse die Samen auf trockenen, saugfähigen Papiertüchern abtropfen.
<G-vec00847-002-s467><drain.abtropfen><en> Drain the seeds on dry, absorbent paper towel.
<G-vec00847-002-s468><drain.abtropfen><de> Lasse das Wasser abtropfen und trockne die Maiskölbchen.
<G-vec00847-002-s468><drain.abtropfen><en> Drain the water and dry the baby corn.
<G-vec00847-002-s469><drain.abtropfen><de> Lasse die Putenschlegel abtropfen und abkühlen.
<G-vec00847-002-s469><drain.abtropfen><en> Drain the turkey legs and let them cool.
<G-vec00847-002-s478><drain.abtropfen><de> Lassen Sie Paprikaschoten ein wenig abtropfen und drücken Sie sie, schneiden Sie sie in Streifen oder dünne Scheiben.
<G-vec00847-002-s478><drain.abtropfen><en> Drain the peppers and squeeze them a little, cut them into strips or round slices.
<G-vec00847-002-s479><drain.abtropfen><de> Bestehen Sie das Gemüse für 9-12 Minuten in kochendem Wasser und lassen Sie die Flüssigkeit abtropfen.
<G-vec00847-002-s479><drain.abtropfen><en> Insist the vegetables in boiling water for 9-12 minutes and drain the liquid.
<G-vec00847-002-s480><drain.abtropfen><de> Lassen Sie die Bohnen abtropfen und geben Sie sie in einen Topf mit dickem Boden.
<G-vec00847-002-s480><drain.abtropfen><en> Recipe: Drain the beans and place them in a heavy-based saucepan.
<G-vec00847-002-s481><drain.abtropfen><de> Lassen Sie sie abtropfen und braten in den Kochtopf zusammen mit der bereits angeordneten Verbindung an.
<G-vec00847-002-s481><drain.abtropfen><en> Drain and sauté them into the saucepan together with the already arranged compound.
