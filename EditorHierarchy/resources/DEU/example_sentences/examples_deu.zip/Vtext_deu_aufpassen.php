<G-vec00211-002-s022><oversee.aufpassen><de> Lehrer müssen auf viele Schüler gleichzeitig aufpassen und als Autoritätsperson fungieren, die Wissen vermittelt.
<G-vec00211-002-s022><oversee.aufpassen><en> Teachers have many students to oversee at once, and must act as authority figures who pass on knowledge.
<G-vec00303-002-s065><heed.aufpassen><de> Abenteuer aufgepasst - den besonderen Kick findest Du auf Klettersteigen, in Hochseil- und Klettergärten, bei Rafting-Touren, Tandemflügen und vielem mehr.
<G-vec00303-002-s065><heed.aufpassen><en> Adventurers take heed: you will find that special kick on the via ferrata, on the high rope courses or whilst climbing, on rafting trips, tandem flights and elsewhere besides.
