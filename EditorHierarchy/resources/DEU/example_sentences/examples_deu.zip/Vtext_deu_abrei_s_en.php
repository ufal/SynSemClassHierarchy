<G-vec00321-002-s000><yank.abreißen><de> Widerstehe dem natürlichen Drang, deine Haut von dem abzureißen, womit sie verbunden ist.
<G-vec00321-002-s000><yank.abreißen><en> Resist the natural urge to pull or yank the skin away from what it’s connected to.
<G-vec00372-002-s113><disrupt.abreißen><de> Um überzuleben, muss man sich darüber, was in der Gegenwart des Kinos geschah, damit erinnern, das Drehbuch abzureißen.
<G-vec00372-002-s113><disrupt.abreißen><en> In order to survive, we have to remember what happened in this movie, in order to disrupt the script.
<G-vec00389-002-s021><demolish.abreißen><de> Mai 1985 Innerhalb von 24 Tagen haben die US-Pioniere mit über 100 Soldaten und 60 Fahrzeugen die weiteren 21 Bauten abgerissen (Offizielle Bezeichnung: Aktion Geisterjagd) und das Gelände eingeebnet.
<G-vec00389-002-s021><demolish.abreißen><en> May 1985 Within 24 days, U.S. pioneer units with more than 100 troops and 60 vehicles demolish the remaining 21 buildings and level the area (official codename "Ghostbusters").
<G-vec00389-003-s065><tear_up.abreißen><de> Um die Gewalt auf den Straßen und grassierende Gang-Delikte einzudämmen, beschloss die Stadtverwaltung im Dezember 2004, einen kompletten Wohnblock in South Central Los Angeles zu räumen und abzureißen.
<G-vec00389-003-s065><tear_up.abreißen><en> In order to contain violence on the streets and rampant gang crime, city authorities decided in December 2004 to clear out and tear down one complete apartment block in South Central Los Angeles.
<G-vec00389-003-s066><tear_up.abreißen><de> Und viele Kinder schaffen es, das Päckchen abzureißen, das sie verhindert.
<G-vec00389-003-s066><tear_up.abreißen><en> And many children contrive to tear off the packet that prevents them.
<G-vec00389-003-s067><tear_up.abreißen><de> Als ich gerade dabei war, es abzureißen, kam ein Mann auf mich zu, der ein Fahrrad schob.
<G-vec00389-003-s067><tear_up.abreißen><en> Just as I was about to tear it down, a man walked toward me pushing a bicycle.
<G-vec00389-003-s068><tear_up.abreißen><de> Leicht abzureißen, mit Mikroperforation zwischen den Tickets.
<G-vec00389-003-s068><tear_up.abreißen><en> Easy to tear off, with micro perforation between each ticket.
<G-vec00389-003-s069><tear_up.abreißen><de> Jede Rolle ist 19mmx50m und einfach abzureißen.
<G-vec00389-003-s069><tear_up.abreißen><en> Each roll is 19mm x 50m and is easy to tear.
<G-vec00389-003-s070><tear_up.abreißen><de> Gaffer Tapes sind sehr robust und typischerweise leicht von Hand abzureißen.
<G-vec00389-003-s070><tear_up.abreißen><en> Gaffer tapes are very robust and characteristically easy to tear off by hand.
<G-vec00389-003-s071><tear_up.abreißen><de> Es gab Diskussionen über verschiedene Pläne entweder das Gebäude zu restaurieren oder es alternativ abzureißen.
<G-vec00389-003-s071><tear_up.abreißen><en> Various plans have been discussed to restore the building or, alternatively, to tear it down.
<G-vec00389-003-s072><tear_up.abreißen><de> Auch der SPD-Außenpolitiker Günter Gloser äußerte sein Unverständnis über das israelische Vorhaben, die Solar- und Windkraftanlagen abzureißen.
<G-vec00389-003-s072><tear_up.abreißen><en> Günter Gloser, Middle East expert of the Social Democrats, has also expressed his incomprehension of Israeli plans to tear down the solar plants and wind turbines.
<G-vec00595-002-s147><detach.abreißen><de> Wahrscheinlich reißt das Wasser diese Krystalle vom anstehenden Gestein ab, wie zu Frascati bei Rom.
<G-vec00595-002-s147><detach.abreißen><en> The waters most probably detach these crystals from the neighbouring rocks, as at Frascati, near Rome.
<G-vec00681-002-s025><rupture.abreißen><de> Werden diese Schäden zu groß, kann es schon bei geringen Belastungen, oder unbedeutenden Bewegungen zum vollständigen Abreißen der Sehnen kommen.
<G-vec00681-002-s025><rupture.abreißen><en> If these tendons are damaged too massively, minor loads or insignificant movements may lead to their entire rupture.
<G-vec00764-002-s000><yank_out.abreißen><de> Widerstehe dem natürlichen Drang, deine Haut von dem abzureißen, womit sie verbunden ist.
<G-vec00764-002-s000><yank_out.abreißen><en> Resist the natural urge to pull or yank the skin away from what it’s connected to.
<G-vec00949-002-s023><rip.abreißen><de> Beachten Sie, dass kein Raum völlig sicher ist, da Tornados Dächer und in einigen Fällen Böden abreißen können.
<G-vec00949-002-s023><rip.abreißen><en> Note that no room is entirely safe as tornadoes have the power to rip off roofs and in some cases floors.
<G-vec00949-002-s024><rip.abreißen><de> Mit ihrer Hilfe können Sie nicht nur die Mängel Ihrer Nägel abreißen, sondern auch ihre Länge und Form anpassen.
<G-vec00949-002-s024><rip.abreißen><en> With their help you can not only rip off the shortcomings of your nails, but also adjust their length and shape.
<G-vec00949-002-s025><rip.abreißen><de> Wenn der Filz geklebt ist, kannst du ihn einfach abreißen, aber du musst vorsichtig sein, dass du den Filz in den Löchern nicht beschädigst, außer du möchtest ihn ebenfalls erneuern.
<G-vec00949-002-s025><rip.abreißen><en> If it is glued, you can simply rip the felt off, but be careful not to damage any felt in the pockets unless you also plan on replacing those portions as well.
<G-vec00949-002-s026><rip.abreißen><de> Wir haben bewusst keinen festen Karabiner verwendet, sodass Sie im Falle einer Beschädigung der Feder die Bojen nicht abreißen müssen, um sie zu ersetzen.
<G-vec00949-002-s026><rip.abreißen><en> We have deliberately not used a fixed carabiner, so that in case of damage to its spring you do not have to rip the buoys to replace it.
<G-vec00949-002-s027><rip.abreißen><de> Eine Nacht vor dem Dreh kam er auf uns zu und fragte ob wir eine ihrer Brüste abreißen könnten.
<G-vec00949-002-s027><rip.abreißen><en> But the night before he came to us, asking if we could rip one of her tits off. Lol what?
<G-vec00949-002-s028><rip.abreißen><de> Man muss also aufpassen, dass man die Klappe nicht aus Versehen abreißt.
<G-vec00949-002-s028><rip.abreißen><en> So one has to take care of not to rip off the lid by accident.
<G-vec00949-002-s029><rip.abreißen><de> Er, der dir deinen Kopf abreißt, wenn du seinen Schlaf störst.
<G-vec00949-002-s029><rip.abreißen><en> He, who’ll rip your head off if you disturb his sleep.
<G-vec00949-002-s030><rip.abreißen><de> Es ist notwendig, dass das Kind den Pickel nicht versehentlich abreißt und die Mikrobe nicht hineinkommt.
<G-vec00949-002-s030><rip.abreißen><en> It is necessary that the child does not accidentally rip off the pimple and the microbe does not get into it.
