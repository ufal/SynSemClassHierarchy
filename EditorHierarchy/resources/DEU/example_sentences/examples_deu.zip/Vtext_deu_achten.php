<G-vec00212-002-s038><make.achten><de> Es ist in Ordnung eine Meinung zu vertreten, aber achte darauf, dass Leute wissen, dass du spekulierst.
<G-vec00212-002-s038><make.achten><en> It’s okay to express an opinion, but make sure people know you’re speculating.
<G-vec00212-002-s039><make.achten><de> Achte darauf, dass du selbst entspannt, ruhig und geduldig bist.
<G-vec00212-002-s039><make.achten><en> Make sure you are patient and relaxed as well!
<G-vec00212-002-s040><make.achten><de> Achte darauf, dass dein Nagel vor dem Auftragen sauber und trocken ist.
<G-vec00212-002-s040><make.achten><en> Make sure your nail is clean and dry before application.
<G-vec00212-002-s041><make.achten><de> Achte aber immer darauf, eine umfangreiche Karte bei dir zu haben.
<G-vec00212-002-s041><make.achten><en> Just make sure to have a comprehensive map with you at all times.
<G-vec00212-002-s042><make.achten><de> Wenn du die Pflanzen zu deinem Ökosystem hinzufügst, achte darauf, sie zu trennen und einzeln hinzuzufügen.
<G-vec00212-002-s042><make.achten><en> When you add the plants to your ecosystem, make sure to separate them and add them individually.
<G-vec00212-002-s043><make.achten><de> Achte darauf, dass du dir den Ort und die Zeit für das Frühstück, den Internetzugang und die Passwörter, die Bürobereiche, Lounges, Bars, Restaurants, Sporteinrichtungen, Wellness-Einrichtungen und dergleichen notierst, um deinen Aufenthalt angenehmer zu gestalten.
<G-vec00212-002-s043><make.achten><en> Make sure to note the location and time of breakfast, internet access and passwords, office work areas, lounges, bars, restaurants, gym and spa facilities and the like, to make your stay more comfortable.
<G-vec00212-002-s044><make.achten><de> Achte darauf, dass deinem Hund immer so viel sauberes, frisches Wasser zur Verfügung steht, wie er trinken möchte.
<G-vec00212-002-s044><make.achten><en> Make sure your dog always has access to as much clean, fresh water as it wants to drink.
<G-vec00212-002-s045><make.achten><de> Achte darauf, dass das Wasser gut abfließen kann.
<G-vec00212-002-s045><make.achten><en> Make sure the water drains well.
<G-vec00212-002-s046><make.achten><de> Achte beim Sprechen auf eine aufrechte Körperhaltung und lege deine Hände in deinen Schoß.
<G-vec00212-002-s046><make.achten><en> When you speak, make sure to keep your posture solid and keep your hands on your lap.
<G-vec00212-002-s047><make.achten><de> Achte auch unbedingt auf die Atmung deines Partners.
<G-vec00212-002-s047><make.achten><en> Make sure that you notice your partner's breathing as well.
<G-vec00212-002-s048><make.achten><de> Wenn du sie zuerst bemerkst, achte darauf, ihr zu erkennen zu geben, dass du sie bemerkt hast.
<G-vec00212-002-s048><make.achten><en> When you first see each other, make sure you acknowledge them.
<G-vec00212-002-s049><make.achten><de> Achte darauf, dass der Barcode gut lesbar und nicht verschmiert ist.
<G-vec00212-002-s049><make.achten><en> Please make sure the printout is well readable.
<G-vec00212-002-s050><make.achten><de> Achte darauf, dass es sich um reinen Joghurt handelt, den sonst wirst du Unmengen an Zucker und Lebensmittelfarbe im Haar haben – was nicht unbedingt erstrebenswert ist.
<G-vec00212-002-s050><make.achten><en> Make sure the yogurt is plain, otherwise you will end up with more sugar and food colourings in your hair — not something you want.
<G-vec00212-002-s051><make.achten><de> Achte darauf, dass es auch die richtige Person trifft.
<G-vec00212-002-s051><make.achten><en> Make sure it's the right person!
<G-vec00212-002-s052><make.achten><de> Rühre um und achte darauf, dass sich das Öl gut auf dem Reis verteilt.
<G-vec00212-002-s052><make.achten><en> Stir it to make sure all the rice is well coated with oil.
<G-vec00212-002-s053><make.achten><de> Achte darauf, dass kein anders Bluetoothgerät ungewünscht eine Verbindung zum °One aufbaut, deshalb schalte alle anderen möglichen Empfangsgeräte aus oder entferne Dich von Ihnen.
<G-vec00212-002-s053><make.achten><en> Make sure there is no other bluetooth device trying to connect to your °One. Please turn off all other possible receiving devices when pairing your sensor.
<G-vec00212-002-s054><make.achten><de> 8 Achte darauf, dass das Seil straff ist, bevor das Boot startet.
<G-vec00212-002-s054><make.achten><en> 8 Make sure the rope is tight before starting.
<G-vec00212-002-s055><make.achten><de> Achte also darauf, dass du als erstes Lied einen Song wählst, von dem du sicher bist, dass er sie packen wird, und wähle stets Songs, die gut ineinander übergehen.
<G-vec00212-002-s055><make.achten><en> Make sure that the first song grabs her attention, and that the subsequent songs flow well.
<G-vec00212-002-s056><make.achten><de> Achte darauf, dass du so parkst, dass du ausreichend Platz hast, um die hintere Tür des Autos zu öffnen und versuche so zu parken, dass die Seite des Babys sich auf der Seite der Straße befindet, die von den fahrenden Autos weg gerichtet ist.
<G-vec00212-002-s056><make.achten><en> Make sure you park so that you have enough room to open the back doors of the car, and try to park so that the baby is on the side of the road away from moving vehicles.
<G-vec00303-002-s258><heed.achten><de> Wir sähen es freilich nur zu gerne, wenn er sich auch in dieser Sache helfen ließe, aber da beissen wir auf Granit und es bleibt uns nichts anderes übrig, als seine Meinung und seinen Willen zu respektieren und zu achten.
<G-vec00303-002-s258><heed.achten><en> We admittedly would see it only gladly, if he could also be helped in this matter, but there we bite on granite and nothing else remains for us but to respect and heed his opinion and his will.
<G-vec00303-002-s019><respect.achten><de> Wir wollen uns verpflichten, der Opfer zu gedenken, die ihr Leben gelassen haben, die noch unter uns weilenden Überlebenden zu achten und das gemeinsame menschliche Streben nach gegenseitigem Verstehen und nach Gerechtigkeit zu bekräftigen.
<G-vec00303-002-s019><respect.achten><en> Our commitment must be to remember the victims who perished, respect the survivors still with us, and reaffirm humanity's common aspiration for mutual understanding and justice.
<G-vec00303-002-s020><respect.achten><de> Wir pflegen, achten und wertschätzen den Kontakt zu den bezaubernden High Class Escorts, sowie zu Office und dem IT Team.
<G-vec00303-002-s020><respect.achten><en> We maintain, respect and value the contact with the enchanting high class escorts, as well as to the office and the IT team.
<G-vec00303-002-s021><respect.achten><de> Wir achten euch nicht mehr....
<G-vec00303-002-s021><respect.achten><en> We no longer respect you....
<G-vec00303-002-s022><respect.achten><de> Ihr würdet die Mädchen, mit denen ihr Umgang habt, ehren und achten, und sie müßten sich unter keinen Umständen davor fürchten, mit euch zusammen zu sein.
<G-vec00303-002-s022><respect.achten><en> You would honor and respect the girls with whom you associate, and they would never have any fear about being alone with you in any set of circumstances.
<G-vec00303-002-s023><respect.achten><de> Maßnahmen im Rahmen des GEAS achten die Grundrechte und befolgen die in der Charta anerkannten Grundsätze(10).
<G-vec00303-002-s023><respect.achten><en> (9) Measures adopted for the purposes of the CEAS respect fundamental rights and observe the principles recognised in the Charter.
<G-vec00303-002-s024><respect.achten><de> Ja, alle bitte ich im Namen Gottes, der Menschheit neue Kriege zu ersparen, das menschliche Leben und die Familie zu achten, den Graben zwischen reich und arm zu schließen und zu verstehen, daß wir alle für alle verantwortlich sind.
<G-vec00303-002-s024><respect.achten><en> Indeed, I ask everyone, in God’s name, to save humanity from further wars, to respect human life and the family, to bridge the gap between the rich and the poor, to realize that we are all responsible for one another.
<G-vec00303-002-s025><respect.achten><de> Wir achten die geistigen Eigentumsrechte Anderer und bitten Sie, es uns gleichzutun.
<G-vec00303-002-s025><respect.achten><en> We respect the intellectual property of others, and we ask you to do the same.
<G-vec00303-002-s026><respect.achten><de> Wir achten andere Kulturen und Einstellungen.
<G-vec00303-002-s026><respect.achten><en> We respect other cultures and attitudes.
<G-vec00303-002-s027><respect.achten><de> Wohin auch immer Sie gehen, was auch immer Sie tun, bitten wir Sie die Natur zu achten.
<G-vec00303-002-s027><respect.achten><en> Where ewer you go and whatever you do, we kindly ask you to respect the nature.
<G-vec00303-002-s028><respect.achten><de> Der Verordnungsentwurf und die zugehörigen Dokumente sind im Internet verfügbar: Der Europäische Datenschutzbeauftragte (EDSB) wurde 2004 mit dem Ziel gegründet, sicherzustellen, dass die Organe und Einrichtungen der EU das Recht der Menschen auf Privatsphäre bei der Verarbeitung ihrer personenbezogenen Daten achten.
<G-vec00303-002-s028><respect.achten><en> GDPR Bodies EDPS The European Data Protection Supervisor (EDPS) was established in 2004 with the goal being to ensure that EU institutions and bodies respect people’s right to privacy when processing their personal data.
<G-vec00303-002-s029><respect.achten><de> Wir achten Ihre Zeit.
<G-vec00303-002-s029><respect.achten><en> We respect your time.
<G-vec00303-002-s030><respect.achten><de> Es bleibt aber dennoch den Menschen überlassen, mit den Lichtwesen in Verbindung zu treten durch Gedanken oder Anruf, ansonsten sie sich nicht helfend betätigen können, da sie die Willensfreiheit der Menschen achten, sie sind jedoch stets in der Nähe ihrer Schützlinge und lenken deren Gedanken in das geistige Reich, es erkennend, wenn sich der Mensch dazu hingezogen fühlt und nun die bewußte Verbindung mit dem geistigen Reich einsetzt.
<G-vec00303-002-s030><respect.achten><en> But it nevertheless remains up to men, to get in contact with the light beings, through thoughts or call, otherwise they cannot act as helpers, since they respect the freedom of will of men; they are however always near their protégés and steer their thoughts into the spiritual kingdom; recognizing when man feels drawn to it and the conscious connection with the spiritual kingdom starts.
<G-vec00303-002-s031><respect.achten><de> Unternehmen und Finanzinstitute müssen berichten, was sie tun, um Menschenrechte zu achten und zu schützen.
<G-vec00303-002-s031><respect.achten><en> Companies and financial institutions have to report what they are doing to respect and protect human rights.
<G-vec00303-002-s032><respect.achten><de> Der Aufruf, „Fremde willkommen heißen“, ihnen also Schutz und Gastfreundschaft zu gewähren, und Fremde oder Angehörige anderer Glaubensrichtungen zu achten und als gleichwertig zu behandeln, ist in allen großen Religionen tief verwurzelt.
<G-vec00303-002-s032><respect.achten><en> The call to “welcome the stranger,” through protection and hospitality, and to honor the stranger or those of other faiths with respect and equality, is deeply rooted in all major religions.
<G-vec00303-002-s033><respect.achten><de> Wie vergleichbare Unternehmen “erwartet” Aqua Star von seinen Lieferanten, dass sie die Menschenrechte achten.
<G-vec00303-002-s033><respect.achten><en> Aqua Star, like its corporate peers, "expects" its suppliers to respect human rights.
<G-vec00303-002-s034><respect.achten><de> "Unsere Strafverfolgungsbehörden – vom FBI bis zur Bundes- und Kommunalpolizei – sind verpflichtet, die Menschenrechte in unseren Gemeinden zu achten und zu wahren," sagte Steven Hawkins, der US-Chef von Amnesty International, damals.
<G-vec00303-002-s034><respect.achten><en> "Law enforcement, from the FBI to state and local police, are obligated to respect and uphold the human rights of our communities," Steven Hawkins, Amnesty's US director, said at the time.
<G-vec00303-002-s035><respect.achten><de> Mögen wir alle immer unser schönes Domizil auf diesem Planeten achten und schützen.
<G-vec00303-002-s035><respect.achten><en> May we always respect and protect our beautiful planetary abode.
<G-vec00303-002-s036><respect.achten><de> Wir achten den Schutz Ihrer personenbezogenen Daten und geben Informationen über Sie nur dann weiter, wenn gesetzliche Bestimmungen dies gebieten, Sie eingewilligt haben, oder zur Erfüllung vertraglicher Verpflichtungen.
<G-vec00303-002-s036><respect.achten><en> We respect the protection of your personal data and will only disclose information about you if required to do so by law, if you have consented to such disclosure, or to comply with a contractual obligation.
<G-vec00303-002-s037><respect.achten><de> Wir achten Ihre Würde und Ihr Selbstbestimmungsrecht.
<G-vec00303-002-s037><respect.achten><en> We respect your dignity and your right to self-determination.
<G-vec00310-002-s019><watch.achten><de> Achten Sie in den Wintermonaten und im Frühjahr auf Eis und Schnee und andere wetterbedingte Gefahren.
<G-vec00310-002-s019><watch.achten><en> During the winter months and early spring, watch out for ice and snow and other weather-related hazards.
<G-vec00310-002-s020><watch.achten><de> Wenn Sie einmal darauf achten, werden Sie schnell feststellen, dass in nahezu allen industriell bearbeiteten Nahrungsmitteln eine hohe Menge an “verstecktem” Zucker enthalten ist.
<G-vec00310-002-s020><watch.achten><en> If you watch out for it, you'll quickly find that in almost all industrially processed foods contain a high amount of "hidden" sugar.
<G-vec00310-002-s021><watch.achten><de> Um Liebe zu definieren, müssen Sie nur auf sich selbst achten.
<G-vec00310-002-s021><watch.achten><en> To define love, you just need to watch yourself.
<G-vec00310-002-s022><watch.achten><de> Im Winter muss man nur auf Frost achten, der die Pflanze abtötet.
<G-vec00310-002-s022><watch.achten><en> In winter you only have to watch out for frost, which will kill the plant.
<G-vec00310-002-s023><watch.achten><de> Achten Sie auch auf Steinschlag und halten Sie daher Abstand zu anderen Wanderern.
<G-vec00310-002-s023><watch.achten><en> Watch out for falling rocks and keep your distance from other walkers.
<G-vec00310-002-s024><watch.achten><de> Meist müssen Sie nur Ihre Ernährung verbessern, auf Stress und Raffinesse achten, aktiv Sport treiben und daran denken, sich zu entspannen oder gut zu schlafen.
<G-vec00310-002-s024><watch.achten><en> Mostly you just need to improve your diet, watch out for stress and sophistication, actively play sports and remember to relax or sleep well.
<G-vec00310-002-s025><watch.achten><de> Wir zeigen, welche Vorteile die Auslagerung mit sich bringt und worauf es dabei zu achten gilt.
<G-vec00310-002-s025><watch.achten><en> We explain the advantages of outsourcing and what to watch out for.
<G-vec00310-002-s026><watch.achten><de> Bitte achten Sie auf das Gleichgewicht bei der Beladung.
<G-vec00310-002-s026><watch.achten><en> Please watch out for the balance of the load.
<G-vec00310-002-s027><watch.achten><de> Bei unseren Produkten achten wir nicht nur auf einen hohen Qualitätsstandard, sondern bieten vor allem Produkte an, die für den jeweiligen Einsatzzweck optimiert sind und sich je nach Bedürfnis des Kunden mit Zusatzfunktionen erweitern lassen.
<G-vec00310-002-s027><watch.achten><en> With our products we do not only watch out for high standards of quality, but we offer products above all else that are optimised for the each intended application and which can be extended with auxiliary functions depending on the needs of the customer.
<G-vec00310-002-s028><watch.achten><de> Achten Sie auf Ihren Kraftstoffstand.
<G-vec00310-002-s028><watch.achten><en> Just watch out for your fuel level.
<G-vec00310-002-s029><watch.achten><de> Sie achten nur auf schwerwiegende Verhaltensverletzungen, aber wenn das passiert, dann ist es nicht nur die Unzufriedenheit.
<G-vec00310-002-s029><watch.achten><en> They only watch for serious violations of behavior, but if this happens, it's not just the discontent that matters.
<G-vec00310-002-s030><watch.achten><de> Achten Sie darauf, welchen Kunden Sie Ihr Vertrauen geben werden.
<G-vec00310-002-s030><watch.achten><en> Watch out which customer you will give you your trust.
<G-vec00310-002-s031><watch.achten><de> Das Einzige, worauf du achten solltest, ist, dass die Häufigkeit deiner "Selbstliebe" nicht dazu führt, dass du nicht mit einem*einer Partner*in zum Orgasmus kommen kannst.
<G-vec00310-002-s031><watch.achten><en> The only thing you want to watch out for is that the frequency of your “self love” isn’t making it so that you’re unable to orgasm with a partner.
<G-vec00310-002-s032><watch.achten><de> Ihr Ausritt in die Umgebung von Cusco umfasst auch einen Reiseleiter, die Ausrüstung, Maultiertreiber, die auf die Pferde achten, Snacks und Wasser sowie Hin- und Rückfahrt von Ihrem Hotel zur Ranch, wo Sie Ihren Ausritt beginnen.
<G-vec00310-002-s032><watch.achten><en> Your horseback ride near Cusco also includes a guide, horseback riding gear, muleteer to watch the horses, snacks and water and round-trip transport from your hotel to the ranch where you’ll start your ride. Horseback-riding excursion to three Inca archaeological sites from Cusco
<G-vec00310-002-s033><watch.achten><de> Achten Sie auf Schatten, die durch natürliche Lichtquellen und eingeschaltete Zimmerlampen entstehen können.
<G-vec00310-002-s033><watch.achten><en> Watch out for shadows that natural light and room lamps can cause.
<G-vec00310-002-s034><watch.achten><de> International achten wir bei der Auswahl unserer Lieferanten auf die Einhaltung von Menschenrechten, Arbeitsnormen und Umweltschutzrichtlinien.
<G-vec00310-002-s034><watch.achten><en> Internationally, we watch out for our suppliers to respect the compliance with human rights, labor standards and environmental protection policies.
<G-vec00310-002-s035><watch.achten><de> Und wenn Sie die Raumtemperatur verstellen, sollten Sie auf die beleuchteten Lüftungsdüsen achten: Sie wechseln ihren Farbton passend zur Veränderung der Temperatur – ein faszinierendes Lichterspiel.
<G-vec00310-002-s035><watch.achten><en> And when you adjust the interior temperature, you should watch the illuminated air vents: they change their colour according to the temperature change – a fascinating light display. Mercedes-Benz Intelligent Drive.
<G-vec00310-002-s036><watch.achten><de> Achten Sie auf die goldenen Münzen, die fallen, weil Sie Punkte mit ihr verdienen können.
<G-vec00310-002-s036><watch.achten><en> Watch out for the golden coins that are falling because you can earn points with her.
<G-vec00310-002-s037><watch.achten><de> Achten Sie auf das Debian tar SNAFU.
<G-vec00310-002-s037><watch.achten><en> Watch out for the Debian tar SNAFU.
<G-vec00206-003-s038><make_up.achten><de> Es ist in Ordnung eine Meinung zu vertreten, aber achte darauf, dass Leute wissen, dass du spekulierst.
<G-vec00206-003-s038><make_up.achten><en> It’s okay to express an opinion, but make sure people know you’re speculating.
<G-vec00206-003-s039><make_up.achten><de> Achte darauf, dass du selbst entspannt, ruhig und geduldig bist.
<G-vec00206-003-s039><make_up.achten><en> Make sure you are patient and relaxed as well!
<G-vec00206-003-s040><make_up.achten><de> Achte darauf, dass dein Nagel vor dem Auftragen sauber und trocken ist.
<G-vec00206-003-s040><make_up.achten><en> Make sure your nail is clean and dry before application.
<G-vec00206-003-s041><make_up.achten><de> Achte aber immer darauf, eine umfangreiche Karte bei dir zu haben.
<G-vec00206-003-s041><make_up.achten><en> Just make sure to have a comprehensive map with you at all times.
<G-vec00206-003-s042><make_up.achten><de> Wenn du die Pflanzen zu deinem Ökosystem hinzufügst, achte darauf, sie zu trennen und einzeln hinzuzufügen.
<G-vec00206-003-s042><make_up.achten><en> When you add the plants to your ecosystem, make sure to separate them and add them individually.
<G-vec00206-003-s043><make_up.achten><de> Achte darauf, dass du dir den Ort und die Zeit für das Frühstück, den Internetzugang und die Passwörter, die Bürobereiche, Lounges, Bars, Restaurants, Sporteinrichtungen, Wellness-Einrichtungen und dergleichen notierst, um deinen Aufenthalt angenehmer zu gestalten.
<G-vec00206-003-s043><make_up.achten><en> Make sure to note the location and time of breakfast, internet access and passwords, office work areas, lounges, bars, restaurants, gym and spa facilities and the like, to make your stay more comfortable.
<G-vec00206-003-s044><make_up.achten><de> Achte darauf, dass deinem Hund immer so viel sauberes, frisches Wasser zur Verfügung steht, wie er trinken möchte.
<G-vec00206-003-s044><make_up.achten><en> Make sure your dog always has access to as much clean, fresh water as it wants to drink.
<G-vec00206-003-s045><make_up.achten><de> Achte darauf, dass das Wasser gut abfließen kann.
<G-vec00206-003-s045><make_up.achten><en> Make sure the water drains well.
<G-vec00206-003-s046><make_up.achten><de> Achte beim Sprechen auf eine aufrechte Körperhaltung und lege deine Hände in deinen Schoß.
<G-vec00206-003-s046><make_up.achten><en> When you speak, make sure to keep your posture solid and keep your hands on your lap.
<G-vec00206-003-s047><make_up.achten><de> Achte auch unbedingt auf die Atmung deines Partners.
<G-vec00206-003-s047><make_up.achten><en> Make sure that you notice your partner's breathing as well.
<G-vec00206-003-s048><make_up.achten><de> Wenn du sie zuerst bemerkst, achte darauf, ihr zu erkennen zu geben, dass du sie bemerkt hast.
<G-vec00206-003-s048><make_up.achten><en> When you first see each other, make sure you acknowledge them.
<G-vec00206-003-s049><make_up.achten><de> Achte darauf, dass der Barcode gut lesbar und nicht verschmiert ist.
<G-vec00206-003-s049><make_up.achten><en> Please make sure the printout is well readable.
<G-vec00206-003-s050><make_up.achten><de> Achte darauf, dass es sich um reinen Joghurt handelt, den sonst wirst du Unmengen an Zucker und Lebensmittelfarbe im Haar haben – was nicht unbedingt erstrebenswert ist.
<G-vec00206-003-s050><make_up.achten><en> Make sure the yogurt is plain, otherwise you will end up with more sugar and food colourings in your hair — not something you want.
<G-vec00206-003-s051><make_up.achten><de> Achte darauf, dass es auch die richtige Person trifft.
<G-vec00206-003-s051><make_up.achten><en> Make sure it's the right person!
<G-vec00206-003-s052><make_up.achten><de> Rühre um und achte darauf, dass sich das Öl gut auf dem Reis verteilt.
<G-vec00206-003-s052><make_up.achten><en> Stir it to make sure all the rice is well coated with oil.
<G-vec00206-003-s053><make_up.achten><de> Achte darauf, dass kein anders Bluetoothgerät ungewünscht eine Verbindung zum °One aufbaut, deshalb schalte alle anderen möglichen Empfangsgeräte aus oder entferne Dich von Ihnen.
<G-vec00206-003-s053><make_up.achten><en> Make sure there is no other bluetooth device trying to connect to your °One. Please turn off all other possible receiving devices when pairing your sensor.
<G-vec00206-003-s054><make_up.achten><de> 8 Achte darauf, dass das Seil straff ist, bevor das Boot startet.
<G-vec00206-003-s054><make_up.achten><en> 8 Make sure the rope is tight before starting.
<G-vec00206-003-s055><make_up.achten><de> Achte also darauf, dass du als erstes Lied einen Song wählst, von dem du sicher bist, dass er sie packen wird, und wähle stets Songs, die gut ineinander übergehen.
<G-vec00206-003-s055><make_up.achten><en> Make sure that the first song grabs her attention, and that the subsequent songs flow well.
<G-vec00206-003-s056><make_up.achten><de> Achte darauf, dass du so parkst, dass du ausreichend Platz hast, um die hintere Tür des Autos zu öffnen und versuche so zu parken, dass die Seite des Babys sich auf der Seite der Straße befindet, die von den fahrenden Autos weg gerichtet ist.
<G-vec00206-003-s056><make_up.achten><en> Make sure you park so that you have enough room to open the back doors of the car, and try to park so that the baby is on the side of the road away from moving vehicles.
<G-vec00211-003-s019><watch_over.achten><de> Achten Sie in den Wintermonaten und im Frühjahr auf Eis und Schnee und andere wetterbedingte Gefahren.
<G-vec00211-003-s019><watch_over.achten><en> During the winter months and early spring, watch out for ice and snow and other weather-related hazards.
<G-vec00211-003-s020><watch_over.achten><de> Wenn Sie einmal darauf achten, werden Sie schnell feststellen, dass in nahezu allen industriell bearbeiteten Nahrungsmitteln eine hohe Menge an “verstecktem” Zucker enthalten ist.
<G-vec00211-003-s020><watch_over.achten><en> If you watch out for it, you'll quickly find that in almost all industrially processed foods contain a high amount of "hidden" sugar.
<G-vec00211-003-s021><watch_over.achten><de> Um Liebe zu definieren, müssen Sie nur auf sich selbst achten.
<G-vec00211-003-s021><watch_over.achten><en> To define love, you just need to watch yourself.
<G-vec00211-003-s022><watch_over.achten><de> Im Winter muss man nur auf Frost achten, der die Pflanze abtötet.
<G-vec00211-003-s022><watch_over.achten><en> In winter you only have to watch out for frost, which will kill the plant.
<G-vec00211-003-s023><watch_over.achten><de> Achten Sie auch auf Steinschlag und halten Sie daher Abstand zu anderen Wanderern.
<G-vec00211-003-s023><watch_over.achten><en> Watch out for falling rocks and keep your distance from other walkers.
<G-vec00211-003-s024><watch_over.achten><de> Meist müssen Sie nur Ihre Ernährung verbessern, auf Stress und Raffinesse achten, aktiv Sport treiben und daran denken, sich zu entspannen oder gut zu schlafen.
<G-vec00211-003-s024><watch_over.achten><en> Mostly you just need to improve your diet, watch out for stress and sophistication, actively play sports and remember to relax or sleep well.
<G-vec00211-003-s025><watch_over.achten><de> Wir zeigen, welche Vorteile die Auslagerung mit sich bringt und worauf es dabei zu achten gilt.
<G-vec00211-003-s025><watch_over.achten><en> We explain the advantages of outsourcing and what to watch out for.
<G-vec00211-003-s026><watch_over.achten><de> Bitte achten Sie auf das Gleichgewicht bei der Beladung.
<G-vec00211-003-s026><watch_over.achten><en> Please watch out for the balance of the load.
<G-vec00211-003-s027><watch_over.achten><de> Bei unseren Produkten achten wir nicht nur auf einen hohen Qualitätsstandard, sondern bieten vor allem Produkte an, die für den jeweiligen Einsatzzweck optimiert sind und sich je nach Bedürfnis des Kunden mit Zusatzfunktionen erweitern lassen.
<G-vec00211-003-s027><watch_over.achten><en> With our products we do not only watch out for high standards of quality, but we offer products above all else that are optimised for the each intended application and which can be extended with auxiliary functions depending on the needs of the customer.
<G-vec00211-003-s028><watch_over.achten><de> Achten Sie auf Ihren Kraftstoffstand.
<G-vec00211-003-s028><watch_over.achten><en> Just watch out for your fuel level.
<G-vec00211-003-s029><watch_over.achten><de> Sie achten nur auf schwerwiegende Verhaltensverletzungen, aber wenn das passiert, dann ist es nicht nur die Unzufriedenheit.
<G-vec00211-003-s029><watch_over.achten><en> They only watch for serious violations of behavior, but if this happens, it's not just the discontent that matters.
<G-vec00211-003-s030><watch_over.achten><de> Achten Sie darauf, welchen Kunden Sie Ihr Vertrauen geben werden.
<G-vec00211-003-s030><watch_over.achten><en> Watch out which customer you will give you your trust.
<G-vec00211-003-s031><watch_over.achten><de> Das Einzige, worauf du achten solltest, ist, dass die Häufigkeit deiner "Selbstliebe" nicht dazu führt, dass du nicht mit einem*einer Partner*in zum Orgasmus kommen kannst.
<G-vec00211-003-s031><watch_over.achten><en> The only thing you want to watch out for is that the frequency of your “self love” isn’t making it so that you’re unable to orgasm with a partner.
<G-vec00211-003-s032><watch_over.achten><de> Ihr Ausritt in die Umgebung von Cusco umfasst auch einen Reiseleiter, die Ausrüstung, Maultiertreiber, die auf die Pferde achten, Snacks und Wasser sowie Hin- und Rückfahrt von Ihrem Hotel zur Ranch, wo Sie Ihren Ausritt beginnen.
<G-vec00211-003-s032><watch_over.achten><en> Your horseback ride near Cusco also includes a guide, horseback riding gear, muleteer to watch the horses, snacks and water and round-trip transport from your hotel to the ranch where you’ll start your ride. Horseback-riding excursion to three Inca archaeological sites from Cusco
<G-vec00211-003-s033><watch_over.achten><de> Achten Sie auf Schatten, die durch natürliche Lichtquellen und eingeschaltete Zimmerlampen entstehen können.
<G-vec00211-003-s033><watch_over.achten><en> Watch out for shadows that natural light and room lamps can cause.
<G-vec00211-003-s034><watch_over.achten><de> International achten wir bei der Auswahl unserer Lieferanten auf die Einhaltung von Menschenrechten, Arbeitsnormen und Umweltschutzrichtlinien.
<G-vec00211-003-s034><watch_over.achten><en> Internationally, we watch out for our suppliers to respect the compliance with human rights, labor standards and environmental protection policies.
<G-vec00211-003-s035><watch_over.achten><de> Und wenn Sie die Raumtemperatur verstellen, sollten Sie auf die beleuchteten Lüftungsdüsen achten: Sie wechseln ihren Farbton passend zur Veränderung der Temperatur – ein faszinierendes Lichterspiel.
<G-vec00211-003-s035><watch_over.achten><en> And when you adjust the interior temperature, you should watch the illuminated air vents: they change their colour according to the temperature change – a fascinating light display. Mercedes-Benz Intelligent Drive.
<G-vec00211-003-s036><watch_over.achten><de> Achten Sie auf die goldenen Münzen, die fallen, weil Sie Punkte mit ihr verdienen können.
<G-vec00211-003-s036><watch_over.achten><en> Watch out for the golden coins that are falling because you can earn points with her.
<G-vec00211-003-s037><watch_over.achten><de> Achten Sie auf das Debian tar SNAFU.
<G-vec00211-003-s037><watch_over.achten><en> Watch out for the Debian tar SNAFU.
<G-vec00511-002-s019><ensure.achten><de> Bei einer tatsächlichen Umsetzung der Empfehlungen für eine Musterklausel zum Schutz öffentlicher Dienstleistungen bleibt es wichtig darauf zu achten, dass diese alle Vertragsbestimmungen derartiger Abkommen umfasst.
<G-vec00511-002-s019><ensure.achten><en> Concerning the actual implementation of recommendations for a model clause for the protection of public services, it remains vital to ensure that this will apply to all contractual provisions of such agreements.
<G-vec00511-002-s020><ensure.achten><de> Es ist darauf zu achten, dass der zu verwendende PC diese Frame Work Updates installiert hat.
<G-vec00511-002-s020><ensure.achten><en> It is important to ensure that the PC has installed to use this frame work updates.
<G-vec00511-002-s021><ensure.achten><de> Als sie sich entschloss, Blütenessenzen selbst zu entwickeln, war es ihr wichtig, auf besondere Qualitätskriterien zu achten.
<G-vec00511-002-s021><ensure.achten><en> When she decided to develop her own flower essences, it was important to her to ensure that special criteria for quality were implemented.
<G-vec00511-002-s022><ensure.achten><de> Hierbei ist darauf zu achten, dass Sie die SIM-Karte mit der Cloud verbinden, um diese nutzen zu können.
<G-vec00511-002-s022><ensure.achten><en> It is important to ensure that you connect the SIM card to the cloud in order to use it.
<G-vec00511-002-s023><ensure.achten><de> Es ist wichtig die Bestands- und Neubauwand zu trennen, und auf eine durchgängige Fuge zwischen den benachbarten Wänden zu achten.
<G-vec00511-002-s023><ensure.achten><en> It is important to isolate the existing wall from the new one and to ensure that there is a continuous joint between the neighbouring walls.
<G-vec00511-002-s024><ensure.achten><de> Wir achten im gesamten Produktionsprozess auf die Unbedenklichkeit der eingesetzten Materialien und Verfahren.
<G-vec00511-002-s024><ensure.achten><en> We ensure that the materials and procedures used are harmless throughout the entire production process.
<G-vec00511-002-s025><ensure.achten><de> Aus diesem Grund achten wir und unser Datenschutzbeauftragter auf die Einhaltung der datenschutzrechtlichen Vorgaben.
<G-vec00511-002-s025><ensure.achten><en> This is why both we and our data protection officer ensure compliance with the stipulations under data protection legislation.
<G-vec00511-002-s026><ensure.achten><de> Daher achten wir bei der Herstellung und beim Einbau unserer Selfstorage-Produkte und Lösungen streng darauf, die örtlich geltenden Arbeits- und Unfallschutzrichtlinien einzuhalten.
<G-vec00511-002-s026><ensure.achten><en> So, where we are responsible for the fit-out or construction of our self-storage products and solutions, we ensure we meet local health and safety laws.
<G-vec00511-002-s027><ensure.achten><de> Schließlich ist auf eine genügende Aufnahme von fettlöslichen Vitaminen (A, D, E, K) zu achten.
<G-vec00511-002-s027><ensure.achten><en> It is also vital to ensure the patient takes a sufficient amount of fat-soluble vitamins (A, D, E K).
<G-vec00511-002-s028><ensure.achten><de> Dadurch ist darauf zu achten, dass die zur Anwendung kommenden Beschichtungsstoffe alkalibeständig sein müssen.
<G-vec00511-002-s028><ensure.achten><en> Consequently, it is important to ensure that the coating materials to be applied are alkaline resistant.
<G-vec00511-002-s029><ensure.achten><de> Unsere Aufgabe besteht darin, auf jede Stufe zu achten: die Weintrauben in dem Keller verfolgen, die Gärung (Maceration mit den Schalen 10 – 12 Tage lang) kontrollieren, die Evolution, die die Apfelsäure in den zarteren Milchsäuren umändert.
<G-vec00511-002-s029><ensure.achten><en> Our job is ensure care is taken at every step: to follow the grapes in the cellar, check the fermentation (maceration on the skins for at least 10 to 12 days), the evolution of malolactic fermentation that converts the sharper- tasting malic acid into the softer lactic acid.
<G-vec00511-002-s030><ensure.achten><de> Wir empfehlen bei Seitenkoffern auf eine gleichmäßige Gewichtsverteilung beim Beladen zu achten und die Gegenstände mit mehr Gewicht möglichst nah am Rumpf zu fixieren.
<G-vec00511-002-s030><ensure.achten><en> Loading with panniers we recommend to ensure an equal distribution of weight and a fixture of heavy items as close to the body as possible.
<G-vec00511-002-s031><ensure.achten><de> Achten Sie immer auf den ordnungsgemäßen und gefahrenfreien Stillstand des Fahrzeugs - um Schäden an sich und anderen zu vermeiden.
<G-vec00511-002-s031><ensure.achten><en> Always ensure that the vehicle is stopped properly and safely to avoid injury to yourself and others.
<G-vec00511-002-s032><ensure.achten><de> Bei der Montage der Spannrolle darauf achten, dass die Gabel der Spannrolle mittig über dem Nocken verbaut wird (Abb.
<G-vec00511-002-s032><ensure.achten><en> When fitting tensioning pulley, ensure that tensioning pulley fork is installed centrally above cam (Fig.
<G-vec00511-002-s033><ensure.achten><de> Wie bei all unseren Produkten achten wir auch hier auf transparente und faire Produktion, bei der niemand benachteiligt wird.
<G-vec00511-002-s033><ensure.achten><en> As with all our products, we rely on transparent and fair manufacturing processes, to ensure no one involved in the making of the garments is being exploited.
<G-vec00511-002-s034><ensure.achten><de> Den Trainingsumfang solltest Du hierbei nur langsam steigern und auf angemessene Pausen achten.
<G-vec00511-002-s034><ensure.achten><en> Only increase the complexity of your training slowly and ensure you take appropriate breaks.
<G-vec00511-002-s035><ensure.achten><de> Bei allen Projekten achten wir auf einen treuhänderischen und nachhaltigen Umgang mit den vorhandenen Ressourcen.
<G-vec00511-002-s035><ensure.achten><en> In the context of executing all of our projects, we ensure a responsible and sustainable use of the available resources.
<G-vec00511-002-s036><ensure.achten><de> Daher achten wir und unser Datenschutzbeauftragter auf die Einhaltung der datenschutzrechtlichen Vorgaben, insbesondere der geltenden europäischen Datenschutzgrundverordnung (DSGVO) und des Bundesdatenschutzgesetzes (BDSG-neu).
<G-vec00511-002-s036><ensure.achten><en> Therefore, we and our data protection officer ensure compliance with data protection regulations, in particular the applicable General Data Protection Regulation (GDPR) in the EU and the German Federal Data Protection Act (BDSG-neu).
<G-vec00511-002-s037><ensure.achten><de> Darum empfehle ich dringend, in den Liturgien mit großer Aufmerksamkeit darauf zu achten, daß das Wort Gottes von gut vorbereiteten Lektoren vorgetragen wird.
<G-vec00511-002-s037><ensure.achten><en> Consequently I urge that every effort be made to ensure that the liturgical proclamation of the word of God is entrusted to well- prepared readers.
<G-vec00574-002-s019><care.achten><de> Für die Synchronisation der Inhalte des iPod oder um die Software zu aktualisieren, müssen Sie nur das Gerät an das System anschließen und lassen Sie den iTunes Media Player auf den Rest achten.
<G-vec00574-002-s019><care.achten><en> For synchronizing the content of iPod or to update the software, you just need to connect the device to the system and let iTunes media player take care of the rest.
<G-vec00574-002-s020><care.achten><de> Es lohnt sich, auf zusätzliche Desktop-Beleuchtung zu achten.
<G-vec00574-002-s020><care.achten><en> It is worth taking care of additional desktop lighting.
<G-vec00574-002-s021><care.achten><de> Nun, um die Nase nachts wieder frisch zu halten, achten Sie auf die gute Luftbefeuchtung.
<G-vec00574-002-s021><care.achten><en> Well, in order to keep the nose fresh again at night, take care of the good air humidification.
<G-vec00574-002-s022><care.achten><de> Zusätzlich zu einer ruhigen Umgebung im Schlafzimmer müssen Sie auf die Qualität der Gartenarbeit achten.
<G-vec00574-002-s022><care.achten><en> In addition to creating a calm environment in the bedroom, you need to take care of its quality gardening.
<G-vec00574-002-s023><care.achten><de> Ich dachte, da mir der Meister das Leben gegeben hat, sollte ich den Meister bitten mir zu helfen, auf mein Leben zu achten.
<G-vec00574-002-s023><care.achten><en> I thought since Master has given me life, I should ask him to help take care of it.
<G-vec00574-002-s024><care.achten><de> Erfahren Sie, was Sie tun können, um besser auf Sie beide zu achten.
<G-vec00574-002-s024><care.achten><en> Learn what you can do to take better care of both of you.
<G-vec00574-002-s025><care.achten><de> Ebenso gibt es Granulozyten, die nicht auf ihre Gesundheit achten müssen, wenn sie zerstörerische Methoden gegen verbrauchte Mikroben wählen.
<G-vec00574-002-s025><care.achten><en> Likewise, there are granulocytes that do not need to take care of their health when choosing destructive methods against microbes that are consumed.
<G-vec00574-002-s026><care.achten><de> Jeder muss nicht nur auf seine Sicherheit, sondern auch auf die seiner Kolleginnen und Kollegen, Besucher und Mitarbeiterinnen und Mitarbeiter anderer Firmen achten.
<G-vec00574-002-s026><care.achten><en> Every single person has to take care not only of his own safety but for the safety of his / her colleagues, visitors as well as employees of other companies.
<G-vec00574-002-s027><care.achten><de> Aus Überzeugung verwenden wir unverfälschte und saisonale BIO-Produkte aus der Region, unterstützen die heimische Landwirtschaft und achten auf einen verantwortungsbewussten und respektvollen Umgang im Einklang mit der Natur.
<G-vec00574-002-s027><care.achten><en> Out of principle, we use pure and seasonal organic products from the region, whilst supporting the local economy and taking care to work responsibly and respectfully in harmony with nature.
<G-vec00574-002-s028><care.achten><de> Beim Schach spielen ist darauf zu achten, dass der Anwender den Computer lediglich zum Übermitteln der Züge benutzt.
<G-vec00574-002-s028><care.achten><en> When playing chess one has to take care that the user only uses the computer to transmit the moves.
<G-vec00574-002-s029><care.achten><de> Man würde lügen zu behaupten, dass wir bei der Optimierung der Qualität nicht auf den Preis achten.
<G-vec00574-002-s029><care.achten><en> One would be lying to say we don't care about prices, while optimizing our standards for quality.
<G-vec00574-002-s030><care.achten><de> Ich erkläre dir, worauf du achten musst.
<G-vec00574-002-s030><care.achten><en> I tell you what to take care of.
<G-vec00574-002-s031><care.achten><de> Konsumenten würden mehr auf Abfallvermeidung achten und bevorzugten natürliche, lokale oder saisonale Produkte, wie Euromonitor betont.
<G-vec00574-002-s031><care.achten><en> More consumers will care about cutting down on waste and will prefer natural, local or seasonal products.
<G-vec00574-002-s032><care.achten><de> Wir begleiten die Realisation des Vorhabens mit den Projektbeteiligten und achten auf Zeitpläne bei strikter Kostenorientierung.
<G-vec00574-002-s032><care.achten><en> We accompany the realization of your plans with the project participants and take care of schedules at a strict cost orientation.
<G-vec00574-002-s033><care.achten><de> Hinweis zur Auswahl des richtigen Titels: Bei der Auswahl des Titels ist auf eine sinnvolle Benennung zu achten.
<G-vec00574-002-s033><care.achten><en> Note to select the correct title: When selecting the title, you should take care of an exact naming.
<G-vec00574-002-s034><care.achten><de> Generell hat ein Halter auf die Fellpflege und Hygiene seines Hundes zu achten.
<G-vec00574-002-s034><care.achten><en> In general, the owner should pay attention to the care of the coat and the hygiene of the dog.
<G-vec00574-002-s035><care.achten><de> Beim Kauf bitte auf die Art des zu reparierenden Zeltmaterials (Silikon- oder PU-Beschichtung) achten.
<G-vec00574-002-s035><care.achten><en> Please take care to select the appropriate sealant for your tent material (i.e. silicone or PU coating).
<G-vec00574-002-s036><care.achten><de> Darum möchte ich meine Stimme erheben und alle auffordern, die Kinder zu beschützen und auf sie zu achten, damit ihr Lächeln nie vergehe, sie in Frieden leben und vertrauensvoll in die Zukunft blicken können.
<G-vec00574-002-s036><care.achten><en> This is why I wish to lift up my voice, inviting everyone to protect and to care for children, so that nothing may extinguish their smile, but that they may live in peace and look to the future with confidence.
<G-vec00574-002-s037><care.achten><de> Auch wenn es Wichtigeres gibt, unterstützt eine gesunde, strahlende Haut das Selbstvertrauen und vermittelt anderen, dass du auf dich achten kannst.
<G-vec00574-002-s037><care.achten><en> While it's not the most important thing in the world, healthy glowing skin helps your self-confidence and lets other people know that you can take care of yourself.
<G-vec00859-002-s038><pay.achten><de> Hier solltest Du nur darauf achten ob es Dir liegt und Du bei Problemen auch Unterstützung bekommst.
<G-vec00859-002-s038><pay.achten><en> Here you should only pay attention to whether it is up to you and you get support in case of problems.
<G-vec00859-002-s039><pay.achten><de> Aber auch hier gilt, wie so oft: Ausnahmen bestätigen die Regel, achten Sie deshalb bitte auf die genaue Kennzeichnung im Katalog und im Webshop.
<G-vec00859-002-s039><pay.achten><en> But in this case, as so often, it's important to remember: exceptions confirm the rule, so please pay attention to the information in the catalogue and in the webshop.
<G-vec00859-002-s040><pay.achten><de> Deshalb achten wir bei der Auswahl unserer direkten Geschäftspartner darauf, dass sie die Gesetze einhalten, ethische Grundsätze befolgen und in diesem Sinne auch in die Zulieferkette wirken.
<G-vec00859-002-s040><pay.achten><en> When selecting our direct business partners, we therefore pay close attention that they comply with the law, follow ethical principles and do the same themselves towards other partners in the supply chain.
<G-vec00859-002-s041><pay.achten><de> Insbesondere achten wir dabei auf die Grundsätze der Datenvermeidung und der Datensparsamkeit.
<G-vec00859-002-s041><pay.achten><en> We pay particular attention to the principles of data avoidance and data minimisation.
<G-vec00859-002-s042><pay.achten><de> Achten Sie unterwegs auf natürliche Sehenswürdigkeiten, welche Sie umgeben, damit Sie diese wiedererkennen können im Falle, dass Sie Hilfe beim Finden des Wegs benötigen.
<G-vec00859-002-s042><pay.achten><en> Pay attention to natural landmarks around you as you walk past them, so you can recognize them if you need help finding your way.
<G-vec00859-002-s043><pay.achten><de> Wenn der Raum eine hohe Luftfeuchtigkeit hat, ist zusätzlich auf die Entlastung der Fliese zu achten.
<G-vec00859-002-s043><pay.achten><en> If the room has a high humidity, it is additionally necessary to pay attention to the relief of the tile.
<G-vec00859-002-s044><pay.achten><de> Es ist wichtig, auch auf die Eingliederung und Einbeziehung behinderter Menschen in die liturgischen Versammlungen zu achten: In der Gemeinde zu sein und einen eigenen Beitrag zum liturgischen Handeln zu leisten durch Gesang und bedeutsame Gesten, trägt dazu bei, das Zugehörigkeitsgefühl eines jeden zu unterstützen.
<G-vec00859-002-s044><pay.achten><en> "It is important also to pay attention to the location and participation of the disabled in liturgical assemblies: to be in the assembly and to play a role in the liturgical action with song and meaningful gestures contributes to supporting each person's sense of belonging.
<G-vec00859-002-s045><pay.achten><de> Daher denke ich, dass jeder Praktizierende auf das Aussenden der Aufrichtigen Gedanken besonders achten sollte.
<G-vec00859-002-s045><pay.achten><en> Therefore, I think that every practitioner should pay great attention to sending forth righteous thoughts.
<G-vec00859-002-s046><pay.achten><de> Sie sollten schon dieses geflügelte Wort vergessen und auf Anwendungen wie Bitdefender Virus Scanner achten.
<G-vec00859-002-s046><pay.achten><en> You should forget about this statement and pay attention to tools like Bitdefender Virus Scanner.
<G-vec00859-002-s047><pay.achten><de> Natürlich beraten wir Sie vor Ihrem Projekt umfassend, achten auf Ihre individuellen Wünsche und Anforderungen und finden immer die passende Lösung für Sie.
<G-vec00859-002-s047><pay.achten><en> Of course, we advise you on your project comprehensively, we pay attention to your individual wishes and requirements and always find the best solutions for you.
<G-vec00859-002-s048><pay.achten><de> Um die Befestigung richtig zu wählen, müssen Sie auf solche Momente achten: die Form des Gesims, die Dichte des Materials und das Gesamtgewicht des Vorhangs, die Gestaltung des Raumes.
<G-vec00859-002-s048><pay.achten><en> To properly choose the fastening, you need to pay attention to such moments: the shape of the cornice, the density of the material and the total weight of the curtain, the design of the room.
<G-vec00859-002-s049><pay.achten><de> Daher ist es wichtig, auf die Fehler des Geschmacks zu achten.
<G-vec00859-002-s049><pay.achten><en> Therefore, it is important to pay attention to the faults of taste.
<G-vec00859-002-s050><pay.achten><de> Auch auf Bruttobeitrag achten.
<G-vec00859-002-s050><pay.achten><en> Also pay attention to gross contribution.
<G-vec00859-002-s051><pay.achten><de> Und auch hier bleiben wir unserer Philosophie treu und achten besonders auf eine nachhaltige, ökologische und sozial faire Erzeugung der duftenden Rohstoffe.
<G-vec00859-002-s051><pay.achten><en> And here, too, we remain true to our philosophy and pay attention to sustainable, ecological and socially fair production of their fragrant raw materials.
<G-vec00859-002-s052><pay.achten><de> Ich hoffe, ich konnte Dir damit ein paar Anregungen geben, wie auch Du ein wenig auf Deinen Müll- und damit Plastikberg achten könntest.
<G-vec00859-002-s052><pay.achten><en> I hope I could provide you some suggestions how to pay attention to your pile of rubbish.
<G-vec00859-002-s053><pay.achten><de> Wir achten nicht nur auf die Einhaltung der gesetzlichen Bestimmungen, sondern legen auch größten Wert auf Wahrung des technischen Zustandes unserer Schiffe und auf die Sicherheit beim Tauchen.
<G-vec00859-002-s053><pay.achten><en> We do not only pay attention to the compliance with the legal regulations, but also attach great importance to maintaining the technical condition and the safety of diving.
<G-vec00859-002-s054><pay.achten><de> Die Menschen achten aber mehr auf den Schein, auf das Unechte, als auf die Wahrheit, die in Mir ihren Ausgang hat.... eben weil sie ohne Liebe sind....
<G-vec00859-002-s054><pay.achten><en> But people pay more attention to appearances, to imitations, than to the truth which originates from Me.... precisely because they lack love....
<G-vec00859-002-s055><pay.achten><de> Hier empfehlen Experten, darauf zu achten, wie Sie schwitzen.
<G-vec00859-002-s055><pay.achten><en> Here experts advise to pay attention to how you sweat.
<G-vec00859-002-s056><pay.achten><de> Damit die „Einzelspalten-Formatierung“ richtig gut funktioniert, musst Du auf ein paar Dinge achten.
<G-vec00859-002-s056><pay.achten><en> Of course, if you want ‘single column formatting’ to work exceptionally well, you need to pay attention to a few other things.
<G-vec00859-002-s076><pay.achten><de> RICH&ROYAL achtet stets auf eine perfekte Passform und hochwertige Materialen.
<G-vec00859-002-s076><pay.achten><en> RICH&ROYAL always pay attention to perfect fit and high-quality materials.
<G-vec00859-002-s077><pay.achten><de> Sie achtet genau darauf, was das Kind scheint zu sein, zu erleben, und Sie reflektieren es zurück zu dem Kind in einer Weise, die bestätigen, was das Kind fühlt.
<G-vec00859-002-s077><pay.achten><en> They pay close attention to what the child seems to be experiencing, and they reflect it back to the child in ways that validate what the child is feeling.
<G-vec00859-002-s078><pay.achten><de> Wenn Ihr plant, Android vom ersten Tag an zu unterstützen und auf die Plattform-Regeln achtet, werdet Ihr gute Erfahrungen machen.
<G-vec00859-002-s078><pay.achten><en> If you plan to support Android from day one, and pay attention to the norms of that platform, your experience will be greatly improved.
<G-vec00859-002-s079><pay.achten><de> Insgesamt erwarten wir 11 Sonnenstunden, also achtet auf entsprechenden Sonnenschutz.
<G-vec00859-002-s079><pay.achten><en> We will have 11 hours of sunshine, so pay attention to appropriate sun protection.
<G-vec00859-002-s080><pay.achten><de> Achtet mal darauf, was übersättigt wird.
<G-vec00859-002-s080><pay.achten><en> Pay attention to what’s being over saturated.
<G-vec00859-002-s081><pay.achten><de> Wichtig ist einfach nur, dass man einigermaßen auf seine Kalorien achtet.
<G-vec00859-002-s081><pay.achten><en> What is important is simply that you pay some attention to your calories.
<G-vec00859-002-s082><pay.achten><de> Seid vorsichtig und achtet auf Eure Kinder und Hunde, denn Autobahnen, Bundesstraße, Straßenbahn und Fahrradweg sind in unmittelbarer Nähe.
<G-vec00859-002-s082><pay.achten><en> Be careful and pay attention to your children and dogs, because motorways, federal highways, streetcars and cycle tracks are near by.
<G-vec00859-002-s083><pay.achten><de> Wir stimmen überein mit der Synthese, die P. Alexandre Awi bezeichnet: “JUMAS ist Kirche – achtet auf eure Botschaften in den Medien”.
<G-vec00859-002-s083><pay.achten><en> We agreed to center on Father Alexandre Awi’s text, “Jumas is Church – Pay attention to posts on social networks”.
<G-vec00859-002-s084><pay.achten><de> Achtet immer darauf, wenn Ihr Eure Produktionsketten anpasst.
<G-vec00859-002-s084><pay.achten><en> Always pay attention when you are adjusting your production chains.
<G-vec00859-002-s085><pay.achten><de> Dabei ist sich die Band durchaus bewusst, dass sich das Rad in der Zwischenzeit bewegt hat, und achtet darauf, nicht in die Falle zu tappen, die den Rockjazz einst zur Strecke brachte.
<G-vec00859-002-s085><pay.achten><en> In doing so, the band is completely aware, that some time has passed though and pay great attention not to fall into the trap that once took down rock-jazz.
<G-vec00859-002-s086><pay.achten><de> An allen Bühnen gibt es einen Infostand mit einer Hostess, die Sie und Ihre Gäste empfängt, Ihre Fragen beantwortet, Ihnen bei Auf- und Ab- bau behilflich ist und auf die Einhaltung der Zeit achtet.
<G-vec00859-002-s086><pay.achten><en> There is an info counter at every stage with a host or hostess who will welcome your guests, answer questions, help out with setting up/clearing the stage, and pay attention to timing.
<G-vec00859-002-s087><pay.achten><de> Ihr Menschen, achtet alles dessen und erwartet von der Zukunft keine Besserung eurer irdischen Lage, denn es wäre dies kein gutes Zeichen für euch, es sei denn, ihr stehet schon in Meinem Lager und erlebet bewußt die letzte Zeit....
<G-vec00859-002-s087><pay.achten><en> Pay attention to all this, you humans, and don't expect a future improvement of your earthly situation, for it would not be a sign for you, unless you are already in My camp and experience the last days consciously....
<G-vec00859-002-s088><pay.achten><de> Achtet auf den Fluss der Energie und seid dankbar, und unsere Macht des Manifestierens wird zunehmen.
<G-vec00859-002-s088><pay.achten><en> Pay attention to the flow of energy and have gratitude and our power of manifest will increase.
<G-vec00859-002-s089><pay.achten><de> Etwa die Hälfte der Kunden (49 Prozent) achtet mehr auf die Preise, wenn nur mit Bargeld bezahlt werden kann – die Tendenz geht zu höheren Bons, wenn Kartenzahlungen akzeptiert werden: 43 Prozent der befragten Unternehmen verzeichnen durch bargeldlose Zahlungen einen Anstieg bei Bon- und Warenkorbhöhen.
<G-vec00859-002-s089><pay.achten><en> Around half of customers (49%) pay more attention to prices when they can pay only with cash; customers tend to have higher bills if card payments are accepted. Of the businesses surveyed, 43% report an increase in bill size and shopping basket amounts through cashless payments.
<G-vec00859-002-s090><pay.achten><de> Er hat daher die folgende Empfehlung für andere Flüchtlinge: „Achtet nicht darauf, was die Deutschen im Biergarten trinken, sondern schaut darauf, welche Berufe sie ausüben.
<G-vec00859-002-s090><pay.achten><en> “Pay no attention to what the Germans drink in the beer gardens, but learn about the professions in which they are working.
<G-vec00859-002-s091><pay.achten><de> Nachdem das Himmelsauge eines Kindes geöffnet worden ist, achtet es normalerweise nicht darauf.
<G-vec00859-002-s091><pay.achten><en> Often after a child’s Third Eye opens he doesn’t pay attention to it.
<G-vec00859-002-s092><pay.achten><de> Achtet vor Allem auf den Teil mit den Gras- und Wasser-Effekten, denn sie sind am schwierigsten zu bewältigen.
<G-vec00859-002-s092><pay.achten><en> Pay extra attention to the sections on grass and water effects, as those are the skills to master.
<G-vec00859-002-s093><pay.achten><de> Beachten Sie, dass die Preise von PrestaShop gestellt werden: das PrestaShop-Team achtet auf korrekte Preise in dieser Datei, aber möglicherweise weichen diese geringfügig von den tatsächlichen ab, weil diese in kurzer Zeit stark schwanken können.
<G-vec00859-002-s093><pay.achten><en> Note that the rates are provided as-is: the PrestaShop team does pay attention to have correct rates in these file, but might slightly differ from the actual ones, if only because these rates can fluctuate greatly in a short time.
<G-vec00859-002-s094><pay.achten><de> Klar: es gibt qualitative Unterschiede, diese sind aber meistens so subtil, dass sie nur derjenige herausfinden dürfte, der hochkonzentriert selbst auf flüchtigste Nuancen achtet.
<G-vec00859-002-s094><pay.achten><en> Of course: there are qualitative differences, but these are mostly so subtle that only those who highly concentrate and pay attention to even the most volatile nuances will find them.
