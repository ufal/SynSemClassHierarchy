<G-vec00847-002-s234><drain.abschütten><de> Die geschälten Kartoffeln weich kochen, abschütten, fein durchdrücken, Eigelb, Sahne zugeben und glatt rühren.
<G-vec00847-002-s234><drain.abschütten><en> Peel and boil the potatoes, drain, pass through a sieve, add egg yolks and cream and stir to a smooth paste.
<G-vec00847-002-s235><drain.abschütten><de> Die Spaghetti in Salzwasser bissfest garen, abschütten, kalt abschrecken und in die Mulden eines leicht gefetteten Muffinblechs verteilen.
<G-vec00847-002-s235><drain.abschütten><en> Cook the spaghetti in salted water until firm to the bite, drain, rinse cold and arrange in the moulds of a slightly greased muffin tin.
<G-vec00847-002-s236><drain.abschütten><de> Das Wasser abschütten und die Kartoffel mit einem Kartoffelstampfer stampfen (für dieses Rezept benötigst du 120 g Kartoffelpüree).
<G-vec00847-002-s236><drain.abschütten><en> Drain the water and mash the potato with a potato masher (you will need 1/2 cup/120 g of mashed potatoes for this recipe).
<G-vec00847-002-s237><drain.abschütten><de> Große Kartoffeln kannst Du zuerst schälen, je nach Größe halbieren oder in Viertel schneiden, dann in Salzwasser gar kochen und abschütten.
<G-vec00847-002-s237><drain.abschütten><en> You can peel large potatoes first, cut them in half or quarters depending on their size, then cook them in salted water and drain them.
<G-vec00847-002-s238><drain.abschütten><de> Die gegarten Kartoffeln abschütten und fein stampfen, mit Thymian, Salz, Pfeffer, Muskat, Olivenöl (anstelle von Sahne) und etwas Butter abschmecken und verfeinern.
<G-vec00847-002-s238><drain.abschütten><en> Drain the cooked potatoes and mash them, than season the mashed potatoes with thyme, salt, pepper, nutmeg and olive oil.
<G-vec00847-002-s239><drain.abschütten><de> Wenn die Graupen gar sind, abschütten und etwas abkühlen lassen.
<G-vec00847-002-s239><drain.abschütten><en> When the grains are cooked, drain and let cool slightly.
<G-vec00847-002-s240><drain.abschütten><de> Die Pasta abschütten und zum Pesto in die Schüssel geben, gut mischen.
<G-vec00847-002-s240><drain.abschütten><en> Drain the pasta and add to the pesto in the bowl, mix well.
<G-vec00847-002-s241><drain.abschütten><de> Die Nudeln nach Packungsanweisung bissfest garen, abschütten und eine Tasse vom Kochwasser aufbewahren.
<G-vec00847-002-s241><drain.abschütten><en> Cook the noodles according to the instruction of the packaging, drain and keep a cup of the cooking water.
<G-vec00847-002-s242><drain.abschütten><de> Fett abschütten, etwas Olivenöl beigeben, Geflügel herausnehmen und warm stellen.
<G-vec00847-002-s242><drain.abschütten><en> Drain off the fat, add some olive oil, remove the chicken and keep warm.
<G-vec00847-002-s243><drain.abschütten><de> Abschütten und trocknen.
<G-vec00847-002-s243><drain.abschütten><en> Drain and dry them.
<G-vec00847-002-s244><drain.abschütten><de> In der Zwischenzeit die Walznudeln bissfest kochen, danach abschütten.
<G-vec00847-002-s244><drain.abschütten><en> Cook the tagliatelle in boiling salted water until al dente, then drain.
