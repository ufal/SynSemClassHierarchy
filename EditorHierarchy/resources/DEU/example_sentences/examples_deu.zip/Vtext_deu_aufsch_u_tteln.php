<G-vec00380-003-s057><shake_off.aufschütteln><de> Den Schlafsack immer wieder drehen und aufschütteln, damit der Loft gleichmäßig wiederhergestellt wird.
<G-vec00380-003-s057><shake_off.aufschütteln><en> Turn the sleeping bag often and shake it out to restore its loft.
<G-vec00380-003-s058><shake_off.aufschütteln><de> Aufschütteln und zum Trocken auf ein Tuch legen.
<G-vec00380-003-s058><shake_off.aufschütteln><en> Shake and lay it down on a towel to dry.
<G-vec00380-003-s059><shake_off.aufschütteln><de> Am nächsten Tag das jeweilige Flechtwerk einfach wieder öffnen, das Haar aufschütteln und abschließend mit Haarspray fixieren.
<G-vec00380-003-s059><shake_off.aufschütteln><en> Simply open up the braids again the next morning, shake out your hair and then secure it with hairspray.
<G-vec00380-003-s060><shake_off.aufschütteln><de> Nach kurzem Aufschütteln ist das ursprüngliche Volumen wiederhergestellt – immer wieder.
<G-vec00380-003-s060><shake_off.aufschütteln><en> A quick shake restores the original loft, time and again. Información adicional
<G-vec00380-003-s061><shake_off.aufschütteln><de> Das funktioniert ganz gut, man muss die Farben nur gut aufschütteln, sehr dünn sprühen und beim ersten Mal Drücken auf die Sprayflasche den Strahl nicht auf das Modell richten (aus der Dose kommen dann meist dicke Tropfen, die eine unschöne Oberfläche ergeben).
<G-vec00380-003-s061><shake_off.aufschütteln><en> That worked pretty well, you just have to shake the paint well, spray very thin and do not point the nozzle to the model the first time you push on the spray-can. (Thick drops, which result in an ugly surface, come out of the can most of the time).
<G-vec00380-003-s062><shake_off.aufschütteln><de> Vor Gebrauch gut aufschütteln, nach Gebrauch auf dem Kopf stehend Ventil sauber sprühen.
<G-vec00380-003-s062><shake_off.aufschütteln><en> Shake well before use, spray valve upside down cleanly after use.
<G-vec00466-002-s057><shake_up.aufschütteln><de> Den Schlafsack immer wieder drehen und aufschütteln, damit der Loft gleichmäßig wiederhergestellt wird.
<G-vec00466-002-s057><shake_up.aufschütteln><en> Turn the sleeping bag often and shake it out to restore its loft.
<G-vec00466-002-s058><shake_up.aufschütteln><de> Aufschütteln und zum Trocken auf ein Tuch legen.
<G-vec00466-002-s058><shake_up.aufschütteln><en> Shake and lay it down on a towel to dry.
<G-vec00466-002-s059><shake_up.aufschütteln><de> Am nächsten Tag das jeweilige Flechtwerk einfach wieder öffnen, das Haar aufschütteln und abschließend mit Haarspray fixieren.
<G-vec00466-002-s059><shake_up.aufschütteln><en> Simply open up the braids again the next morning, shake out your hair and then secure it with hairspray.
<G-vec00466-002-s060><shake_up.aufschütteln><de> Nach kurzem Aufschütteln ist das ursprüngliche Volumen wiederhergestellt – immer wieder.
<G-vec00466-002-s060><shake_up.aufschütteln><en> A quick shake restores the original loft, time and again. Información adicional
<G-vec00466-002-s061><shake_up.aufschütteln><de> Das funktioniert ganz gut, man muss die Farben nur gut aufschütteln, sehr dünn sprühen und beim ersten Mal Drücken auf die Sprayflasche den Strahl nicht auf das Modell richten (aus der Dose kommen dann meist dicke Tropfen, die eine unschöne Oberfläche ergeben).
<G-vec00466-002-s061><shake_up.aufschütteln><en> That worked pretty well, you just have to shake the paint well, spray very thin and do not point the nozzle to the model the first time you push on the spray-can. (Thick drops, which result in an ugly surface, come out of the can most of the time).
<G-vec00466-002-s062><shake_up.aufschütteln><de> Vor Gebrauch gut aufschütteln, nach Gebrauch auf dem Kopf stehend Ventil sauber sprühen.
<G-vec00466-002-s062><shake_up.aufschütteln><en> Shake well before use, spray valve upside down cleanly after use.
<G-vec00937-002-s057><shake.aufschütteln><de> Den Schlafsack immer wieder drehen und aufschütteln, damit der Loft gleichmäßig wiederhergestellt wird.
<G-vec00937-002-s057><shake.aufschütteln><en> Turn the sleeping bag often and shake it out to restore its loft.
<G-vec00937-002-s058><shake.aufschütteln><de> Aufschütteln und zum Trocken auf ein Tuch legen.
<G-vec00937-002-s058><shake.aufschütteln><en> Shake and lay it down on a towel to dry.
<G-vec00937-002-s059><shake.aufschütteln><de> Am nächsten Tag das jeweilige Flechtwerk einfach wieder öffnen, das Haar aufschütteln und abschließend mit Haarspray fixieren.
<G-vec00937-002-s059><shake.aufschütteln><en> Simply open up the braids again the next morning, shake out your hair and then secure it with hairspray.
<G-vec00937-002-s060><shake.aufschütteln><de> Nach kurzem Aufschütteln ist das ursprüngliche Volumen wiederhergestellt – immer wieder.
<G-vec00937-002-s060><shake.aufschütteln><en> A quick shake restores the original loft, time and again. Información adicional
<G-vec00937-002-s061><shake.aufschütteln><de> Das funktioniert ganz gut, man muss die Farben nur gut aufschütteln, sehr dünn sprühen und beim ersten Mal Drücken auf die Sprayflasche den Strahl nicht auf das Modell richten (aus der Dose kommen dann meist dicke Tropfen, die eine unschöne Oberfläche ergeben).
<G-vec00937-002-s061><shake.aufschütteln><en> That worked pretty well, you just have to shake the paint well, spray very thin and do not point the nozzle to the model the first time you push on the spray-can. (Thick drops, which result in an ugly surface, come out of the can most of the time).
<G-vec00937-002-s062><shake.aufschütteln><de> Vor Gebrauch gut aufschütteln, nach Gebrauch auf dem Kopf stehend Ventil sauber sprühen.
<G-vec00937-002-s062><shake.aufschütteln><en> Shake well before use, spray valve upside down cleanly after use.
