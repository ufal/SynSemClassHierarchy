<G-vec00169-001-s026><reclaim.abgewinnen><de> Die 165 Kanäle, die sich durch die Stadt Amsterdam ziehen, wurden im Laufe der Jahrhunderte angelegt, um den Handel zu vereinfachen und dem Wasser Land abzugewinnen.
<G-vec00169-001-s026><reclaim.abgewinnen><en> The 165 canals that crisscross the city of Amsterdam were created in the 17th century to facilitate trade and to reclaim land from the water.
