<G-vec00290-001-s038><prepare.aufbereiten><de> Um die Daten von Quanten-Rechnungen aufzubereiten und auch um bislang unbekanntes Terrain der Werkstoffwissenschaften zu erkunden, verfolgen die Nomad-Forscher im Wesentlichen zwei Ansätze: Zum einen verwenden sie data mining Techniken, um in großen Datenmengen Muster zu erkennen.
<G-vec00290-001-s038><prepare.aufbereiten><en> To prepare the data from quantum calculations and also to investigate previously unknown territory in materials science, the Nomad researchers are pursuing two main approaches: on the one hand, they use data mining techniques to discover patterns in large quantities of data.
<G-vec00290-001-s039><prepare.aufbereiten><de> Im ersten Teilprojekt liegt der Fokus auf der Abtrennung und Reinigung von CO2, um dieses für eine weitere Nutzung aufzubereiten.
<G-vec00290-001-s039><prepare.aufbereiten><en> The first is focused on the separation and cleaning of CO2 in order to prepare it for additional use.
<G-vec00290-001-s040><prepare.aufbereiten><de> Um die Alt-Module optimal aufzubereiten, wird ein hochwertiges, flächendeckendes Recycling-System entlang der gesamten solaren Wertschöpfungskette notwendig.
<G-vec00290-001-s040><prepare.aufbereiten><en> In order to prepare the old modules optimally, a high-quality comprehensive recycling system is needed along the entire solar value-creation chain.
<G-vec00290-001-s041><prepare.aufbereiten><de> Bei der Umsetzung des Projektes stehen drei Aspekte im Vordergrund: Erstens geht es darum, Wissen für städtische Praktiker und Entscheidungsträger aufzubereiten und zugänglich zu machen, um zielgerichtete städtische Maßnahmen für den Klimawandel zu identifizieren und umzusetzen.
<G-vec00290-001-s041><prepare.aufbereiten><en> Implementation of the project focuses on three aspects. The first is to prepare and make knowledge accessible for urban practitioners and decision-makers in order to identify and implement targeted urban development measures that address climate change.
<G-vec00290-001-s042><prepare.aufbereiten><de> Ziel des Prozesses ist es, eine kreative Idee technisch so aufzubereiten, dass sie digital, im Druck und als Verpackung konsistent umgesetzt werden kann.
<G-vec00290-001-s042><prepare.aufbereiten><en> The aim of this process is to technically prepare a creative idea so that it can be implemented digitally to produce consistent print and packaging.
<G-vec00290-001-s043><prepare.aufbereiten><de> Diese Option ist Interessant wenn Sie für den Export auf der READ Seite große Datenmengen abfragen und die SQLite Datenbank sehr lange benötigt um die Daten aufzubereiten.
<G-vec00290-001-s043><prepare.aufbereiten><en> This option makes sense when you select massive data volumes from a database on the READ side and the SQLite database takes a long time to prepare its result.
<G-vec00290-001-s044><prepare.aufbereiten><de> Die Arbeitsschwerpunkte des Labors bestehen unter anderem darin, vorhandene Technologien für Anwendungen in globalen Märkten aufzubereiten.
<G-vec00290-001-s044><prepare.aufbereiten><en> Amongst other things, the focus of the laboratory will be to prepare and upgrade existing technologies for applications in global markets.
<G-vec00290-001-s045><prepare.aufbereiten><de> Hierbei gilt es Informationen von Dritten zu einem Aspekt des persönlichen Interesses zu sammeln und für die Schublade aufzubereiten.
<G-vec00290-001-s045><prepare.aufbereiten><en> This includes collecting information from third parties on an aspect of interest and prepare it for the drawer.
<G-vec00290-001-s046><prepare.aufbereiten><de> Die Daten werden in den geologischen Landesämtern gesammelt, die sich bemühen, diese auch entsprechend aufzubereiten und zur Verfügung zu stellen.
<G-vec00290-001-s046><prepare.aufbereiten><en> The data is collected in the geological state offices that strive to prepare the information accordingly and make it available.
<G-vec00290-001-s047><prepare.aufbereiten><de> "Das Ziel dieser Forschungsarbeit war es Inhalt, Methoden und didaktische Ansätze der neuen Disziplin ""Architectural Geometry"" zu definieren und für den Einsatz im Architekturstudium an technischen Fakultäten aufzubereiten."
<G-vec00290-001-s047><prepare.aufbereiten><en> "The aim of this research work was to define the content, methods and didactical approaches of the new discipline ""Architectural Geometry"" and to prepare it for use in architectural programmes offered by technological faculties."
<G-vec00290-001-s048><prepare.aufbereiten><de> Denn die Lösung nutzt die Open Telekom Cloud, um die vorhandene Datenbasis in Echtzeit nach passenden Aufnahmen zu durchsuchen und diese wie gewünscht aufzubereiten.
<G-vec00290-001-s048><prepare.aufbereiten><en> The solution uses the Open Telekom Cloud to search the existing database for suitable images in real time and prepare them as required.
<G-vec00290-001-s049><prepare.aufbereiten><de> Für alle Beteiligten war es keine kleine Herausforderung das Thema kindergerecht aufzubereiten.
<G-vec00290-001-s049><prepare.aufbereiten><en> It was quite a challenge to prepare the topic in a way that it is suitable for children.
<G-vec00290-001-s050><prepare.aufbereiten><de> Diese Option ist Interessant wenn Sie für den Export auf der READ Seite große Datenmengen abfragen und der MySQL Server sehr lange benötigt um die Daten Aufzubereiten.
<G-vec00290-001-s050><prepare.aufbereiten><en> This option makes sense when you select massive data volumes from a database on the READ side and the MySQL Server takes a long time to prepare its result.
<G-vec00290-001-s051><prepare.aufbereiten><de> Von vielen Plottertreibern werden die Alternativen angeboten, die Grafik im Plotter oder im Computer aufzubereiten.
<G-vec00290-001-s051><prepare.aufbereiten><en> Many plotter drivers offer alternatives to prepare the graphic in the plotter or in the computer.
<G-vec00290-001-s052><prepare.aufbereiten><de> Daher sind die Mitarbeiter gezwungen, Grundwasser zu fördern und es eigenständig aufzubereiten.
<G-vec00290-001-s052><prepare.aufbereiten><en> As a result, the employees are forced to extract groundwater and prepare it independently.
<G-vec00290-001-s053><prepare.aufbereiten><de> Seit Beginn des Projektes eignete sich Karl Lang das Know-How, um mit der CNC-Maschine zurecht zu kommen, Programme zu schreiben und für die Produktion in Sozialbetrieben aufzubereiten, stetig selbst an, schulte sogar Sozialbetriebe ein und produzierte diverse Prototypen.
<G-vec00290-001-s053><prepare.aufbereiten><en> Since the beginning of this project, Karl Lang has constantly taught himself the know-how to handle CNC machines, to write programmes, and to prepare production in social enterprises, furthermore he has trained workers of social enterprises and has produced various prototypes.
<G-vec00290-001-s054><prepare.aufbereiten><de> """Wir helfen, diese aufzubereiten und in Anwendungen mit Raumbezug sinnvoll einzusetzen."
<G-vec00290-001-s054><prepare.aufbereiten><en> """We help prepare the data for practical use in spatial applications."
<G-vec00290-001-s055><prepare.aufbereiten><de> Diese Option ist interessant wenn Sie für den Export auf der READ Seite große Datenmengen abfragen und der SQL Server sehr lange benötigt um die Daten Aufzubereiten.
<G-vec00290-001-s055><prepare.aufbereiten><en> This option makes sense when you select massive data volumes from a database on the READ side and the SQL Server takes a long time to prepare its result.
<G-vec00290-001-s056><prepare.aufbereiten><de> Eine in diesem Segment eingesetzte Business Intelligence-Software muss deshalb weit mehr leisten als nur aus verschiedenen Quellen Daten für ein Reporting aufzubereiten: Sie muss alle relevanten Parameter schnell für kurzfristige Entscheidungen sammeln und aufgrund des Datenbestands ein umfassendes Bild über die aktuelle Verkaufssituation liefern, aber zusätzlich auch den Gesamtkontext darstellen.
<G-vec00290-001-s056><prepare.aufbereiten><en> For this reason, business intelligence software used in the retail industry must do far more than just prepare data for a report using different sources; it must rapidly gather all relevant parameters for making quick decisions and provide a comprehensive picture of the current sales situation based on the data available, while also showing the overall context.
<G-vec00169-001-s031><reclaim.aufbereiten><de> Die Bereitstellung von zuverlässigen und kostengünstigen Dienstleistungen zur Bereitstellung hochwertigen Wasser, das sicher zu entsorgen oder aufzubereiten ist, ist von entscheidender Bedeutung.
<G-vec00169-001-s031><reclaim.aufbereiten><en> Providing a reliable, inexpensive service that produces high quality water that is safe to dispose or reclaim is essential.
<G-vec00290-002-s076><prepare.aufbereiten><de> Mit den Gestaltungsprinzipien von Professor Rolf Hichert steigert die BA ihre Berichtsqualität, um Informationen verständlich aufzubereiten und Entscheidungsträgern klare Empfehlungen zu geben.
<G-vec00290-002-s076><prepare.aufbereiten><en> With the principles of design from Professor Rolf Hichert, the BA is able to improve the level of quality in reporting, to prepare information in an understandable manner, and to give decision-makers clear recommendations.
<G-vec00290-002-s077><prepare.aufbereiten><de> Wir können die bestehende kleine Küche des Kindergartens nutzen um für die Kleinkinder warme Schoppen und warmes Essen aufzubereiten.
<G-vec00290-002-s077><prepare.aufbereiten><en> We can use the existing small kitchen of the nursery in order to prepare warm pint and hot food for toddlers.
<G-vec00290-002-s078><prepare.aufbereiten><de> Nach Abschluss der LVA sind die Studenten in der Lage, Daten für statistische Auswertungen entsprechend aufzubereiten und die mit verschiedenen Computerprogrammen erzielten Ergebnisse problemadäquat zu interpretieren.
<G-vec00290-002-s078><prepare.aufbereiten><en> Finally, students are able to prepare data for statistical analyses accordingly, to use adequate methods and to interpret results correctly.
<G-vec00290-002-s079><prepare.aufbereiten><de> Unsere Aufgabe bestand darin, die Gebäude zurückzubauen, den Boden aufzubereiten und anschließend die Grundstücke zu veräußern.
<G-vec00290-002-s079><prepare.aufbereiten><en> Our task was to demolish the buildings, prepare the land, and subsequently sell the plots.
<G-vec00290-002-s080><prepare.aufbereiten><de> Unser Anspruch liegt darin, die Daten für alle denkbaren Arten der Nutzung bestmöglich aufzubereiten und bereitzustellen.
<G-vec00290-002-s080><prepare.aufbereiten><en> Our job is to prepare and provide the data in the best way possible for any conceivable use.
<G-vec00290-002-s081><prepare.aufbereiten><de> Es ist nicht notwendig, Daten auf eine bestimmte Art und Weise aufzubereiten, zu exportieren oder in einer weiteren Anwendung zu verarbeiten.
<G-vec00290-002-s081><prepare.aufbereiten><en> There is no need to prepare data in some specific way, export it or process in a third-party application.
<G-vec00290-002-s082><prepare.aufbereiten><de> Das ermöglicht Dir die Daten für verschiedenste Programme aufzubereiten.
<G-vec00290-002-s082><prepare.aufbereiten><en> This allows you to prepare the data for whatever purpose you have in mind.
<G-vec00290-002-s083><prepare.aufbereiten><de> Die Benutzeroberfläche ist darauf ausgelegt, große BI Architekturen aufzubereiten.
<G-vec00290-002-s083><prepare.aufbereiten><en> The user interface is designed to prepare large BI architectures.
<G-vec00290-002-s084><prepare.aufbereiten><de> Begleitpapiere lassen sich online erstellen und ausdrucken, womit Auslandspakete, Express- und Kuriersendungen einfach aufzubereiten sind.
<G-vec00290-002-s084><prepare.aufbereiten><en> Accompanying documents can be created and printed online, making it easy to prepare international parcels, express items and courier consignments.
<G-vec00290-002-s085><prepare.aufbereiten><de> Zu diesem Zweck ist es notwendig, die Grafik mit entsprechenden Zusätzen an allen Rändern aufzubereiten.
<G-vec00290-002-s085><prepare.aufbereiten><en> For this purpose, it is necessary to prepare the graphics with appropriate bleeds on all edges.
<G-vec00290-002-s086><prepare.aufbereiten><de> Modernes Datenmanagement eröffnet neue, innovative Wege, um Daten aus neuen Quellen aufzubereiten und in die Analysen einzubeziehen.
<G-vec00290-002-s086><prepare.aufbereiten><en> A modernized data management software solution is about rapid data access and integration. Such solutions provide fast, innovative ways to access and prepare new data sources.
<G-vec00290-002-s087><prepare.aufbereiten><de> Die Studierenden sollen befähigt werden, sowohl den aktuellen Anforderungen des Lehrerberufs fachlich und fachdidaktisch gerecht zu werden, als auch künftige Entwicklungen der Physik und der Astronomie zu verfolgen, zu bewerten und gegebenenfalls für eine adressatengerechte Vermittlung im Unterricht aufzubereiten.
<G-vec00290-002-s087><prepare.aufbereiten><en> They are also given the tools to meet the current requirements of the teaching profession for their subject and generally as teachers, as well as to follow and assess future developments in physics and astronomy and, if appropriate, prepare such content for delivery in the classroom at the appropriate level.
<G-vec00290-002-s088><prepare.aufbereiten><de> Nur ein Team aus spezialisierten Datenexperten und Entwicklern ist in der Lage, die richtigen Daten aufzubereiten, die richtigen Modelle zu erstellen und dann die Prognosefunktionen in eine Benutzeroberfläche wie die des CRM zu integrieren.
<G-vec00290-002-s088><prepare.aufbereiten><en> It takes a specialised team of data scientists and developers to access the correct data, prepare the data, build the correct models, and then integrate the predictions back into an end-user experience such as CRM.
<G-vec00290-002-s090><prepare.aufbereiten><de> Es besteht keine Notwendigkeit Ihre Originaldaten für das System anders als bisher aufzubereiten.
<G-vec00290-002-s090><prepare.aufbereiten><en> There is no need to individually prepare images for print jobs.
<G-vec00290-002-s091><prepare.aufbereiten><de> Und schließlich geht es auch darum, Abwasser zu behandeln und industrielles Betriebswasser aufzubereiten.
<G-vec00290-002-s091><prepare.aufbereiten><en> And finally, it is also important to treat waste water and prepare water for industrial uses.
<G-vec00290-002-s092><prepare.aufbereiten><de> Dadurch wird es möglich, gezielt auf sämtliche Daten in der LOGINventory Datenbank zuzugreifen und diese nach Belieben zu verarbeiten und aufzubereiten.
<G-vec00290-002-s092><prepare.aufbereiten><en> This makes it possible to specifically access all data in the LOGINventory database and process and prepare them as required.
<G-vec00290-002-s093><prepare.aufbereiten><de> Wird im Gesprächsfenster verwendet um die Details zum gerufenen Kontakt aufzubereiten.
<G-vec00290-002-s093><prepare.aufbereiten><en> Is used in the Call window to prepare the details for a called contact.
<G-vec00290-002-s094><prepare.aufbereiten><de> Die technische Anleitung, wie diese Dateien aufzubereiten sind, ist in englischer Sprache verfügbar.
<G-vec00290-002-s094><prepare.aufbereiten><en> Technical indications on how to prepare these type of files can be found here.
<G-vec01098-002-s019><recycle.aufbereiten><de> Aber jetzt denken Sie zu selbst, daß Sie alles aufbereiten können, das Sie gerade kauften.
<G-vec01098-002-s019><recycle.aufbereiten><en> But now you’re thinking to yourself that you can recycle everything that you just purchased.
<G-vec01098-002-s020><recycle.aufbereiten><de> Um Mahlgut entsprechend dieser Kriterien aufbereiten zu können, muss der Recyclingextruder mit durchgewärmten Mahlgutpartikeln befüllt werden damit erstens eine außerordentlich schonende Aufbereitung und zweitens eine leistungsfähige Filtration gewährleistet ist.
<G-vec01098-002-s020><recycle.aufbereiten><en> In order to be able to recycle in line with these criteria the recycling extruder has to be filled with thoroughly warmed regrind particles to ensure first of all exceptionally gentle processing and, secondly, high-performance filtration.
<G-vec01098-002-s021><recycle.aufbereiten><de> 10) Materialien aufbereiten.
<G-vec01098-002-s021><recycle.aufbereiten><en> 10) Recycle Materials.
<G-vec01098-002-s022><recycle.aufbereiten><de> Spritzen Sie Wasser ein, um aufzubereiten, verringern Sie Energieverbrauch.
<G-vec01098-002-s022><recycle.aufbereiten><en> Inject water to recycle, reduce energy consumption.
<G-vec01098-002-s023><recycle.aufbereiten><de> Es ist einfach, die alte Stromversorgung und das Motherboard für Reparatur oder Ersatz aufzubereiten, wenn es installiert wird.
<G-vec01098-002-s023><recycle.aufbereiten><en> It is easy to recycle the old power supply and motherboard for repair or replacement when installed.
