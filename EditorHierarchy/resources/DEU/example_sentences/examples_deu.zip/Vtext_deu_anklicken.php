<G-vec00507-002-s019><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die FAT-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s019><file.anklicken><en> Simply right-click on the IBAK file, then from the available list select "Choose default program".
<G-vec00507-002-s020><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die CVM-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s020><file.anklicken><en> Simply right-click on the CVM file, then from the available list select "Choose default program".
<G-vec00507-002-s021><file.anklicken><de> Viele XML-Programme richten sich selbst als Standardprogramm für XML-Dateien ein, was es dir erlaubt, die XML-Datei einfach doppelt anzuklicken, um sie zu öffnen.
<G-vec00507-002-s021><file.anklicken><en> Many XML programs will set themselves as the default program for XML files, allowing you to simply double-click the XML file to open it.
<G-vec00507-002-s022><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PDI-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s022><file.anklicken><en> Simply right-click on the PDI file, then from the available list select "Choose default program".
<G-vec00507-002-s023><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die BWP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s023><file.anklicken><en> Simply right-click on the BUR file, then from the available list select "Choose default program".
<G-vec00507-002-s024><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die TRK-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s024><file.anklicken><en> Simply right-click on the TRK file, then from the available list select "Choose default program".
<G-vec00507-002-s025><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PQW-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s025><file.anklicken><en> Simply right-click on the CPO file, then from the available list select "Choose default program".
<G-vec00507-002-s026><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die XLV-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s026><file.anklicken><en> Simply right-click on the XLV file, then from the available list select "Choose default program".
<G-vec00507-002-s027><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PACK-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s027><file.anklicken><en> Simply right-click on the PACK file, then from the available list select "Choose default program".
<G-vec00507-002-s028><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die NUC-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s028><file.anklicken><en> Simply right-click on the NUC file, then from the available list select "Choose default program".
<G-vec00507-002-s029><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die WMZ-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s029><file.anklicken><en> Simply right-click on the WMZ file, then from the available list select "Choose default program".
<G-vec00507-002-s030><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die CATALOG-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s030><file.anklicken><en> Simply right-click on the CATALOG file, then from the available list select "Choose default program".
<G-vec00507-002-s031><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die XTREME-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s031><file.anklicken><en> Simply right-click on the XTREME file, then from the available list select "Choose default program".
<G-vec00507-002-s032><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die LWV-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s032><file.anklicken><en> Simply right-click on the MPD file, then from the available list select "Choose default program".
<G-vec00507-002-s033><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die SSM-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s033><file.anklicken><en> Simply right-click on the SSM file, then from the available list select "Choose default program".
<G-vec00507-002-s034><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die FDE-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s034><file.anklicken><en> Simply right-click on the FDE file, then from the available list select "Choose default program".
<G-vec00507-002-s035><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die VRH-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s035><file.anklicken><en> Simply right-click on the VRH file, then from the available list select "Choose default program".
<G-vec00507-002-s036><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die JMP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s036><file.anklicken><en> Simply right-click on the JMP file, then from the available list select "Choose default program".
<G-vec00507-002-s037><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die EPD-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s037><file.anklicken><en> Simply right-click on the EPD file, then from the available list select "Choose default program".
<G-vec00728-002-s019><click.anklicken><de> Wenn Sie den Facebook "Like-Button" anklicken während Sie in Ihrem Facebook-Account eingeloggt sind, können Sie die Inhalte unserer Seiten auf Ihrem Facebook-Profil verlinken.
<G-vec00728-002-s019><click.anklicken><en> If you click the Facebook “Like button” when you are logged on to your Facebook account, you may link the contents of our sites on your Facebook profile.
<G-vec00728-002-s020><click.anklicken><de> +In den meisten Email-Programmen erscheint dieser Link blau, so dass Sie diesen anklicken können.
<G-vec00728-002-s020><click.anklicken><en> +In most mail programs, this should appear as a blue link +which you can just click on.
<G-vec00728-002-s021><click.anklicken><de> Märkte Märkte Um mehr über unsere Märkte zu erfahren, eines der unten gezeigten Symbole anklicken.
<G-vec00728-002-s021><click.anklicken><en> Markets Markets To learn more about the markets we serve, click on any of the icons below.
<G-vec00728-002-s022><click.anklicken><de> 2.3 Durch Anklicken des Buttons „Bestellung abschließen“ am Ende des Bestellvorgangs geben Sie eine verbindliche Bestellung der im Warenkorb enthaltenen Waren zu dem Ihnen dort mitgeteilten Gesamtpreis ab.
<G-vec00728-002-s022><click.anklicken><en> 2.3 When you click on the “conclude order” button at the end of the ordering procedure, you are submitting a binding order for the goods contained within the shopping basket at the total price quoted to you there.
<G-vec00728-002-s023><click.anklicken><de> Wenn Sie gebeten werden, ein Formular auf der Website auszufüllen, suchen Sie nach dem Kästchen, das Sie anklicken können, um anzugeben, dass Sie nicht möchten, dass die Informationen von irgendjemandem für Direktmarketingzwecke verwendet werden.
<G-vec00728-002-s023><click.anklicken><en> Whenever you are asked to fill in a form on the website, look for the box that you can click to indicate whether or not you wish to receive future contact from us.
<G-vec00728-002-s024><click.anklicken><de> Eine Übersicht zu Stahlprodukte sowie zum gesamten Lieferprogramm erhalten Sie beim Anklicken des grünen Buttons "Produkte und Dienstleistungen" oder Sie gehen direkt auf die WEB Seiten von Coiltrade Stahlhandel GmbH.
<G-vec00728-002-s024><click.anklicken><en> If you would like Coiltrade Stahlhandel GmbH to call you back about Steel Products, please click on the button "Display contact details", enter your contact details in the mailing form and click on Send.
<G-vec00728-002-s025><click.anklicken><de> Den Schraubenschlüssel in der oberen rechten Ecke anklicken und „Einstellungen“ auswählen.
<G-vec00728-002-s025><click.anklicken><en> Click the 'wrench' icon in the upper right corner and select 'Settings'.
<G-vec00728-002-s026><click.anklicken><de> Auch weitere Informationen über unsere Angebote erhalten Sie – jederzeit widerruflich – nur dann, wenn Sie diese Option ausdrücklich anklicken.
<G-vec00728-002-s026><click.anklicken><en> You will only be sent further information about our offers only if you expressly click on this option, and you can unsubscribe at any time.
<G-vec00728-002-s027><click.anklicken><de> Diese Funktion wird nicht automatisch geladen, sondern erst wenn Sie den entsprechenden Link anklicken.
<G-vec00728-002-s027><click.anklicken><en> The function will not be automatically loaded, but only if you click the “comments” link.
<G-vec00728-002-s028><click.anklicken><de> Dies alles führt dazu, dass die Einwilligungserklärungen, welche die Anbieter uns vorlegen, meist lang und kompliziert sind – und dass wir immer öfter "Ich stimme zu" anklicken, ohne alles gründlich gelesen und verstanden zu haben.
<G-vec00728-002-s028><click.anklicken><en> All this leads to the fact that the declarations of consent presented by the providers are usually long and complicated – and that we increasingly click "I agree" without having thoroughly read and understood everything.
<G-vec00728-002-s029><click.anklicken><de> Dies geschieht jedoch erst dann, wenn Sie aktiv eine dieser Schaltflächen anklicken.
<G-vec00728-002-s029><click.anklicken><en> This only happens if you actively click on one of these social sharing buttons.
<G-vec00728-002-s030><click.anklicken><de> Deutsch, Englisch Das gesamte Lieferprogramm, Adressdaten, Telefon- und Faxnummern finden Sie beim Anklicken des grünen Buttons "Produkte und Dienstleistungen".
<G-vec00728-002-s030><click.anklicken><en> German, English Please click on the link "Show products and services" or on the web address of Braun & Partner GmbH.
<G-vec00728-002-s031><click.anklicken><de> Der Zählpixel wird auf Ihrem Endgerät geladen, wenn Sie auf eine von uns über Twitter geschaltete Anzeigen reagieren, etwa weil Sie einen enthaltenen Link auf unsere Seite anklicken.
<G-vec00728-002-s031><click.anklicken><en> The tracking pixel is loaded on your device when you respond to any ad we send via Twitter, for example when you click on a link to our page.
<G-vec00728-002-s032><click.anklicken><de> Erst mit dieser Aktivierung wird eine Verbindung mit dem sozialen Netzwerk aufgebaut, unabhängig davon, ob Sie die Social Plugins tatsächlich anklicken.
<G-vec00728-002-s032><click.anklicken><en> Only with this activation is a connection set up with the social network, independent of whether you actually click on the social plugin, or not.
<G-vec00728-002-s033><click.anklicken><de> Zu Ihrer Sicherheit erhalten Sie dann von uns eine E-Mail mit einem Bestätigungslink, den Sie bitte anklicken, um Ihre E-Mail-Adresse zu bestätigen.
<G-vec00728-002-s033><click.anklicken><en> For your security, you will then receive an E-mail containing a confirmation link, please click this link to confirm your E-mail address.
<G-vec00728-002-s034><click.anklicken><de> Deutsch, Englisch Beim Anklicken des grünen Buttons "Produkte und Dienstleistungen" finden Sie außer Edelstahlküchen noch weitere Angebote von K2 Edelstahl - technik & Metallbau Berlin.
<G-vec00728-002-s034><click.anklicken><en> Our contact languages German, English Please click on the green button "Show contact details" and send a message regarding Stainless Steel Kitchens to K2 Edelstahl - technik & Metallbau Berlin.
<G-vec00728-002-s035><click.anklicken><de> Zum Beispiel, wenn Sie Zitaten aus Filmen herunterladen, können Sie einen Teil eines Zitats in dieses Feld eingeben und "Suche" anklicken, um den Film zu finden.
<G-vec00728-002-s035><click.anklicken><en> For example, if you download movie quotes, you can enter a part of some quote into this field and click "Search" to find the movie.
<G-vec00728-002-s036><click.anklicken><de> Mit UBS Safe können Sie all Ihre Passwörter digital an einem sicheren Ort speichern – und in 2019 nie mehr "Passwort vergessen" anklicken.
<G-vec00728-002-s036><click.anklicken><en> With UBS Safe you can save all your passwords digitally in a secure location – and from 2019, never click on “Forgot my Password" again.
<G-vec00728-002-s037><click.anklicken><de> Du kannst einen neuen Link auf irgendeiner Seite irgendwo einfügen und diesen neuen Link anklicken, um eine neue Seite anzulegen.
<G-vec00728-002-s037><click.anklicken><en> You can create a link on another page, then click the link you just inserted, to create the new page:
