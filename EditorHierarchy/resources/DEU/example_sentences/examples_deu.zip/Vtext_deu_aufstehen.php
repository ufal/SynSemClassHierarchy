<G-vec00510-001-s190><rise.aufstehen><de> Ich bin bereit, dich zu energetisieren, solange es noch Tag ist, und du wirst aufstehen und durch die Nacht sehen.
<G-vec00510-001-s190><rise.aufstehen><en> I am ready to energize you while it’s still day, and you will rise up and see through the night ahead.
<G-vec00510-001-s191><rise.aufstehen><de> Wenn wir aufstehen, wenn wir uns niederlegen, wenn wir reden, wenn wir schweigen, wenn wir handeln, wenn wir ruhen: ob wir essen oder trinken, was immer wir tun, wir wollen nie vergessen: „über all das wird uns Gott vor Gericht führen“ (Prd 11, 9).
<G-vec00510-001-s191><rise.aufstehen><en> When we rise, when we lie down; when we speak, when we are silent; when we act, and when we rest: whether we eat or drink, or whatever we do, may we never forget that “for all these things God will bring us into judgment.” (Eccles. 11:9.)
<G-vec00510-001-s192><rise.aufstehen><de> 35 Da sprach sie zu ihrem Vater: Mein HERR, zürne nicht, denn ich kann nicht aufstehen gegen dir; denn es gehet mir nach der Frauen Weise.
<G-vec00510-001-s192><rise.aufstehen><en> 35 And she said to her father, Let it not displease my lord that I cannot rise up before thee; for the custom of women is upon me.
<G-vec00510-001-s193><rise.aufstehen><de> Beim ziemlich breiten Lineal der professionellen Ausrüstung Wacom – der graphischen Zeichenbretter einer Serie Intuos 4 und interaktiven Displays Cintiq und PL, werden Sie vor der Auswahl des Formates, der Möglichkeiten, der zusätzlichen Zubehöre für die Arbeit in CAD/CAM/CAE die Systeme und 2D/3D die graphischen Anlagen aufstehen.
<G-vec00510-001-s193><rise.aufstehen><en> At enough wide ruler of professional equipment Wacom – graphic tablets of series Intuos of 4 and interactive displays Cintiq and PL, you will rise before a choice of a format, possibilities, additional accessories for work in CAD/CAM/CAE systems and 2D/3D graphic applications.
<G-vec00510-001-s194><rise.aufstehen><de> Eher wäre ich derjenige, der sich vor ihm verneigen sollte, aus Respekt vor ihm von meinem Sitz aufstehen sollte, ihm einen Platz anbieten sollte, ihn einladen sollte, Geschenke von Roben, Almosenspeise, Behausung und medizinischen Notwendigkeiten für den Fall der Krankheit anzunehmen.
<G-vec00510-001-s194><rise.aufstehen><en> Rather, I am the one who should bow down to him, rise up out of respect for him, invite him to a seat, invite him to accept gifts of robes, almsfood, lodgings, and medicinal requisites for the sick.
<G-vec00510-001-s195><rise.aufstehen><de> Ihr, liebe Knaben, müßt früh aufstehen, um zur Schule zu gehen; ich kenne den römischen Verkehr und kann mir deshalb vorstellen, wie schwierig es oft ist, pünktlich zu sein.
<G-vec00510-001-s195><rise.aufstehen><en> You have to rise early, boys, in order to get to school; I know Rome's traffic and I can therefore guess how difficult it often is for you to arrive on time.
<G-vec00510-001-s196><rise.aufstehen><de> [HG 2.5.7] Der Abedam aber hieß sie wieder aufstehen, um zu empfangen nach Sitte der Liebe von alters her das junge Ehepaar.
<G-vec00510-001-s196><rise.aufstehen><en> [HG 2.5.7] But Abedam bade them rise up again so as to receive the young couple in accordance with the ancient custom of love.
<G-vec00510-001-s197><rise.aufstehen><de> Es wird aus der Asche unseres veralteten Systems aufstehen, wie ein mächtiger Phoenix.
<G-vec00510-001-s197><rise.aufstehen><en> It will rise out of the ashes of our obsolete monetary system like a mighty Phoenix.
<G-vec00510-001-s198><rise.aufstehen><de> Nichtsdestoweniger, es sind die Unterhaltungen möglich, in die ein oder mehrere Teilnehmer vom Essen aufstehen müssen.
<G-vec00510-001-s198><rise.aufstehen><en> Nevertheless, entertainments in which one or several participants should rise because of a table are possible.
<G-vec00510-001-s199><rise.aufstehen><de> Qi wird sofort aufstehen, und im ersten Stock, ohne es zu überlassen.
<G-vec00510-001-s199><rise.aufstehen><en> Qi will immediately rise up, and the first floor will be left without it.
<G-vec00510-001-s200><rise.aufstehen><de> "Das Papier ""soll in die Falze» aufstehen."
<G-vec00510-001-s200><rise.aufstehen><en> "Paper has to ""rise in grooves""."
<G-vec00510-001-s201><rise.aufstehen><de> 16Und der HERR sprach zu Mose: Siehe, wenn du bei deinen Vätern liegst, wird dieses Volk aufstehen und den fremden Göttern des Landes, darein sie kommen, nachbuhlen, und sie werden mich verlassen und meinen Bund brechen, den ich mit ihnen gemacht habe.
<G-vec00510-001-s201><rise.aufstehen><en> 16 And the Lord said to Moses, Behold, you shall sleep with your fathers, and this people will rise up and play the harlot after the strange gods of the land where they go to be among them; and they will forsake Me and break My covenant which I have made with them.
<G-vec00510-001-s202><rise.aufstehen><de> 35 Und sie sprach zu ihrem Vater: Mein Herr möge nicht zürnen, daß ich nicht vor dir aufstehen kann; denn es ergeht mir nach der Weiber Weise.
<G-vec00510-001-s202><rise.aufstehen><en> 35 And she said to her father, Let it not be an occasion of anger in the eyes of my lord that I cannot rise up before thee, for it is with me after the manner of women.
<G-vec00510-001-s203><rise.aufstehen><de> Der Geist Christi klopft an die Tür jeder Potenz, damit wir erwachen, aufstehen und nackt und unbehindert der Wahrheit begegnen.
<G-vec00510-001-s203><rise.aufstehen><en> The Spirit of Christ strikes the door of each potential so that he might be aroused, to rise and meet the truth naked and unhindered.
<G-vec00510-001-s204><rise.aufstehen><de> 49:7 So spricht Jehova, der Erlöser Israels, sein Heiliger, zu dem von jedermann Verachteten, zu dem Abscheu der Nation, zu dem Knechte der Herrscher: Könige werden es sehen und aufstehen, Fürsten, und sie werden sich niederwerfen, um Jehovas willen, der treu ist, des Heiligen Israels, der dich erwählt hat.
<G-vec00510-001-s204><rise.aufstehen><en> "49:7 This is what the LORD says--the Redeemer and Holy One of Israel--to him who was despised and abhorred by the nation, to the servant of rulers: ""Kings will see you and rise up, princes will see and bow down, because of the LORD, who is faithful, the Holy One of Israel, who has chosen you."""
<G-vec00510-001-s205><rise.aufstehen><de> 7 und er drinnen würde antworten und sprechen: Mach' mir keine Unruhe; die Tür ist schon zugeschlossen, und meine Kindlein sind bei mir in der Kammer; ich kann nicht aufstehen und dir geben.
<G-vec00510-001-s205><rise.aufstehen><en> 7 And he from within should answer and say: Trouble me not; the door is now shut, and my children are with me in bed. I cannot rise and give thee.
<G-vec00510-001-s206><rise.aufstehen><de> Du wirst wohl nicht jeden Tag in aller Munterkeit aufstehen, aber früher oder später wirst du aufstehen.
<G-vec00510-001-s206><rise.aufstehen><en> You may not rise to each day with alacrity, but sooner or later you rise.
<G-vec00510-001-s207><rise.aufstehen><de> 10Denn wenn ihr gleich das ganze Heer der Chaldäer, welche euch belagern, schlüget, und es blieben von ihnen nur etliche Verwundete übrig, so würden sie dennoch, ein jeder in seinem Zelte, aufstehen und diese Stadt mit Feuer verbrennen.
<G-vec00510-001-s207><rise.aufstehen><en> 10 For though you should defeat the whole army of the Chaldeans who fight against you, and there remained only the wounded and men stricken through among them, every man confined to his tent, yet they would rise up and burn this city with fire .
<G-vec00510-001-s208><rise.aufstehen><de> 7 So spricht der HERR, der Erlöser Israels, sein Heiliger, zu dem, der verachtet ist von den Menschen und verabscheut von den Heiden, zu dem Knecht, der unter Tyrannen ist: Könige sollen sehen und aufstehen, und Fürsten sollen niederfallen um des HERRN willen, der treu ist, um des Heiligen Israels willen, der dich erwählt hat.
<G-vec00510-001-s208><rise.aufstehen><en> 7 Thus saith the Lord the redeemer of Israel, his Holy One, to the soul that is despised, to the nation that is abhorred, to the servant of rulers: Kings shall see, end princes shall rise up, and adore for the Lord's sake, because he is faithful, and for the Holy One of Israel, who hath chosen thee.
<G-vec00246-002-s036><resurrect.aufstehen><de> Das tiefste Lied der Beatles hieß: „All you need is love.“ Die Menschheit braucht Erfül-lung in der Liebe, um wieder auferstehen zu können.
<G-vec00246-002-s036><resurrect.aufstehen><en> One of The Beatles’ deepest songs was: “All you need is love.” Humankind needs fulfillment in love in order to resurrect.
<G-vec00258-002-s608><arise.aufstehen><de> Aber damit ihr, die ihr Zeuge all dessen seid, endlich wisst, dass der Menschensohn auf Erden die Autorität und Macht besitzt, Sünden zu vergeben, will ich zu diesem geplagten Mann sagen: Steh auf, nimm dein Bett, und geh nach Hause.“ Und nachdem Jesus diese Worte gesprochen hatte, erhob sich der Gelähmte, man gab ihm den Weg frei, und er schritt vor ihrer aller Augen hinaus.
<G-vec00258-002-s608><arise.aufstehen><en> But that you who witness all this may finally know that the Son of Man has authority and power on earth to forgive sins, I will say to this afflicted man, Arise, take up your bed, and go to your own house.” And when Jesus had thus spoken, the paralytic arose, and as they made way for him, he walked out before them all.
<G-vec00258-002-s609><arise.aufstehen><de> Darauf legte der heilige Petrus die Gebeine in ihre rechte Ordnung, sprach dreimal zu ihr: "Im Namen der allerheiligsten Dreifaltigkeit, Tote, steh auf," und die Königstochter stand auf, war gesund und schön wie vorher.
<G-vec00258-002-s609><arise.aufstehen><en> Thereupon St. Peter laid the bones in their right order, said to the maiden three times, "In the name of the most holy Trinity, dead maiden, arise," and the King's daughter arose, healthy and beautiful as before.
<G-vec00258-002-s610><arise.aufstehen><de> 11 Der Herr sprach zu ihm: Steh auf und geh in die Straße, die die Gerade heißt, und frage in dem Haus des Judas nach einem Mann mit Namen Saulus von Tarsus.
<G-vec00258-002-s610><arise.aufstehen><en> Acts 9:11 So the Lord said to him, "Arise and go to the street called Straight, and inquire at the house of Judas for one called Saul of Tarsus, for behold, he is praying.
<G-vec00258-002-s611><arise.aufstehen><de> Again "ein Engel des Herrn erschien in Schlaf zu Joseph, sagte: Steh auf, nimm das Kind und seine Mutter, und fliegen in Ägypten: und da sein, bis ich dir erzählen werde "(Nazareth.
<G-vec00258-002-s611><arise.aufstehen><en> Again "an angel of the Lord appeared in sleep to Joseph, saying: Arise, and take the child and his mother, and fly into Egypt: and be there until I shall tell thee" (Matthew 2:13).
<G-vec00258-002-s612><arise.aufstehen><de> 18 Steh auf, nimm den Knaben und führe ihn an deiner HandHand; denn ich will ihn zum großen Volk machen.
<G-vec00258-002-s612><arise.aufstehen><en> 18 Arise, lift up the lad, and hold him in thy hand. For I will make him a great nation.
<G-vec00258-002-s613><arise.aufstehen><de> Später spricht der Dritte Mensch zum Mond der Erderneuerung: „Steh bitte auf und nimm Deinen Platz ein.
<G-vec00258-002-s613><arise.aufstehen><en> Later the Third Man says to the Moon of renewal of the earth: "Please arise and take over your place.
<G-vec00258-002-s614><arise.aufstehen><de> Spielen Steh auf und wieder sterben ähnliche Spiele und Updates.
<G-vec00258-002-s614><arise.aufstehen><en> Play Arise and Die Again related games and updates.
<G-vec00258-002-s615><arise.aufstehen><de> Wir lesen dort: „Als die Sterndeuter wieder gegangen waren, erschien dem Josef im Traum ein Engel des Herrn und sagte: Steh auf, nimm das Kind und seine Mutter, und flieh nach Ägypten; dort bleibe, bis ich dir etwas anderes auftrage; denn Herodes wird das Kind suchen, um es zu töten“ (Mt 2,13).
<G-vec00258-002-s615><arise.aufstehen><en> That was the occasion of another message from an angel of the Lord to Joseph in a dream: “Arise and take the Child and His mother, and flee to Egypt, and remain there until I tell you; for Herod is going to search for the Child to destroy Him” (Matt. 2:13).
<G-vec00258-002-s616><arise.aufstehen><de> 10 In Damạskus befand sich ein gewisser Jünger namens Ananịas,+ und der Herr sprach in einer Vision zu ihm: „Ananịas!“ Er sagte: „Hier bin ich, Herr.“ 11 Der Herr sprach zu ihm: „Steh auf, geh in die Straße, die man die Gerade nennt, und such im Haus des Judas einen Mann namens Saulus aus Tạrsus.+ Denn siehe, er betet, 12 und in einer Vision* hat er einen Mann namens Ananịas eintreten und ihm die Hände auflegen sehen, damit er wieder sehend werde.“+ 13 Ananịas aber antwortete: „Herr, ich habe von vielen über diesen Mann gehört, wieviel Schaden er deinen Heiligen in Jerusalem zugefügt hat.
<G-vec00258-002-s616><arise.aufstehen><en> 10 And there was a certain disciple at Damascus, named Ananias; and to him said the Lord in a vision, Ananias. And he said, Behold, I am here, Lord. 11 And the Lord said unto him, Arise, and go into the street which is called Straight, and enquire in the house of Judas for one called Saul, of Tarsus: for, behold, he prayeth, 12 And hath seen in a vision a man named Ananias coming in, and putting his hand on him, that he might receive his sight.
<G-vec00258-002-s617><arise.aufstehen><de> Steh auf, nimm den Knaben und führe ihn an deiner Hand; denn ich will ihn zum großen Volk machen.
<G-vec00258-002-s617><arise.aufstehen><en> Arise, lift up the lad, and hold him in thine hand; for I will make him a great nation.
<G-vec00258-002-s618><arise.aufstehen><de> Jeder von uns möge an den eigenen Tod denken und möge sich jenen Augenblick vorstellen, der kommen wird, wenn Jesus uns an der Hand fassen und zu uns sagen wird: »Komm, komm mit mir, steh auf.« Dort wird die Hoffnung enden und zur Wirklichkeit werden, zur Wirklichkeit des Lebens.
<G-vec00258-002-s618><arise.aufstehen><en> Each of us think about our own death, and imagine that moment that will come, when Jesus will take us by the hand and tell us: “Come, come with me, arise”. There, hope will end and reality will abide, the reality of life.
<G-vec00258-002-s619><arise.aufstehen><de> Steh auf, fahr zu den Kittäern - / auch dort findest du keine Ruhe.
<G-vec00258-002-s619><arise.aufstehen><en> Arise, pass over to Cyprus; even there you will find no rest." 13.
<G-vec00258-002-s620><arise.aufstehen><de> 6 Aber ich, Abraham, und aLot, meines Bruders Sohn, beteten zum Herrn, und der bHerr erschien mir und sprach zu mir: Steh auf und nimm Lot mit dir; denn ich habe vor, dich aus dem Land Haran fortzunehmen und aus dir einen geistlichen Diener zu machen, der meinen cNamen in einem dfremden Land trägt, das ich deinen Nachkommen nach dir als immerwährenden Besitz geben werde, wenn sie auf meine Stimme hören.
<G-vec00258-002-s620><arise.aufstehen><en> 6 But I, Abraham, and Lot, my brother’s son, prayed unto the Lord, and the Lord aappeared unto me, and said unto me: Arise, and take Lot with thee; for I have purposed to take thee away out of Haran, and to make of thee a bminister to bear my cname in a strange dland which I will give unto thy seed after thee for an everlasting possession, when they hearken to my voice.
<G-vec00258-002-s621><arise.aufstehen><de> Im Hause des Jaïrus angekommen, schickt Jesus die weinenden Menschen hinaus – da waren auch die Klageweiber, die laut schrien – und betritt den Raum nur mit den Eltern und den drei Jüngern, und an die Verstorbene gerichtet sagt er: »Mädchen, ich sage dir, steh auf!« (V.41).
<G-vec00258-002-s621><arise.aufstehen><en> When they arrive at Jairus’ house, Jesus sends out the people who were weeping — there were also women mourners who were wailing loudly — and He enters the room with just the parents and the three disciples, and speaking to the dead girl He says: “Little girl, I say to you, arise” (v. 41).
<G-vec00258-002-s622><arise.aufstehen><de> Der Herr aber sprach zu mir: Steh auf und geh nach Damaskus, und dort wird dir von allem gesagt werden, was dir zu tun verordnet ist.
<G-vec00258-002-s622><arise.aufstehen><en> And the Lord said unto me, Arise, and go into Damascus; and there it shall be told thee of all things which are appointed for thee to do.
<G-vec00258-002-s623><arise.aufstehen><de> „Steh auf, o Frau, leuchte, denn dein Licht ist gekommen, und die Herrlichkeit Jehovas selbst ist über dir aufgeleuchtet“ (JESAJA 60:1).
<G-vec00258-002-s623><arise.aufstehen><en> “Arise, O woman, shed forth light, for your light has come and upon you the very glory of Jehovah has shone forth.”—ISAIAH 60:1.
<G-vec00258-002-s624><arise.aufstehen><de> Steh auf und rufe seinen Namen an und lass dich taufen und deine Sünden abwaschen“ (Apostelgeschichte 22,16).
<G-vec00258-002-s624><arise.aufstehen><en> Arise and be baptized, and wash away your sins, calling on the name of the Lord” (Acts 22:16).
<G-vec00323-002-s057><stand.aufstehen><de> Ich habe gelernt, etwas bestimmt abzulehnen, zu widerstehen, aufzustehen und auf Distanz zu gehen.
<G-vec00323-002-s057><stand.aufstehen><en> I learned to determinedly reject, resist, stand up, and distance myself.
<G-vec00323-002-s058><stand.aufstehen><de> Danach zwingt sie ihn, aufzustehen und seine Beine zu spreizen.
<G-vec00323-002-s058><stand.aufstehen><en> Then she forces him to stand up and spread his legs.
<G-vec00323-002-s059><stand.aufstehen><de> Dann bat er mich, aufzustehen und meine Augen zu öffnen.
<G-vec00323-002-s059><stand.aufstehen><en> Then he asked me to stand up and open my eyes.
<G-vec00323-002-s060><stand.aufstehen><de> Investieren Sie in einen Stehpult, oder stellen Sie sich einen Wecker, der Sie daran erinnert einen Spaziergang zu machen oder alle 30 Minuten aufzustehen.
<G-vec00323-002-s060><stand.aufstehen><en> Invest in a standing desk, or set up a timer for reminders to go for a walk or simply stand every 30 minutes.
<G-vec00323-002-s061><stand.aufstehen><de> Die EU hat ein Versprechen gegeben, die Religionsfreiheit und Glaubensfreiheit zu schützen und sie hat versprochen, gegen Folter aufzustehen, indem sie die internationale Menschenrechtskonvention unterzeichnet hat.
<G-vec00323-002-s061><stand.aufstehen><en> To begin with, the EU made a promise to safeguard the freedom of religion and belief and has promised to stand up against torture by signing the International Convention on Human Rights.
<G-vec00323-002-s062><stand.aufstehen><de> Er versuchte aufzustehen und stützte sich dabei auf seinen rechten Arm, da er dabei seinen linken Arm samt einem Teil seines Brustkorbes verloren hatte.
<G-vec00323-002-s062><stand.aufstehen><en> He tried to stand up by leaning on his right arm because he had lost his left arm and part of his ribs.
<G-vec00323-002-s063><stand.aufstehen><de> Es ist äußerst unbequem, wenn man gezwungen ist aufzustehen und auf den nicht verstellbaren Kamera-LCD oder durch den optischen Sucher zu blicken, um den Bildausschnitt und/oder die Bildkomposition zu kontrollieren.
<G-vec00323-002-s063><stand.aufstehen><en> It is extremely uncomfortable if the photographer is forced to stand up and look at the immovable camera LCD or through the optical viewfinder in order to check the display window and/or the image composition.
<G-vec00323-002-s064><stand.aufstehen><de> Denn es ist schwer, aufzustehen und zum Sessel zurückzukehren.
<G-vec00323-002-s064><stand.aufstehen><en> Because it is hard to stand up and return to the easy chair.
<G-vec00323-002-s065><stand.aufstehen><de> Es ist eine Verpflichtung, aufzustehen und Widerstand gegen Atomwaffen zu leisten, unabhängig davon, in wessen Besitz sie sind.
<G-vec00323-002-s065><stand.aufstehen><en> It is a must to stand up and struggle against nuclear weapons regardless of whoever owns them.
<G-vec00323-002-s066><stand.aufstehen><de> Wir sind hier, um gemeinsam mit den Menschen die sich in Tervola und auch anderswo gegen Atomkraft erheben, gegen die atomare Gefahr für unsere Zukunft aufzustehen", sagt Ruta Vimba aus Lettland.
<G-vec00323-002-s066><stand.aufstehen><en> We are here to stand with the people of Tervola, as we stand with all people opposing the nuclear threat to our future” said Ruta Vimba from Latvia.
<G-vec00323-002-s067><stand.aufstehen><de> Man denkt während des Schlafens darüber nach, aufzustehen um diese Handlungen zu erledigen.
<G-vec00323-002-s067><stand.aufstehen><en> One thinks during the sleeping about to stand up and do these actions.
<G-vec00323-002-s068><stand.aufstehen><de> Dank der neuen Aktivitätserinnerung kann dich die StepsApp jetzt daran erinnern, aufzustehen um dich zu bewegen, wenn du in letzter Zeit zu lange gesessen hast.
<G-vec00323-002-s068><stand.aufstehen><en> Activity reminder: You can now get a reminder to stand up and move, if you’ve been sitting too much recently.
<G-vec00323-002-s069><stand.aufstehen><de> Du musst lernen, selber aufzustehen.
<G-vec00323-002-s069><stand.aufstehen><en> You have to learn to stand up by yourself.
<G-vec00323-002-s070><stand.aufstehen><de> Sie hat sich geweigert, von ihrem Platz im Bus aufzustehen.
<G-vec00323-002-s070><stand.aufstehen><en> She refused to stand up from her (segregated) bus seat.
<G-vec00323-002-s071><stand.aufstehen><de> Seitdem hat sie starke Schmerzen beim Atmen oder beim Versuch aufzustehen.
<G-vec00323-002-s071><stand.aufstehen><en> Since then she has suffered from severe pain when she breathes or tries to stand up.
<G-vec00323-002-s072><stand.aufstehen><de> Ihr habt Angst davor, aufzustehen und eure Wahrheit zu sagen.
<G-vec00323-002-s072><stand.aufstehen><en> You are afraid to stand up and speak your truth.
<G-vec00323-002-s073><stand.aufstehen><de> Durch die vielen Menschen im Raum war es unmöglich, umher zu laufen oder aufzustehen.
<G-vec00323-002-s073><stand.aufstehen><en> Because there were too many people in the room, it was impossible to walk around or even to stand up.
<G-vec00323-002-s074><stand.aufstehen><de> Der Hund ist schon ganz fähig, für sich selbst und für Sie aufzustehen, wenn nötig.
<G-vec00323-002-s074><stand.aufstehen><en> The dog is already quite capable to stand up for itself and for you if necessary.
<G-vec00323-002-s075><stand.aufstehen><de> Es ist eine Frage der Ethik, des Gewissens und der Verantwortung, gegen das Leiden der Tiere für Unterhaltungszwecke aufzustehen.
<G-vec00323-002-s075><stand.aufstehen><en> It is a question of ethics, conscience and responsibility to stand against the suffering of animals for our entertainment.
<G-vec00205-003-s057><stand_up.aufstehen><de> Ich habe gelernt, etwas bestimmt abzulehnen, zu widerstehen, aufzustehen und auf Distanz zu gehen.
<G-vec00205-003-s057><stand_up.aufstehen><en> I learned to determinedly reject, resist, stand up, and distance myself.
<G-vec00205-003-s058><stand_up.aufstehen><de> Danach zwingt sie ihn, aufzustehen und seine Beine zu spreizen.
<G-vec00205-003-s058><stand_up.aufstehen><en> Then she forces him to stand up and spread his legs.
<G-vec00205-003-s059><stand_up.aufstehen><de> Dann bat er mich, aufzustehen und meine Augen zu öffnen.
<G-vec00205-003-s059><stand_up.aufstehen><en> Then he asked me to stand up and open my eyes.
<G-vec00205-003-s060><stand_up.aufstehen><de> Investieren Sie in einen Stehpult, oder stellen Sie sich einen Wecker, der Sie daran erinnert einen Spaziergang zu machen oder alle 30 Minuten aufzustehen.
<G-vec00205-003-s060><stand_up.aufstehen><en> Invest in a standing desk, or set up a timer for reminders to go for a walk or simply stand every 30 minutes.
<G-vec00205-003-s061><stand_up.aufstehen><de> Die EU hat ein Versprechen gegeben, die Religionsfreiheit und Glaubensfreiheit zu schützen und sie hat versprochen, gegen Folter aufzustehen, indem sie die internationale Menschenrechtskonvention unterzeichnet hat.
<G-vec00205-003-s061><stand_up.aufstehen><en> To begin with, the EU made a promise to safeguard the freedom of religion and belief and has promised to stand up against torture by signing the International Convention on Human Rights.
<G-vec00205-003-s062><stand_up.aufstehen><de> Er versuchte aufzustehen und stützte sich dabei auf seinen rechten Arm, da er dabei seinen linken Arm samt einem Teil seines Brustkorbes verloren hatte.
<G-vec00205-003-s062><stand_up.aufstehen><en> He tried to stand up by leaning on his right arm because he had lost his left arm and part of his ribs.
<G-vec00205-003-s063><stand_up.aufstehen><de> Es ist äußerst unbequem, wenn man gezwungen ist aufzustehen und auf den nicht verstellbaren Kamera-LCD oder durch den optischen Sucher zu blicken, um den Bildausschnitt und/oder die Bildkomposition zu kontrollieren.
<G-vec00205-003-s063><stand_up.aufstehen><en> It is extremely uncomfortable if the photographer is forced to stand up and look at the immovable camera LCD or through the optical viewfinder in order to check the display window and/or the image composition.
<G-vec00205-003-s064><stand_up.aufstehen><de> Denn es ist schwer, aufzustehen und zum Sessel zurückzukehren.
<G-vec00205-003-s064><stand_up.aufstehen><en> Because it is hard to stand up and return to the easy chair.
<G-vec00205-003-s065><stand_up.aufstehen><de> Es ist eine Verpflichtung, aufzustehen und Widerstand gegen Atomwaffen zu leisten, unabhängig davon, in wessen Besitz sie sind.
<G-vec00205-003-s065><stand_up.aufstehen><en> It is a must to stand up and struggle against nuclear weapons regardless of whoever owns them.
<G-vec00205-003-s066><stand_up.aufstehen><de> Wir sind hier, um gemeinsam mit den Menschen die sich in Tervola und auch anderswo gegen Atomkraft erheben, gegen die atomare Gefahr für unsere Zukunft aufzustehen", sagt Ruta Vimba aus Lettland.
<G-vec00205-003-s066><stand_up.aufstehen><en> We are here to stand with the people of Tervola, as we stand with all people opposing the nuclear threat to our future” said Ruta Vimba from Latvia.
<G-vec00205-003-s067><stand_up.aufstehen><de> Man denkt während des Schlafens darüber nach, aufzustehen um diese Handlungen zu erledigen.
<G-vec00205-003-s067><stand_up.aufstehen><en> One thinks during the sleeping about to stand up and do these actions.
<G-vec00205-003-s068><stand_up.aufstehen><de> Dank der neuen Aktivitätserinnerung kann dich die StepsApp jetzt daran erinnern, aufzustehen um dich zu bewegen, wenn du in letzter Zeit zu lange gesessen hast.
<G-vec00205-003-s068><stand_up.aufstehen><en> Activity reminder: You can now get a reminder to stand up and move, if you’ve been sitting too much recently.
<G-vec00205-003-s069><stand_up.aufstehen><de> Du musst lernen, selber aufzustehen.
<G-vec00205-003-s069><stand_up.aufstehen><en> You have to learn to stand up by yourself.
<G-vec00205-003-s070><stand_up.aufstehen><de> Sie hat sich geweigert, von ihrem Platz im Bus aufzustehen.
<G-vec00205-003-s070><stand_up.aufstehen><en> She refused to stand up from her (segregated) bus seat.
<G-vec00205-003-s071><stand_up.aufstehen><de> Seitdem hat sie starke Schmerzen beim Atmen oder beim Versuch aufzustehen.
<G-vec00205-003-s071><stand_up.aufstehen><en> Since then she has suffered from severe pain when she breathes or tries to stand up.
<G-vec00205-003-s072><stand_up.aufstehen><de> Ihr habt Angst davor, aufzustehen und eure Wahrheit zu sagen.
<G-vec00205-003-s072><stand_up.aufstehen><en> You are afraid to stand up and speak your truth.
<G-vec00205-003-s073><stand_up.aufstehen><de> Durch die vielen Menschen im Raum war es unmöglich, umher zu laufen oder aufzustehen.
<G-vec00205-003-s073><stand_up.aufstehen><en> Because there were too many people in the room, it was impossible to walk around or even to stand up.
<G-vec00205-003-s074><stand_up.aufstehen><de> Der Hund ist schon ganz fähig, für sich selbst und für Sie aufzustehen, wenn nötig.
<G-vec00205-003-s074><stand_up.aufstehen><en> The dog is already quite capable to stand up for itself and for you if necessary.
<G-vec00205-003-s075><stand_up.aufstehen><de> Es ist eine Frage der Ethik, des Gewissens und der Verantwortung, gegen das Leiden der Tiere für Unterhaltungszwecke aufzustehen.
<G-vec00205-003-s075><stand_up.aufstehen><en> It is a question of ethics, conscience and responsibility to stand against the suffering of animals for our entertainment.
<G-vec00749-002-s116><arise.aufstehen><de> 6 Wegen der gewalttätigen Behandlung der Elenden, wegen des Seufzens der Armen will ich nun aufstehen, spricht der HERR; ich will in Sicherheit stellen den, gegen den man schnaubt.
<G-vec00749-002-s116><arise.aufstehen><en> 5. For the oppression of the poor, for the sighing of the needy, now will I arise, says the LORD; I will set him in safety from him that sneers at him.
<G-vec00749-002-s117><arise.aufstehen><de> 24 Denn aufstehen werden falsche Gesalbte und falsche Propheten und werden geben große Zeichen und Wunder, so daß verführen, wenn möglich, auch die Auserwählten.
<G-vec00749-002-s117><arise.aufstehen><en> (24) For there shall arise false Christs, and false prophets, and shall shew great signs and wonders; insomuch that, if it were possible, they shall deceive the very elect.
<G-vec00749-002-s118><arise.aufstehen><de> 12:6 Wegen der gewalttätigen Behandlung der Elenden, wegen des Seufzens der Armen will ich nun aufstehen, spricht der HERR; ich will in Sicherheit stellen den, gegen den man schnaubt.
<G-vec00749-002-s118><arise.aufstehen><en> 12:5 "Because of the oppression of the weak and because of the groaning of the needy, I will now arise," says Yahweh; "I will set him in safety from those who malign him."
<G-vec00749-002-s119><arise.aufstehen><de> * Nirgendwo in den 66 Schriften der Bibel ist davon die Rede, daß ein Prophet arabischer Abstammung aufstehen werde.
<G-vec00749-002-s119><arise.aufstehen><en> * Nowhere in the 66 books of the Bible is there mention that a prophet of Arabic descent would arise.
<G-vec00749-002-s121><arise.aufstehen><de> Als Paulus die Gemeinde in Ephesus verlassen hatte und später die Ältesten zusammenrief sagte er, als er sie Gott anbefahl: «Aus eurer eigenen Mitte werden Männer aufstehen, die verkehrte Dinge reden, um die Jünger abzuziehen in ihre Gefolgschaft» (Apg.
<G-vec00749-002-s121><arise.aufstehen><en> When Paul left that church at Ephesus and met the elders, as he was committing them to God, he said: "From among your own selves shall men arise, speaking perverse things, to draw away the disciples after them" (Acts 20:30).
<G-vec00749-002-s122><arise.aufstehen><de> 7 So spricht der HERR, der Erlöser Israels, sein Heiliger, zu der verachteten Seele, zu dem Volk, das man verabscheut, zu dem Knecht, der unter den Tyrannen ist: Könige sollen sehen und aufstehen, und Fürsten sollen niederfallen um des HERRN willen, der treu ist, um des Heiligen in Israel willen, der dich erwählt hat.
<G-vec00749-002-s122><arise.aufstehen><en> 7 Thus saith the Lord, the Redeemer of Israel, and his Holy One, to him whom man[2] Translatorís note: whom man...: or, that is despised in soul despiseth, to him whom the nation abhorreth, to a servant of rulers, Kings shall see and arise, princes also shall worship, because of the Lord that is faithful, and the Holy One of Israel, and he shall choose thee.
<G-vec00749-002-s124><arise.aufstehen><de> Denn in der griechischen Übersetzung des Originaltextes bei Nestle-Aland heißt es: "Denn aufstehen wird Volk gegen Volk und Reich gegen Reich" – also ganz ähnlich der Elberfelder Übersetzung.
<G-vec00749-002-s124><arise.aufstehen><en> For in the translation from the Greek of the original text in Nestle‒Aland we find: "For people will arise against people and kingdom against kingdom" – quite similar to the Elberfeld translation.
<G-vec00749-002-s125><arise.aufstehen><de> 49:7 So spricht Jehova, der Erlöser Israels, sein Heiliger, zu dem von jedermann Verachteten, zu dem Abscheu der Nation, zu dem Knechte der Herrscher: Könige werden es sehen und aufstehen, Fürsten, und sie werden sich niederwerfen, um Jehovas willen, der treu ist, des Heiligen Israels, der dich erwählt hat.
<G-vec00749-002-s125><arise.aufstehen><en> 49:7 Thus says the Jehovah, the Redeemer of Israel, and his Holy One, to him whom man despises, to him whom the nation detests, to a servant of rulers, Kings shall see and arise, princes also shall worship, because of the Jehovah that is faithful, and the Holy One of Israel, and he shall choose you.
<G-vec00749-002-s126><arise.aufstehen><de> 41Männer von Ninive werden aufstehen im Gericht mit diesem Geschlecht und werden es verdammen, denn sie taten Buße auf die Predigt Jonas'; und siehe, mehr als Jonas ist hier.
<G-vec00749-002-s126><arise.aufstehen><en> 41 The men of Nineveh shall arise in judgment with this generation, and they shall condemn it. For, at the preaching of Jonah, they repented. And behold, there is a greater than Jonah here.
<G-vec00749-002-s127><arise.aufstehen><de> 20:30 Und aus eurer eigenen Mitte werden Männer aufstehen, die verkehrte Dinge reden, um die Jünger abzuziehen hinter sich her.
<G-vec00749-002-s127><arise.aufstehen><en> 20:30 and from among your own selves shall men arise, speaking perverse things, to draw away the disciples after them.
<G-vec00749-002-s128><arise.aufstehen><de> 10 Der Herr aber spricht: »Jetzt will ich aufstehen, ich will mich aufrichten und mich jetzt erheben.
<G-vec00749-002-s128><arise.aufstehen><en> 10 “Now I will arise,” says the Lord, “now I will lift myself up; now I will be exalted.
<G-vec00749-002-s129><arise.aufstehen><de> 20 Und es wird an seiner Stelle jemand aufstehen, der einen Eintreiber [von Abgaben] durch die Herrlichkeit des Königreichs ziehen läßt; aber in wenigen Tagen wird er zerschmettert werden, und zwar weder durch Zorn noch durch Krieg.
<G-vec00749-002-s129><arise.aufstehen><en> 20 "Then in his place one will arise who will send an oppressor through the Jewel of his kingdom; yet within a few days he will be shattered, though not in anger nor in battle.
<G-vec00749-002-s130><arise.aufstehen><de> Denn es werden falsche Christusse und falsche Propheten aufstehen und werden große Zeichen und Wunder tun, um so, wenn möglich, selbst die Auserwählten irrezuführen.
<G-vec00749-002-s130><arise.aufstehen><en> For false Christs and false prophets will arise and will show great signs and wonders, so as to mislead, if possible, even the elect.
<G-vec00749-002-s131><arise.aufstehen><de> Manche von uns sind womöglich der Meinung, die Zeit für das Gebet sei morgens nach dem Aufstehen oder abends nach getaner Arbeit vor dem Schlafengehen, und es gebe keine andere Zeit dafür.
<G-vec00749-002-s131><arise.aufstehen><en> Some of us may have the idea that the season of prayer is when we arise in the morning, and when we are about to retire at night when our work is done, and that there is no other season for prayer.
<G-vec00749-002-s132><arise.aufstehen><de> Matthäus 24, Vers 11 Und viele falsche Propheten werden aufstehen und werden viele verführen.
<G-vec00749-002-s132><arise.aufstehen><en> Matthew 24, verse 11 And many false prophets will arise, and shall deceive many.
<G-vec00749-002-s133><arise.aufstehen><de> 49:7 So spricht der HERR, der Erlöser Israels, sein Heiliger, zu der verachteten Seele, zu dem Volk, das man verabscheut, zu dem Knecht, der unter den Tyrannen ist: Könige sollen sehen und aufstehen, und Fürsten sollen niederfallen um des HERRN willen, der treu ist, um des Heiligen in Israel willen, der dich erwählt hat.
<G-vec00749-002-s133><arise.aufstehen><en> 49:7 his Holy One, to him whom man despises, to him whom the nation detests, to a servant of rulers, Kings shall see and arise, princes also shall worship, because of the LORD that is faithful, and the Holy One of Israel, and he shall choose you.
<G-vec00749-002-s134><arise.aufstehen><de> 49:7 So spricht der HERR, der Erlöser Israels, sein Heiliger, zu der verachteten Seele, zu dem Volk, des man Greuel hat, zu dem Knechte, der unter den Tyrannen ist: Könige sollen sehen und aufstehen, und Fürsten sollen anbeten um des HERRN willen, der treu ist, um des Heiligen in Israel willen, der dich erwählet hat.
<G-vec00749-002-s134><arise.aufstehen><en> 7 Thus saith Jehovah, The Redeemer of Israel, His Holy One, To the contemptible in the soul, To the abhorred nation, To the servant of rulers; Kings shall see, And princes shall arise, And shall worship for the sake of Jehovah; For faithful is the Holy One of Israel, who hath chosen thee.
<G-vec00749-002-s625><arise.aufstehen><de> 24 Auf daß ihr aber wisset, daß der Sohn des Menschen Gewalt hat auf der Erde Sünden zu vergeben... sprach er zu dem Gelähmten: Ich sage dir, stehe auf und nimm dein Bettlein auf und gehe nach deinem Hause.
<G-vec00749-002-s625><arise.aufstehen><en> 24But that ye may know that the Son of man hath power upon earth to forgive sins, (he said unto the sick of the palsy,) I say unto thee, Arise, and take up thy couch, and go into thine house.
<G-vec00749-002-s626><arise.aufstehen><de> In Psalm 68 lesen wir: „Es stehe Gott auf, daß seine Feinde zerstreut werden, und die ihn hassen, vor ihm fliehen.
<G-vec00749-002-s626><arise.aufstehen><en> In Psalm 68 we read, "Let God arise, let his enemies be scattered: let them also that hate him flee before him.
<G-vec00749-002-s627><arise.aufstehen><de> 2:11 Ich sage dir, stehe auf, nimm dein Ruhebett auf und geh nach deinem Hause.
<G-vec00749-002-s627><arise.aufstehen><en> 2:11 I say to thee, Arise, and take up thy bed, and go into thy house.
<G-vec00749-002-s628><arise.aufstehen><de> 31 H935 Und auch er H6213 bereitete ein schmackhaftes Gericht und brachte es zu H1 seinem Vater H559 und sprach H1 zu seinem Vater H1: Mein Vater H6965 stehe auf H398 und esse H6718 von dem Wildbret H1121 seines Sohnes H5315, damit deine Seele H1288 mich segne .
<G-vec00749-002-s628><arise.aufstehen><en> 31 H6213 And he also had made H4303 savory meat, H935 and brought it H1 unto his father, H559 and said H1 unto his father, H1 Let my father H6965 arise, H398 and eat H1121 of his son's H6718 venison, H5315 that your soul H1288 may bless me.
<G-vec00749-002-s629><arise.aufstehen><de> Der HERR aber sprach zu mir: Stehe auf und gehe gen Damaskus; da wird man dir sagen von allem, was dir zu tun verordnet ist.
<G-vec00749-002-s629><arise.aufstehen><en> The Lord said to me, 'Arise, and go into Damascus. There you will be told about all things which are appointed for you to do.'
<G-vec00749-002-s630><arise.aufstehen><de> Denn Gott hat auf die Stimme des Knaben gehört, da, wo er ist; 18 stehe auf, nimm den Knaben und fasse ihn mit deiner Hand, denn ich will ihn zu einer großen Nation machen.
<G-vec00749-002-s630><arise.aufstehen><en> Do not fear, God has heard the voice of the lad where he is. 18 Arise, lift up the lad and hold him in your hand, because I will make him a great nation.
<G-vec00749-002-s631><arise.aufstehen><de> 8 Stehe auf, o Gott, richte die Erde!Denn du sollst zum Erbteil haben alle Nationen.
<G-vec00749-002-s631><arise.aufstehen><en> 8 Arise, God, judge the earth, for you inherit all of the nations.
<G-vec00749-002-s632><arise.aufstehen><de> 31 Und auch er bereitete ein schmackhaftes Gericht und brachte es zu seinem Vater und sprach zu seinem Vater: Mein Vater stehe auf und esse von dem Wildbret seines Sohnes, damit deine Seele mich segne.
<G-vec00749-002-s632><arise.aufstehen><en> 31 And he also made savory food, and brought it unto his father. And he said unto his father, Let my father arise, and eat of his son's venison, that thy soul may bless me.
<G-vec00749-002-s633><arise.aufstehen><de> 30 Als nun Isaak vollendet hatte den Segen über Jakob, und Jakob kaum hinausgegangen war von seinem Vater Isaak, da kam Esau, sein Bruder, von seiner Jagd 31 und machte auch ein Essen; und trug's hinein zu seinem Vater und sprach zu ihm: Stehe auf, mein Vater, und iß von dem Wildbret deines Sohnes, daß mich deine Seele segne.
<G-vec00749-002-s633><arise.aufstehen><en> 27:30 It happened, as soon as Isaac had made an end of blessing Jacob, and Jacob had just gone out from the presence of Isaac his father, that Esau his brother came in from his hunting. 27:31 He also made savory food, and brought it to his father. He said to his father, "Let my father arise, and eat of his son`s venison, that your soul may bless me."
<G-vec00749-002-s634><arise.aufstehen><de> 13 Und als sie fortgingen, siehe, da erschien der Engel des Herrn Joseph im Traum und sprach: Stehe auf, nimm das Kindlein und seine Mutter und fliehe nach Ägypten und sei dort, bis ich dir das Wort bringe: denn Herodes wird das junge Kind suchen, um es zu töten.
<G-vec00749-002-s634><arise.aufstehen><en> 13 And when they were departed, behold, the angel of the Lord appeareth to Joseph in a dream, saying, Arise, and take the young child and his mother, and flee into Egypt, and be thou there until I bring thee word: for Herod will seek the young child to destroy him.
<G-vec00749-002-s635><arise.aufstehen><de> 24 Auf daß ihr aber wisset, daß der Sohn des Menschen Gewalt hat auf der Erde, Sünden zu vergeben... sprach er zu dem Gelähmten: Ich sage dir, stehe auf und nimm dein Bettlein auf und geh nach deinem Hause.
<G-vec00749-002-s635><arise.aufstehen><en> 24 But that all of you may know that the Son of man has power upon earth to forgive sins, (he said unto the sick of the palsy,) I say unto you, Arise, and take up your couch, and go into your house.
<G-vec00749-002-s636><arise.aufstehen><de> 19Und er sprach zu ihm: Stehe auf, gehe hin; dein Glaube hat dir geholfen.
<G-vec00749-002-s636><arise.aufstehen><en> And he said unto him: Arise, and go thy way, thy faith hath saved thee.
<G-vec00749-002-s637><arise.aufstehen><de> 9 Und der HERR sprach in derselben Nacht zu ihm: Stehe auf und gehe hinab zum Lager; denn ich habe es in deine Hände gegeben.
<G-vec00749-002-s637><arise.aufstehen><en> 9And the same night, the LORD said to him, Arise, get down to the host, for I have delivered it into your hand.
<G-vec00749-002-s638><arise.aufstehen><de> 8:26 Aber der Engel des HERRN redete zu Philippus und sprach: Stehe auf und gehe gegen Mittag auf die Straße, die von Jerusalem hinabgehet gen Gaza, die da wüste ist.
<G-vec00749-002-s638><arise.aufstehen><en> 8:26 Now an angel of the Lord spoke to Philip, saying: Arise, go towards the south, to the way that goeth down from Jerusalem into Gaza: this is desert.
<G-vec00749-002-s639><arise.aufstehen><de> 20 Stehe aber auf, geh hinab und ziehe mit ihnen, ohne irgend zu zweifeln, weil ich sie gesandt habe.
<G-vec00749-002-s639><arise.aufstehen><en> 20 But arise, get down, and go with them, doubting nothing; for I have sent them.”
<G-vec00749-002-s640><arise.aufstehen><de> 5:24 Auf daß ihr aber wisset, daß des Menschen Sohn Macht hat auf Erden Sünden zu vergeben, sprach er zu dem Gichtbrüchigen: Ich sage dir, stehe auf und hebe dein Bettlein auf; und gehe heim.
<G-vec00749-002-s640><arise.aufstehen><en> 5:24 But that ye may know that the Son of man has power on earth to forgive sins, he said to the paralysed man, I say to thee, Arise, and take up thy little couch and go to thine house.
<G-vec00749-002-s641><arise.aufstehen><de> 31Und auch er bereitete ein schmackhaftes Gericht und brachte es zu seinem Vater und sprach zu seinem Vater: Mein Vater stehe auf und esse von dem Wildbret seines Sohnes, damit deine Seele mich segne.
<G-vec00749-002-s641><arise.aufstehen><en> 30Isaac had scarce ended his words, when Jacob being now gone out abroad, Esau came, 31And brought in to his father meats made of what he had taken in hunting, saying: Arise, my father, and eat of thy son's venison; that thy soul may bless me.
<G-vec00749-002-s642><arise.aufstehen><de> Auf daß ihr aber wisset, daß des Menschen Sohn Macht habe auf Erden, die Sünden zu vergeben (sprach er zu dem Gichtbrüchigen): Stehe auf, heb dein Bett auf und gehe heim!” Und er stand auf und ging heim.
<G-vec00749-002-s642><arise.aufstehen><en> But that ye may know that the Son of man hath power on earth to forgive sins, (then saith he to the sick of the palsy,) Arise, take up thy bed, and go unto thine house.
<G-vec00749-002-s643><arise.aufstehen><de> Der HERR sprach zu ihm: Stehe auf und gehe in die Stadt; da wird man dir sagen, was du tun sollst.
<G-vec00749-002-s643><arise.aufstehen><en> And the Lord said to him, Arise, and go into the city, and it shall be told thee what thou must do.
<G-vec00979-002-s038><stand_up.aufstehen><de> 14 Und in jenen Zeiten werden viele gegen den König des Südens aufstehen; und Gewalttätige deines Volkes werden sich erheben, um das Gesicht zu erfüllen, und sie werden zu Fall kommen.
<G-vec00979-002-s038><stand_up.aufstehen><en> 11:14 And in those times shall many stand up against the king of the south; and the violent of thy people will exalt themselves to establish the vision; but they shall fall.
<G-vec00979-002-s039><stand_up.aufstehen><de> Er half ihr beim Aufstehen und sofort verschwand das Fieber.
<G-vec00979-002-s039><stand_up.aufstehen><en> He helped her to stand up and her fever left her immediately.
<G-vec00979-002-s040><stand_up.aufstehen><de> Wer aufgerufen wurde, musste aufstehen und aufs Feld gehen.
<G-vec00979-002-s040><stand_up.aufstehen><en> The person whose name was called out, had to stand up and go into the field.
<G-vec00979-002-s041><stand_up.aufstehen><de> Die Fischerboote zeichnen sich insbesondere durch ihre Stabilität aus - das Aufstehen im Boot ist sicher.
<G-vec00979-002-s041><stand_up.aufstehen><en> Their main feature is stability: it is safe to stand up in them.
<G-vec00979-002-s042><stand_up.aufstehen><de> Rollstuhlfahrende, die besonders große Rollstühle haben und/oder nicht aufstehen können, beachten außerdem bitte die Hinweise zur Barrierefreiheit der Aussichtsplattform.
<G-vec00979-002-s042><stand_up.aufstehen><en> People with particularly large wheelchairs and/or those unable to stand up should also please read the information on Disabled access to the observation platform.
<G-vec00979-002-s043><stand_up.aufstehen><de> 21 Und an seiner Statt wird ein Verachteter aufstehen, auf den man nicht die Würde des Königtums legen wird; und er wird unversehens kommen und durch Schmeicheleien sich des Königtums bemächtigen.
<G-vec00979-002-s043><stand_up.aufstehen><en> 21 And in his estate shall stand up a vile person, to whom they shall not give the honor of the kingdom: but he shall come in peaceably, and obtain the kingdom by flatteries.
<G-vec00979-002-s044><stand_up.aufstehen><de> Jesus fuhr fort: "Ja, ja, die Leute von Ninive werden auch aufstehen mit diesem Geschlechte am Tage des jüngsten Gerichtes und werden es verdammen; denn sie taten Buße nach der Predigt des Jonas.
<G-vec00979-002-s044><stand_up.aufstehen><en> The men of Nineveh will stand up at the judgment with this generation and condemn it; for they repented at the preaching of Jonah, and now one greater than Jonah is here.
<G-vec00979-002-s045><stand_up.aufstehen><de> Plötzlich erkenne ich, dass ich aufstehen und gehen sollte, um den vielen anderen Praktizierenden folgen zu können.
<G-vec00979-002-s045><stand_up.aufstehen><en> Then I suddenly realized that I should stand up and walk to follow the many other practitioners.
<G-vec00979-002-s046><stand_up.aufstehen><de> Die Fallenergie wird im Fluss gehalten und zum direkten Aufstehen genutzt, wobei das Abschlagen nur flüchtig erfolgt, da man weiterrollt und letztendlich wieder steht.
<G-vec00979-002-s046><stand_up.aufstehen><en> The fall energy will keep flowing and used to stand up directly, the hitting is only fleeting, because of the rolling movement and at last the stand up.
<G-vec00979-002-s047><stand_up.aufstehen><de> Damit Du bequem sitzen und aufstehen kannst, solltest Du für die Laufwege und Stühle etwa einen Meter Platz lassen.
<G-vec00979-002-s047><stand_up.aufstehen><en> So that you can sit comfortably and stand up, you should leave about one meter of space for the walkways and chairs.
<G-vec00979-002-s048><stand_up.aufstehen><de> Lasse die Teilnehmer*innen aufstehen und alle Stühle oder anderen Hindernisse vom Boden wegräumen.
<G-vec00979-002-s048><stand_up.aufstehen><en> Have participants stand up and clear out any mess/chairs from the floor space.
<G-vec00979-002-s049><stand_up.aufstehen><de> Als nächstes solltest du schnell und mit viel Kraft aufstehen, als würdest du dich strecken.
<G-vec00979-002-s049><stand_up.aufstehen><en> Next, it is intended that you stand up quickly and with much force, just as if you were stretching.
<G-vec00979-002-s050><stand_up.aufstehen><de> Der Bewehrungskorb darf nicht auf der Sohle der Schlitzwand aufstehen; er wird deswegen an der Leitwand aufgehängt.
<G-vec00979-002-s050><stand_up.aufstehen><en> The reinforcing cage must not stand on the sole of the slot wall; He is therefore suspended from the wall.
<G-vec00979-002-s051><stand_up.aufstehen><de> Im Laufe des zweistündigen Konzerts wirkte er allerdings streckenweise irritiert, dass denn so gar niemand aufstehen und tanzen wollte.
<G-vec00979-002-s051><stand_up.aufstehen><en> In the course of the two hour concerts he seemed confused at times that nobody wanted to stand up and dance.
<G-vec00979-002-s052><stand_up.aufstehen><de> Der Beamte befindet sich unter dem gewalttätigen Gegner und muss sofort aufstehen.
<G-vec00979-002-s052><stand_up.aufstehen><en> The professional is underneath the violent opponent and must stand up immediately.
<G-vec00979-002-s053><stand_up.aufstehen><de> Am dritten Tag kam ein tschechischer Arzt und brüllte mich an, ich solle aufstehen, da ich mich jedoch nicht rühren konnte, riß er mich am Haar hoch und warf mich wieder zu Boden.
<G-vec00979-002-s053><stand_up.aufstehen><en> On the third day a Czech doctor came into the cell and shouted at me to stand up. Since I could not move, he pulled me up by the hair and threw me down again.
<G-vec00979-002-s054><stand_up.aufstehen><de> Das Projekt soll querschnittsgelähmten Patienten, mit einer Restkontrolle über die Beinmuskulatur, durch elektrische Anregung das Gehen von einigen Schritten oder das Aufstehen aus dem Rollstuhl ermöglichen.
<G-vec00979-002-s054><stand_up.aufstehen><en> The project is supposed to enable paraplegic patients with residual control over the leg musculature to walk a few steps or to stand up from their wheelchair by means of electrical stimulation.
<G-vec00979-002-s055><stand_up.aufstehen><de> Lassen Sie die Kinder aufstehen und das Spiel „Der Lehrer sagt“ spielen.
<G-vec00979-002-s055><stand_up.aufstehen><en> Have the children stand and play the game “Teacher Says.”
<G-vec00979-002-s056><stand_up.aufstehen><de> 41 Männer von Ninive werden aufstehen im Gericht mit diesem Geschlecht und werden es verdammen, denn sie taten Buße auf die Predigt Jonas'; und siehe, mehr als Jonas ist hier.
<G-vec00979-002-s056><stand_up.aufstehen><en> 41 The men of Nineveh will stand up at the judgment and condemn the people living today, because they repented at the preaching of Jonah.
