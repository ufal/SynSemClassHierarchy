<G-vec00257-002-s067><fail.ausfallen><de> Papierseekarten sind nach wie vor empfehlenswert; entsprechend sollte man auch wissen, wie ohne Bordelektronik navigiert wird, wenn die Bordelektronik unerwartet ausfällt.
<G-vec00257-002-s067><fail.ausfallen><en> Paper charts are still recommended; you should therefore also know how to navigate without on-board electronics, should these fail unexpectedly.
<G-vec00257-002-s068><fail.ausfallen><de> Zudem wurde der produktseitige Gleitring mit einer Messerschneide versehen, die als zusätzliche Absicherung dient, damit die Gleitringdichtung nicht kurzfristig bei einer mangelnden Spülung ausfällt.
<G-vec00257-002-s068><fail.ausfallen><en> A knife-edge is placed on the product-side seal face to provide an added margin of safety, ensuring that the mechanical seal does not fail due to insufficient flushing.
<G-vec00257-002-s069><fail.ausfallen><de> Ohne Test ist nicht vorhersagbar, ob die Messstelle bereits nach Tagen oder erst nach Jahren ausfällt.
<G-vec00257-002-s069><fail.ausfallen><en> It is impossible to predict without a test whether the measuring point will fail after just a few days or several years.
<G-vec00257-002-s070><fail.ausfallen><de> Ausgewählte Online TOC-Analyzer von METTLER TOLEDO bieten vorausschauende Diagnose mit Intelligent Sensor Management (ISM®), die dazu beiträgt, dass Ihr Sensor während des Betriebs nicht ausfällt.
<G-vec00257-002-s070><fail.ausfallen><en> Select on-line TOC analyzers from METTLER TOLEDO offer Intelligent Sensor Management (ISM®) predictive diagnostics that help to ensure your sensor will not fail during operation.
<G-vec00257-002-s071><fail.ausfallen><de> Dies ist im Grunde ein schneller Schalter, mit dem ein viel schnellerer Schalter ein- und ausgeschaltet werden kann, der häufig aufgrund von Temperaturschwankungen ausfällt.
<G-vec00257-002-s071><fail.ausfallen><en> This is basically a fast switch on a much faster switch that can turn off and on, which fail often due to temperature fluctuations.
<G-vec00257-002-s072><fail.ausfallen><de> Doppelte Lampen mit Wechsler gewährleisten auch dann eine kontinuierliche Projektion, wenn während der Präsentation eine Lampe ausfällt.
<G-vec00257-002-s072><fail.ausfallen><en> Top Funktioner Twin lamps with changer - ensures continued projection should lamp fail during your presentation
<G-vec00257-002-s073><fail.ausfallen><de> Während die kinetische Energie der Düsensysteme durch den Widerstand im flüssigen Medium tendenziell geringer ausfällt, können im getauchten Zustand Verfahren wie beispielsweise das Injektionsfluten oder die vielfältigen Möglichkeiten der besonderen Flutreinigungsverfahren (z.
<G-vec00257-002-s073><fail.ausfallen><en> Whereas the kinetic energy of jet systems has a lesser tendency to fail owing to the resistance in a liquid medium, in an immersed state methods such as injection flooding or the various options of special flood cleaning methods (e.g.
<G-vec00257-002-s074><fail.ausfallen><de> Die von REINER entwickelte Technik stellt sicher, dass die Tintendruckpatrone im laufenden Betrieb weder eintrocknet noch ausfällt.
<G-vec00257-002-s074><fail.ausfallen><en> The technology developed by REINER ensures that the ink cartridge does not dry out or fail while in operation.
<G-vec00257-002-s075><fail.ausfallen><de> Wenn Ihr Ladegerät ausfällt, haben wir in Octilus das Beste.
<G-vec00257-002-s075><fail.ausfallen><en> If your charger starts to fail, in Octilus we have the best.
<G-vec00257-002-s076><fail.ausfallen><de> Natalia ist verfügbar und nicht ausfällt, von Ihnen zu nehmen.
<G-vec00257-002-s076><fail.ausfallen><en> Natalia is available and does not fail to take from you.
<G-vec00257-002-s077><fail.ausfallen><de> Vorbeugende Wartung gibt dem Anwender die Sicherheit, dass er rechtzeitig eingreifen kann, bevor etwas passiert und die Anlage komplett ausfällt.
<G-vec00257-002-s077><fail.ausfallen><en> Predictive maintenance ensures that the user can intervene in time before something happens that causes a system to fail completely.
<G-vec00257-002-s078><fail.ausfallen><de> Mit dem Vier-Lampen-System kann der Projektor auch dann weiterlaufen, wenn eine Lampe ausfällt.
<G-vec00257-002-s078><fail.ausfallen><en> The four-lamp system allows the projector to keep working even if a lamp should fail.
<G-vec00280-002-s022><outweigh.ausfallen><de> Soweit negative Berichte über die Aufnahmesituation von Asylsuchenden sowie über unmenschliche und erniedrigende Behandlungen eines Erstaufnahmestaates darauf hinweisen, dass ein Antragssteller in einem solchen Land gegebenenfalls nicht sicher wäre, muss dem Antragsteller, der eine Abschiebeentscheidung anficht und der ein Interesse daran hat in dem Mitgliedstaat zu bleiben, im Rahmen einer umfassenden Interessenabwägung, die aufgrund des offenen Ausgangs der Hauptsacheentscheidung, zu seinen Gunsten ausfällt, dass Recht eingeräumt werden bis zur...
<G-vec00280-002-s022><outweigh.ausfallen><en> Where negative reports regarding the reception conditions and inhuman or degrading treatment in a first country of asylum indicate that an Applicant may not be safe in such a country, an Applicant’s request to remain in a Member State pending a decision on their right to remain must be given the benefit of doubt and outweigh the public’s interest in immediate enforcement of the ordered transfer.
<G-vec00337-002-s015><precipitate.ausfallen><de> Wenn es aus adstringierenden Pflanzen hergestellt wird, ist es besser, es sofort oder nach 10 Minuten zu belasten, andernfalls werden die Adstringentien schnell ausfallen.
<G-vec00337-002-s015><precipitate.ausfallen><en> If it is prepared from astringent plants, it is better to strain it immediately or after 10 minutes, otherwise the astringents will quickly precipitate.
<G-vec00337-002-s016><precipitate.ausfallen><de> Carbonatation ist das hinzufügen von Kalkmilch (Calciumhydroxid) und Kohlendioxid (CO2) an einer Lösung damit sich Calciumcarbonat formt und Verunreinigungen ausfallen und entfernt werden können.
<G-vec00337-002-s016><precipitate.ausfallen><en> Carbonatation is the introduction of milk of lime (calcium hydroxide) and carbon dioxide gas (CO2) into a liquid to form calcium carbonate and to precipitate and remove impurities.
<G-vec00829-002-s358><differ.ausfallen><de> Es muss hinzugesagt werden, dass der Farbton auch von einer Produktion zur anderen im Laufe Zeit unterschiedlich ausfallen kann, denn schließlich handelt es sich immer um Rohmaterialien, die einem Brennverfahren und einer chemischen Umformung bei über 1250°C unterzogen werden.
<G-vec00829-002-s358><differ.ausfallen><en> We mustn’t forget that the tone can also differ slightly between different productions over time, as the process involves raw materials that are fired and then undergo a chemical transformation at over 1250° C.
<G-vec00829-002-s359><differ.ausfallen><de> Da diese Parameter bei jedem Anwender unterschiedlich ausfallen und individuelle Lösungen gefordert sind, bedient sich Handtmann dabei seines modularen Systemes.
<G-vec00829-002-s359><differ.ausfallen><en> Since these parameters will differ from one user to another, individual solutions are required and Handtmann uses its modular system for this purpose.
<G-vec00829-002-s360><differ.ausfallen><de> Attacken des Spielers könnten je nach Herzfrequenz unterschiedlich ausfallen.
<G-vec00829-002-s360><differ.ausfallen><en> A player's attacks could differ depending on heart rate.
<G-vec00829-002-s361><differ.ausfallen><de> Sie zeigen, dass die Ergebnisse je nach Region unterschiedlich ausfallen.
<G-vec00829-002-s361><differ.ausfallen><en> Recently published regional analyses show that results differ depending on the region.
<G-vec00829-002-s362><differ.ausfallen><de> So werden sowohl die Warenarten als auch die Kundentypen und der gewünschte Lagerprozess unterschiedlich ausfallen.
<G-vec00829-002-s362><differ.ausfallen><en> Matters such as the kind of goods stored as well as the types of customers and the desired storage process will differ.
<G-vec00829-002-s363><differ.ausfallen><de> Die Goldmenge pro Paket/Tag wird anhand des Paketpreises pro Tag berechnet, sie kann also den Preisen der jeweiligen Spielwelt entsprechend unterschiedlich ausfallen.
<G-vec00829-002-s363><differ.ausfallen><en> The amount of Gold per package/day is calculated based on the package price per day, so it will differ depending on the prices of the game world.
<G-vec00829-002-s364><differ.ausfallen><de> Die Ergebnisse können je nach Individuum unterschiedlich ausfallen, abhängig von der jeweiligen Morphologie und den Umständen unter welchen das Produkt angewendet wird.
<G-vec00829-002-s364><differ.ausfallen><en> These results may differ from one person to the next, depending on the product's morphology and conditions of use. Feature
<G-vec00829-002-s365><differ.ausfallen><de> Hierfür bieten sich verschiedene Maße an, beispielsweise der Deflator des Bruttoinlandsprodukts, der Deflator der pri- vaten Konsumausgaben, der Index der Konsumentenpreise insgesamt sowie die Entwicklung der verschiedenen Inflations- maße kann recht unterschiedlich ausfallen (Graphik 9) und führt somit auch zu unterschiedlichen Taylor-Sätzen.
<G-vec00829-002-s365><differ.ausfallen><en> Here, various measures may be used such as the GDP deflator, the consumer spending deflator, the consumer price index as a whole as well as the so-called core inflation rate, i.e. the consumer price index excluding energy and food prices. The development of the various inflation measures can differ considerably (chart 9) and will thus also lead to different Taylor interest rates.
<G-vec00829-002-s366><differ.ausfallen><de> Je nach Szenario kann das Setup für ein Elasticsearch-Cluster sehr unterschiedlich ausfallen.
<G-vec00829-002-s366><differ.ausfallen><en> The setup of an elasticsearch cluster can differ strongly depending on its scenario.
<G-vec00829-002-s367><differ.ausfallen><de> In Abhängigkeit von den Team Skills wird das Risikodiagramm auch bei gleichen Taktikvarianten unterschiedlich ausfallen.
<G-vec00829-002-s367><differ.ausfallen><en> Depending on the Team Skills the risk diagram will differ even with the same tactical variants.
<G-vec00829-002-s618><vary.ausfallen><de> Diese Klausel muss verwendet werden, wenn bekannt ist, dass das Ergebnis der Funktion mit gegebenen Parametern unterschiedlich ausfallen kann.
<G-vec00829-002-s618><vary.ausfallen><en> This clause must be used when it is known that the function result for a given set of parameters can vary.
<G-vec00829-002-s619><vary.ausfallen><de> Da die Anforderungen sehr unterschiedlich ausfallen, erhält jede Zielgruppe ihre eigenen Inhalte in spezieller Aufbereitung auf ihrem jeweils bevorzugten Kanal.
<G-vec00829-002-s619><vary.ausfallen><en> Since requirements vary greatly, every target group receives their own content, personalized based on their specific needs, via their preferred channel.
<G-vec00829-002-s620><vary.ausfallen><de> Wenn es den Erzeugerorganisationen und Genossenschaften überlassen ist, ob sie sich an einer Produktionsrücknahme beteiligen oder nicht, wird die Bereitschaft sehr unterschiedlich ausfallen.
<G-vec00829-002-s620><vary.ausfallen><en> If producer organisations and cooperatives have the choice whether or not to implement production cuts, their willingness to participate will vary significantly.
<G-vec00829-002-s621><vary.ausfallen><de> Bitte beachten Sie, dass die Holzmaserung von Modell zu Modell unterschiedlich ausfallen kann.
<G-vec00829-002-s621><vary.ausfallen><en> Please note that the wood grain can vary from model to model.
<G-vec00829-002-s622><vary.ausfallen><de> Wir beziehen unsere Merchandiseprodukte von verschiedenen Zulieferern, sodass die Größen unterschiedlich ausfallen können.
<G-vec00829-002-s622><vary.ausfallen><en> We receive our merchandise goods from various suppliers, so sizes can vary slightly.
<G-vec00829-002-s623><vary.ausfallen><de> Spezialangriffe können abhängig von der verwendeten Rüstung unterschiedlich ausfallen.
<G-vec00829-002-s623><vary.ausfallen><en> The special attack can vary depending on the armor you use.
<G-vec00829-002-s624><vary.ausfallen><de> Die Zusammensetzung des Leitungswassers kann weltweit von Region zu Region und von Tag zu Tag sehr unterschiedlich ausfallen.
<G-vec00829-002-s624><vary.ausfallen><en> The composition of mains water can vary greatly across the world from region to region and from day to day.
<G-vec00829-002-s625><vary.ausfallen><de> Situation: Von einem festen Startpunkt aus sollen im Rahmen einer langfristigen Kampagne eine große Anzahl an Ballons geflogen werden, wobei die Flugpfade sehr unterschiedlich ausfallen können.
<G-vec00829-002-s625><vary.ausfallen><en> Situation: During a long time campaign a big number of research flights should be started from a fix launch area, wherein the trajectories can vary widely
<G-vec00829-002-s626><vary.ausfallen><de> Die Wirkungen der auf der Webseite erwähnten spirituellen Heilmittel können je nach Mensch unterschiedlich ausfallen, abhängig von ihrem spirituellen Zustand (d.h., ob Sie von negativen feinstofflichen Wesenheiten angegriffen oder besessen sind), oder dem Zustand von Körper und Geist.
<G-vec00829-002-s626><vary.ausfallen><en> The effect of the spiritual remedies mentioned on the Site may vary per person depending on their spiritual state (i.e. whether affected or possessed by negative subtle entities), or state of mind and body.
<G-vec00829-002-s627><vary.ausfallen><de> Das Symptombild kann unterschiedlich ausfallen, einige Beschwerden treten aber besonders häufig auf.
<G-vec00829-002-s627><vary.ausfallen><en> The symptoms can vary, but some symptoms are particularly frequent.
<G-vec00829-002-s628><vary.ausfallen><de> * Gemessen vom hinteren Ende des TVs kann die Lücke unterschiedlich ausfallen, je nach Befestigung und Wandbeschaffenheit.
<G-vec00829-002-s628><vary.ausfallen><en> * The peak brightness may vary depending on the model and size of the TV. Q Viewing Angle
<G-vec00829-002-s629><vary.ausfallen><de> Bitte beachte, dass je nach Material die Farben unterschiedlich ausfallen können.
<G-vec00829-002-s629><vary.ausfallen><en> Please note, color may be vary depending on yarn base.
<G-vec00829-002-s630><vary.ausfallen><de> Da Auflagen kontinuierlich Änderungen unterliegen und von Region zu Region unterschiedlich ausfallen, liegt die Einordnung umweltfreundlich im Auge des Betrachters.
<G-vec00829-002-s630><vary.ausfallen><en> As regulations continue to evolve and vary from region to region, being ‘green’ may be ‘in the eyes of the beholder.’
<G-vec00829-002-s631><vary.ausfallen><de> Da die angegebenen Größen verschiedener Hersteller recht unterschiedlich ausfallen, achten Sie bitte unbedingt auch auf die angegebenen Maße.
<G-vec00829-002-s631><vary.ausfallen><en> Since the specified sizes from different manufacturers vary considerably, please ensure on the specified dimensions.
<G-vec00829-002-s632><vary.ausfallen><de> Die Verfügbarkeit der Car-Net Dienste kann länderabhängig unterschiedlich ausfallen.
<G-vec00829-002-s632><vary.ausfallen><en> Availability of Car-Net Services may vary depending on the country in question.
