<G-vec00185-001-s019><catch.auffangen><de> Zu einem kleinen Brunnenturm mit mehreren Wasserpumpen staffeln sich verschieden große Holzplateaus, zwischen den Fugen befinden sich breite Wasserrinnen zum Auffangen und Leiten des Wassers.
<G-vec00185-001-s019><catch.auffangen><en> Various large wooden plateaux are phased into a small fountain tower with several water pumps, between the joints there are wide water gutters to catch and channel the water.
<G-vec00185-001-s020><catch.auffangen><de> „Wenn der Hauptmann dich deshalb von einer Klippe werfen will, werden wir dich heimlich unten auffangen“, tröstete ihn Ed.
<G-vec00185-001-s020><catch.auffangen><en> “If the Captain wants to push you down a cliff because of this, we will secretly catch you at the bottom,” Ed comforted him.
<G-vec00185-001-s021><catch.auffangen><de> Die Biegung an der Unterseite soll die Kräfte, die im Zusammenhang mit der Doll auftreten auffangen und weiterleiten.
<G-vec00185-001-s021><catch.auffangen><en> The inflection at the underside should catch the forces, that occur in the context of the Doll, and should refer.
<G-vec00185-001-s022><catch.auffangen><de> Das Blut schießt in schwerer Fontäne aus dem Schnitt hervor, ehe ihn noch jemand auffangen kann, sinkt er nach rückwärts in den tiefen Staub.
<G-vec00185-001-s022><catch.auffangen><en> The blood spouts in a heavy fountain from his carotid artery, and before anyone can catch him he sinks backward into the dust.
<G-vec00185-001-s023><catch.auffangen><de> Art Die Glaskugel ist Symbol unsere Zerbrechlichkeit...das rote Seidenband symbolisiert unsere Familie und Freunde die uns in den schwierigen Situationen unseres Lebens auffangen...
<G-vec00185-001-s023><catch.auffangen><en> The glass pearl is a symbol of our fragility... the red silk ribbon symbolizes our family and friends the often catch us in difficult situations of our lives...
<G-vec00185-001-s024><catch.auffangen><de> Und ich hielt für schlimm, daß ich seine Befehle in meinem Bewusstsein nicht auffangen konnte, denn, wie ich feststellte, der König der Maros verfügt über dieselbe Fähigkeit wie ich: Er weiß, seinem eigenen Sinn seine Worte zu verbergen; hier wandte er diese Fähigkeit vor dem Feind an.
<G-vec00185-001-s024><catch.auffangen><en> What I considered as bad was that I could not catch in my consciousness the commands he was issuing, since the king of Maros, as I had to admit, disposed of the same ability as I had: He could conceal his words to his own mind.
<G-vec00185-001-s025><catch.auffangen><de> Filter sind zum effektiven Auffangen von Staub ohne Einbußen bei der Luftstromleistung aus einem feinen Nylongitter hergestellt.
<G-vec00185-001-s025><catch.auffangen><en> Filters are made of fine nylon mesh to catch dust effectively without airflow performance penalty.
<G-vec00185-001-s026><catch.auffangen><de> Die Orangen über einem Teller oder einer Schüssel filetieren und den Saft auffangen.
<G-vec00185-001-s026><catch.auffangen><en> Fillet the oranges over a plate or bowl to catch the juice.
<G-vec00185-001-s027><catch.auffangen><de> Er weist außerdem ein Kiefsieb auf, sodass Du Trichome auffangen und sammeln kannst.
<G-vec00185-001-s027><catch.auffangen><en> It also features a kief screen so you can catch and collect trichomes.
<G-vec00185-001-s028><catch.auffangen><de> 'Auffangen' bezog sich auf mein Bewusstsein anstatt meinen Körper.
<G-vec00185-001-s028><catch.auffangen><en> 'Catch me' referred to my consciousness versus my body.
<G-vec00185-001-s029><catch.auffangen><de> Die Proklamation der drei Artikel unseres Glaubens und ihrer Erklärung im Katechismus sind so massiv und dicht, dass sie wie ein Schild die feurigen Pfeile des Bösewichts auffangen und auslöschen können.
<G-vec00185-001-s029><catch.auffangen><en> The proclamation of the three articles of faith of the Evangelical Lutheran Church and their explanation in the church catechism are so massive and compact that they can, like a shield, catch and extinguish the fiery darts of the evil one.
<G-vec00185-001-s030><catch.auffangen><de> Da der Bau von Brunnen angesichts der natürlichen Gegebenheiten praktisch unmöglich war, wurden in vielen Schlössern findige Systeme zum Auffangen des Regenwassers eingerichtet; das Wasser wurde mit Sand gefiltert und in Zisternen aufbewahrt.
<G-vec00185-001-s030><catch.auffangen><en> As it was virtually impossible to draw sufficient water from a well given the nature of the sites, ingenious systems were designed to catch rain water, filter it through sand and store it in cisterns in numerous castles.
<G-vec00185-001-s031><catch.auffangen><de> Seit Jahrhunderten sind Prinzen, Präsidenten, Bankiers(Bankhalter), lass von der Inflation auffangen, aber nicht unsere Genies.
<G-vec00185-001-s031><catch.auffangen><en> "Since centuries, princes, presidents, bankers are make catch up with by inflation, but not our ""geniuses""."
<G-vec00185-001-s032><catch.auffangen><de> und Freunde die uns in den schwierigen Situationen unseres Lebens auffangen...
<G-vec00185-001-s032><catch.auffangen><en> the often catch us in difficult situations of our lives...
<G-vec00185-001-s033><catch.auffangen><de> Es sind Leute da, die jene auffangen, die fallen, damit niemand sich verletzt.
<G-vec00185-001-s033><catch.auffangen><en> There are people to catch anyone who falls so none should be hurt.
<G-vec00185-001-s034><catch.auffangen><de> Genießen Sie pure Aromen, die Ihre Stimmung auffangen und zu dem Moment passen.
<G-vec00185-001-s034><catch.auffangen><en> Savor the pure pleasure of flavours that catch your mood and match the moment.
<G-vec00185-001-s035><catch.auffangen><de> Schaut, er wird fallen und Niemand wird ihn auffangen und gross wird sein Fall sein!...
<G-vec00185-001-s035><catch.auffangen><en> Behold, he shall fall with none to catch him, and great shall be his fall!...
<G-vec00185-001-s036><catch.auffangen><de> """Die Welt"" sieht das ABM-Projekt in Polen und Tschechien als Systeme zum Auffangen der letzten Reste der russischen Atomraketen nach einem US-Erstschlag gegen Russland ."
<G-vec00185-001-s036><catch.auffangen><en> Die Welt sees the ABM project in Poland and Czechia as systems to catch the last remnants of Russian nuclear missiles after a US first strike against Russia.
<G-vec00185-001-s056><catch.auffangen><de> Natürlich versuchte er auch etwas davon mit dem Mund aufzufangen, scheiterte aber kläglich.
<G-vec00185-001-s056><catch.auffangen><en> Of course he also tried to catch some of it with his mouth, but he failed miserably.
<G-vec00185-001-s057><catch.auffangen><de> Tauchen Sie die Spitze jedes gekühlt Donut in die Glasur und auf einem Rack-Kühlung, die über ein Backblech ist es, die Tropfen aufzufangen.
<G-vec00185-001-s057><catch.auffangen><en> Dip the top of each cooled doughnut into the glaze and place on a cooling rack that is over a baking sheet to catch the drips.
<G-vec00185-001-s058><catch.auffangen><de> Dann sind wir in der Lage mit offenen Armen die wunderbaren Gelegenheiten aufzufangen, welche dann erscheinen werden.
<G-vec00185-001-s058><catch.auffangen><en> Then we will be able to catch with open arms the wondrous opportunities which will then appear.
<G-vec00185-001-s059><catch.auffangen><de> Es ist möglich aus der Garage durch die Paneele einen Schimmer von der Stadt aufzufangen, während von außen gesehen gerade die durchleuchteten Paneele die Aufmerksamkeit auf sich ziehen.
<G-vec00185-001-s059><catch.auffangen><en> It is possible to catch a glimpse of the city through the panels from the garage, while at the same time the screened panels draw the attention on the outside.
<G-vec00185-001-s060><catch.auffangen><de> Aber wenn wir kräftig als Wahre Eine stehen, mit offenen Händen bereit das Neue zu umarmen, werde wir frei sein Melone nach Melone nach Melone aufzufangen.
<G-vec00185-001-s060><catch.auffangen><en> But if we are standing strong as a True One with our hands open in readiness to embrace the New, then we will be free to catch melon after melon after melon.
<G-vec00185-001-s061><catch.auffangen><de> Und unser polnischer Freund war mit Antenne und Empfangsgerät unterwegs, um die Signale besenderter Kraniche aufzufangen.
<G-vec00185-001-s061><catch.auffangen><en> Our polish friend was on his way with antenna and receiver to catch the signals of tagged cranes.
<G-vec00185-001-s062><catch.auffangen><de> Außerdem verfügt das System über eine große Kapazität um temporär angesammeltes überflüssiges Regenwasser aufzufangen und somit Überschwemmungen frühzeitig vermieden werden können.
<G-vec00185-001-s062><catch.auffangen><en> The system includes natural water purification and, moreover, has sufficient capacity to catch excess rainwater temporarily, thereby helping to prevent flooding.
<G-vec00185-001-s063><catch.auffangen><de> Er besteht aus einem 220 Mikrometer und einem 70 Mikrometer Sieb, um die Abfälle herauszufiltern und Deine Kristalle aufzufangen.
<G-vec00185-001-s063><catch.auffangen><en> It consists of a 220 micron screen and a 70 micron screen to filter out the waste and catch your crystals.
<G-vec00185-001-s064><catch.auffangen><de> Sie kennen das Sprichwort, und je länger die Jungen versuchen, ein Blatt aufzufangen, desto deutlicher tritt Leungs Wunsch hervor.
<G-vec00185-001-s064><catch.auffangen><en> Both are aware of this proverb and, the longer the boys try to catch a leaf, the more Leung’s wish becomes apparent.
<G-vec00185-001-s065><catch.auffangen><de> Jeff Bezos, der reichste Mann der Welt, wird da sein, um es aufzufangen.
<G-vec00185-001-s065><catch.auffangen><en> Jeff Bezos, the world's richest man, will be there to catch it.
<G-vec00185-001-s066><catch.auffangen><de> Bevor sie nach unten fällt, müsst ihr euch darunter stellen, um sie aufzufangen.
<G-vec00185-001-s066><catch.auffangen><en> Before the plum falls, position yourself under it to catch it.
<G-vec00185-001-s067><catch.auffangen><de> """, schrie ihre Mutter, als sie unter Tränen mit ausgestreckten Armen zu ihr flog um ihre Tochter aufzufangen."
<G-vec00185-001-s067><catch.auffangen><en> cried her mother, flying towards her, weeping and stretching out her arms to catch her daughter.
<G-vec00185-001-s068><catch.auffangen><de> Glücklicherweise schafften es die königlichen Ritter in ihrer Nähe den Kronprinz rechtzeitig aufzufangen, sodass Seine Hoheit nicht zu Boden fiel.
<G-vec00185-001-s068><catch.auffangen><en> Luckily, the knights around them managed to catch the crown prince in time, so His Highness didn’t fall to the floor.
<G-vec00185-001-s069><catch.auffangen><de> „Das System unserer offenen Chat-Option ist bereits dafür ausgelegt, alle offensichtlichen Schimpfwörter und unangemessenen Kommentare aufzufangen, aber es kann zudem auch Codes knacken und versteckte Methoden aussondern, die Spieler vielleicht manchmal benutzen, um dem Filter zu entgehen und andere Teilnehmer zu schikanieren oder zu belästigen“, so Merrifield.
<G-vec00185-001-s069><catch.auffangen><en> """The system on our Open Chat option is already designed to catch any obvious swear words and inappropriate comments, but it can also break codes and screen out hidden methods players might sometimes use in an effort to get past the filter and bully or harass another participant,"" says Merrifield."
<G-vec00185-001-s070><catch.auffangen><de> Versuche alle Schätze und Extras, die von oben herab fallen aufzufangen.
<G-vec00185-001-s070><catch.auffangen><en> Try to catch all treasures and stuff that falls from above.
<G-vec00185-001-s071><catch.auffangen><de> Besonders hervorzuheben ist die jüngste Schwäche, die das gefürchtete Dilemma des Versuchs,'ein fallendes Messer aufzufangen', darstellt.
<G-vec00185-001-s071><catch.auffangen><en> Of particular note is the recent weakness, presenting the dreaded conundrum of ‘trying to catch a falling knife.’
<G-vec00185-001-s072><catch.auffangen><de> Eine Entscheidung war während der Entbindung dass niemand da war um mich bei der Geburt 'aufzufangen'.
<G-vec00185-001-s072><catch.auffangen><en> One decision was during delivery that no one was there to 'catch me' at delivery.
<G-vec00185-001-s073><catch.auffangen><de> Dann hielten sie plötzliche ihre Szepter hoch und warfen sie in die Luft Richtung Brücken - von denen sich einige aus einem alten Reflex heraus weg duckten um sie nicht aufzufangen.
<G-vec00185-001-s073><catch.auffangen><en> Then they suddenly held their sceptres on high and tossed them in the air to the Bridges -- some of whom ducked out of old reflex patterns so they wouldn't have to catch them.
<G-vec00185-001-s074><catch.auffangen><de> Versuchen Sie, in den Spiegel Lichtstrahl aufzufangen.
<G-vec00185-001-s074><catch.auffangen><en> Try to catch in the mirror light beam.
<G-vec00126-002-s038><catch.auffangen><de> Ich werde dich aus deinem Sturz heraus auffangen.
<G-vec00126-002-s038><catch.auffangen><en> I will catch ya, I will catch your fall
<G-vec00126-002-s039><catch.auffangen><de> Hey, Anwalt, du musst mich auffangen, wenn ich falle.
<G-vec00126-002-s039><catch.auffangen><en> Hey lawyer gotta catch me when I fall
<G-vec00126-002-s040><catch.auffangen><de> Da Ihr Gehirn zwischen einfachen und großen Konzepten hin und her wechselt, kann es einen Tippfehler nicht auffangen.
<G-vec00126-002-s040><catch.auffangen><en> Because your brain is shifting back and forth between simple and big concept, it may not catch a typo.
<G-vec00126-002-s041><catch.auffangen><de> Bedenket nun, in welchem Geistesdunkel die Menschheit dahingeht, bedenket, daß nur einige wenige eine lichtvolle Sphäre um sich schaffen, daß also gleichsam nur Lichtfunken auf der Erde aufblitzen, die zwar jeder Mensch auffangen könnte und die genügen würden, wieder ein Licht anzuzünden im Herzen eines Menschen, der dem Dunkel entfliehen möchte.
<G-vec00126-002-s041><catch.auffangen><en> Now consider, in what spiritual darkness mankind goes along; consider that only very few create a sphere full of light around themselves, that therefore as it were only sparks of light flash on earth, which certainly every man could catch and which would be enough to again light a light in the heart of a man who wants to flee from darkness.
<G-vec00126-002-s042><catch.auffangen><de> Diese Öffnungen befinden sich im oberen Teil des Schachtes, wodurch sie stärkeren Wind auffangen können.
<G-vec00126-002-s042><catch.auffangen><en> These openings are placed at the top of the shaft; therefore they can catch more privileged wind.
<G-vec00126-002-s043><catch.auffangen><de> In Kombination mit einer f/1.75 Blende kann der Hauptsensor selbst bei sehr ungünstigen Lichtverhältnissen noch viele Details auffangen.
<G-vec00126-002-s043><catch.auffangen><en> In combination with an f/1.75 aperture, the main sensor can catch many details even in very unfavourable lighting conditions.
<G-vec00126-002-s045><catch.auffangen><de> Du kannst die Münze auffangen oder musst beobachten, wo sie hinfällt, wenn sie auf dem Fußboden landet.
<G-vec00126-002-s045><catch.auffangen><en> Watch the coin in the air and either catch it or pay attention to where it rolls after it hits the floor.
<G-vec00126-002-s046><catch.auffangen><de> Das Interview, ob werblich oder informativ, basiert auf Kommunikationstechniken, die das Publikum auffangen und alles tun, um dieses Publikum zu halten.
<G-vec00126-002-s046><catch.auffangen><en> The interview, whether promotional or informative, is based on communication techniques that will catch the audience and do everything to keep this audience.
<G-vec00126-002-s047><catch.auffangen><de> Der Brunnen des Square Lamartine, auch Passybrunnen genannt, wurde ab 1855 gegraben und man fasste den Bau eines Steigrohres ins Auge, welches das heraufsprudelnde Wasser auffangen sollte.
<G-vec00126-002-s047><catch.auffangen><en> The well in Lamartine square, called the Passy well, was dug in 1855, and a standpipe was to be built over it to catch the gushing water.
<G-vec00126-002-s048><catch.auffangen><de> Hier müssen Sie möglichst viele Blumen (20) auffangen.
<G-vec00126-002-s048><catch.auffangen><en> Here you need to catch as many flowers (20) as possible.
<G-vec00126-002-s049><catch.auffangen><de> Wir können uns nicht länger auf Sicherheitsnetze verlassen, die uns auffangen.
<G-vec00126-002-s049><catch.auffangen><en> No longer can we rely on safety nets to catch us.
<G-vec00126-002-s050><catch.auffangen><de> Die eingesetzten Filter können Verunreinigung von bis zu 5 Mikron auffangen.
<G-vec00126-002-s050><catch.auffangen><en> The filters can catch the impurities minimal 5 microns.
<G-vec00126-002-s051><catch.auffangen><de> Die Unterseite des Grinders ist konisch, so dass Sie Ihr gemahlenes Pulver leicht auffangen können, in der runden Kunststoffbox die mit diesem Produkt mitgeliefert wird.
<G-vec00126-002-s051><catch.auffangen><en> The bottom of the grinder is tapered, so you can easily catch your grinded powder in the round plastic box which comes extra with this product.
<G-vec00126-002-s052><catch.auffangen><de> Den Saft in einer Schüssel auffangen und aus den Orangenhäuten drücken und ebenfalls zu den Fruchtfilets geben.
<G-vec00126-002-s052><catch.auffangen><en> Catch the juice in a bowl and squeeze out the orange skins, then add them to the segments.
<G-vec00126-002-s054><catch.auffangen><de> Im unteren Bereich befindet sich eine Schüssel zum Auffangen der abtropfenden Fette, in die Räucherkammer kann man auch Siebe (gegen Aufpreis) einlegen und als Obsttrockner benutzen.
<G-vec00126-002-s054><catch.auffangen><en> In the bottom part is plate for catch escaping fat. It is also possible to insert the sieve inside the smoke house (for surcharge) and use this device as a fruit dryer.
<G-vec00126-002-s074><catch.auffangen><de> Es ist keine gute Idee, bei Kastensprüngen Kurzhanteln zu verwenden; du könntest deine Hände benötigen, um dich im Falle eines Sturzes aufzufangen.
<G-vec00126-002-s074><catch.auffangen><en> It’s not a good idea to use dumbbells when you do box jumps; you might need your hands to catch yourself if you trip.
<G-vec00126-002-s075><catch.auffangen><de> Dass größere Objekt muss seine Balance verlassen um die Bewegungsenergie des kleineren aufzufangen.
<G-vec00126-002-s075><catch.auffangen><en> The bigger object has to leave it´s balance in order to catch the movement energy of the smaller object.
<G-vec00126-002-s076><catch.auffangen><de> Du kontrollierst eine riesige Hand und Deine Aufgabe ist es, all die Dinge aufzufangen, die durchs Bild fallen.
<G-vec00126-002-s076><catch.auffangen><en> You control a large hand and it is your objective to catch all the things that are falling through the screen.
<G-vec00126-002-s078><catch.auffangen><de> Der beste Platz für den Wischeimer ist jedoch kein Haken, er sollte auf dem Boden oder auf einem Regal unter dem Mop stehen, um Tropfen aufzufangen.
<G-vec00126-002-s078><catch.auffangen><en> But the best place for the mop bucket is not a hook, it should be on the floor or a shelf under the mop to catch drops.
<G-vec00126-002-s079><catch.auffangen><de> Als Peter versucht, selbst zu fliegen, sieht Nathan ihn fallen und fliegt nach oben, um ihn aufzufangen.
<G-vec00126-002-s079><catch.auffangen><en> When Peter attempts to fly on his own, Nathan sees him fall and flies up to catch him.
<G-vec00126-002-s080><catch.auffangen><de> Allerdings ist die Verzögerung, bevor Elsword sich erneut bewegen kann zu lang, um bestimmte schwere Gegner wieder aufzufangen.
<G-vec00126-002-s080><catch.auffangen><en> However, the delay before you can move again is too long to catch certain heavier targets.
<G-vec00126-002-s081><catch.auffangen><de> Zur Reinigung der Dosierpistolen: Vor dem Beginn der Arbeiten sollte der Anwender einen geeigneten Abfallbehälter und einen Lappen bereithalten, um angelöste Schaumreste und Reinigerflüssigkeit aufzufangen.
<G-vec00126-002-s081><catch.auffangen><en> To clean the dispensing guns: before starting work, the operator should have to hand a suitable waste container and a rag to catch dissolved foam residue and cleaning fluid.
<G-vec00126-002-s082><catch.auffangen><de> Entferne die Teeblätter aus der Kanne (wenn du ein Sieb oder ein Tee-Ei hast) oder gieße die Flüssigkeit über ein Sieb in ein anderes Gefäß, um die Teeblätter aufzufangen.
<G-vec00126-002-s082><catch.auffangen><en> Get rid of the tea leaves in the pot (if you have a strainer or infuser) or pour the liquid into another vessel with a strainer to catch any tea leaves.
<G-vec00126-002-s083><catch.auffangen><de> Schieben Sie ein größeres Blech darunter, um das Öl aufzufangen, das beim Backen aus der Form laufen wird.
<G-vec00126-002-s083><catch.auffangen><en> Place a larger tray underneath it to catch any oil that overflows from the tin while cooking.
<G-vec00126-002-s084><catch.auffangen><de> Wenn möglich, bringe Stützstangen am Gestell an, um das Gewicht aufzufangen, falls du es nicht wieder im Gestell ablegen kannst.
<G-vec00126-002-s084><catch.auffangen><en> If possible, set up supporting bars underneath the rack to catch the weight in case you are unable to bring the weight back up to the rack.
<G-vec00126-002-s085><catch.auffangen><de> Die Seiten der Folie zu einem Rand hochschlagen, um den Fleischsaft aufzufangen.
<G-vec00126-002-s085><catch.auffangen><en> Turn up the sides of the foil to catch the meat juice.
<G-vec00126-002-s086><catch.auffangen><de> Wegen der sensiblen Oberfläche des Druckgrundes ist es ihm möglich, kleinste Bewegungen aufzufangen und darzustellen: die Flügelschläge von an Lampen vorbeifliegenden Nachtfaltern oder die Spuren von Ameisen.
<G-vec00126-002-s086><catch.auffangen><en> Because of the sensitive surface of the printing area he is enabled to catch and illustrate the slightest movements: the wing beats of moths passing by lamps or the tracks ants leave behind.
<G-vec00126-002-s087><catch.auffangen><de> Natürlich ist ein Schirmständer auch dazu da, herabtropfendes Wasser aufzufangen.
<G-vec00126-002-s087><catch.auffangen><en> Of course, an umbrella stand is also used to catch dripping water.
<G-vec00126-002-s089><catch.auffangen><de> Wahrlich, von Gottes Königreich der Himmel aus kam ein himmlisches Fangnetz, um viele Seelen und die Kinder aufzufangen, und um sie beieinander vor Gottes Thron zu bringen.
<G-vec00126-002-s089><catch.auffangen><en> Verily, from God’s Kingdom of heaven a heavenly safety net came, in order to catch many souls and the children, and to gather them before God’s throne.
<G-vec00126-002-s090><catch.auffangen><de> Zuerst mochte ich diesen süßen Plüschhund noch und habe ihn hochgeworfen um ihn wieder aufzufangen, doch er ist daneben gefallen und nicht zurück gekommen.
<G-vec00126-002-s090><catch.auffangen><en> First I really liked this little plush doggy and threw it into the air to catch it again, but it fell off my hands and didn't come back.
<G-vec00126-002-s091><catch.auffangen><de> Popularität: 8,0 Versuche alle fallende Schneeflocken aufzufangen.
<G-vec00126-002-s091><catch.auffangen><en> Popularity: 8.7 Run up and down and jump to catch all snowflakes.
<G-vec00126-002-s092><catch.auffangen><de> Versuch in der Süßwarenfabrik so viel Süßigkeiten aufzufangen wie du nur kannst.
<G-vec00126-002-s092><catch.auffangen><en> Try to catch as many sweets as you can before time runs out.
<G-vec00689-002-s038><catch_on.auffangen><de> Ich werde dich aus deinem Sturz heraus auffangen.
<G-vec00689-002-s038><catch_on.auffangen><en> I will catch ya, I will catch your fall
<G-vec00689-002-s039><catch_on.auffangen><de> Hey, Anwalt, du musst mich auffangen, wenn ich falle.
<G-vec00689-002-s039><catch_on.auffangen><en> Hey lawyer gotta catch me when I fall
<G-vec00689-002-s040><catch_on.auffangen><de> Da Ihr Gehirn zwischen einfachen und großen Konzepten hin und her wechselt, kann es einen Tippfehler nicht auffangen.
<G-vec00689-002-s040><catch_on.auffangen><en> Because your brain is shifting back and forth between simple and big concept, it may not catch a typo.
<G-vec00689-002-s041><catch_on.auffangen><de> Bedenket nun, in welchem Geistesdunkel die Menschheit dahingeht, bedenket, daß nur einige wenige eine lichtvolle Sphäre um sich schaffen, daß also gleichsam nur Lichtfunken auf der Erde aufblitzen, die zwar jeder Mensch auffangen könnte und die genügen würden, wieder ein Licht anzuzünden im Herzen eines Menschen, der dem Dunkel entfliehen möchte.
<G-vec00689-002-s041><catch_on.auffangen><en> Now consider, in what spiritual darkness mankind goes along; consider that only very few create a sphere full of light around themselves, that therefore as it were only sparks of light flash on earth, which certainly every man could catch and which would be enough to again light a light in the heart of a man who wants to flee from darkness.
<G-vec00689-002-s042><catch_on.auffangen><de> Diese Öffnungen befinden sich im oberen Teil des Schachtes, wodurch sie stärkeren Wind auffangen können.
<G-vec00689-002-s042><catch_on.auffangen><en> These openings are placed at the top of the shaft; therefore they can catch more privileged wind.
<G-vec00689-002-s043><catch_on.auffangen><de> In Kombination mit einer f/1.75 Blende kann der Hauptsensor selbst bei sehr ungünstigen Lichtverhältnissen noch viele Details auffangen.
<G-vec00689-002-s043><catch_on.auffangen><en> In combination with an f/1.75 aperture, the main sensor can catch many details even in very unfavourable lighting conditions.
<G-vec00689-002-s044><catch_on.auffangen><de> Die Biegung an der Unterseite soll die Kräfte, die im Zusammenhang mit der Doll auftreten auffangen und weiterleiten.
<G-vec00689-002-s044><catch_on.auffangen><en> The inflection at the underside should catch the forces, that occur in the context of the Doll, and should refer.
<G-vec00689-002-s045><catch_on.auffangen><de> Du kannst die Münze auffangen oder musst beobachten, wo sie hinfällt, wenn sie auf dem Fußboden landet.
<G-vec00689-002-s045><catch_on.auffangen><en> Watch the coin in the air and either catch it or pay attention to where it rolls after it hits the floor.
<G-vec00689-002-s046><catch_on.auffangen><de> Das Interview, ob werblich oder informativ, basiert auf Kommunikationstechniken, die das Publikum auffangen und alles tun, um dieses Publikum zu halten.
<G-vec00689-002-s046><catch_on.auffangen><en> The interview, whether promotional or informative, is based on communication techniques that will catch the audience and do everything to keep this audience.
<G-vec00689-002-s047><catch_on.auffangen><de> Der Brunnen des Square Lamartine, auch Passybrunnen genannt, wurde ab 1855 gegraben und man fasste den Bau eines Steigrohres ins Auge, welches das heraufsprudelnde Wasser auffangen sollte.
<G-vec00689-002-s047><catch_on.auffangen><en> The well in Lamartine square, called the Passy well, was dug in 1855, and a standpipe was to be built over it to catch the gushing water.
<G-vec00689-002-s048><catch_on.auffangen><de> Hier müssen Sie möglichst viele Blumen (20) auffangen.
<G-vec00689-002-s048><catch_on.auffangen><en> Here you need to catch as many flowers (20) as possible.
<G-vec00689-002-s049><catch_on.auffangen><de> Wir können uns nicht länger auf Sicherheitsnetze verlassen, die uns auffangen.
<G-vec00689-002-s049><catch_on.auffangen><en> No longer can we rely on safety nets to catch us.
<G-vec00689-002-s050><catch_on.auffangen><de> Die eingesetzten Filter können Verunreinigung von bis zu 5 Mikron auffangen.
<G-vec00689-002-s050><catch_on.auffangen><en> The filters can catch the impurities minimal 5 microns.
<G-vec00689-002-s051><catch_on.auffangen><de> Die Unterseite des Grinders ist konisch, so dass Sie Ihr gemahlenes Pulver leicht auffangen können, in der runden Kunststoffbox die mit diesem Produkt mitgeliefert wird.
<G-vec00689-002-s051><catch_on.auffangen><en> The bottom of the grinder is tapered, so you can easily catch your grinded powder in the round plastic box which comes extra with this product.
<G-vec00689-002-s052><catch_on.auffangen><de> Den Saft in einer Schüssel auffangen und aus den Orangenhäuten drücken und ebenfalls zu den Fruchtfilets geben.
<G-vec00689-002-s052><catch_on.auffangen><en> Catch the juice in a bowl and squeeze out the orange skins, then add them to the segments.
<G-vec00689-002-s053><catch_on.auffangen><de> Genießen Sie pure Aromen, die Ihre Stimmung auffangen und zu dem Moment passen.
<G-vec00689-002-s053><catch_on.auffangen><en> Savor the pure pleasure of flavours that catch your mood and match the moment.
<G-vec00689-002-s054><catch_on.auffangen><de> Im unteren Bereich befindet sich eine Schüssel zum Auffangen der abtropfenden Fette, in die Räucherkammer kann man auch Siebe (gegen Aufpreis) einlegen und als Obsttrockner benutzen.
<G-vec00689-002-s054><catch_on.auffangen><en> In the bottom part is plate for catch escaping fat. It is also possible to insert the sieve inside the smoke house (for surcharge) and use this device as a fruit dryer.
<G-vec00689-002-s074><catch_on.auffangen><de> Es ist keine gute Idee, bei Kastensprüngen Kurzhanteln zu verwenden; du könntest deine Hände benötigen, um dich im Falle eines Sturzes aufzufangen.
<G-vec00689-002-s074><catch_on.auffangen><en> It’s not a good idea to use dumbbells when you do box jumps; you might need your hands to catch yourself if you trip.
<G-vec00689-002-s075><catch_on.auffangen><de> Dass größere Objekt muss seine Balance verlassen um die Bewegungsenergie des kleineren aufzufangen.
<G-vec00689-002-s075><catch_on.auffangen><en> The bigger object has to leave it´s balance in order to catch the movement energy of the smaller object.
<G-vec00689-002-s076><catch_on.auffangen><de> Du kontrollierst eine riesige Hand und Deine Aufgabe ist es, all die Dinge aufzufangen, die durchs Bild fallen.
<G-vec00689-002-s076><catch_on.auffangen><en> You control a large hand and it is your objective to catch all the things that are falling through the screen.
<G-vec00689-002-s077><catch_on.auffangen><de> Versuchen Sie, in den Spiegel Lichtstrahl aufzufangen.
<G-vec00689-002-s077><catch_on.auffangen><en> Try to catch in the mirror light beam.
<G-vec00689-002-s078><catch_on.auffangen><de> Der beste Platz für den Wischeimer ist jedoch kein Haken, er sollte auf dem Boden oder auf einem Regal unter dem Mop stehen, um Tropfen aufzufangen.
<G-vec00689-002-s078><catch_on.auffangen><en> But the best place for the mop bucket is not a hook, it should be on the floor or a shelf under the mop to catch drops.
<G-vec00689-002-s079><catch_on.auffangen><de> Als Peter versucht, selbst zu fliegen, sieht Nathan ihn fallen und fliegt nach oben, um ihn aufzufangen.
<G-vec00689-002-s079><catch_on.auffangen><en> When Peter attempts to fly on his own, Nathan sees him fall and flies up to catch him.
<G-vec00689-002-s080><catch_on.auffangen><de> Allerdings ist die Verzögerung, bevor Elsword sich erneut bewegen kann zu lang, um bestimmte schwere Gegner wieder aufzufangen.
<G-vec00689-002-s080><catch_on.auffangen><en> However, the delay before you can move again is too long to catch certain heavier targets.
<G-vec00689-002-s081><catch_on.auffangen><de> Zur Reinigung der Dosierpistolen: Vor dem Beginn der Arbeiten sollte der Anwender einen geeigneten Abfallbehälter und einen Lappen bereithalten, um angelöste Schaumreste und Reinigerflüssigkeit aufzufangen.
<G-vec00689-002-s081><catch_on.auffangen><en> To clean the dispensing guns: before starting work, the operator should have to hand a suitable waste container and a rag to catch dissolved foam residue and cleaning fluid.
<G-vec00689-002-s082><catch_on.auffangen><de> Entferne die Teeblätter aus der Kanne (wenn du ein Sieb oder ein Tee-Ei hast) oder gieße die Flüssigkeit über ein Sieb in ein anderes Gefäß, um die Teeblätter aufzufangen.
<G-vec00689-002-s082><catch_on.auffangen><en> Get rid of the tea leaves in the pot (if you have a strainer or infuser) or pour the liquid into another vessel with a strainer to catch any tea leaves.
<G-vec00689-002-s083><catch_on.auffangen><de> Schieben Sie ein größeres Blech darunter, um das Öl aufzufangen, das beim Backen aus der Form laufen wird.
<G-vec00689-002-s083><catch_on.auffangen><en> Place a larger tray underneath it to catch any oil that overflows from the tin while cooking.
<G-vec00689-002-s084><catch_on.auffangen><de> Wenn möglich, bringe Stützstangen am Gestell an, um das Gewicht aufzufangen, falls du es nicht wieder im Gestell ablegen kannst.
<G-vec00689-002-s084><catch_on.auffangen><en> If possible, set up supporting bars underneath the rack to catch the weight in case you are unable to bring the weight back up to the rack.
<G-vec00689-002-s085><catch_on.auffangen><de> Die Seiten der Folie zu einem Rand hochschlagen, um den Fleischsaft aufzufangen.
<G-vec00689-002-s085><catch_on.auffangen><en> Turn up the sides of the foil to catch the meat juice.
<G-vec00689-002-s086><catch_on.auffangen><de> Wegen der sensiblen Oberfläche des Druckgrundes ist es ihm möglich, kleinste Bewegungen aufzufangen und darzustellen: die Flügelschläge von an Lampen vorbeifliegenden Nachtfaltern oder die Spuren von Ameisen.
<G-vec00689-002-s086><catch_on.auffangen><en> Because of the sensitive surface of the printing area he is enabled to catch and illustrate the slightest movements: the wing beats of moths passing by lamps or the tracks ants leave behind.
<G-vec00689-002-s087><catch_on.auffangen><de> Natürlich ist ein Schirmständer auch dazu da, herabtropfendes Wasser aufzufangen.
<G-vec00689-002-s087><catch_on.auffangen><en> Of course, an umbrella stand is also used to catch dripping water.
<G-vec00689-002-s088><catch_on.auffangen><de> Eine Entscheidung war während der Entbindung dass niemand da war um mich bei der Geburt 'aufzufangen'.
<G-vec00689-002-s088><catch_on.auffangen><en> One decision was during delivery that no one was there to 'catch me' at delivery.
<G-vec00689-002-s089><catch_on.auffangen><de> Wahrlich, von Gottes Königreich der Himmel aus kam ein himmlisches Fangnetz, um viele Seelen und die Kinder aufzufangen, und um sie beieinander vor Gottes Thron zu bringen.
<G-vec00689-002-s089><catch_on.auffangen><en> Verily, from God’s Kingdom of heaven a heavenly safety net came, in order to catch many souls and the children, and to gather them before God’s throne.
<G-vec00689-002-s090><catch_on.auffangen><de> Zuerst mochte ich diesen süßen Plüschhund noch und habe ihn hochgeworfen um ihn wieder aufzufangen, doch er ist daneben gefallen und nicht zurück gekommen.
<G-vec00689-002-s090><catch_on.auffangen><en> First I really liked this little plush doggy and threw it into the air to catch it again, but it fell off my hands and didn't come back.
<G-vec00689-002-s091><catch_on.auffangen><de> Popularität: 8,0 Versuche alle fallende Schneeflocken aufzufangen.
<G-vec00689-002-s091><catch_on.auffangen><en> Popularity: 8.7 Run up and down and jump to catch all snowflakes.
<G-vec00689-002-s092><catch_on.auffangen><de> Versuch in der Süßwarenfabrik so viel Süßigkeiten aufzufangen wie du nur kannst.
<G-vec00689-002-s092><catch_on.auffangen><en> Try to catch as many sweets as you can before time runs out.
