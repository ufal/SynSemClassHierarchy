<G-vec00880-002-s019><awake.aufwachen><de> Petrus aber und die mit ihm waren, waren beschwert vom Schlaf; als sie aber völlig aufgewacht waren, sahen sie seine Herrlichkeit und die zwei Männer, die bei ihm standen.
<G-vec00880-002-s019><awake.aufwachen><en> 32 Now Peter and those who were with him were overcome with sleep: but when they were fully awake, they saw his glory and the two men who were with him.
<G-vec00880-002-s020><awake.aufwachen><de> An diesem Tag kamen die OP-Schwestern herein, als sie hörten, daß ich aufgewacht wäre.
<G-vec00880-002-s020><awake.aufwachen><en> That day the operating room nurses came in when they heard I was awake.
<G-vec00880-002-s021><awake.aufwachen><de> Im Dashboard erkennen Sie, wie lange Sie geschlafen haben und wie oft Sie aufgewacht sind.
<G-vec00880-002-s021><awake.aufwachen><en> The dashboard shows how long you slept and how often you were awake.
<G-vec00880-002-s022><awake.aufwachen><de> Tag 2, aufgewacht in Aguas Calientes, dann erkunden Sie Machu Picchu während einer geführten Tour bevor Sie zurück nach Cusco fahren.
<G-vec00880-002-s022><awake.aufwachen><en> Day 2, awake refreshed in Aguas Calientes then explore more of Machu Picchu during a guided tour before heading back to Cusco.
<G-vec00880-002-s023><awake.aufwachen><de> Und danach wenn die Fledermäuse aufgewacht waren.
<G-vec00880-002-s023><awake.aufwachen><en> The rest was spent when the bats were awake.
<G-vec00880-002-s024><awake.aufwachen><de> 32Petrus aber und die mit ihm waren, waren beschwert vom Schlaf; als sie aber völlig aufgewacht waren, sahen sie seine Herrlichkeit und die zwei Männer, welche bei ihm standen.
<G-vec00880-002-s024><awake.aufwachen><en> 32Now Peter and they that were with him were heavy with sleep: but when they were fully awake, they saw his glory, and the two men that stood with him.
<G-vec00880-002-s025><awake.aufwachen><de> Frühe wille ich aufwachen.
<G-vec00880-002-s025><awake.aufwachen><en> I myself will awake right early.
<G-vec00880-002-s026><awake.aufwachen><de> Das Gerüst, an das wir uns klammern, wenn wir in der Nacht schweißgebadet aufwachen, weil wir vergessen hatten, wer wir sind.
<G-vec00880-002-s026><awake.aufwachen><en> The framework of references that we cling to when we awake in the night, drenched with sweat because we have forgotten who we are.
<G-vec00880-002-s027><awake.aufwachen><de> Bevor die anderen Leute aufwachen brechen wir unsere Zelte ab und laufen los.
<G-vec00880-002-s027><awake.aufwachen><en> Before the others awake we break our camp and hike on.
<G-vec00880-002-s028><awake.aufwachen><de> Und viele von denen, die im Staub der Erde schlafen, werden aufwachen: die einen zu ewigem Leben und die anderen zur Schande, zu ewigem Abscheu.
<G-vec00880-002-s028><awake.aufwachen><en> 2 Many of those who sleep in the dust of the earth shall awake, some to everlasting life, and some to shame and everlasting contempt.
<G-vec00880-002-s029><awake.aufwachen><de> Und - so gab er uns zu bedenken: Wenn er überhaupt wieder aufwachen könnte, dann würde er mit Sicherheit ein 100 %er Pflegefall werden.
<G-vec00880-002-s029><awake.aufwachen><en> And – what we should consider: If he was to awake at all, he would be a 100 % invalide.
<G-vec00880-002-s030><awake.aufwachen><de> Begib dich selbst in eine Position, die es dir erlaubt, dich schlafend zu stellen (oder dich schnell zu verstecken), sollte die Person aufwachen.
<G-vec00880-002-s030><awake.aufwachen><en> Take a position that will allow you to feign sleep (or quickly hide) if they awake.
<G-vec00880-002-s031><awake.aufwachen><de> Denn Pillen für oder gegen alles Mögliche zu nehmen ist heute normal geworden: zum Zu- oder Abnehmen, Einschlafen oder Aufwachen, um sich zu beruhigen oder noch eine Nacht durchzuarbeiten.
<G-vec00880-002-s031><awake.aufwachen><en> Today, taking pills for or against whatever – to gain or lose weight, to go to sleep or stay awake, to calm down or to work around the clock – has become the norm.
<G-vec00880-002-s032><awake.aufwachen><de> Daniel 12,2 sagt: “Und viele, die unter der Erde schlafen liegen, werden aufwachen, die einen zum ewigen Leben, die andern zu ewiger Schmach und Schande.“ Ähnlich hat Jesus selbst über die Ungläubigen gesagt: „Und sie werden hingehen: diese zur ewigen Strafe, aber die Gerechten in das ewige Leben“ (Matthäus 25,46).
<G-vec00880-002-s032><awake.aufwachen><en> Daniel 12:2 says, “Multitudes who sleep in the dust of the earth will awake: some to everlasting life, others to shame and everlasting contempt.” Similarly, Jesus Himself said that the wicked “will go away to eternal punishment, but the righteous to eternal life” (Matthew 25:46).
<G-vec00880-002-s033><awake.aufwachen><de> 2 Und viele von denen, die im Staub der Erde schlafen, werden aufwachen; die einen zum ewigen Leben, die anderen zur ewigen Schmach und Schande.
<G-vec00880-002-s033><awake.aufwachen><en> 2 Many of those who sleep in the dust of the earth[bk] shall awake, some to everlasting life, and some to shame and everlasting contempt.
<G-vec00880-002-s034><awake.aufwachen><de> Der Patient muss lernen, mit dem Pressen des Kiefers und Knirschen der Zähne beim Aufwachen aufzuhören.
<G-vec00880-002-s034><awake.aufwachen><en> The patient must learn to stop clenching the jaw and grinding the teeth when awake.
<G-vec00880-002-s035><awake.aufwachen><de> Zweitens und am wichtigsten: Es ist an der Zeit für alle Deutschen, dass sie aus einem verständlichen Schlaf aufwachen.
<G-vec00880-002-s035><awake.aufwachen><en> The second and main thing to be said is that it is now time for all Germans to awake from an understandable sleep.
<G-vec00880-002-s036><awake.aufwachen><de> Die da schlafen, auf der Erde, werden aufwachen und jubeln; Denn dein Tau ist ein Tau des funkelnden Licht, und die Erde wird die schon lange tot zur Welt zurückbringen "(Jesaja 26: 19).
<G-vec00880-002-s036><awake.aufwachen><en> They that sleep in the earth will awake and shout for joy; for thy dew is a dew of sparkling light, and the earth will bring those long dead to birth again.”
<G-vec00880-002-s037><awake.aufwachen><de> Zwar ist das Zelt eine der ältesten Behausungsarten, doch auch heute verkriecht der Mensch sich noch gern in Zelten, Jurten und Tipis, um morgens nach dem Aufwachen gleich mitten in der Natur zu stehen.
<G-vec00880-002-s037><awake.aufwachen><en> Although tents are one of the oldest types of dwellings, even today people still enjoy tucking themselves away in tents, yurts and tepees, to awake in the morning surrounded by nature. Nowadays, you don’t have to sacrifice luxury and comfort for the sake of mobility.
<G-vec00880-002-s038><awake.aufwachen><de> Beim Aufwachen erwartet Sie das leckere Frühstücksbuffetmit süßen und herzhaften Köstlichkeiten: Brioches, verschiedene Mürbeteigtorten, Plumcakesund Gebäck sowie Wurstwaren, Käse und Obst.
<G-vec00880-002-s038><awake.aufwachen><en> When you awake, a sweet and savoury breakfast awaits you. You can look forward to our croissants, pies, plum cake and pastries, but also meats, cheeses and fruit.
<G-vec00880-002-s039><awake.aufwachen><de> Und viele, die unter der Erde schlafen liegen, werden aufwachen, die einen zum ewigen Leben, die andern zu ewiger Schmach und Schande.
<G-vec00880-002-s039><awake.aufwachen><en> Multitudes who sleep in the dust of the earth will awake: some to everlasting life, others to shame and everlasting contempt.
<G-vec00880-002-s040><awake.aufwachen><de> Alles um uns herum ist ausgeschaltet, wir befinden uns in einer anderen, ruhigen Welt, und wenn wir aufwachen, gibt es eine großes Staunen … und Glück, Demut, Dankbarkeit.
<G-vec00880-002-s040><awake.aufwachen><en> Everything around us is turned off, we’re in a different, quiet world and when we awake there is a big surprise … and happiness, humility, gratitude. Flow.
<G-vec00880-002-s041><awake.aufwachen><de> Und viele von denen, die im Staub der Erde schlafen, werden aufwachen; die einen zum ewigen Leben, die anderen zur ewigen Schmach und Schande.
<G-vec00880-002-s041><awake.aufwachen><en> And many of them that sleep in the dust of the earth shall awake, some to everlasting life, and some to shame, to everlasting contempt.
<G-vec00880-002-s042><awake.aufwachen><de> 2 Und viele von denen, die im Staub der Erde schlafen, werden aufwachen: die einen zu ewigem Leben und die anderen zur Schande, zu ewigem Abscheu.
<G-vec00880-002-s042><awake.aufwachen><en> 2 And many of them that sleepe in the dust of the earth, shall awake, some to euerlasting life, and some to shame and perpetuall contempt.
<G-vec00880-002-s043><awake.aufwachen><de> Dieser nächste Film ist wieder einfach brillant und ich hoffe, dass die Menschen Amerikas aus ihrer mentalen Krankheit aufwachen.
<G-vec00880-002-s043><awake.aufwachen><en> This next film again is just brilliant and I hope American people awake from their mental illness.
<G-vec00880-002-s044><awake.aufwachen><de> Wenn ihr aufwacht, kommt schnurstracks zu Mir und sucht Meinen Willen und lehnt ab, vom Kurs weggezogen zu werden.
<G-vec00880-002-s044><awake.aufwachen><en> When you awake, make a beeline for My will and refuse to be steered off course.
<G-vec00880-002-s045><awake.aufwachen><de> “Viele von euch liegen in Betten der Verurteilung, von dem Zeitpunkt, wo ihr aufwacht und zu Bewusstsein kommt bis zu dem Augenblick, wo ihr ins Bett fällt, um zu schlafen.
<G-vec00880-002-s045><awake.aufwachen><en> “Many of you are lying in beds of condemnation, from the time you awake and become conscious to the very moment you drop off to sleep.
<G-vec00880-002-s046><awake.aufwachen><de> Und wenn es aufwacht, kommt alles wieder.
<G-vec00880-002-s046><awake.aufwachen><en> And when it´s awake again, everything returns.
<G-vec00880-002-s133><awake.aufwachen><de> Nehmen Sie diese Ergänzung am Abend nicht, weil es Sie die ganze Nacht hindurch wach halten kann.
<G-vec00880-002-s133><awake.aufwachen><en> Do not take this supplement in the evening given that it could remain you awake via the night.
<G-vec00880-002-s143><awake.aufwachen><de> Die Vergeßlichkeit der Träume für das wache Bewußtsein ist augenscheinlich nur das Gegenstück zu der früher erwähnten Tatsache, daß der Traum (fast) nie geordnete Erinnerungen aus dem Wachleben, sondern nur Einzelheiten aus demselben übernimmt, die er aus ihren gewohnten psychischen Verbindungen reißt, in denen sie im Wachen erinnert werden.
<G-vec00880-002-s143><awake.aufwachen><en> The forgetfulness of the waking consciousness for dreams is evidently only the counter- part of the fact already mentioned, that the dream (almost) never takes over successive memories from the waking state, but only certain details of these memories which it tears away from the habitual psychic connections in which they are re- called while we are awake.
<G-vec00880-002-s144><awake.aufwachen><de> Hierauf gestand er uns, daß ihn ein Traum herauf an diese Stelle treibe, ein Traum, der so klar, bestimmt und deutlich gewesen sei, als ob er im Wachen, nicht aber im Schlafe stattgefunden habe.
<G-vec00880-002-s144><awake.aufwachen><en> Regarding this, he confessed to us that a dream drove him to this conclusion, a dream that had been so certain and so clear that it seemed he was awake and not sleeping at all.
<G-vec00880-002-s161><awake.aufwachen><de> Sie waren schon lange vor dem ersten Hahnenschrei wach und haben noch vor Tagesanbruch ihre Marktstände aufgebaut.
<G-vec00880-002-s161><awake.aufwachen><en> They were awake long before the first rooster began to crow and have been busy setting up their market stands since before daybreak.
<G-vec00880-002-s162><awake.aufwachen><de> Shinji war schon seit einigen Minuten wach, doch er hatte nicht die Absicht schon aufzustehen.
<G-vec00880-002-s162><awake.aufwachen><en> Shinji was awake for several minutes, yet he had no intention to get up.
<G-vec00880-002-s163><awake.aufwachen><de> [GEJ 10.178.5] Als er zurückkam, waren auch die Jünger schon wach, und der Oberstadtrichter und die beiden Pharisäer Dismas und Barnabas standen auch schon vor der Tür der Herberge und wollten eintreten; aber Ich war auch schon bei der Tür, um mit den Meinen, dem Wirte und seinem Sohne den Berg Mosis zu besteigen.
<G-vec00880-002-s163><awake.aufwachen><en> [GGJ 10.178.5] When he came back, the disciples were also awake, and also the supreme judicial city officer and the 2 Pharisees Dismas and Barnabas stood already at the door of the inn and wanted to come in. Also I was already at the door with My followers, the innkeeper and his son to climb the Mountain of Moses.
<G-vec00880-002-s167><awake.aufwachen><de> Ich gehe in diesem Artikel nicht detailliert darauf ein, aber zuerst einmal musste ich in einen Zustand gelangen, indem ich den physischen Körper in eine Tiefenentspannung begleite, sodass er einschläft und ich brav wach bleibe.
<G-vec00880-002-s167><awake.aufwachen><en> I do not go in this article into the details, but first I had to get into a state by accompanying the physical body into a deep relaxation, so that it falls asleep and I remain bravely awake.
<G-vec00880-002-s168><awake.aufwachen><de> Der Multiple Wachbleibetest wird durchgeführt, um festzustellen, wie gut Menschen im Sitzen in einem ruhigen Raum wach bleiben können.
<G-vec00880-002-s168><awake.aufwachen><en> The maintenance of wakefulness test is used to determine how well people can remain awake while sitting in a quiet room.
<G-vec00880-002-s169><awake.aufwachen><de> Ihr Baby ist nie länger als 30 Minuten wach.
<G-vec00880-002-s169><awake.aufwachen><en> Your baby doesn't stay awake for more than 30 minutes at a time.
<G-vec00880-002-s170><awake.aufwachen><de> Bildschirmzeitüberschreitung, Wach bleiben, Taschenlampe, Wecker, Vibrationsalarm, Synchro, Hintergrunddaten, Debug, Unbekannte Quellen, Neustart usw.
<G-vec00880-002-s170><awake.aufwachen><en> GPS,WiFi localization,WiFi,BT,APN,NFC,Airplane,Tethering,Brightness,Screen time-out,Stay awake,Flashlight,Ringer,Vibrate,Synchro,Background data,Debug,Unknown sources,Reboot,etc
<G-vec00880-002-s171><awake.aufwachen><de> Das Ziel, die Erinnerung an Salzburgs Natur, Geschichte, Kunst- und Kulturgeschichte wach zu halten, führte seit der Gründung des Salzburg Museum im Jahr 1834 auch zum Sammeln kunstgewerblicher und kulturhistorischer Gegenstände.
<G-vec00880-002-s171><awake.aufwachen><en> The goal of keeping awake the memory of Salzburg’s nature, history, art and cultural history since the foundation of the Salzburg Museum in 1834 has also led to the collecting of objects from the applied arts and cultural history.
<G-vec00880-002-s172><awake.aufwachen><de> Alle Karten sind darauf ausgerichtet, die Bewusstheit zu erhöhen - wach auch im Alltag zu sein.
<G-vec00880-002-s172><awake.aufwachen><en> All cards are designed to increase the awareness - to be awake in everyday life.
<G-vec00880-002-s174><awake.aufwachen><de> Zum Beispiel, “Ich” existiert nur, wenn ich wach bin.
<G-vec00880-002-s174><awake.aufwachen><en> For example, “I” exist only when I am awake.
<G-vec00880-002-s175><awake.aufwachen><de> Sogar Jerome und MiBi sind wieder wach.
<G-vec00880-002-s175><awake.aufwachen><en> Even Jerome and MiBi are awake again.
<G-vec00880-002-s176><awake.aufwachen><de> Die erste Nacht schlief ich mit zwei Bettdecken, Bademäntel und Schlafanzüge, Socken, und ich bin mehr wach 'mal in der Nacht.
<G-vec00880-002-s176><awake.aufwachen><en> The first night I slept with two duvets, robes and pajamas, socks, and I am more awake 'times in the night.
<G-vec00880-002-s177><awake.aufwachen><de> Die Musik fließt durch die Seele, der Körper folgt der Musik, der Geist ist wach und entspannt, so entsteht der geheimnisvolle „Flow“, der uns Raum und Zeit vergessen lässt.
<G-vec00880-002-s177><awake.aufwachen><en> The music flows through the soul, the body follows the music, the mind is awake and relaxed, this creates the mysterious “flow” that makes us forget space and time.
<G-vec00880-002-s178><awake.aufwachen><de> Glauben schläfert ein und ihr sollt wach sein.
<G-vec00880-002-s178><awake.aufwachen><en> Believing makes numb but you must be awake.
<G-vec00880-002-s180><awake.aufwachen><de> Diejenigen von euch, die wach und bewusst sind, machen sehr schwierige Zeiten durch.
<G-vec00880-002-s180><awake.aufwachen><en> Those of you who are awake and aware are going through very difficult times.
<G-vec00880-002-s181><awake.aufwachen><de> Sie werden jederzeit wissen, ob Ihr Kind schläft oder wach ist, egal, ob Sie gerade im Büro oder im Garten sind.
<G-vec00880-002-s181><awake.aufwachen><en> You’ll always know if your child is sleeping or awake, whether you’re at the office or right in the backyard.
<G-vec00880-002-s182><awake.aufwachen><de> Hinterher fühlte ich mich sehr wach und konzentriert, wenn ich das Fa lernte.
<G-vec00880-002-s182><awake.aufwachen><en> Afterward, I felt very awake and concentrated when I was studying the Fa.
<G-vec00880-002-s183><awake.aufwachen><de> Sogar nachdem das Ereignis vorüber war und ich viel Zeit hatte darüber nachzudenken, fühlte ich dennoch als wäre ich, während des Erlebnisses vollständig wach, und mir meiner Umgebung total bewusst gewesen.
<G-vec00880-002-s183><awake.aufwachen><en> Even after the event was over and I had much time to reflect, I still felt as if I was full awake and totally aware of my surroundings during the experience.
<G-vec00880-002-s184><awake.aufwachen><de> Gut, wo ich schon mal wach bin, kann ich tatsächlich die Gelegenheit nutzen und schreiben und nebenher etwas meinem Sarkasmus frönen.
<G-vec00880-002-s184><awake.aufwachen><en> But since I’m already awake I can really take the opportunity to write and alongside feed my sarcasm a little bit.
<G-vec00880-002-s185><awake.aufwachen><de> Wenn dein Schatz nur noch im Halbschlaf ist, sag einfach, dass du schon wach bist und raus musst.
<G-vec00880-002-s185><awake.aufwachen><en> If your treasure is only in the half sleep, simply say that you are quite awake and have to go out.
<G-vec00880-002-s186><awake.aufwachen><de> GODOT sagt im Film: „Woher weißt du, dass du wach bist?“ Vielleicht sind wir alle Träumer, die darauf warten, aufzuwachen.
<G-vec00880-002-s186><awake.aufwachen><en> In the film GODOT says: “How do you know, you are awake?” Perhaps we are all dreamers who are waiting to awake.
<G-vec00880-002-s187><awake.aufwachen><de> Erschöpfung kann viele Dinge bedeuten: dass du mehr Ruhe brauchst, dass es etwas gibt, was du dir nicht anschaust, dass du mehr Energie hinaus gibst, als du herein nimmst, dass du nicht ganz wach bist, dass etwas deine Aufmerksamkeit benötigt.
<G-vec00880-002-s187><awake.aufwachen><en> Fatigue may mean many things, that you need more rest, that there is something you don't want to look at, that you are giving out more energy than you take in, that you are not wide awake, that something needs attention.
<G-vec00880-002-s188><awake.aufwachen><de> Ich greife nach ihren Schultern und versuche sie wach zu rütteln.
<G-vec00880-002-s188><awake.aufwachen><en> I grab her shoulders and shake her awake.
<G-vec00880-002-s189><awake.aufwachen><de> Seht, Ich habe euch 7 Mal gerufen, um euch wach zu rütteln; ja sogar 10 Mal soll es gesprochen werden durch Meine Propheten.
<G-vec00880-002-s189><awake.aufwachen><en> See, I have called you to awake these seven times; yea, even ten times shall it be spoken through My prophets.
<G-vec00880-002-s190><awake.aufwachen><de> Weitere Probleme können die Schwierigkeit einschließen einen Partner zu finden und die Beziehung zu solch unüblichen Zeiten weiterzuführen, das Einkaufen wenn die Geschäfte offen sind, sowie wach sein für frühe Termine mit Handwerkern und Ärzten.
<G-vec00880-002-s190><awake.aufwachen><en> Other issues can include difficulty finding and maintaining relationships on such an unusual schedule, shopping when the stores are open, and being awake for early appointments with repair people and doctors.
<G-vec00880-002-s191><awake.aufwachen><de> Zusätzlich wird Ihr Tagesrhythmus stark durch Ihre biologische Uhr beeinflusst Diese Uhr befindet sich im Gehirn und ist verantwortlich dafür, dass man jeden Tag in etwa zur gleichen Zeit Hunger verspürt, sie kontrolliert die Körpertemperatur und lässt uns müde oder wach sein.
<G-vec00880-002-s191><awake.aufwachen><en> Your circadian rhythms are heavily influenced by your biological clock. This biological clock is found in the brain and it’s what makes you hungry every day around the same time, what controls your body temperature, and what makes you feel tired and awake again.
<G-vec00880-002-s192><awake.aufwachen><de> Er ist eine weitere wichtige Chance für uns, wach zu sein und für mehr Toleranz zu kämpfen.
<G-vec00880-002-s192><awake.aufwachen><en> This is another important chance for us, to stay awake, in LIGHT for more tolerance.
<G-vec00880-002-s193><awake.aufwachen><de> Wach sein ist mit einem Preis verbunden.
<G-vec00880-002-s193><awake.aufwachen><en> Being awake comes with a price.
<G-vec00880-002-s196><awake.aufwachen><de> Jetzt ist es eine unglaubliche Sache, mit dem Fahrrad durch diese schöne Stadt zu fahren und ohne jeden Zweifel zu sehen, dass Amsterdam vorbeifliegt, während „ich“ diese wache, unbewegte Ruhe bin.
<G-vec00880-002-s196><awake.aufwachen><en> Now its a tremendous thing to cycle around this beautiful city and see, beyond all doubt, that it's Amsterdam that flies by while 'I' am this awake unmoving stillness.
<G-vec00880-002-s197><awake.aufwachen><de> Wache auf, schüttle dich und zieh Seine Kraft an.
<G-vec00880-002-s197><awake.aufwachen><en> Awake, shake, and put on His strength.
<G-vec00880-002-s198><awake.aufwachen><de> Wie zwei Wache unter allen anderen, die schlafen, sehen Mika und Shinji in die tägliche graue Wahrheit der Arbeiterklasse: Eine Gesellschaft von jungen japanischen Erwachsenen, die kaum eine Perspektive haben, die nur noch funktionieren statt zu leben und keine Träume haben.
<G-vec00880-002-s198><awake.aufwachen><en> Like two awake persons among all others sleeping, Mika and Shinji are looking into the daily grey truth of the working class: A society of young Japanese adults, who almost don’t have a perspective, who are only functioning instead of living and don’t have dreams anymore.
<G-vec00880-002-s199><awake.aufwachen><de> Durch seine Überzahl, den Geländevorteil, Sichelwagen, Kampfelefanten und die starke Kampfkraft fühlte sich Dareios äußerst siegessicher, doch die Perser befürchteten einen Nachtangriff der Makedonen und befahlen deshalb allen Männern, Wache zu halten, um gegen einen Angriff gewappnet zu sein.
<G-vec00880-002-s199><awake.aufwachen><en> On account of his numerical advantage, the favourable terrain, the scythed chariots, war elephants and fighting power, Darius was very sure of victory, but the Persians feared a night attack by the Macedonians and therefore ordered all men to remain awake, in order to be prepared for an attack.
<G-vec00880-002-s200><awake.aufwachen><de> Wir können einen Weg entlang gehen und gleichzeitig mit einem anderen Wesen reden, ohne daß wir der Bewegung unserer Beine irgendeine besondere wache, tagesbewußte Aufmerksamkeit schenken müßten.
<G-vec00880-002-s200><awake.aufwachen><en> We can walk along a road and at the same time talk to another being without having to give the movement of our legs any particular awake, day-conscious attention.
<G-vec00880-002-s201><awake.aufwachen><de> Ich wache immer auf, aber kann mich nicht zusammenreißen und aufstehen.
<G-vec00880-002-s201><awake.aufwachen><en> I am sometimes awake for very short times, but cannot pull myself together enough to get up and out of bed.
<G-vec00880-002-s202><awake.aufwachen><de> Von Sonnenstrahlen geküsst wache ich auf und sehe meine Zuhause für die nächsten 3 Tage zum ersten Mal bei Tageslicht.
<G-vec00880-002-s202><awake.aufwachen><en> Kissed by warm sunbeams I awake and see my home for the next 3 days in daylight for the first time.
<G-vec00880-002-s203><awake.aufwachen><de> Ergebnis: strahlende und wache Augen.
<G-vec00880-002-s203><awake.aufwachen><en> The result: radiant, wide-awake eyes.
<G-vec00880-002-s204><awake.aufwachen><de> Weitere Druckbestimmungen wurden am wachen Tier vorgenommen.
<G-vec00880-002-s204><awake.aufwachen><en> Further pressure measurements were performed on awake animals.
<G-vec00880-002-s205><awake.aufwachen><de> Das sollt ihr aber wissen: Wenn der Hausvater wüßte, welche Stunde der Dieb kommen wollte, so würde er ja wachen und nicht in sein Haus brechen lassen.
<G-vec00880-002-s205><awake.aufwachen><en> Be sure of this: if the master of the house had known the hour of night when the thief was coming, he would have stayed awake and not let his house be broken into.
<G-vec00880-002-s206><awake.aufwachen><de> So lasst uns nun nicht schlafen wie die andern, sondern lasst uns wachen und nüchtern sein.
<G-vec00880-002-s206><awake.aufwachen><en> So then let us not sleep, as others do, but let us keep awake and be Thessalonians 5:6 | ESV
<G-vec00880-002-s207><awake.aufwachen><de> Wir waren alle irgendwie zwischen Wachen und Träumen, zwischen Geschichte, Erinnerung und nirgendwo.
<G-vec00880-002-s207><awake.aufwachen><en> We were all somewhere between awake and dreaming, between history, memory, and nowhere.
<G-vec00880-002-s208><awake.aufwachen><de> Tragen Sie den Haufstraffer für weite, Augen mit einem wachen Blick auf.
<G-vec00880-002-s208><awake.aufwachen><en> Glide on skin tightener for wide awake eyes.
<G-vec00880-002-s209><awake.aufwachen><de> Wir wünschen uns für Lou eine Verwendung als Freizeit- oder Therapiepferd bei fachkundigen Menschen, die Freude an ihrer wachen Intelligenz und ihrem liebenswerten Charakter haben.
<G-vec00880-002-s209><awake.aufwachen><en> We would like Lou to be used as a recreational or therapy horse for knowledgeable people who enjoy their awake intelligence and their Pedigree
<G-vec00880-002-s210><awake.aufwachen><de> Agni Yoga spricht an vielen Stellen von der Wichtigkeit, unserem Leben einen harmonischen Rhythmus zu geben: Leben und Tod, Schlafen und Wachen, Säen und Ernten, Aktivität und Kontemplation, Denken und Handeln, geistige Arbeit und physisches Wirken – überall sehen wir: Ein gesundes Leben hängt davon ab, dass wir allen Aspekten unseres Daseins gleichermaßen und gleichgewichtig Ausdruck verleihen.
<G-vec00880-002-s210><awake.aufwachen><en> Agni Yoga often speaks about the importance of giving our life a harmonious rhythm: Life and death, sleeping and being awake, sowing and harvesting, activity and contemplation, thinking and acting, spiritual and physical work – again and again we see: A healthy life requires that we give all aspects of our existence equal weight.
<G-vec00880-002-s211><awake.aufwachen><de> Wenn eine Mutter plötzlich spürt oder vor sich sieht, sei es nun im Traum oder im wachen Zustand, daß sich ihr Sohn, der in Amerika lebt, in großer Gefahr befindet, so liegt das daran, daß der Sohn in der Gefahrensituation so stark an seine Mutter gedacht hat, daß diese Gedankenkonzentration, so wie Radiowellen, den „Empfangsapparat“ der Mutter getroffen hat, der aufgrund ihrer Liebe zu dem Sohn in hohem Maße empfänglich dafür ist.
<G-vec00880-002-s211><awake.aufwachen><en> If a mother suddenly senses or sees in her mind's eye, whether it is in a dream or an awake state, that her son who lives in America is in grave danger, it is because the son in the dangerous situation has thought so strongly about his mother, that this concentration of thought just like radio waves comes into contact with the mother's "radio receiver", which because of her love for her son is highly receptive.
<G-vec00880-002-s212><awake.aufwachen><de> Doch diese Lichtwesen werden immer wieder die Menschen zu bestimmen suchen, die Verbindung mit der geistigen Welt im wachen, bewußten Zustand herzustellen, sie werden sie über das "Wirken des Geistes" im Menschen aufklären und sie anzuregen suchen, mit Mir Selbst in innigen Kontakt zu treten, um dann ein tiefes Wissen entgegennehmen zu können, das auf medialem Wege.... in unbewußtem Zustand.... nicht zur Erde geleitet werden kann.
<G-vec00880-002-s212><awake.aufwachen><en> Yet these beings of light will time and again try to influence people into establishing the connection with the spiritual world in an awake, conscious state, they will enlighten them about the 'working of the spirit' in a person and aim to encourage them to enter into heartfelt contact with Me, which will enable them to receive profound knowledge which cannot be conveyed to earth in a psychic way.... in a state of trance.
<G-vec00880-002-s213><awake.aufwachen><de> Floris Vanhoof ist mit seinem „Music For Moving Lamps“ weniger an einem wissenschaftlichen Aspekt einer Versuchsanordnung interessiert, sondern um eine poetische Bedeutung bemüht: Wie im Theater wenn die Lichter ausgehen und die Bühne umgebaut wird, wachen wir jeden Tag in einer neuen Situation auf.
<G-vec00880-002-s213><awake.aufwachen><en> In his "Music for Moving Lamps", Floris Vanhoof is less interested in the scientific aspect of an experimental arrangement than in seeking poetic meaning: Much like the experience at the theater when the lights go out while the stage is adapted, we awake each day to a new situation.
<G-vec00880-002-s214><awake.aufwachen><de> Die großen, wachen Augen und auffälligen Ohrmuscheln sind stets in Bewegung, die Schnurrhaare vibrieren – es sind sinneswache, ruhelose Tiere.
<G-vec00880-002-s214><awake.aufwachen><en> The large, awake eyes and distinctive auricles are always in motion, its whiskers vibrate – these are restless animals with wakeful senses.
<G-vec00880-002-s215><awake.aufwachen><de> Wir laden euch ein, ein wirklich wunderschönes Schriftstück von einer Frau zu lesen, die das Gespräch darüber eröffnet wie das Reich der derzeitigen und künftigen Möglichkeiten von einem wachen und femininen Blickwinkel aussieht.
<G-vec00880-002-s215><awake.aufwachen><en> We invite you to check out a really beautiful piece of writing from a woman who opens the discussion on what the realm of current and future possibilities looks from an awake and feminine point of view.
<G-vec00880-002-s216><awake.aufwachen><de> 10 Er ist für uns gestorben, damit wir vereint mit ihm leben, ob wir nun wachen oder schlafen.
<G-vec00880-002-s216><awake.aufwachen><en> 10 who died for us so that whether we are awake or asleep we might live with him.
<G-vec00880-002-s218><awake.aufwachen><de> An einem Modell für schwere Querschnittslähmung soll die gleichzeitige Aktivität einer großen Anzahl an Nervenzellen innerhalb des Transplantats und dem angrenzenden Wirtsgewebe in wachen Tieren beobachtet werden; das soll es ermöglichen, zu verstehen, wie Signale in NSC-Transplantate und darüber hinaus übertragen werden.
<G-vec00880-002-s218><awake.aufwachen><en> Using a rodent model of severe SCI, we will image the simultaneous activity of large populations of neurons within NSC grafts and adjacent host spinal cord in awake, behaving animals; this will allow us to understand how signals are transmitted into and across NSC grafts on a large scale.
<G-vec00880-002-s219><awake.aufwachen><de> 9 Denn Gott hat uns nicht gesetzt zum Zorn, sondern die Seligkeit zu besitzen durch unsern HERRN Jesus Christus, 10 der für uns alle gestorben ist, auf daß, wir wachen oder schlafen, wir zugleich mit ihm leben sollen.
<G-vec00880-002-s219><awake.aufwachen><en> 9 For God's purpose for us is not wrath, but salvation through our Lord Jesus Christ, 10 Who was put to death for us, so that, awake or sleeping, we may have a part in his life.
<G-vec00880-002-s221><awake.aufwachen><de> 43 Das sollt ihr aber wissen: Wenn der Hausvater wüßte, welche Stunde der Dieb kommen wollte, so würde er ja wachen und nicht in sein Haus brechen lassen.
<G-vec00880-002-s221><awake.aufwachen><en> 43 “But know one thing, that if the householder had known in what watch the thief was coming, he would have kept awake and not allowed his house to be broken into.
<G-vec00880-002-s222><awake.aufwachen><de> Moderne Techniken ermöglichen aber inzwischen eine minimale Schädigung des tumorumgebenden gesunden Gewebes (Färbetechniken, Computer-gestützte Operation, Operation am wachen Patienten).
<G-vec00880-002-s222><awake.aufwachen><en> Modern techniques do enable minimal damage to healthy tissue surrounding the tumour (dyeing techniques, computer-supported operations, operations on patients who are awake).
<G-vec00880-002-s255><awake.aufwachen><de> Müht euch miteinander, kämpft gemeinsam, lauft gemeinsam, leidet gemeinsam, schlaft und wacht gemeinsam als Verwalter Gottes, seine Hausgenossen und Diener.
<G-vec00880-002-s255><awake.aufwachen><en> Labour together with one another; strive in company together; run together; suffer together; sleep together; and awake together as the stewards and associates and servants of God.
<G-vec00880-002-s256><awake.aufwachen><de> Wir sehen ein Panorama des Schlafs, das total und in dieser vollkommenen Ausschliesslichkeit unheimlich geworden ist: Alles schläft, keiner wacht, keine bewegt sich.
<G-vec00880-002-s256><awake.aufwachen><en> We see a panorama of sleep that, in its totality and exclusiveness, has become scary: everybody is asleep, nobody is awake, nobody moving.
<G-vec00880-002-s257><awake.aufwachen><de> Am Gaumen noch immer verschlossen, wacht gerade erst langsam auf.
<G-vec00880-002-s257><awake.aufwachen><en> In the mouth closed still awake, just to slowly.
<G-vec00880-002-s258><awake.aufwachen><de> Glückselig, der wacht und seine Kleider bewahrt, damit er nicht nackt umhergehe.
<G-vec00880-002-s258><awake.aufwachen><en> Blessed is the one who stays awake and keeps his clothes, so that he will not walk about naked.
<G-vec00880-002-s259><awake.aufwachen><de> Jeder Schritt, den Sie nehmen, denn das große Auge wacht.
<G-vec00880-002-s259><awake.aufwachen><en> Every step that you take, this great Eye is awake,
<G-vec00880-002-s282><awake.aufwachen><de> In dieser Nacht lag ich die meiste Zeit wach und am nächsten Mittag taten mir alle Knochen weh.
<G-vec00880-002-s282><awake.aufwachen><en> I lay awake most of that night, and by noon the next day every bone in my body ached.
<G-vec00880-002-s283><awake.aufwachen><de> An einer heißen Sommernacht die ganze Zeit wach zu liegen und dem ständigen Summen der Mücken zuhören zu müssen, ist schon schlimm genug, also müssen Sie sich nicht noch mehr Unannehmlichkeiten aussetzen.
<G-vec00880-002-s283><awake.aufwachen><en> Laying awake on a hot summer night listening to their insistent droning is bad enough, so you need not add any further inconvenience to the equation.
<G-vec00880-002-s041><wake_up.aufwachen><de> Wenn Sie einen genaueren Blick auf die Details des Bildes werfen, bemerken Sie, daß die im Schlamm spielenden Kinder niemals Schuhe tragen, dass die Schule im Hintergrund seit einer Woche geschlossen ist, da es zu viel geregnet hat und die Straße überflutet war, oder die Schule zu weit weg vom Wohnort der Kinder ist, oder daß die Betreiber der Schule einfach diesen Morgen nicht rechtzeitig aufgewacht sind...
<G-vec00880-002-s041><wake_up.aufwachen><en> As you take a deeper look at the details of the portrait, you note that the children playing in the mud never wear shoes, that the school in the background has been closed for a week because it rained too much and the road was flooded, or the school is too far away from where the children live, or those who operate the school just didn't wake up on time this morning...
<G-vec00880-002-s042><wake_up.aufwachen><de> 6 Falls Du heute Morgen gesund und nicht krank aufgewacht bist, bist Du glücklicher als 1 Million Menschen, welche die nächste Woche nicht erleben werden.
<G-vec00880-002-s042><wake_up.aufwachen><en> 9 Now think: If you wake up this morning with more health than diseases, you have more luck than millions of people who did not survive this week.
<G-vec00880-002-s043><wake_up.aufwachen><de> Im Sommer bin ich oft total gerädert aufgewacht, da ich bei der Hitze sehr schlecht schlafe.
<G-vec00880-002-s043><wake_up.aufwachen><en> In summer i often wake up feeling destroyed, because i sleep very poorly with the heat.
<G-vec00880-002-s044><wake_up.aufwachen><de> Ich bin nicht in einem Raum aufgewacht.
<G-vec00880-002-s044><wake_up.aufwachen><en> I didn't wake up in a room
<G-vec00880-002-s045><wake_up.aufwachen><de> Marie ist heute morgen nicht aufgewacht.
<G-vec00880-002-s045><wake_up.aufwachen><en> Marie she didn't wake up this morning
<G-vec00880-002-s046><wake_up.aufwachen><de> Dem König gefiel der Rat, und er schickte einen von seinen Hofleuten an das Schneiderlein ab, der sollte ihm, wenn es aufgewacht wäre, Kriegsdienste anbieten.
<G-vec00880-002-s046><wake_up.aufwachen><en> The King then summoned his council, and sent one of his courtiers to the little tailor to beg him, so soon as he should wake up, to consent to serve in the King's army.
<G-vec00880-002-s047><wake_up.aufwachen><de> Frau Schläfer kommt verspätet und gesteht Herrn Beinling ohne Umschweife, dass sie nicht rechtzeitig aufgewacht ist.
<G-vec00880-002-s047><wake_up.aufwachen><en> Mrs. Sleeper arrives late and admits freely to Mr. Legg that she did not wake up in time.
<G-vec00880-002-s048><wake_up.aufwachen><de> Mein Papa sagte, dass ich die Mama damals oft gesucht hätte, wenn ich in der Nacht aufgewacht war.
<G-vec00880-002-s048><wake_up.aufwachen><en> My dad said I would often wake up in the middle of the night and look for her.
<G-vec00880-002-s064><wake_up.aufwachen><de> Und wenn ich morgen aufwache, bist du verschwunden.
<G-vec00880-002-s064><wake_up.aufwachen><en> And when I wake up tomorrow morning, you're gone.
<G-vec00880-002-s065><wake_up.aufwachen><de> Die Nacht ist frostig und als ich am Morgen aufwache hat sich auf meiner Tasche neben mir eine Eisschicht gebildet.
<G-vec00880-002-s065><wake_up.aufwachen><en> The night is frosty and as I wake up the next morning a thin layer of ice covers my bag beside me.
<G-vec00880-002-s066><wake_up.aufwachen><de> Wenn ich morgens aufwache und in einem Café etwas trinken möchte, muss ich einen Fahrer rufen, damit er mich dorthin bringt.
<G-vec00880-002-s066><wake_up.aufwachen><en> When I wake up in the morning and I want to go out for a coffee, I have to call a driver to take me to the café.
<G-vec00880-002-s067><wake_up.aufwachen><de> Als ich aufwache, fällt mein Blick auf die friedlich grasenden Pferde auf der Koppel nebenan.
<G-vec00880-002-s067><wake_up.aufwachen><en> When I wake up, my gaze falls on the peacefully grazing horses in the next paddock along.
<G-vec00880-002-s068><wake_up.aufwachen><de> Wenn ich aufwache, hab' ich Angst, dass jemand anderes vielleicht damit endet, ich zu sein.
<G-vec00880-002-s068><wake_up.aufwachen><en> When I wake up I’m afraid, somebody else might end up being me
<G-vec00880-002-s069><wake_up.aufwachen><de> Als ich aufwache, fühle ich mich wieder besser und der Wirt reicht mir ein Sandwich und eine Dose Cola.
<G-vec00880-002-s069><wake_up.aufwachen><en> When I wake up, I feel better again and the owner of the place hands me a sandwich and a coke.
<G-vec00880-002-s070><wake_up.aufwachen><de> Seine Stimme moduliert die Worte, die ich vergessen habe, als ich aufwache.
<G-vec00880-002-s070><wake_up.aufwachen><en> His voice modulates the words that I have forgotten when I wake up.
<G-vec00880-002-s071><wake_up.aufwachen><de> In dieser Zeit wird er vor allem seine Familie und die australische Natur vermissen: „Wenn ich in meiner Heimat morgens aufwache, dann höre ich meistens 15 bis 20 verschiedene Vogelarten singen.
<G-vec00880-002-s071><wake_up.aufwachen><en> During this time, he will miss his family and the nature in Australia: "When I wake up in my home in the morning, I usually hear 15 to 20 different bird species sing.
<G-vec00880-002-s072><wake_up.aufwachen><de> Clarissa: Wenn ich aufwache, bevor mein Wecker klingelt.
<G-vec00880-002-s072><wake_up.aufwachen><en> Clarissa: When I wake up before my alarm clock goes off.
<G-vec00880-002-s073><wake_up.aufwachen><de> Ich bat meine Frau, mich jeden Morgen zu kneifen, wenn ich aufwache und mein Bankguthaben überprüfe.
<G-vec00880-002-s073><wake_up.aufwachen><en> I ask my wife to pinch me every morning when I wake up and check my bank balance.
<G-vec00880-002-s074><wake_up.aufwachen><de> Michael entgegnete: „Wenn ich am Morgen aufwache, sage ich mir: Du hast zwei Möglichkeiten, Du kannst wählen, ob Du guter oder schlechter Laune sein willst.
<G-vec00880-002-s074><wake_up.aufwachen><en> Michael replied, "Each morning I wake up and say to myself, you have two choices today. You can choose to be in a good mood or you can choose to be in a bad mood.
<G-vec00880-002-s075><wake_up.aufwachen><de> Ich habe auch ein eigenes Programm geschrieben, bei dem die Lichter eingeschaltet werden, wenn ich aufwache und ausgeschaltet werden, wenn ich zur Arbeit gehe usw.
<G-vec00880-002-s075><wake_up.aufwachen><en> I even wrote my own program that turns the lights on when I wake up, off when I go to work, etc.
<G-vec00880-002-s076><wake_up.aufwachen><de> Ich kann mir einen halben Liter Buttercreme Eis als Nachtimbiss reinziehen und wenn ich aufwache, hab' ich sogar abgenommen.
<G-vec00880-002-s076><wake_up.aufwachen><en> See, I can moose down a pint of fudge ripple for a midnight snack and wake up having lost weight.
<G-vec00880-002-s077><wake_up.aufwachen><de> Sonntags verwende ich nicht so gerne Peelings, da ich sonst in 80% der Fälle mit mindestens einem Pickel auf der Nase aufwache.
<G-vec00880-002-s077><wake_up.aufwachen><en> If I exfoliate my face on Sunday, 80% of time I’ll wake up on Monday morning with a beautiful spot on my nose.
<G-vec00880-002-s078><wake_up.aufwachen><de> Als ich an meinem letzten Tag hier aufwache, scheint die Sonne.
<G-vec00880-002-s078><wake_up.aufwachen><en> As I wake up on my last day the sun is shining beautifully.
<G-vec00880-002-s079><wake_up.aufwachen><de> Sie haben jeweils eine besondere Atmosphäre oder Gefühl, so erkenne ich nahezu immer einen prophetischen Traum während ich träume oder sobald ich aufwache.
<G-vec00880-002-s079><wake_up.aufwachen><en> They have a special atmosphere or feeling, either so I nearly always know a prophetic dream while I'm dreaming it or as soon as I wake up.
<G-vec00880-002-s080><wake_up.aufwachen><de> Ich melde ständig Stalker, aber das reicht nicht, wenn ich am nächsten Morgen aufwache, es wieder einen neuen Account gibt und alles von vorne losgeht.
<G-vec00880-002-s080><wake_up.aufwachen><en> But it’s not enough when tomorrow I wake up and there’s another new account, and it just keeps continually happening.
<G-vec00880-002-s081><wake_up.aufwachen><de> Wenn Ihre Muskeln sich versteifen und Sie mit Rückenschmerzen aufwachen, dann ist Ihre Matratze nicht mehr gut genug.
<G-vec00880-002-s081><wake_up.aufwachen><en> If you start feeling stiff or have back pain when you wake, it means that your mattress needs to be changed.
<G-vec00880-002-s082><wake_up.aufwachen><de> Denn, wie Thomas Jefferson 1787 sagte: “Wenn das amerikanische Volk jemals privaten Banken erlaubt, die Kontrolle über ihre Währung zu übernehmen, werden die Banken und Konzerne, die um sie herum aufwachsen, zuerst durch Inflation, dann durch Deflation, den Menschen ihr Eigentum nehmen, bis ihre Kinder obdachlos auf dem Kontinent, das ihre Väter eroberten, aufwachen.
<G-vec00880-002-s082><wake_up.aufwachen><en> For, as Thomas Jefferson had said in 1787: ” “If the American people ever allow private banks to control the issue of their currency, first by inflation, then by deflation, the banks and the corporations which grow up around them will deprive the people of all property until their children wake up homeless on the continent their fathers conquered.”
<G-vec00880-002-s083><wake_up.aufwachen><de> Sie können in einem solchen tiefen Schlaf sein, dass Sie nicht aufwachen, wenn Sie auf Ihr Baby rollen.
<G-vec00880-002-s083><wake_up.aufwachen><en> You may be in such a deep sleep that you don’t wake up if you roll onto your baby.
<G-vec00880-002-s084><wake_up.aufwachen><de> Schönheit: Hilft Ihnen, sich nach dem Aufwachen frisch und ausgeruht zu fühlen und auch so auszusehen.
<G-vec00880-002-s084><wake_up.aufwachen><en> Beauty: Helps you wake up feeling and looking refreshed.
<G-vec00880-002-s085><wake_up.aufwachen><de> Kristall Es kann seine Psychokräfte nur einsetzen, wenn seine schlafenden Gehirnzellen zu- fällig aufwachen.
<G-vec00880-002-s085><wake_up.aufwachen><en> The only time it can use its psychic power is when its sleeping brain cells happen to wake.
<G-vec00880-002-s086><wake_up.aufwachen><de> Dann, als Amerika anfing aufzuwachen, wurden uns 3 weitere Jahre bedingt gewährt, unter der Voraussetzung, dass die Menschen weiterhin aufwachen und beten und auch eine kleine Andeutung, dass es eine Wiederbelebung vor der Entrückung geben könnte.
<G-vec00880-002-s086><wake_up.aufwachen><en> Then, as America started to wake up, we were given three years more—conditionally, that the people would continue to wake up and pray. And a slight hint that there may be a Revival before the Rapture.
<G-vec00880-002-s087><wake_up.aufwachen><de> Aufwachen mit tollem Meerblick.
<G-vec00880-002-s087><wake_up.aufwachen><en> Wake to superb ocean views.
<G-vec00880-002-s088><wake_up.aufwachen><de> Und dann hinuntergehen und in den Strom jener erwerbs- und mittellosen Existenzen eintauchen, den Duft des frischen Fisches und des gegrillten Fleisches eines improvisierten Marktes entführen, mit einem gezuckerten Kaffee und einem Schluck Wasser aufwachen und abreisen, um dann nur wiederzukommen.
<G-vec00880-002-s088><wake_up.aufwachen><en> And then descend, plunge themselves into the river of all those lives which held no particular distinction, take the stench of the fresh fish and the grilled meat in the pop-up market, wake themselves up with a sugared coffee and a sip of water, and then leave, only to return later.
<G-vec00880-002-s089><wake_up.aufwachen><de> Ich begann zu verstehen, daß ich nicht aufwachen konnte, und dann wurden mir alle guten Dinge und die schlechten Dinge gezeigt, die in meinem Leben geschahen….ich habe eine Tochter, die zu der Zeit nur 2 Jahre alt war.
<G-vec00880-002-s089><wake_up.aufwachen><en> I started out knowing that I couldn't wake up, and then I was shown all the good things and the bad things that have happened in my life... I have a daughter who was just about two at the time.
<G-vec00880-002-s090><wake_up.aufwachen><de> Leicht und nicht fettig, schmilzt es in die Haut mühelos ein, so dass du mit heller, weicher und geschmeidiger Haut aufwachen kannst.
<G-vec00880-002-s090><wake_up.aufwachen><en> Lightweight and non-greasy, it melts into the skin effortlessly, so you can wake up to luminous, soft and supple skin.
<G-vec00880-002-s091><wake_up.aufwachen><de> Arobanai hockte immer noch erstarrt inmitten des Heulens und Klagens, und das Heulen und Klagen würde nie mehr enden, denn Balekimito würde nie mehr aufwachen.
<G-vec00880-002-s091><wake_up.aufwachen><en> Arobanai, still numb with grief, was huddling in the middle of the wailing and crying people. And the wailing and crying would never end because Balekimito would never again wake up.
<G-vec00880-002-s092><wake_up.aufwachen><de> Zum Aufwachen, Aufwärmen und Auftanken.
<G-vec00880-002-s092><wake_up.aufwachen><en> In order to wake, warming up and refuelling.
<G-vec00880-002-s093><wake_up.aufwachen><de> Wir können manchmal einfach nicht aufwachen, ohne dass ein Alarm in unserem Ohr ertönt.
<G-vec00880-002-s093><wake_up.aufwachen><en> We sometimes just can't wake up without an alarm going off in our ear.
<G-vec00880-002-s094><wake_up.aufwachen><de> Wenn Sie das Gerät SmartSleep Deep Sleep Headband nutzen, zeichnet das Gerät Schlafmuster, Signal und Impedanz sowie Schlafmetriken auf, beispielsweise wann Sie schlafen gegangen sind, wann Sie aufwachen, Ihre Schlafdauer insgesamt, Ihre Wellenaktivität im Niederfrequenzbereich, vom Gerät ausgesendete Töne, die Dauer der ausgesendeten Töne, Ihre Schlafphasen, wie oft Sie nachts aufwachen und wie lange Sie dabei wach sind, und synchronisiert diese Daten mit der App.
<G-vec00880-002-s094><wake_up.aufwachen><en> If you use the SmartSleep Deep Sleep Headband Device, the Device records (sleep patterns, signal and impedance, sleep metrics such as: when you went to sleep, when you wake, your total sleep time, your slow wave activity, tones delivered by the device, duration of tones delivered, your sleep stages, how many times you wake at night and for how long, and syncs it to the App.
<G-vec00880-002-s095><wake_up.aufwachen><de> TalkClok ändert völlig die Art, wie Sie aufwachen und Ihren Tag beginnen.
<G-vec00880-002-s095><wake_up.aufwachen><en> TalkClok is totally changing the way you wake up and start your day.
<G-vec00880-002-s096><wake_up.aufwachen><de> Wir benutzen unsere Hände für alles vom Moment, den wir aufwachen, bis wir schlafen gehen.
<G-vec00880-002-s096><wake_up.aufwachen><en> We use our hands for everything from the moment we wake up until we go to bed.
<G-vec00880-002-s097><wake_up.aufwachen><de> Das Kind kann oft zusammenzucken und aufwachen in der Nacht.
<G-vec00880-002-s097><wake_up.aufwachen><en> The child may tremble and often Wake up during the night.
<G-vec00880-002-s098><wake_up.aufwachen><de> Die Unterstützung des Aufwachen bei LAN/WAN-Verbindung, das geplante Ein- und Ausschalten und der Festplatten-Ruhemodus können den Stromverbrauch und die Betriebskosten weiter senken.
<G-vec00880-002-s098><wake_up.aufwachen><en> Synology DS112 consumes only 13.2 watts in operation, and support of Wake on LAN/WAN, multiple scheduled power on/off, and hard drive hibernation can further reduce power consumption and operation cost, as well as extending the lifespan of the hard disk.
<G-vec00880-002-s099><wake_up.aufwachen><de> Manche werden kämpfen, um die täglichen Schwierigkeiten zu überleben, während andere aufwachen und es nicht erwarten können, einen weiteren Tag zu gewinnen… täglich.
<G-vec00880-002-s099><wake_up.aufwachen><en> Some will struggle to survive the daily difficulties, while others will wake up eager to win another day… on a daily basis.
<G-vec00880-002-s100><wake_up.aufwachen><de> Sorge also dafür, dass du früh aufwachst und deinen Morgen in einem guten Tempo und auf eine wohlüberlegte Art angehst.
<G-vec00880-002-s100><wake_up.aufwachen><en> So be sure to wake up early and tackle your morning in a well-paced, thoughtful way. Advertisement
<G-vec00880-002-s101><wake_up.aufwachen><de> Wenn deine Morgen-Routine für dich nicht funktioniert hat, erstelle einen Plan, um die Art zu ändern, wie du aufwachst und deinen Tag beginnst.
<G-vec00880-002-s101><wake_up.aufwachen><en> If your morning routine has not been working out for you, make a plan to change the way you wake up and start your day.
<G-vec00880-002-s102><wake_up.aufwachen><de> Wenn du aufwachst und dich an deinen Traum erinnerst, dann schreibe es in deinem Traumtagebuch auf, schließe dann die Augen erneut und konzentriere dich auf den Traum.
<G-vec00880-002-s102><wake_up.aufwachen><en> When you wake up and remember your dream, write it down in your dream journal, then close your eyes and focus on the dream.
<G-vec00880-002-s103><wake_up.aufwachen><de> Schlafe so lange, bis du von selbst aufwachst.
<G-vec00880-002-s103><wake_up.aufwachen><en> Sleep until you wake up naturally.
<G-vec00880-002-s104><wake_up.aufwachen><de> Das Licht leuchtet, solange das Gehäuse auf Deiner Haut anliegt und sollte deshalb auch noch leuchten, wenn Du am nächsten Morgen aufwachst.
<G-vec00880-002-s104><wake_up.aufwachen><en> This light should stay on as long as Ava is in contact with your skin and should still be on when you wake up in the morning.
<G-vec00880-002-s105><wake_up.aufwachen><de> Wenn du morgens mit trockenen, aufgerissenen Lippen aufwachst, liegt das vielleicht daran, dass du mit offenen Mund geschlafen hast.
<G-vec00880-002-s105><wake_up.aufwachen><en> If you wake up in the morning with dry, cracked lips, it might be because your mouth was open while you slept.
<G-vec00880-002-s106><wake_up.aufwachen><de> Er ist nicht nur weich und atmungsaktiv, wodurch du erfrischt und bereit für den Tag aufwachst, sondern er sorgt auch dafür, dass deine Matratze im optimalen Zustand bleibt.
<G-vec00880-002-s106><wake_up.aufwachen><en> Not only is it soft and breathable, meaning that you wake up refreshed and ready to take on the day, it also ensures your mattress stays in optimum condition.
<G-vec00880-002-s107><wake_up.aufwachen><de> Wenn du mitten in der Nacht aufwachst und dich fühlst, als müsstest du einen Traum aufschreiben, ist es gut, ein Licht neben dir zu haben, das du einfach anschalten kannst, bevor du den Traum wieder vergisst.
<G-vec00880-002-s107><wake_up.aufwachen><en> If you wake up in the middle of the night and feel compelled to write down a dream, an easily accessible light will enable you to do this before forgetting the dream.
<G-vec00880-002-s108><wake_up.aufwachen><de> Auch wenn Alkohol dir helfen kann einzuschlafen, unterstützt er keine gute Schlafqualität und es kann sein, dass du Stunden später aufwachst und nicht mehr einschlafen kannst.
<G-vec00880-002-s108><wake_up.aufwachen><en> Even though alcohol may help you fall asleep, it does not promote good quality sleep and you may wake up hours later and be unable to fall asleep again.
<G-vec00880-002-s109><wake_up.aufwachen><de> Beim Schlafen können sich die Muskeln entspannen und sich die Schmerzrezeptoren zurücksetzen, sodass du am Morgen ohne Schmerzen aufwachst.
<G-vec00880-002-s109><wake_up.aufwachen><en> Sleep can help to relax muscles and reset pain receptors, so that you wake up in the morning feeling pain-free. Steps
<G-vec00880-002-s110><wake_up.aufwachen><de> Konzentriere dich darauf, dich an deinen Traum zu erinnern, sobald du aufwachst.
<G-vec00880-002-s110><wake_up.aufwachen><en> Concentrate on recalling your dream as soon as you wake up.
<G-vec00880-002-s111><wake_up.aufwachen><de> Der A300 erkennt automatisch wenn du einschläfst und aufwachst und er weckt dich mit einer sanften Vibration.
<G-vec00880-002-s111><wake_up.aufwachen><en> The A300 automatically clocks both the moment you start sleeping and wake up, and wakes you up with a gentle vibration.
<G-vec00880-002-s112><wake_up.aufwachen><de> Benutze ein Basalthermometer gleich nachdem du aufwachst und noch bevor du morgens aus dem Bett aufstehst.
<G-vec00880-002-s112><wake_up.aufwachen><en> Use a basal thermometer right when you wake up, before you get out of bed in the morning.
<G-vec00880-002-s113><wake_up.aufwachen><de> Dasselbe passiert, wenn du mit schlechter Laune aufwachst.
<G-vec00880-002-s113><wake_up.aufwachen><en> Same thing happens if you wake up in a bad mood.
<G-vec00880-002-s114><wake_up.aufwachen><de> Es war als wäre ich in Zeitlupe gewesen und jetzt freigelassen worden-nicht unähnlich wie wenn jemand dich in einem Traum verfolgt aber du kannst nicht schnell genug rennen um zu flüchten, und wenn du aufwachst, kannst du dich wieder mit normaler Geschwindigkeit bewegen.
<G-vec00880-002-s114><wake_up.aufwachen><en> It was as if I had been in slow motion and been released - not unlike when someone is chasing you in a dream but you can't run fast to escape, and when you wake up, you can move at normal speed again.
<G-vec00880-002-s115><wake_up.aufwachen><de> Wenn Du morgens aufwachst, dann bist Du dabei, wenn Du nachts im Bett liegst, dann bist Du mit dabei, wenn Du im Sonnenschein eine Straße runter läufst – dann bist Du mit dabei.
<G-vec00880-002-s115><wake_up.aufwachen><en> When you wake up in the morning, you are with yourself, laying in bed at night you are with yourself, walking down the street in the sunlight you are with yourself.
<G-vec00880-002-s116><wake_up.aufwachen><de> Jedes Mal, wenn Du aufwachst, schreib sofort auf, an was Du Dich von Deinem Traum erinnern kannst.
<G-vec00880-002-s116><wake_up.aufwachen><en> Any time you wake up, immediately write down as much as you remember from your dream.
<G-vec00880-002-s117><wake_up.aufwachen><de> Du wirst staunen, wie viele der Sorgen gelöscht, gelöst oder besser sind sobald du aufwachst.
<G-vec00880-002-s117><wake_up.aufwachen><en> You’ll be amazed at how many are gone, solved, or improved by the time you wake up.
<G-vec00880-002-s118><wake_up.aufwachen><de> Wenn du aber nicht aufwachst, werde ich kommen wie ein Dieb und du wirst bestimmt nicht wissen, zu welcher Stunde ich komme.
<G-vec00880-002-s118><wake_up.aufwachen><en> If you do not wake up, I shall come to you like a thief, and you will have no idea at what hour I shall come upon you.
<G-vec00880-002-s119><wake_up.aufwachen><de> Es sei denn, dass Frau Angela Merkel aufwacht und sich erinnert, dass sie im Namen des Vaters, des Sohnes und des Heiligen Geistes getauft wurde, eine Gnade, die ihr berühmter Vorgänger Dr. Konrad Adenauer, Gründer der CDU, ernst genommen und in die Tat umgesetzt hat.
<G-vec00880-002-s119><wake_up.aufwachen><en> Unless Angela Merkel wake up in remembering that she was christened in the name of the Father, the Son and the Holy Spirit, as did so courageously the catholic Dr. Konrad Adenauer, founder of the CDU?
<G-vec00880-002-s120><wake_up.aufwachen><de> Wenn ihr am Morgen aufwacht, seid ihr erfrischt und wenn ihr auf euer Leben blickt, dann denkt ihr: "Das ist nicht so schlimm.
<G-vec00880-002-s120><wake_up.aufwachen><en> When you wake up in the morning, you are refreshed and when you look at your life you think, "That is not so bad.
<G-vec00880-002-s121><wake_up.aufwachen><de> Berge ueberall, die man auch aus den Zimmern sieht wenn man morgens aufwacht.
<G-vec00880-002-s121><wake_up.aufwachen><en> Mountains everywhere, so you can see them out of the window in the morning when you wake up.
<G-vec00880-002-s122><wake_up.aufwachen><de> Sowohl bei der obstruktiven als auch bei der zentralen Schlafapnoe führt der Sauerstoffmangel dazu, dass die betroffene Person aufwacht und wieder beginnt zu atmen; so wird die Schlafphase unterbrochen.
<G-vec00880-002-s122><wake_up.aufwachen><en> In either situation, the lack of oxygen causes the person to wake up to catch their breath and start breathing again, interrupting continuous sleep. This may occur multiple times in an hour.
<G-vec00880-002-s123><wake_up.aufwachen><de> “Die Stunde ist gekommen für euch, dass ihr von eurem Schlaf aufwacht, denn unsere Erlösung ist näher, als damals, als wir zuerst glaubten.
<G-vec00880-002-s123><wake_up.aufwachen><en> “The hour has come for you to wake up from your slumber, for our salvation is nearer now than when we first believed.
<G-vec00880-002-s124><wake_up.aufwachen><de> Samsung hat eine Premium-Abdeckung erstellt, die das Display Ihres Telefons aufwacht, wenn Sie die Abdeckung öffnen und es wieder ausschaltet, wenn sie geschlossen ist.
<G-vec00880-002-s124><wake_up.aufwachen><en> Samsung have created a premium cover that will wake up your phone's display when you open the cover and turn it off again when closed.
<G-vec00880-002-s125><wake_up.aufwachen><de> Doch wenn ihr zu früh aufwacht und so früh zum Bahnhof geht wie ihr könnt, dann werdet ihr frustriert sein wenn der Zug nicht da ist.
<G-vec00880-002-s125><wake_up.aufwachen><en> But if you wake up too soon and go to the station as soon as you can, you're going to be frustrated that the train isn't there.
<G-vec00880-002-s126><wake_up.aufwachen><de> Die Lakota erwiderten die Angriffe mit Gebeten, "damit die Polizei aufwacht" und sie versuchten der Polizei zu erklären, dass der Zweck ihres Aufenthalts hier in diesem Lager auch sei, das Wasser für die Polizei und ihre Familien zu schützen.
<G-vec00880-002-s126><wake_up.aufwachen><en> The Lakota youths responded with prayer “for the police to wake up”, and they explained to police that they were camped there to protect water for the police’s children too.
<G-vec00880-002-s127><wake_up.aufwachen><de> Ich liebe es, wenn man morgens aufwacht und man hört all die Vögel zwitschern und man weiß, heute wird ein schöner Tag.
<G-vec00880-002-s127><wake_up.aufwachen><en> I just love it, when you wake up in the morning, hearing the birds chirping, knowing, today's going to be a good day.
<G-vec00880-002-s129><wake_up.aufwachen><de> Man weiß nie, was kommt, wenn man am Morgen aufwacht», sagt Gala.
<G-vec00880-002-s129><wake_up.aufwachen><en> You never know what is going to happen when you wake up in the morning», says Gala.
<G-vec00880-002-s130><wake_up.aufwachen><de> Die Geschichte erzählt uns, wie plötzlich unsere Mutter, die bisher die kleine Familiencafeteria übernommen hatte, eines Tages nicht mehr aufwacht.
<G-vec00880-002-s130><wake_up.aufwachen><en> History tells us how suddenly our mother, who until now had taken over the small family cafeteria, does not wake up one day.
<G-vec00880-002-s131><wake_up.aufwachen><de> Viele von euch wissen das schon, weil ihr oft erschöpft aufwacht und ihr braucht ein oder zwei Stunden um die Energie wieder ins Fließen zu bringen.
<G-vec00880-002-s131><wake_up.aufwachen><en> Many of you already know that because you often wake up exhausted,and it takes you an hour or two to get your energy moving again.
<G-vec00880-002-s132><wake_up.aufwachen><de> Wenn man über Pädophilie forscht, sind die meisten Experten einer Meinung, dass ein Kinderschänder nicht gerade eines Tags aufwacht und zu versuchen beginnt, Kinder zu belästigen.
<G-vec00880-002-s132><wake_up.aufwachen><en> If you do research on pedophilia most experts agree that a child molester does not just wake up one day and start trying to molest children.
<G-vec00880-002-s133><wake_up.aufwachen><de> Achtet auch auf eine langsame, fast nicht wahrnehmbare Tendenz, wo ihr euch schlecht fühlt über euch selbst bis zum Punkt, wo ihr aufwacht und euch völlig hoffnungslos und verurteilt fühlt.
<G-vec00880-002-s133><wake_up.aufwachen><en> Also watch for a slow almost imperceptible drift into feeling badly about yourself to the point where you wake up feeling totally hopeless and condemned.
<G-vec00880-002-s134><wake_up.aufwachen><de> Ihr lebt in einer Lüge, und wenn ihr nicht ziemlich bald aufwacht, wird sich die Neue Weltordnung umdrehen und dein Mittagessen für dich essen.
<G-vec00880-002-s134><wake_up.aufwachen><en> You have been living a lie and if you don’t wake up pretty soon, the New World Order will turn around at eat your lunch for you.
<G-vec00880-002-s135><wake_up.aufwachen><de> Sieh, wie dein Herz für sich selbst aufwacht.
<G-vec00880-002-s135><wake_up.aufwachen><en> See your heart wake up to itself.
<G-vec00880-002-s136><wake_up.aufwachen><de> Wer allerdings immer wieder nachts aufwacht, lange wachliegt oder nach dem Zubettgehen deutlich mehr als 30 Minuten zum Einschlafen benötigt, sollte den Ursachen auf den Grund gehen und Wege finden, den Schlaf zu verbessern.
<G-vec00880-002-s136><wake_up.aufwachen><en> However, those who constantly wake up in the night, lie awake for a long time or take much longer than 30 minutes to fall asleep after going to bed should investigate the causes and find ways to improve sleep.
<G-vec00880-002-s137><wake_up.aufwachen><de> Weisen Sie Direktzugriffstasten zum Aufrufen gespeicherter Sender direkt zu, um diese im Handumdrehen zu finden, und stellen Sie Ihr Radio so ein, dass es mit Ihnen einschläft und aufwacht, indem Sie den zweifachen Alarm verwenden.
<G-vec00880-002-s137><wake_up.aufwachen><en> Assign stations their own preset button to find them instantly, and set your radio to fall asleep or wake up when you do, with the dual alarm.
<G-vec00880-002-s157><wake_up.aufwachen><de> P3 Morgen hat ein Konzept, bei dem Künstler ein Lied covern, von dem sie meinen, dass es schön wäre, dazu aufzuwachen.
<G-vec00880-002-s157><wake_up.aufwachen><en> P3 Morgen has a concept that involves artists covering a song that they think is nice to wake up to.
<G-vec00880-002-s158><wake_up.aufwachen><de> Frischer Rettich im zeitigen Frühjahr hilft unserem Körper nach einem langen Winter "aufzuwachen" und füllt ihn mit Vitaminen, Mikro- und Makroelementen.
<G-vec00880-002-s158><wake_up.aufwachen><en> Fresh radish in early spring helps our body to "wake up" after a long winter, filling it with vitamins, micro and macro elements.
<G-vec00880-002-s160><wake_up.aufwachen><de> Das Bett war erstaunlich weich und überraschend groß - plus, es war sehr schön, aufzuwachen, öffne deine Augen, und sofort weit über die Felder durch das kleine Fenster neben dem Bett.
<G-vec00880-002-s160><wake_up.aufwachen><en> The bed was amazingly soft and surprisingly big - plus, it was very nice to wake up, open your eyes, and immediately far across the fields through the small window next to the bed.
<G-vec00880-002-s161><wake_up.aufwachen><de> Auf dieser Seite können Sie den Klingelton "Hahn, Zeit aufzuwachen" anhören und herunterladen.
<G-vec00880-002-s161><wake_up.aufwachen><en> On this page you can listen to and download ringtone Rooster, time to wake up, use the button "Play" to listen or "Download" to download a ringtone.
<G-vec00880-002-s162><wake_up.aufwachen><de> Dual-Alarm-Innovation gibt Ihnen flexiblere Möglichkeiten, um aufzuwachen, es ist sowohl ein Lautsprecher und eine Uhr, mit zwei Alarmen.
<G-vec00880-002-s162><wake_up.aufwachen><en> Dual alarm innovation gives you more flexible choices to wake you up, it is both a speaker, and a clock, with two alarms.
<G-vec00880-002-s163><wake_up.aufwachen><de> Es ist immer am besten, langsam und friedlich aufzuwachen, und zu deiner eigenen Zeit.
<G-vec00880-002-s163><wake_up.aufwachen><en> It's always best to wake up slowly, peacefully, and at your own time.
<G-vec00880-002-s164><wake_up.aufwachen><de> Die Zimmer verfügen alle über eine herrliche Aussicht auf die Berge am Morgen aufzuwachen.
<G-vec00880-002-s164><wake_up.aufwachen><en> The bedrooms all have beautiful views of the mountains to wake up to in the morning.
<G-vec00880-002-s165><wake_up.aufwachen><de> Es sind die Impulse, die uns veranlassen, einen Traum zu haben, uns umzudrehen, weiterzuschlafen oder aufzuwachen.
<G-vec00880-002-s165><wake_up.aufwachen><en> It is what draws us to having a dream, to rolling over, to continue to sleep, or to wake up.
<G-vec00880-002-s166><wake_up.aufwachen><de> Noch deutlicher, obwohl ich in etwa fünfzehn Bücher über den Irrsinn dieser Kultur geschrieben habe, kann ich nichts anderes glauben, als dass es ein böser Traum ist mit dieser besessenen Aufrechterhaltung dieser Kultur, während die Welt gemordet wird, und ich wünsche aufzuwachen, aber immer, wenn ich wach bin, tötet man immer noch den Planeten und es gibt nicht viele Leute, die es bekümmert.
<G-vec00880-002-s166><wake_up.aufwachen><en> But more to the point, even though I've written something on the order of fifteen books about this culture's insanity, I still cannot believe this isn't all a bad dream, with this frenzied maintenance of this culture as the world is murdered. I keep wanting to wake up, but each time I awaken this culture is still killing the planet, and not many people care.
<G-vec00880-002-s167><wake_up.aufwachen><de> Je älter wir sind, desto früher fühlen wir uns bereit, einzuschlafen und aufzuwachen.
<G-vec00880-002-s167><wake_up.aufwachen><en> The older we get the earlier we feel ready to fall asleep and wake up.
<G-vec00880-002-s168><wake_up.aufwachen><de> Der Blick auf den See war atemberaubend jeden Morgen aufzuwachen und ist ebenso wie das Foto.
<G-vec00880-002-s168><wake_up.aufwachen><en> The view of the lake was stunning to wake up to every morning and is just like the photo.
<G-vec00880-002-s169><wake_up.aufwachen><de> Andere Menschen (Nachtmenschen oder Eulen) ziehen es vor, spät schlafen zu gehen und spät aufzuwachen.
<G-vec00880-002-s169><wake_up.aufwachen><en> Others (night people or owls) prefer to go to sleep and wake late.
<G-vec00880-002-s170><wake_up.aufwachen><de> Ein Buch, nach dem ich endlich anfing aufzuwachen, nach einer Zeit, in der ich nicht einmal an unsere Urquelle und das geistige Reich glaubte oder das was ich im Grunde selbst bin.
<G-vec00880-002-s170><wake_up.aufwachen><en> A book after which I finally began to wake up after a time when I did not even believe in our original source and the spiritual realm or what I am basically myself.
<G-vec00880-002-s171><wake_up.aufwachen><de> Die einzigartigen temperaturregulierenden Qualitäten der Wolle werden Ihnen helfen, jeden Morgen frisch aufzuwachen.
<G-vec00880-002-s171><wake_up.aufwachen><en> Wool's unique body temperature regulating features will ensure that you wake up fresh and rested every morning.
<G-vec00880-002-s172><wake_up.aufwachen><de> Ein Traum eines Tages in St. Tropez aufzuwachen, ein Hauch der warmen und unglaublich sanften Bri..
<G-vec00880-002-s172><wake_up.aufwachen><en> Would you like to wake up in sunny and warm St. Tropez, feel Aftershave Fragrance Family: ..
<G-vec00880-002-s173><wake_up.aufwachen><de> Am Morgen signalisiert helles, reiches blaues Sonnenlicht Ihrem Körper, dass es Zeit ist aufzuwachen.
<G-vec00880-002-s173><wake_up.aufwachen><en> In the morning, bright, blue-light-rich sunlight signals to your body that it's time to wake up.
<G-vec00880-002-s174><wake_up.aufwachen><de> Der Hauptgrund für das Trinken koffeinhaltiger Getränke ist es, aufzuwachen und wach zu bleiben, daher kann Koffein natürlich Probleme zur Schlafenszeit verursachen.
<G-vec00880-002-s174><wake_up.aufwachen><en> The main reason for drinking caffeinated drinks is to wake up and stay awake, so naturally, caffeine can cause problems at bedtime.
<G-vec00880-002-s175><wake_up.aufwachen><de> Schon der Erzvater hätte ja bloß aufzuwachen und dem himmlischen Botschafter nachzusteigen brauchen.
<G-vec00880-002-s175><wake_up.aufwachen><en> All the patriarch would have had to do was wake up and climb up after the angels.
<G-vec00880-002-s208><wake_up.aufwachen><de> Sie werden schon beim Aufwachen ein Lächeln auf den Lippen haben, ganz gleich, ob Sie es vorziehen, Ihren Tag mit einer Extraportion Süße zu beginnen, oder ob Sie ein Fan von energiegeladenen, eiweißhaltigen Weckern sind.
<G-vec00880-002-s208><wake_up.aufwachen><en> You'll already wake up with a smile on your face, whether you prefer to start your day with an extra load of sweetness, or if you're a fan of energetic, protein-packed wake-ups.
<G-vec00880-002-s209><wake_up.aufwachen><de> Beim Aufwachen: müdes Gesicht, geschwollene und gerötete Augen, kleine Pickel, verschwommener Teint.
<G-vec00880-002-s209><wake_up.aufwachen><en> Which is why we wake up looking gaunt with puffy, red eyes, pimples and skin problems.
<G-vec00880-002-s210><wake_up.aufwachen><de> Wenn Du den Philips Hue White Ambiance Runner-Spot in Dein Philips Hue Lichtsystem integrierst, kannst Du natürliches Weißlicht genießen, das Dir beim Aufwachen, Energietanken, Konzentrieren, Lesen und Entspannen hilft.
<G-vec00880-002-s210><wake_up.aufwachen><en> Available soon With a Philips Hue White Ambiance spot Runner included in your Philips Hue system you can enjoy natural white light that helps you to wake up, energise, concentrate, read and relax.
<G-vec00880-002-s211><wake_up.aufwachen><de> Integrieren Sie die Fair Philips hue White Ambiance-Deckenleuchte in Ihr Philips Hue Lichtsystem und genießen Sie natürliches Weißlicht, das Ihnen beim Aufwachen, Energietanken, Konzentrieren, Lesen und Entspannen hilft.
<G-vec00880-002-s211><wake_up.aufwachen><en> Include the Still Philips Hue white ambiance ceiling in your Philips Hue system and enjoy natural white light that helps you to wake up, energise, concentrate, read and relax.
<G-vec00880-002-s212><wake_up.aufwachen><de> Jetzt erkennt er, dass er mehr Energie hat beim aufwachen als vorher, und meint: "Es ist ein Weg des Essens, dass ich jedem empfehlen kann, denn diese Ernährung ist weit entfernt von den traditionellen Speisen, " und fügt hinzu:" diese Ernährung ist aber sehr viel problematischer als ich dachte, und ich dachte, sie wäre schwierig.
<G-vec00880-002-s212><wake_up.aufwachen><en> While now he recognizes that he has more energy and wake up before; also states that "There is a way of eating that you can recommend to anyone because as it is far from traditional grilled foods, " and adds:" was much more problematic than I thought.
<G-vec00880-002-s213><wake_up.aufwachen><de> Weil man beim Aufwachen, mit Blick auf ein Reh, mal wieder auf die Idee gebracht wird, das Ruhe und Zeit eine Wunderbare Sache sind die es zu schätzen und genießen gilt.
<G-vec00880-002-s213><wake_up.aufwachen><en> Because when you wake up with a view to a deer, you get the idea that peace and time are a wonderful thing to cherish and enjoy.
<G-vec00880-002-s214><wake_up.aufwachen><de> Integriere die Being Philips Hue White Ambiance-Deckenleuchte in Dein Philips Hue Lichtsystem und genieße natürliches weißes Licht, das Dir beim Aufwachen, Energietanken, Konzentrieren, Lesen und Entspannen hilft.
<G-vec00880-002-s214><wake_up.aufwachen><en> £119.99 Add to cart Include the Being Philips Hue white ambiance ceiling in your Philips Hue system and enjoy natural white light that helps you to wake up, energise, concentrate, read and relax.
<G-vec00880-002-s215><wake_up.aufwachen><de> Im Schlafzimmer steht ein Doppelbett und es hat einen wunderschönen Meerblick, den man beim Aufwachen genießen kann.
<G-vec00880-002-s215><wake_up.aufwachen><en> The bedroom has a double bed and magnificent sea view that you can enjoy the moment you wake up.
<G-vec00880-002-s430><wake_up.aufwachen><de> Wach auf, Drucken, Versenden und Empfangen von E-Mails, Faxempfang .
<G-vec00880-002-s430><wake_up.aufwachen><en> Wake up, printing, sending and receiving e-mails, Fax Reception .
<G-vec00880-002-s431><wake_up.aufwachen><de> Da viele unserer "Mitbewohner" heute mit dem morgendlichen Zug nach Peking weiterreisen, werden wir schon gegen 6 Uhr wach.
<G-vec00880-002-s431><wake_up.aufwachen><en> As many of our „roommates“ leave in the early morning to catch the train to Beijing, we wake up pretty early too.
<G-vec00880-002-s432><wake_up.aufwachen><de> Und das Signal ist wirklich laut genug, um wach zu werden.
<G-vec00880-002-s432><wake_up.aufwachen><en> And the alarm will definitely be loud enough to wake up from.
<G-vec00880-002-s433><wake_up.aufwachen><de> Morgens wirst du vom Gesang der Vögel wach, und nachts hörst du zuweilen das plätschern des Regens.
<G-vec00880-002-s433><wake_up.aufwachen><en> In the morning you wake up to the song of birds, and at night you can hear sometimes the splashing of rain.
<G-vec00880-002-s434><wake_up.aufwachen><de> Und wir haben endlich den passenden Kaffee für unsere tolle Espressomaschine bekommen, so dass wir nach holprigen Nächten auf polnischen Strassen richtig wach werden können.
<G-vec00880-002-s434><wake_up.aufwachen><en> And we finally managed to get our hands on some coffee grains for out top-notch expresso machine so we can wake up easily after the bouncy nights on Polish roads.
<G-vec00880-002-s435><wake_up.aufwachen><de> Damit Jasper wach wird, schüttet er ihm einen Eimer Wasser ins Gesicht.
<G-vec00880-002-s435><wake_up.aufwachen><en> Monty walks over to Jasper and throws a bucket of water in his face to wake him up.
<G-vec00880-002-s436><wake_up.aufwachen><de> Ich blickte auf meinen Ehemann und sagte „Sag es mir nur“, er sagte „Baby, ich muss mit dir sprechen, ich muss dich wach haben“, ich sagte „Brian, ich bin wach, sag es nur“ er sagte „Nein, Honey, ich muss mit dir sprechen und ich muss dich wach haben, du mußt aufstehen!“ Da war es, als ich zu zittern anfing.
<G-vec00880-002-s436><wake_up.aufwachen><en> I looked at my husband and said 'Just tell me' he said 'Baby, I need to talk to you I need you to wake up' I said 'Brian, I'm awake, just say it' he said 'No, honey, I have to talk to you and I need you to wake up, I need you get up!' That's when I started to shake.
<G-vec00880-002-s438><wake_up.aufwachen><de> Und seitdem wurde ich umfassend über Manipulationen unterrichtet und gebe all mein WISSEN darüber den Menschen weiter, damit sie endlich wach werden und sich über ihr manipuliertes Dasein als Objekte von Unterdrückung, Macht- und Geldgier erheben können.
<G-vec00880-002-s438><wake_up.aufwachen><en> And since that time I have been thoroughly taught about manipulation and I give this knowledge on to all people, so that they may finally wake up and rise above their manipulated lives as objects of suppression, lust for power and and gain.
<G-vec00880-002-s439><wake_up.aufwachen><de> Nein Im Moment als ich es aufgab zu versuchen wach zu werden, das war als ich sah dass ich schon gestorben war und es war als seien Stunden vergangen, während denen sie meiner Familie sagten dass sie mich verloren hatten.
<G-vec00880-002-s439><wake_up.aufwachen><en> No At the moment when I quit trying to wake up that's when I saw that I had already died and it was as though hours passed during which they told my family they had lost me.
<G-vec00880-002-s440><wake_up.aufwachen><de> Das bedeutet, wenn dir bis jetzt das Bibellesen etwas langweilig war, etwas mühsames, dann wach auf und esse soviel du kannst vom Wort Gottes, lerne so viele Bibelverse wie möglich auswendig speziell auch für Zeiten von Leiden: Denn ich bin gewiss, dass weder Tod noch Leben, weder Engel noch Mächte noch Gewalten, weder Gegenwärtiges noch Zukünftiges, weder Hohes noch Tiefes noch eine andere Kreatur uns scheiden kann von der Liebe Gottes, die in Christus Jesus ist, unserm Herrn.
<G-vec00880-002-s440><wake_up.aufwachen><en> That means that if reading the Bible has been boring and dreary for you, then wake up and eat as much as you can of God’s Word, learn as many Bible verses as you can, especially for times of trouble: “For I am convinced that neither death nor life, neither angels nor demons, neither the present nor the future, nor any powers, neither height nor depth, nor anything else in all creation, will be able to separate us from the love of God that is in Christ Jesus our Lord”.
<G-vec00880-002-s441><wake_up.aufwachen><de> Sie war von dem Wurf die erste, die wach, munter und agil war.
<G-vec00880-002-s441><wake_up.aufwachen><en> Surprisingly enough she was the first of the litter to wake up and the quickest to recover and be up and about.
<G-vec00880-002-s442><wake_up.aufwachen><de> Die Leute werden oft erst wach, wenn ich dastehe und fotografiere, dann sehen sie sich den Ort genauer an.
<G-vec00880-002-s442><wake_up.aufwachen><en> People often wake up for the first time when I am standing there and photographing; Only then do they look more closely at the site.
<G-vec00880-002-s443><wake_up.aufwachen><de> Wach auf, ich hasse dich... hasse dich, wie ich hasse meinen Ex und das ist traurig.
<G-vec00880-002-s443><wake_up.aufwachen><en> The clock is ticking..Wake up I hate you...hate you like I hate my ex and that is sad.
<G-vec00880-002-s444><wake_up.aufwachen><de> Mithilfe des Somneo Sleep and Wake-up Light werden Sie leichter wach und fühlen sich wohler und voller Energie.
<G-vec00880-002-s444><wake_up.aufwachen><en> When you use the Somneo Sleep & Wake-Up Light, you wake up more easily, have a better overall mood in the morning and feel more energetic.
<G-vec00880-002-s445><wake_up.aufwachen><de> Um Wach zu werden und gut in den Tag zu starten gönne ich mir einen kleinen Kaffee.
<G-vec00880-002-s445><wake_up.aufwachen><en> To wake up and to start the day I take a small cafe.
<G-vec00880-002-s446><wake_up.aufwachen><de> Nicht alle Bären verschlafen Weihnachten oder brauchen einen Wecker, um wach zu werden.
<G-vec00880-002-s446><wake_up.aufwachen><en> Not all bears miss Christmas or need an alarm clock to wake up.
<G-vec00880-002-s447><wake_up.aufwachen><de> Das ist gesünder und vor allem auch effektiver, wenn es darum geht, wach zu werden.
<G-vec00880-002-s447><wake_up.aufwachen><en> This is a healthier, more effective way to wake you up.
<G-vec00880-002-s448><wake_up.aufwachen><de> Wach auf, wenn dir dein Leben lieb ist.
<G-vec00880-002-s448><wake_up.aufwachen><en> Wake up, quick, if you value your skin.
<G-vec00880-002-s449><wake_up.aufwachen><de> Wache zu Hause auf, egal wo auf der Welt du bist.
<G-vec00880-002-s449><wake_up.aufwachen><en> Wake up at home, anywhere in the world. Ireland Galway
<G-vec00880-002-s450><wake_up.aufwachen><de> Wache mit erneuerter, strahlender Haut auf, die samtweich ist und eine jugendliche Ausstrahlung hat.
<G-vec00880-002-s450><wake_up.aufwachen><en> Wake up to renewed, radiant skin that feels soft and refined with a youthful glow.
<G-vec00880-002-s451><wake_up.aufwachen><de> Wache früh auf.
<G-vec00880-002-s451><wake_up.aufwachen><en> Wake up early.
<G-vec00880-002-s452><wake_up.aufwachen><de> DE// Ich wache von der schwuelen Hitze in meinem Zimmer auf.
<G-vec00880-002-s452><wake_up.aufwachen><en> EN// I wake up from the humid heat in my room.
<G-vec00880-002-s453><wake_up.aufwachen><de> Steige beispielsweise am frühen Abend in München in einen EuroNight und wache am nächsten Morgen ausgeruht in Budapest auf, um auf Sightseeingtour zu gehen.
<G-vec00880-002-s453><wake_up.aufwachen><en> For instance, board the EuroNight train in Munich in the early evening and wake up in Budapest the next morning, ready to explore!
<G-vec00880-002-s454><wake_up.aufwachen><de> Ich wache auf, als ich höre, wie die Wohnungstür aufgeschlossen wird.
<G-vec00880-002-s454><wake_up.aufwachen><en> I wake when I hear the key turning in the apartment door.
<G-vec00880-002-s455><wake_up.aufwachen><de> Seit ich oft lange arbeite und viel ausgehe, wache ich meistens mit müden Augen auf.
<G-vec00880-002-s455><wake_up.aufwachen><en> 25 June 2015 Working late nights and going out often, I wake up with tired eyes frequently.
<G-vec00880-002-s456><wake_up.aufwachen><de> Ich wache auf und frühstücke gemütlich auf der Terrasse.
<G-vec00880-002-s456><wake_up.aufwachen><en> I wake up and eat breakfast on the terrace.
<G-vec00880-002-s457><wake_up.aufwachen><de> Wache mitten in der Nacht auf.
<G-vec00880-002-s457><wake_up.aufwachen><en> Wake up in the middle of the night.
<G-vec00880-002-s458><wake_up.aufwachen><de> Weine oft, schlaf unruhig, wache aus dem geringsten Rascheln auf.
<G-vec00880-002-s458><wake_up.aufwachen><en> Cry often, sleep restlessly, wake up from the slightest rustle.
<G-vec00880-002-s459><wake_up.aufwachen><de> Ich wache auf, schaue auf die Uhr und entdecke, dass ich eine Dreiviertelstunde verschlafen habe.
<G-vec00880-002-s459><wake_up.aufwachen><en> I wake up, take a look at my alarm clock and realize that I’m already 45 minutes late.
<G-vec00880-002-s460><wake_up.aufwachen><de> Aber manchmal wache ich morgens verängstigt auf.
<G-vec00880-002-s460><wake_up.aufwachen><en> But I wake up sometimes in the morning anxious.
<G-vec00880-002-s461><wake_up.aufwachen><de> Als die Sonne ihre ersten Strahlen in mein Schlafzimmer schickt, wache ich auf.
<G-vec00880-002-s461><wake_up.aufwachen><en> I wake up with the sun’s first rays of light are dawning through the city of Seattle easing into my bedroom.
<G-vec00880-002-s462><wake_up.aufwachen><de> Also im Prinzip wache ich auf, trinke einen Kaffee, esse vor meinem Computer etwas zum Frühstück, lese E-Mails und Nachrichten auf Skype.
<G-vec00880-002-s462><wake_up.aufwachen><en> So basically, I wake up, drink coffee and have breakfast in front of my computer, reading emails and skype messages.
<G-vec00880-002-s463><wake_up.aufwachen><de> Am Freitagmorgen wache ich zerknautscht im Zelt auf und genieße die verschlafene Stimmung auf dem Camp.
<G-vec00880-002-s463><wake_up.aufwachen><en> On Friday morning I wake up a bit crumpled in the tent and enjoy the sleepy mood at the camp.
<G-vec00880-002-s464><wake_up.aufwachen><de> Sie wache jeden Morgen auf die erfrischende blaue Meer, strahlend blauer Himmel und die erstaunliche griechische Sonnenaufgang auf.
<G-vec00880-002-s464><wake_up.aufwachen><en> You will wake up every morning to the refreshing blue sea, bright blue sky and the amazing greek sunrise.
<G-vec00880-002-s465><wake_up.aufwachen><de> "Ich wache in einem Hotelzimmer auf, amnestisch, allein, nicht wissend wer ich bin und was ich hier mache.
<G-vec00880-002-s465><wake_up.aufwachen><en> “I wake up in a hotel room, alone, not able to remember who I am or what I am doing here.
<G-vec00880-002-s466><wake_up.aufwachen><de> „Jeden Tag wache ich mit dem Gefühl auf, nicht nur ein Rädchen im Getriebe von Flexera Software zu sein, sondern direkt den Erfolg unseres Unternehmens mitzugestalten.
<G-vec00880-002-s466><wake_up.aufwachen><en> “Every day, I wake up and feel that I am not just a contributor to Flexera Software, but that I am empowered to have a direct influence on our company’s success.
<G-vec00880-002-s467><wake_up.aufwachen><de> Na ja, Du musst Dir darüber nicht mehr den Kopf zerbrechen, genehmige Dir ein paar Drinks in der nassen, dreckigen Umgebung und gehe in den Kleidern zu Bett die Du gerade anhattest und wache am nächsten Morgen wieder auf.
<G-vec00880-002-s467><wake_up.aufwachen><en> Well you needn't worry any more, have a few drinks in the wet mess and just go to bed in what you've got on, wake up the next day.
<G-vec00880-002-s468><wake_up.aufwachen><de> Wenn Sie nicht mehr schlafen müssen, wird eine weitere Gabe des Medikaments ausgesetzt und Sie wachen nach kurzer Zeit von selbst auf.
<G-vec00880-002-s468><wake_up.aufwachen><en> When sedation is no longer required, the next dose of medication will be withheld, and you will wake up on your own within a short period of time.
<G-vec00880-002-s469><wake_up.aufwachen><de> Nach einem erholsamen Schlaf in einem unserer komfortablen Doppelbetten wachen Sie in einem stilvollen und dennoch gemütlichen Zimmer auf.
<G-vec00880-002-s469><wake_up.aufwachen><en> After a good night’s sleep in one of our comfortable king size beds, you will wake up in a stylish yet cosy room.
<G-vec00880-002-s470><wake_up.aufwachen><de> Wachen Sie zum Zirpen der lokalen Vogelwelt und sehen lokale Beuteltiere einschließlich den Flinkwallaby aus dem Komfort der eigenen Terrasse.
<G-vec00880-002-s470><wake_up.aufwachen><en> Wake up to the chirping of the local bird life and view local marsupials including the Agile Wallaby from the comfort of your own patio.
<G-vec00880-002-s471><wake_up.aufwachen><de> Exmortis Sie wachen in den Wäldern ohne Erinnerung an wie Sie es bekommen.
<G-vec00880-002-s471><wake_up.aufwachen><en> Exmortis You wake up in the woods with no memory of how you got there.
<G-vec00880-002-s472><wake_up.aufwachen><de> “Wir wachen jeden Morgen mit neuen Tweets des US-Präsidenten auf.
<G-vec00880-002-s472><wake_up.aufwachen><en> “We wake every morning to new tweets from the U.S. president.
<G-vec00880-002-s473><wake_up.aufwachen><de> Wenn du nun nicht wachen wirst, so werde ich über dich kommen, wie ein Dieb, und du wirst nicht wissen, um welche Stunde ich über dich kommen werde.
<G-vec00880-002-s473><wake_up.aufwachen><en> Repent and turn to me again. If you don’t wake up, I will come to you suddenly, as unexpected as a thief.
<G-vec00880-002-s475><wake_up.aufwachen><de> 44 Prozent der Frauen wachen nachts häufig oder gar jede Nacht auf.
<G-vec00880-002-s475><wake_up.aufwachen><en> 44% of women wake up at night often.
<G-vec00880-002-s476><wake_up.aufwachen><de> All diese Zeit ist einzigartig: Die Stadt scheint lebendig zu werden, ihre Bewohner wachen aus der herbstlichen Melancholie auf, in der Luft beginnt eine gute festliche Euphorie, die sich um sich selbst auflädt.
<G-vec00880-002-s476><wake_up.aufwachen><en> All this period is unique: the city seems to come to life, its inhabitants wake up from the autumn melancholy, in the air begins to hang up a good festive euphoria, charging all around itself.
<G-vec00880-002-s477><wake_up.aufwachen><de> Laut Statistik wachen Kinder, die mit ihren Eltern im selben Zimmer schlafen, selten mitten in der Nacht auf und verhalten sich in der Regel gelassener.
<G-vec00880-002-s477><wake_up.aufwachen><en> According to statistics, children who sleep in the same room with their parents, rarely wake up in the middle of the night and generally behave more calmly.
<G-vec00880-002-s478><wake_up.aufwachen><de> Wachen Sie auf und hören Sie....
<G-vec00880-002-s478><wake_up.aufwachen><en> Wake up and listen out....
<G-vec00880-002-s479><wake_up.aufwachen><de> Fahren Sie ab, um die Sternen zu sammeln Aber wachen Sie nicht auf.
<G-vec00880-002-s479><wake_up.aufwachen><en> Go plucking the stars But do not wake up
<G-vec00880-002-s480><wake_up.aufwachen><de> Willkommen bei Blau Privilege PortoPetro Beach Resort & Spa Erholen Sie sich am Mittelmeer und wachen Sie jeden Morgen voller Freude auf, weil Sie das wunderbare Gefühl haben, einen endlosen Urlaub zu genießen.
<G-vec00880-002-s480><wake_up.aufwachen><en> Welcome to Blau Privilege PortoPetro Beach Resort & Spa: Relax in front of the Mediterranean Sea and wake up every day to an unbeatable holiday.
<G-vec00880-002-s481><wake_up.aufwachen><de> Wachen Sie jeden Tag mit dem inspirierenden Wort Gottes auf.
<G-vec00880-002-s481><wake_up.aufwachen><en> Wake up every day with the inspiring word of God.
<G-vec00880-002-s482><wake_up.aufwachen><de> Sie wachen mit einem schönen Blick über den See und die Berge.
<G-vec00880-002-s482><wake_up.aufwachen><en> You wake up with a beautiful view over the lake and the mountains.
<G-vec00880-002-s483><wake_up.aufwachen><de> Mit einem Gläschen Alkohol schlafen wir vielleicht besser ein, erleben aber keinen erholsamen Schlaf und wachen morgens möglicherweise gerädert auf.
<G-vec00880-002-s483><wake_up.aufwachen><en> Bottom line: a glass of alcohol might help us fall asleep, but it prevents us from getting healthy, restful sleep and might cause us to wake up exhausted the next morning.
<G-vec00880-002-s484><wake_up.aufwachen><de> Wir wachen in einem komplett verregneten Dominical auf, das Meer schaut aus wie Kaba (für Schweizer Ovomaltine), das Zimmer ist feucht und grausig.
<G-vec00880-002-s484><wake_up.aufwachen><en> We wake up in a completely rainy Dominical, the ocean looks like a hot chocolate, the rooms is humid and moldy.
<G-vec00880-002-s485><wake_up.aufwachen><de> Wachen Sie erholt auf und starten Sie in Ihren Tag mit unserem kräftigenden, kostenlosen täglichen Frühstücksbüfett.
<G-vec00880-002-s485><wake_up.aufwachen><en> Wake up refreshed and start your day by fueling up at our free daily breakfast buffet.
<G-vec00880-002-s486><wake_up.aufwachen><de> Radiowecker NY Bigben Wachen Sie mit diesem New Yorker Radiowecker gut gelaunt auf.
<G-vec00880-002-s486><wake_up.aufwachen><en> Radio Alarm Clock NY Bigben Wake up in a good mood with this New York radio alarm clock.
<G-vec00880-002-s487><wake_up.aufwachen><de> Nimm die blaue Pille - die Geschichte endet, du wachst in deinem Bett auf und glaubst, was immer du glauben möchtest.
<G-vec00880-002-s487><wake_up.aufwachen><en> "You take the blue pill -- the story ends, you wake up in your bed and believe whatever you want to believe.
<G-vec00880-002-s488><wake_up.aufwachen><de> An deinem ersten Arbeitstag verlierst du durch einen Unfall das Bewusstsein … Du wachst in einem zerstörten Teil des Komplexes wieder auf, ausgerüstet mit einem schweren Exoskelett.
<G-vec00880-002-s488><wake_up.aufwachen><en> A catastrophic event has knocked you out during the first day on the job… you wake up equipped with a heavy-grade exoskeleton, in a destroyed section of the complex.
<G-vec00880-002-s489><wake_up.aufwachen><de> Du wachst auf, abrupt, außer Atem.
<G-vec00880-002-s489><wake_up.aufwachen><en> You wake up, abruptly, breathlessly.
<G-vec00880-002-s490><wake_up.aufwachen><de> Irgendwann später wachst Du auf.
<G-vec00880-002-s490><wake_up.aufwachen><en> Some when later you wake up.
<G-vec00880-002-s491><wake_up.aufwachen><de> „ Jeden Tag wachst du auf und bekommst die Chance, etwas Bedeutungsvolles zu tun.
<G-vec00880-002-s491><wake_up.aufwachen><en> Life is a second and everyday you wake up and you get one day to do something important.
<G-vec00880-002-s492><wake_up.aufwachen><de> Du wachst eines Tages auf und bemerkst, dass Deine Webseite gehackt wurde.
<G-vec00880-002-s492><wake_up.aufwachen><en> You wake up one day only to find out that your site has been hacked.
<G-vec00880-002-s493><wake_up.aufwachen><de> Stell dir einmal Folgendes vor: Du wachst auf, frühstückst unglaublich lecker im Hotel und wirst dann von deinem Tauchlehrer abgeholt, um das Mittelmeer zu entdecken.
<G-vec00880-002-s493><wake_up.aufwachen><en> Picture this: You wake up, have a devilishly divine hotel breakfast, before your scuba instructor whisks you away to explore the Mediterranean Sea.
<G-vec00880-002-s494><wake_up.aufwachen><de> Wenn du nun nicht wachst, werde ich kommen wie ein Dieb, und du wirst nicht wissen, zu welcher Stunde ich über dich kommen werde.
<G-vec00880-002-s494><wake_up.aufwachen><en> If you will not wake up, I will come like a thief, and you will not know at what […]
<G-vec00880-002-s495><wake_up.aufwachen><de> Zu viel schlafen bedeutet, Du wachst schmerzhaft auf, bist dehydriert und ein wenig benommen.
<G-vec00880-002-s495><wake_up.aufwachen><en> Sleeping too much means you wake up feeling achy, dehydrated, and a little bit fuzzy.
<G-vec00880-002-s496><wake_up.aufwachen><de> Klickst Du auf das rote Kreuz rechts oben, endet alles, Du wachst morgen auf und bist der, der Du immer warst .
<G-vec00880-002-s496><wake_up.aufwachen><en> If you click the red cross on the right above, it all ends, you wake up tomorrow and you`re the one you have always been.
<G-vec00880-002-s497><wake_up.aufwachen><de> Du wachst morgens auf, mit einer richtig harten, langen Latte.
<G-vec00880-002-s497><wake_up.aufwachen><en> You wake up in the morning, with a really hard, long cock.
<G-vec00880-002-s498><wake_up.aufwachen><de> An manchen Tagen wachst du auf und die Wellen rufen nach dir.
<G-vec00880-002-s498><wake_up.aufwachen><en> Some days you wake up to the waves calling your name.
<G-vec00880-002-s499><wake_up.aufwachen><de> Nach einem Autounfall wachst du auf und entdeckst, dass du dich nicht in einem Krankenhaus befindest, sondern in einem Irrenhaus, un...
<G-vec00880-002-s499><wake_up.aufwachen><en> After a car accident you wake up to find that instead of lying in a hospital, you’re in an asylum with your head wrapped in bandages.
<G-vec00880-002-s500><wake_up.aufwachen><de> Wenn du abends zu Bett gehst und deine Hände so über dich legst und einfach so da liegst und Ihn preist, bis du einschläfst; des Morgens wachst du auf und preist Ihn immer noch.
<G-vec00880-002-s500><wake_up.aufwachen><en> When you go to bed at night, and put your hands behind you like this, and just lay there and praise Him till you go to sleep. Wake up, of a morning, still praising Him.
<G-vec00880-002-s501><wake_up.aufwachen><de> Du wachst am Morgen auf, doch der Schlaf war mal wieder nicht so erholsam wie notwendig.
<G-vec00880-002-s501><wake_up.aufwachen><en> You wake up in the morning, but sleep was not as relaxing as necessary.
<G-vec00880-002-s502><wake_up.aufwachen><de> Du wachst auf und hast Angst vor dem Arbeitstag.
<G-vec00880-002-s502><wake_up.aufwachen><en> You wake up dreading the work-day.
<G-vec00880-002-s503><wake_up.aufwachen><de> Mit der verbesserten Weckfunktion wachst du zu deinen Lieblingssongs, Radiosendern oder Playlisten auf.
<G-vec00880-002-s503><wake_up.aufwachen><en> Wake up to your favorite songs, radio stations or playlists with the enhanced alarm feature, now with the much requested snooze function.
<G-vec00880-002-s504><wake_up.aufwachen><de> Du wachst auf am Morgen, spürst 'nen langen Kuß.
<G-vec00880-002-s504><wake_up.aufwachen><en> You’ll wake up in the morning with a lingering kiss.
<G-vec00880-002-s505><wake_up.aufwachen><de> Eines Morgens wachst du auf, schaust in den Spiegel und plötzlich fragst du dich, wo die Jahre geblieben sind...
<G-vec00880-002-s505><wake_up.aufwachen><en> One morning, you wake up, look in the mirror, and ask yourself, "What happened?
<G-vec00880-002-s506><wake_up.aufwachen><de> Man wacht morgens mit dem Gefühl auf, dass man nicht aufstehen möchte und man fühlt sich missverstanden und eben sehr sehr schwach.
<G-vec00880-002-s506><wake_up.aufwachen><en> You'd wake up in the morning feeling you didn't want to get out of bed, you felt misunderstood, and just very, very low in yourself.
<G-vec00880-002-s507><wake_up.aufwachen><de> Morgen wacht man auf den angenehmen Klang der Wiesenvögel auf.
<G-vec00880-002-s507><wake_up.aufwachen><en> Morning you wake up to the pleasant sound of the meadow birds.
<G-vec00880-002-s508><wake_up.aufwachen><de> Man wacht auf mit der Sonne, atmet pure und frischeste Berg- und Waldluft, schmeißt den Kocher an und brüht erstmal einen leckern Kaffee.
<G-vec00880-002-s508><wake_up.aufwachen><en> You wake up with the sun, breathe pure and fresh mountain and forest air, start the cooker and brew a delicious coffee.
<G-vec00880-002-s509><wake_up.aufwachen><de> Man wacht auf, macht die Augen auf: die Zelle fährt; nachmittags, wenn die Sonne reinscheint, bleibt sie plötzlich stehen.
<G-vec00880-002-s509><wake_up.aufwachen><en> You wake up, open your eyes: the cell drives; In the afternoon, when the sun comes in, it suddenly stops.
<G-vec00880-002-s510><wake_up.aufwachen><de> Nach einem Nickerchen sollte übrigens Nahrung zur Verfügung stehen, denn die Hauptfigur wacht oftmals hungrig auf.
<G-vec00880-002-s510><wake_up.aufwachen><en> Be sure to have food ready after a nap, as your character will often wake up hungry.
<G-vec00880-002-s511><wake_up.aufwachen><de> Deshalb sagt Baba: Wacht morgens auf, erinnert euch an den Vater und denkt tief über den Wissensozean im Hinblick darauf nach, welcher Name gegeben werden soll.
<G-vec00880-002-s511><wake_up.aufwachen><en> Good suggestions emerge. This is why Baba says: Wake up in the morning, remember the Father and churn the ocean of knowledge about what name should be given.
<G-vec00880-002-s512><wake_up.aufwachen><de> Er lautet: "Wacht zu euch selbst auf.
<G-vec00880-002-s512><wake_up.aufwachen><en> The clarion call is: "Wake up to yourself.
<G-vec00880-002-s513><wake_up.aufwachen><de> Man wacht morgens auf und das alte Leben wurde durch ein gänzlich Neues abgelöst.
<G-vec00880-002-s513><wake_up.aufwachen><en> You wake up one morning and your old life has been superseded by an entirely new one.
<G-vec00880-002-s514><wake_up.aufwachen><de> Ein Gerät wacht nur dann auf, wenn die Informationen im WoL-Paket mit seinen Daten übereinstimmen.
<G-vec00880-002-s514><wake_up.aufwachen><en> A device will only wake up if the information in the WoL packet matches it.
<G-vec00880-002-s515><wake_up.aufwachen><de> Trotz gesperrter Tasten wacht das Telefon gegebenenfalls aus dem Standby auf und stellt eine Verbindung mit der gewünschten Nummer her.
<G-vec00880-002-s515><wake_up.aufwachen><en> If the phone is in locked mode and standby it will also wake up and dial in this mode the selected number.
<G-vec00880-002-s516><wake_up.aufwachen><de> Drückt Ihr zweimal die Leiser-Taste, wenn das Mate 9 im Stand-by ist, wacht das Smartphone auf und macht in unter einer Sekunde ein Foto.
<G-vec00880-002-s516><wake_up.aufwachen><en> If you press the volume down button twice, while the Mate 9 is on standby, the phone will wake up and take a photo in less than one second.
<G-vec00880-002-s517><wake_up.aufwachen><de> (Alles ist in den Bildern) Dort ist alles für einen angenehmen Aufenthalt und einen Bonus des Sonnenuntergang vom Bett erforderlich ist, und wacht unten ein kleines Reh auf!...
<G-vec00880-002-s517><wake_up.aufwachen><en> (Everything is in the pictures) There is everything necessary for a great stay and a bonus the sunset from the bed, and wake up a little deer below!...
<G-vec00880-002-s518><wake_up.aufwachen><de> Nun, seht ihr, wer wirklich die Kontrolle hat, und wacht dieser Tatsache gegenüber auf.
<G-vec00880-002-s518><wake_up.aufwachen><en> Now, see who is really in control and wake up to this fact.
<G-vec00880-002-s519><wake_up.aufwachen><de> Man schläft mit all seinen Freunden in einem großen Saal voll kuscheliger Betten, erzählt noch lang, obwohl das Licht längst aus ist, wacht auf, wenn der Hahn kräht, sieht aus dem Fenster in die schöne Natur und wenn man dann runter tapst in den Frühstückraum und Katharina in der Küche die Brötchen aus dem Ofen holt, ist es wieder wie früher, wie zu Hause.
<G-vec00880-002-s519><wake_up.aufwachen><en> You sleep with all his friends in a large hall full of cozy beds, tells still long, although the light is from a time long, wake up when the rooster crows, looks out the window at the beautiful nature and if you down tapst in the breakfast room and Catherine the rolls obtained from the oven in the kitchen, it's the same again, at home.
<G-vec00880-002-s520><wake_up.aufwachen><de> In den meisten Fällen wacht ein Mensch plötzlich auf, weil er einen Albtraum hatte.
<G-vec00880-002-s520><wake_up.aufwachen><en> In most cases, a person will wake up suddenly because of a nightmare.
<G-vec00880-002-s521><wake_up.aufwachen><de> Wenn man abends mit der Fähre vom Takeshiba-Pier losfährt und die Nacht auf dem Schiff verbringt, wacht man am nächsten Morgen in einer anderen Welt auf.
<G-vec00880-002-s521><wake_up.aufwachen><en> Board at Takeshiba Pier late Friday evening, spend the night on board, and wake up Saturday morning to arrive in an entirely different world.
<G-vec00880-002-s522><wake_up.aufwachen><de> Oder ihr wacht nach ein paar Stunden Schlaf gestreßt auf.
<G-vec00880-002-s522><wake_up.aufwachen><en> Or you may wake up after a few hours feeling stressed.
<G-vec00880-002-s523><wake_up.aufwachen><de> Oft merkt man gar nicht, wie lange man der intensiven Sonne ausgesetzt ist und wacht mit einem unschönen Brand am nächsten Tag auf.
<G-vec00880-002-s523><wake_up.aufwachen><en> Often I forget how long my skin is exposed to the intensive fun and I wake up with a sun burn the next morning.
<G-vec00880-002-s524><wake_up.aufwachen><de> Eines Morgens wacht man auf, macht sich bereit zum Einkaufen und als man versucht, auf die ListX-Einkaufsliste zuzugreifen, wird einem klar: Man hat sein Passwort vergessen.
<G-vec00880-002-s524><wake_up.aufwachen><en> One morning you wake up, get ready to go shopping and as you try to access your ListX shopping list you realize it: You forgot your password.
<G-vec00880-002-s525><wake_up.aufwachen><de> Kurt wachte als erster auf.
<G-vec00880-002-s525><wake_up.aufwachen><en> The first to wake up was Kurt.
<G-vec00880-002-s526><wake_up.aufwachen><de> Er konnte rasch hinter einen Baum treten und sich retten, aber selbst da wachte er noch nicht auf.
<G-vec00880-002-s526><wake_up.aufwachen><en> He quickly hid behind a tree and saved himself, but even then he didn't wake up.
<G-vec00880-002-s527><wake_up.aufwachen><de> Aber jedes Mal, wenn ich es versuchte, wachte er auf und weinte wie verrückt.
<G-vec00880-002-s527><wake_up.aufwachen><en> But every time I tried he’d wake up immediately and cry like crazy.
<G-vec00880-002-s528><wake_up.aufwachen><de> Sie hatte schon gelesen, dass ältere Paare abends gemeinsam einschliefen, und dann wachte morgens einer von ihnen auf und der andere war tot.
<G-vec00880-002-s528><wake_up.aufwachen><en> She had read once about how older couples would fall asleep together at night, and then in the morning one of them would wake up and the other would be dead.
<G-vec00880-002-s529><wake_up.aufwachen><de> Ich 'wachte auf' in der Nacht und rollte aus meinem Bett, stolperte über die Matte am Ende von meinem Bett.
<G-vec00880-002-s529><wake_up.aufwachen><en> I would in the night ‘wake up’ and roll out of my bed tumbling onto the mat at the end of my bed.
<G-vec00880-002-s530><wake_up.aufwachen><de> Manchmal wachte der Vater auf, und als wisse er gar nicht, daß er geschlafen habe, sagte er zur Mutter: »Wie lange du heute schon wieder nähst!« und schlief sofort wieder ein, während Mutter und Schwester einander müde zulächelten.
<G-vec00880-002-s530><wake_up.aufwachen><en> Sometimes his father would wake up and say to Gregor’s mother “you’re doing so much sewing again today!”, as if he did not know that he had been dozing – and then he would go back to sleep again while mother and sister would exchange a tired grin.
<G-vec00880-002-s531><wake_up.aufwachen><de> Wenn ich mich hinlegte, schlief ich mit dem Jesus-Gebet ein, und jeden Morgen wachte ich damit auf.
<G-vec00880-002-s531><wake_up.aufwachen><en> I would fall asleep with the Jesus prayer and every morning I would wake up with the prayer.
<G-vec00880-002-s532><wake_up.aufwachen><de> Rose wurde begraben, Wheely stieß gegen ihren Kopf und wachte nicht auf, bis sie ihren Vater über die KI rufen hörte.
<G-vec00880-002-s532><wake_up.aufwachen><en> Rose was buried, Wheely hit her head, and didn't wake up until she heard her father calling her on her KI.
<G-vec00880-002-s533><wake_up.aufwachen><de> Ungefähr zu der Zeit, bekam meine Tochter Alpträume und wachte öfter mitten in der Nacht schreiend und weinend auf.
<G-vec00880-002-s533><wake_up.aufwachen><en> Round about that time, my daughter started to have nightmares and very often would wake up in the middle of the night screaming and crying.
<G-vec00880-002-s534><wake_up.aufwachen><de> Manchmal wachte ich sogar mitten in der Nacht auf und schrieb etwas.
<G-vec00880-002-s534><wake_up.aufwachen><en> I would also wake up in the middle of the night with new ideas and would get up and write them down or record them.
