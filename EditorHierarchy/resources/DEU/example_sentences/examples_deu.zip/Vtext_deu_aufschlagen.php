<G-vec00230-002-s005><deplore.aufschlagen><de> Die „amerikanischen Sitten“, vor denen europäische Professoren und wohlgesinnte Bürger so heuchlerisch die Augen zum Himmel aufschlagen, sind in der Epoche des Finanzkapitals buchstäblich zu Sitten einer jeden Großstadt in jedem beliebigen Lande geworden.
<G-vec00230-002-s005><deplore.aufschlagen><en> "American ethics," which the European professors and well-meaning bourgeois so hypocritically deplore, have, in the age of finance capital, become the ethics of literally every large city in every country.
<G-vec00279-002-s050><beat.aufschlagen><de> Mascarpone und Sahne aufschlagen, bis die Masse fast steif ist.
<G-vec00279-002-s050><beat.aufschlagen><en> Combine mascarpone and heavy cream in a bowl and beat until nearly stiff.
<G-vec00279-002-s051><beat.aufschlagen><de> In der Küchenmaschine aufschlagen, bis eine sehr steife Meringue entstanden ist und der Schüsselboden Raumtemperatur hat.
<G-vec00279-002-s051><beat.aufschlagen><en> Beat on high speed in the standing mixer until you get a stiff meringue and the bottom of the bowl reaches room temperature.
<G-vec00279-002-s052><beat.aufschlagen><de> Butter mit Zucker, Vanillezucker und Honig aufschlagen.
<G-vec00279-002-s052><beat.aufschlagen><en> Beat butter with sugar, vanilla sugar and honey.
<G-vec00279-002-s053><beat.aufschlagen><de> Den Zucker und Zimt mischen, in die Schüssel einrieseln lassen und auf höchster Stufe aufschlagen, bis alles hell und luftig ist.
<G-vec00279-002-s053><beat.aufschlagen><en> Slowly add the sugar and cinnamon and beat on high speed until light and fluffy.
<G-vec00279-002-s054><beat.aufschlagen><de> In einer großen Schüssel Eiweiße, Zucker, Vanilleextrakt und Salz aufschlagen.
<G-vec00279-002-s054><beat.aufschlagen><en> In a large bowl, beat egg whites, sugar, vanilla extract and salt.
<G-vec00279-002-s055><beat.aufschlagen><de> Verwendungsvorschlag Unser Tipp: Schneller Rigatoniauflauf - 250 g Rigatoni Nudeln al dente kochen, 4 Eier aufschlagen und mit Salz, schwarzem Pfeffer, einer gepressten Knoblauchzehe, etwas Olivenöl, Paprikapulver, einer kleingehackten roten Chilischote oder getrockneten Chili Flocken und 200g geriebenem Käse vermischen.
<G-vec00279-002-s055><beat.aufschlagen><en> Our top tip: Quick Rigatoni Pasta Bake: Boil 250g rigatoni pasta until al dente. Beat 4 eggs and mix together with salt, black pepper, a crushed garlic clove, a dash of olive oil, paprika powder, a finely chopped red chili pepper or dried chili flakes and 200g grated cheese.
<G-vec00279-002-s056><beat.aufschlagen><de> Eier aufschlagen, mit Salz und Pfeffer würzen und verquirlen.
<G-vec00279-002-s056><beat.aufschlagen><en> Beat the eggs, season with salt and pepper and whisk.
<G-vec00279-002-s057><beat.aufschlagen><de> Für die Vanilleglasur die Margarine mit dem Mixer sehr weich aufschlagen.
<G-vec00279-002-s057><beat.aufschlagen><en> For the vanilla frosting beat margarine with an electric mixer until very soft.
<G-vec00279-002-s058><beat.aufschlagen><de> Zucker und Ei aufschlagen, dann die Stärke unterrühren.
<G-vec00279-002-s058><beat.aufschlagen><en> Beat the egg and sugar, then stir in the starch.
<G-vec00279-002-s059><beat.aufschlagen><de> Weiche Butter und Zucker in einer großen Schüssel luftig aufschlagen.
<G-vec00279-002-s059><beat.aufschlagen><en> Beat the butter and sugar in a large bowl until light and airy.
<G-vec00279-002-s060><beat.aufschlagen><de> Eier mit Zucker und Honig cremig aufschlagen.
<G-vec00279-002-s060><beat.aufschlagen><en> Beat the eggs with sugar and honey until creamy.
<G-vec00279-002-s061><beat.aufschlagen><de> Eigelb aufschlagen und den Blätterteig damit bepinseln.
<G-vec00279-002-s061><beat.aufschlagen><en> Beat the egg yolk and coat the puff pastry with it.
<G-vec00389-003-s050><beat_out.aufschlagen><de> Mascarpone und Sahne aufschlagen, bis die Masse fast steif ist.
<G-vec00389-003-s050><beat_out.aufschlagen><en> Combine mascarpone and heavy cream in a bowl and beat until nearly stiff.
<G-vec00389-003-s051><beat_out.aufschlagen><de> In der Küchenmaschine aufschlagen, bis eine sehr steife Meringue entstanden ist und der Schüsselboden Raumtemperatur hat.
<G-vec00389-003-s051><beat_out.aufschlagen><en> Beat on high speed in the standing mixer until you get a stiff meringue and the bottom of the bowl reaches room temperature.
<G-vec00389-003-s052><beat_out.aufschlagen><de> Butter mit Zucker, Vanillezucker und Honig aufschlagen.
<G-vec00389-003-s052><beat_out.aufschlagen><en> Beat butter with sugar, vanilla sugar and honey.
<G-vec00389-003-s053><beat_out.aufschlagen><de> Den Zucker und Zimt mischen, in die Schüssel einrieseln lassen und auf höchster Stufe aufschlagen, bis alles hell und luftig ist.
<G-vec00389-003-s053><beat_out.aufschlagen><en> Slowly add the sugar and cinnamon and beat on high speed until light and fluffy.
<G-vec00389-003-s054><beat_out.aufschlagen><de> In einer großen Schüssel Eiweiße, Zucker, Vanilleextrakt und Salz aufschlagen.
<G-vec00389-003-s054><beat_out.aufschlagen><en> In a large bowl, beat egg whites, sugar, vanilla extract and salt.
<G-vec00389-003-s055><beat_out.aufschlagen><de> Verwendungsvorschlag Unser Tipp: Schneller Rigatoniauflauf - 250 g Rigatoni Nudeln al dente kochen, 4 Eier aufschlagen und mit Salz, schwarzem Pfeffer, einer gepressten Knoblauchzehe, etwas Olivenöl, Paprikapulver, einer kleingehackten roten Chilischote oder getrockneten Chili Flocken und 200g geriebenem Käse vermischen.
<G-vec00389-003-s055><beat_out.aufschlagen><en> Our top tip: Quick Rigatoni Pasta Bake: Boil 250g rigatoni pasta until al dente. Beat 4 eggs and mix together with salt, black pepper, a crushed garlic clove, a dash of olive oil, paprika powder, a finely chopped red chili pepper or dried chili flakes and 200g grated cheese.
<G-vec00389-003-s056><beat_out.aufschlagen><de> Eier aufschlagen, mit Salz und Pfeffer würzen und verquirlen.
<G-vec00389-003-s056><beat_out.aufschlagen><en> Beat the eggs, season with salt and pepper and whisk.
<G-vec00389-003-s057><beat_out.aufschlagen><de> Für die Vanilleglasur die Margarine mit dem Mixer sehr weich aufschlagen.
<G-vec00389-003-s057><beat_out.aufschlagen><en> For the vanilla frosting beat margarine with an electric mixer until very soft.
<G-vec00389-003-s058><beat_out.aufschlagen><de> Zucker und Ei aufschlagen, dann die Stärke unterrühren.
<G-vec00389-003-s058><beat_out.aufschlagen><en> Beat the egg and sugar, then stir in the starch.
<G-vec00389-003-s059><beat_out.aufschlagen><de> Weiche Butter und Zucker in einer großen Schüssel luftig aufschlagen.
<G-vec00389-003-s059><beat_out.aufschlagen><en> Beat the butter and sugar in a large bowl until light and airy.
<G-vec00389-003-s060><beat_out.aufschlagen><de> Eier mit Zucker und Honig cremig aufschlagen.
<G-vec00389-003-s060><beat_out.aufschlagen><en> Beat the eggs with sugar and honey until creamy.
<G-vec00389-003-s061><beat_out.aufschlagen><de> Eigelb aufschlagen und den Blätterteig damit bepinseln.
<G-vec00389-003-s061><beat_out.aufschlagen><en> Beat the egg yolk and coat the puff pastry with it.
<G-vec00903-002-s028><crack.aufschlagen><de> Ein Ei aufschlagen können erweist sich in der Küche als praktische Fähigkeit.
<G-vec00903-002-s028><crack.aufschlagen><en> Being able to crack an egg is a handy kitchen skill.
<G-vec00903-002-s029><crack.aufschlagen><de> Das Ei vorsichtig über die gesamte Oberfläche aufschlagen, dann die Schale unter fließendem Wasser abziehen.
<G-vec00903-002-s029><crack.aufschlagen><en> Crack the egg gently all over its surface, then peel away the shell under running water.
<G-vec00903-002-s030><crack.aufschlagen><de> Ein Ei aufschlagen, in eine kleine Auflaufform, kleine Schüssel oder eine Suppenkelle geben.
<G-vec00903-002-s030><crack.aufschlagen><en> To poach an egg, first crack an egg into a small bowl.
