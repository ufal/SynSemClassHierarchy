<G-vec00081-001-s026><discontinue.absetzen><de> Darüber hinaus konnten 34% der Patienten andere Medikamente, darunter Opioide, Stimulanzien und Benzodiazepine, reduzieren oder absetzen.
<G-vec00081-001-s026><discontinue.absetzen><en> In addition, 34% of patients were able to decrease or discontinue other medications including opioids, stimulants, and benzodiazepines.
<G-vec00081-001-s027><discontinue.absetzen><de> Empire of Sports AG kann jeden Aspekt von EOS (einschließlich des Kontos), der Software, des Systems oder der Websites zu jeder Zeit ändern, modifizieren, einstellen oder absetzen und kann auch Einschränkungen für bestimmte Funktionen auferlegen oder Ihren Zugang zu Teilen oder der Gesamtheit des EOS-Eigentums ohne Mitteilung oder Haftung einschränken.
<G-vec00081-001-s027><discontinue.absetzen><en> Empire of Sports AG may change, modify, suspend, or discontinue any aspect of EOS (including the Account), the Software, System or the websites at any time and may also impose limits on certain features or restrict your access to parts or all of EOS Property without notice or liability.
<G-vec00081-001-s028><discontinue.absetzen><de> Es ist wichtig, dieses Medikament für den gesamten Zeitraum, für den es verschrieben wurde, weiter einzunehmen, da Patienten, die es absetzen, möglicherweise eine Rückkehr ihrer Symptome bemerken.
<G-vec00081-001-s028><discontinue.absetzen><en> It is important to continue taking this medication for the entire period of time for which it was prescribed, as patients who discontinue taking it may notice a return of their symptoms.
<G-vec00081-001-s029><discontinue.absetzen><de> Es gibt noch andere Gründe, warum wir ein Promo absetzen können (zum Beispiel ein unseres Tieres hasst, ist Casino, die Angebote zu werben, die nicht richtig oder wahr sind).
<G-vec00081-001-s029><discontinue.absetzen><en> There are other reasons why we may discontinue a promo (for example, one of our pet hates is casinos who advertise offers which are not accurate or true).
<G-vec00418-001-s076><drop.absetzen><de> Sie müssen dann den Fahrer auf Ihrem Rückweg am Parkplatz absetzen, bevor Sie Ihren Heimweg antreten.
<G-vec00418-001-s076><drop.absetzen><en> On your journey home, please drop off the driver at the car park, then continue your journey.
<G-vec00418-001-s077><drop.absetzen><de> 23:30 Uhr: Unser Abend neigt sich dem Ende zu, als wir Sie gegen Mitternacht in Ihrem Hotel absetzen.
<G-vec00418-001-s077><drop.absetzen><en> 11:30pm: Our evening will come to a close as we drop you back at your hotel for around midnight.
<G-vec00418-001-s078><drop.absetzen><de> Drahtglas mit laminierten verdrahtet oder wire Mesh, mit stärker Schlagzähigkeit, wenn Auswirkungen auf gewesen, ist Form ein radialer Spalt nicht absetzen verletzt Menschen, vor allem auf Hochhäuser und der Werkstatt] Gebäude unter den mächtigen erschütternder.
<G-vec00418-001-s078><drop.absetzen><en> Wired glass, laminated with wired or wire mesh, with stronger impact resistance, when been impacting, is form a radial crack not drop off to hurt human,mainly use on High-rise buildings and the workshop] building under the powerful concussive.
<G-vec00418-001-s079><drop.absetzen><de> Der Vorgang gleicht trotz der hohen Geschwindigkeit dem sanften Absetzen durch eine Dosiernadel.
<G-vec00418-001-s079><drop.absetzen><en> In spite its high speed the procedure resembles the gentle way of placing a drop with a dosing needle.
<G-vec00418-001-s080><drop.absetzen><de> Was passiert mit den Schrott Kabeldraht, nachdem Sie sie absetzen?Sie sind sortiert nach Material und in kleinere Stücke geschnitten.Die verarbeiteten Schrott ist verpackt und ausgeliefert, ein Unternehmen, das wieder schmilzt das Material und macht...
<G-vec00418-001-s080><drop.absetzen><en> What happens to the scrap cable wire after you drop them off They are sorted by material and sliced into smaller pieces The processed scrap is packaged and shipped to a company that re melts the materials and makes new products out of it An...
<G-vec00418-001-s081><drop.absetzen><de> Jede U-Bahn hat 15 Haltestellen, so dass sie Sie in der Nähe Ihres Endziels absetzen kann.
<G-vec00418-001-s081><drop.absetzen><en> Each tube has 15 stops, so it can drop you close to your final destination.
<G-vec00418-001-s082><drop.absetzen><de> Mit der linken Maustaste mit der Maus bewegen Sie den Fleisch und Fett absetzen.
<G-vec00418-001-s082><drop.absetzen><en> With the left mouse button with the mouse, move the meat and fat drop off.
<G-vec00418-001-s083><drop.absetzen><de> Der Helikopter muss nicht landen, er kann einfach darüber schweben und mit der Longline, Vorräte absetzen oder sogar Menschen aus engen Talwände retten.
<G-vec00418-001-s083><drop.absetzen><en> It doesn’t need to land, it can just hover above and use the long line to drop off supplies or even rescue people from narrow valley walls.
<G-vec00418-001-s084><drop.absetzen><de> Doch Klöden und Landis sind die Stärksten und können sich nach einer Temposteigerung des Deutschen wieder absetzen und das Ziel 25 Sekunden vor Sastre erreichen.
<G-vec00418-001-s084><drop.absetzen><en> But Klöden and Landis are the strongest and they can once again drop their opponents after an acceleration from the German to finish 25 seconds ahead of Sastre.
<G-vec00418-001-s085><drop.absetzen><de> Das Motorrad hätte mich an einer ganz anderen Stelle absetzen sollen.
<G-vec00418-001-s085><drop.absetzen><en> The motorcycle drop was to have been at an entirely different place.
<G-vec00418-001-s086><drop.absetzen><de> Unsere Gruppe wird Sie abholen und in Ihrer Unterkunft absetzen, damit Sie sich keine Sorgen machen müssen und Ihre Reise genießen können.
<G-vec00418-001-s086><drop.absetzen><en> Our group will pick you up and drop you off in your accommodation so you don’t have to worry and enjoy your trip.
<G-vec00418-001-s087><drop.absetzen><de> Der Shuttlefahrer wird Sie zum Flughafen Maastricht Aachen fahren und direkt vor dem Abflugsterminal absetzen.
<G-vec00418-001-s087><drop.absetzen><en> The shuttle driver will bring you to Maastricht Aachen Airport and drop you off in front of the departure terminal.
<G-vec00418-001-s088><drop.absetzen><de> Wenn es das Ziel wäre, die Rückseite der Sonne zu sehen, würde man bloß einen Satelliten nahe des Erdorbits absetzen und 6 Monate auf einen vollen 360 Grad Rundumblick warten müssen.
<G-vec00418-001-s088><drop.absetzen><en> If the goal were to see the backside of the Sun, one would merely have to drop a satellite near Earth's orbit and wait 6 months for a full 360 round view of the Sun.
<G-vec00418-001-s089><drop.absetzen><de> "In diesem Fall könnte man tatsächlich einen Passagier auf diesem Planeten absetzen und den Flug danach fortsetzen, da man ja nicht auf diesem Planeten ""gelandet"" ist."
<G-vec00418-001-s089><drop.absetzen><en> "In this case you could drop the passenger on this planet and indeed could continue your flight since you never in fact ""landed"" on the planet."
<G-vec00418-001-s090><drop.absetzen><de> "Wenn Sie jemanden zum Flughafen bringen, folgen Sie bitte den Schildern zum Abflug, ""Departures"", und benutzen Sie die äußere Spur, wenn Sie sie absetzen."
<G-vec00418-001-s090><drop.absetzen><en> If you are bringing someone to the airport follow the signs for 'Departures' and use the outside lane to drop them off.
<G-vec00418-001-s091><drop.absetzen><de> Eine bar, Restaurant-Buffet Buena Vista mit einer Vielzahl und Show-cooking, Snack-Bar geöffnet in der Hauptsaison genießen Sie leckere Snacks im Pool, einem Parkplatz wo Sie Ihr Fahrzeug, ein Friseur und ein Geschäft absetzen.
<G-vec00418-001-s091><drop.absetzen><en> A bar, restaurant buffet Buena Vista with a wide range and show cooking, the snack bar open in high season to enjoy delicious snacks in the pool, a parking lot where to drop off your vehicle, a Hairdresser and a shop.
<G-vec00418-001-s092><drop.absetzen><de> Lisa war spät dran für unsere Berufung und hatte keine Zeit zu Shelby absetzen, bevor er über für sie zu schießen.
<G-vec00418-001-s092><drop.absetzen><en> Lisa was running late for our appointment and didn't have time to drop Shelby off before coming over for her shoot.
<G-vec00418-001-s093><drop.absetzen><de> Wenn Sie uns nicht am Treffpunkt treffen können, können wir Sie abholen und in Ihrer Unterkunft absetzen.
<G-vec00418-001-s093><drop.absetzen><en> If you cannot meet us at the meeting point we can pick you up and drop you off in your accommodation.
<G-vec00418-001-s094><drop.absetzen><de> Reisebusse Wenn Sie mit dem Bus anreisen, möchten Sie Ihre Gruppe an einem günstig gelegenen Ort absetzen und wieder abholen.
<G-vec00418-001-s094><drop.absetzen><en> Coaches If you travel by coach, you probably want drop off and pick up your group at a suitable place.
<G-vec00301-001-s039><settle.absetzen><de> Für zwei Monate muss das Ganze nun lagern bis sich die Schwebstoffe absetzen und er langsam von oben herab den fertigen Honigschnaps abschöpfen kann.
<G-vec00301-001-s039><settle.absetzen><en> Everything then needs to be stored for 2 months until the suspended solids settle, and the finished honey schnapps can be slowly scooped off the top.
<G-vec00301-001-s040><settle.absetzen><de> Vor dem Verdünnen des Konzentrats sollte das Fläschchen mit dem Produkt aufgerührt werden, da die Insektizid-Mikrokapseln zwar sehr klein sind, jedoch ein gewisses Gewicht haben und sich allmählich absetzen.
<G-vec00301-001-s040><settle.absetzen><en> Before diluting the concentrate, the vial with the product should be stirred up, since the insecticide microcapsules, although very small, do have some weight and ways to gradually settle.
<G-vec00301-001-s041><settle.absetzen><de> Emulgatoren in Ölbadkonzentraten verteilen Fettstoffe oder Öle in Wasser und verhindern deren unerwünschtes Absetzen am Wannenrand.
<G-vec00301-001-s041><settle.absetzen><en> Emulsifiers in bath oil concentrates disperse fatty substances or oils in water and avoid that they settle at the bathtub.
<G-vec00301-001-s042><settle.absetzen><de> Holz ist bekannt, hat eine geringe Beständigkeit gegenüber Feuchtigkeit, dann auf der Formoberfläche absetzen kann.
<G-vec00301-001-s042><settle.absetzen><en> Wood is known, has a low resistance to moisture, then may settle on the mold surface.
<G-vec00301-001-s043><settle.absetzen><de> Vor der Anwendung wird empfohlen, aufrütteln, wie die Naturfasern kann am Boden absetzen.
<G-vec00301-001-s043><settle.absetzen><en> Before the application is recommended, shake up, as the natural fibers can settle to the bottom.
<G-vec00301-001-s044><settle.absetzen><de> Da Schadstoffe, die sich lange in der Luft befinden, insbesondere schädliche Gase, nicht oder kaum durch Absetzen abgeschieden werden, sind sie besonders gefährlich für Mensch, Umwelt und Maschine.
<G-vec00301-001-s044><settle.absetzen><en> Harmful substances, especially harmful gases, that remain in the air for a long time and do not settle fully or at all in the form of deposits, are extremely dangerous for employees, the environment and machines.
<G-vec00301-001-s045><settle.absetzen><de> Er kann einen kleinen Überschuss zu genehmigen und â € ~overrideâ € ™ System, aber jeder großen Überschuss sollte für eine Untersuchung nennen und vielleicht eine Forderung an den Kunden zu beweisen, dass er bald den Betrag absetzen können.
<G-vec00301-001-s045><settle.absetzen><en> He may approve a small excess and ‘override’ the system, but any large excess should call for an investigation and perhaps a demand on the customer to prove that he can settle the amount soon.
<G-vec00301-001-s046><settle.absetzen><de> An diesem Morgen fuhren wir wieder zurück auf dem Fluss, um eine Einsalzen von Papageien und Sittiche zu besuchen, sie früh morgens ankommen, um die Mineralsalze, die im Schlamm absetzen nehmen.
<G-vec00301-001-s046><settle.absetzen><en> That morning we sailed back down the river to visit a salting of parrots and parakeets, them arriving early every morning to take the mineral salts that settle in the mud.
<G-vec00301-001-s047><settle.absetzen><de> Beachten Sie, dass der Boden, wenn sie konzentriert ist sehr langsam und ungleichmäßig absetzen, eine Spur für die Jahre .
<G-vec00301-001-s047><settle.absetzen><en> Note that the ground unless it is concentrated will settle very slowly and unevenly, leaving a trace for years.
<G-vec00301-001-s048><settle.absetzen><de> In diesem Fall absetzen große Partikel auf den Boden und das Wasser dringt in den Boden.
<G-vec00301-001-s048><settle.absetzen><en> In this case large particles settle to the bottom and the water penetrates into the ground.
<G-vec00301-001-s049><settle.absetzen><de> Nette Begrüßung von den Eigentümern, die in allen absetzen wollen.
<G-vec00301-001-s049><settle.absetzen><en> Nice welcome from the owners who are trying to settle in all.
<G-vec00301-001-s050><settle.absetzen><de> Monster Hotel ist ein Spaß-Simulationsspiel, in dem Spieler Monster in Ihrem Hotel absetzen und stellen Sie sicher, sie waren glücklich.
<G-vec00301-001-s050><settle.absetzen><en> Monster Hotel is a fun simulation game in which players will settle monsters in your hotel and make sure they were happy.
<G-vec00301-001-s051><settle.absetzen><de> Sie können wählen, richtig zu essen in FLC Sam Son Golf Links oder Schritt für ein leckeres kulinarisches Erlebnis in einem bestimmten Lokal absetzen.
<G-vec00301-001-s051><settle.absetzen><en> You might choose to eat right in FLC Sam Son Golf Links or step out to settle in a certain eatery for a tasty culinary experience.
<G-vec00301-001-s052><settle.absetzen><de> Kein Absetzen in der Lidfalte.
<G-vec00301-001-s052><settle.absetzen><en> Won’t settle in the crease.
<G-vec00301-001-s053><settle.absetzen><de> Auf diese Weise können eingeschlossene Feuchtigkeit unter der Oberfläche zu erodieren und Membran Kondensat absetzen.
<G-vec00301-001-s053><settle.absetzen><en> This allows trapped moisture to erode under the finish and settle membrane condensate.
<G-vec00301-001-s054><settle.absetzen><de> "Die Dicke der Naht zwischen zwei horizontalen Reihen von Fliesen sollte nicht weniger als 3 mm: Schrumpf-Ziegelplatte ""Mail"" zur gleichen Zeit mit ihm absetzen."
<G-vec00301-001-s054><settle.absetzen><en> "The thickness of the seam between two horizontal rows of tiles should be not less than 3 mm: shrinkage brick tile ""mail"" will settle at the same time with him."
<G-vec00301-001-s055><settle.absetzen><de> In der Regel können sich die Wespen auf den gepflegten, sauberen und verglasten Balkonen physisch einfach nicht absetzen.
<G-vec00301-001-s055><settle.absetzen><en> In general, the wasps on the well-groomed, clean and glazed balconies just physically can not settle.
<G-vec00301-001-s056><settle.absetzen><de> Abwasser fließt in den Brunnen, große Teilchen absetzen, geht das Wasser durch den Boden.
<G-vec00301-001-s056><settle.absetzen><en> Wastewater flows into the well, large particles settle, the water goes through the soil.
<G-vec00301-001-s057><settle.absetzen><de> Letztendlich wird es absetzen, wie die alte Beiträge verfallen, aber dies war eine lästige Nebenwirkung.
<G-vec00301-001-s057><settle.absetzen><en> Ultimately it will settle out as the old posts expire, but this was an annoying side effect.
<G-vec00081-001-s037><discontinue.absetzen><de> Im Rahmen des gesetzlich Zulässigen behalten wir uns das Recht vor, die Forte Village Bestpreisgarantie nach unserem Ermessen und ohne vorherige Ankündigung jederzeit zu überarbeiten, zu korrigieren, aus- oder abzusetzen.
<G-vec00081-001-s037><discontinue.absetzen><en> To the extent permitted by law, we reserve the right to revise, amend, supplement, suspend or discontinue the Forte Village Best Rate Guarantee at any time in our sole discretion and without prior notice.
<G-vec00081-001-s240><discontinue.absetzen><de> Wenn eine leichte Reizung auftritt, setzen Sie das Produkt 1-2 Tage lang ab und setzen Sie es jeden zweiten Tag fort.
<G-vec00081-001-s240><discontinue.absetzen><en> If mild irritation occurs, discontinue use of the product for 1-2 days and continue using it every other day.
<G-vec00301-002-s042><settle.absetzen><de> Es ist auch periodisch nötig, die Gesimse, die Ringe (die Haken) abzuwischen, von denen sich der Staub auf den Texturen absetzen kann.
<G-vec00301-002-s042><settle.absetzen><en> Also periodically it is necessary to wipe cornices, rings (hooks) from which dust can settle on tissues.
<G-vec00301-002-s043><settle.absetzen><de> Allerdings ist die Fahrbahnoberfläche aus Kies, die wir kontinuierlich absetzen.
<G-vec00301-002-s043><settle.absetzen><en> However, the road surface is made of gravel that we continuously settle.
<G-vec00301-002-s045><settle.absetzen><de> Darüber hinaus müssen Sie alle Unkräuter entfernen, damit sie den Boden nicht schwächen und die Erdbeeren sich schneller und schmerzlos absetzen können.
<G-vec00301-002-s045><settle.absetzen><en> In addition, you need to remove all the weeds, so that they do not weaken the soil, and the strawberries could settle down faster and painlessly.
<G-vec00301-002-s046><settle.absetzen><de> - auch im VR-Modus komplett durch die App navigieren, ohne die VR-Brille absetzen zu müssen.
<G-vec00301-002-s046><settle.absetzen><en> - navigate through the app in VR mode completely without having to settle the VR goggles.
<G-vec00301-002-s047><settle.absetzen><de> Nach der Fortifikation mit Brandy wurde der Portwein über den Winter zum Absetzen belassen.
<G-vec00301-002-s047><settle.absetzen><en> After being fortified with brandy, the Port was left to settle over the winter.
<G-vec00301-002-s048><settle.absetzen><de> Die Magnet-Füße sind die Erhöhung der Ausrüstung auf einem Luftkissen (Maglev); zu arbeiten, sollten richtig gewichtet werden (müssen biegen, aber nicht absetzen).
<G-vec00301-002-s048><settle.absetzen><en> .The magnetic feet are raising the equipment on an air pillow (magnetic levitation); to work, should be properly weighted (must bend, but not settle).
<G-vec00308-002-s383><settle.absetzen><de> Dies sorgt für die optimale Kühlung und Filterung von Schadstoffen, die sich dann in der Bong absetzen.
<G-vec00308-002-s383><settle.absetzen><en> This all, ensures optimum cooling and filtration of any impurities, which then settle into the bong.
<G-vec00308-002-s384><settle.absetzen><de> Die Hightech-Beschichtung wird per Nanotechnologie aufgetragen, wodurch das Brillenglas besonders glatt wird und Schmutz und Staub sich weniger darauf absetzen.
<G-vec00308-002-s384><settle.absetzen><en> The high-tech coating is applied using nanotechnology and makes the lens totally smooth, so that dirt and dust have no chance to settle.
<G-vec00308-002-s385><settle.absetzen><de> Trocknen Sie Wäsche nicht an der Luft, da sich Schimmel und Pollen darauf absetzen können.
<G-vec00308-002-s385><settle.absetzen><en> Don’t air-dry laundry as mould spores and pollen can settle on it.
<G-vec00308-002-s386><settle.absetzen><de> Betrieblich – Wird die Filterwartung ignoriert, können sich Rauch und Schmutzpartikel auf den Laseroptiken absetzen, die die Linse dauerhaft schädigen und die Qualität der Kennzeichnung beeinträchtigen.
<G-vec00308-002-s386><settle.absetzen><en> Operational – If filter maintenance is ignored smoke and debris can settle on the laser optics causing permanent damage to the lens and impairing the quality of the marking.
<G-vec00308-002-s387><settle.absetzen><de> Eine hohe Drehzahl liefert eine Zentrifugalkraft, die dazu führt, dass sich in der zugeführten Flüssigkeit schwebende Feststoffe an der Oberfläche des Filtermediums absetzen.
<G-vec00308-002-s387><settle.absetzen><en> High rotational speed provides high centrifugal force that allows the suspended solid in the feed to settle on the surface of a filter media.
<G-vec00308-002-s388><settle.absetzen><de> Sie entfernen auch Feuchtigkeit und mitgerissenes Öl aus der Luft, so dass sie sich auf dem Boden des Behälters absetzen können, wo sie periodisch weggeblasen werden können.
<G-vec00308-002-s388><settle.absetzen><en> They also remove moisture and entrained oil from the air allowing them to settle to the bottom of the receiver where it can be periodically blown off.
<G-vec00308-002-s389><settle.absetzen><de> Krümelige Speisen, sie könnten sich teilweise in der Wunde absetzen und zu Infektionen beitragen.
<G-vec00308-002-s389><settle.absetzen><en> crumbly foods, they could partially settle in the wound and contribute to infections
<G-vec00308-002-s390><settle.absetzen><de> Ergänzend sind die HelmPads ohne Prägung, so dass sich Feuchtigkeit erst gar nicht absetzen kann.
<G-vec00308-002-s390><settle.absetzen><en> In addition, the helmet pads have no embossing so that moisture cannot settle in the first place.
<G-vec00308-002-s391><settle.absetzen><de> Das Wasser sollte so sauber und klar wie möglich gehalten werden, da Schmutzpartikel sich auf Pflanzen absetzen könnte oder das Wasser trüben könnte, was die Beleuchtung behindern könnte.
<G-vec00308-002-s391><settle.absetzen><en> The water should be kept as clean and clear as possible because free debris can settle on plant leaves or cloud the water, interfering with light intensity.
<G-vec00308-002-s392><settle.absetzen><de> Lassen Sie die Zellen sich absetzen und wachsen.
<G-vec00308-002-s392><settle.absetzen><en> Let the cells settle down and start growing.
<G-vec00308-002-s393><settle.absetzen><de> Der Grund ist denkbar einfach: Wenn keine Luftbewegung in der Lunge stattfindet, kann die Arznei sich besser absetzen und aufgenommen werden.
<G-vec00308-002-s393><settle.absetzen><en> The logic is simple: when there’s no air moving in the lungs, there’s more time for the medicine to settle and absorb.
<G-vec00308-002-s394><settle.absetzen><de> In dem Raum, wo die Wände nicht ausreichend getrocknet sind, wird sich der Pilz absetzen.
<G-vec00308-002-s394><settle.absetzen><en> In the room, where the walls are not sufficiently dried, the fungus will settle.
<G-vec00308-002-s395><settle.absetzen><de> Deshalb kann sich das nusseigene Öl absetzen.
<G-vec00308-002-s395><settle.absetzen><en> Therefore, the nut settle their own oil.
<G-vec00321-002-s075><drop.absetzen><de> Flughafen abholen oder absetzen (mit dem Auto) auf Anfrage erhältlich.
<G-vec00321-002-s075><drop.absetzen><en> Airport pick up or drop off (by car) available on request.
<G-vec00321-002-s076><drop.absetzen><de> Ihr Urlaub im Gran Hotel Son Net wird gerade erst begonnen haben, wenn Sie Ihr Gepäck in Ihrem Zimmer absetzen.
<G-vec00321-002-s076><drop.absetzen><en> Your holiday at the Gran Hotel Son Net will have only just begun once you drop off your luggage at reception.
<G-vec00321-002-s077><drop.absetzen><de> Erfahre, wie du Fahrgäste am Flughafen EWR abholen und absetzen kannst.
<G-vec00321-002-s077><drop.absetzen><en> Learn how to pick up and drop off riders at IAH Airport.
<G-vec00321-002-s079><drop.absetzen><de> Danach werden wir dich in einer Gegend absetzen, die vormals als San Francisco Bay Area bekannt war und du wirst dich auf der Jagd nach Archentech begeben.
<G-vec00321-002-s079><drop.absetzen><en> After that, we’ll drop you into the area formerly known as the San Francisco Bay Area and set you loose to hunt for Arktech. Good luck.
<G-vec00321-002-s080><drop.absetzen><de> Klick Sie einfach auf der Schaltfläche " " und dann ziehen und absetzen beliebige Musikdateien oder Wiedergabelisten von Spotify zu Spotify Music Converter.
<G-vec00321-002-s080><drop.absetzen><en> Just click icon and then drag & drop any music or playlist from Spotify to Sidify Music converter.
<G-vec00321-002-s081><drop.absetzen><de> Nicht enthalten: Mahlzeiten, Trinkgeld für den Fahrer, Rückfahrt zu Ihrem Hotel, da wir Sie am Pier 39 absetzen, wo Sie an Bord der Bootstour gehen, Überstunden und andere optionale Aktivitäten oder Angebote.
<G-vec00321-002-s081><drop.absetzen><en> Not included: Meals, driver’s gratuity, and drop off at the hotel is not included as we drop you off at Pier 39 to enjoy your bay cruise trip and then return to your hotel on your own, overtime and optional activities or features.
<G-vec00321-002-s082><drop.absetzen><de> Das Schöne am Abel Tasman Coastal Track ist, dass Sie entscheiden können, welchen Abschnitt des 4 Day Great Walk Sie machen möchten, da Wassertaxis Sie an verschiedenen Stellen des Tracks absetzen und Sie auch wieder abholen können.
<G-vec00321-002-s082><drop.absetzen><en> The beauty of the Abel Tasman Coastal Track is that you can decide which section of the 4 day Great Walk you would like to do, as water taxis can drop you off at different locations on the track, as well as pick you up again.
<G-vec00321-002-s083><drop.absetzen><de> Wir werden Sie an der Küste absetzen, um Ihnen Zeit zu geben, diese charmante alte dalmatinische Stadt zu erkunden.
<G-vec00321-002-s083><drop.absetzen><en> We will drop you off on the waterfront to give you time for exploring this charming old Dalmatian town.
<G-vec00321-002-s084><drop.absetzen><de> In unserem SYD-Guide für Fahrer erfährst du, wie du Fahrgäste am Flughafen abholen und absetzen kannst.
<G-vec00321-002-s084><drop.absetzen><en> Driving with Uber at SBA Airport Learn how to pick up and drop off riders at SBA Airport.
<G-vec00321-002-s085><drop.absetzen><de> Die Option billigere und bequemere ist, den Greenline-757-Dienst zu fangen, der Sie an der Bahnstation Finchley Road absetzen wird.
<G-vec00321-002-s085><drop.absetzen><en> The cheaper and more convenient option is to catch the Greenline 757 service which will drop you off at Finchley Road tube station.
<G-vec00321-002-s086><drop.absetzen><de> Positiv: Schnell und einfach absetzen.
<G-vec00321-002-s086><drop.absetzen><en> Pros: Painless and easy drop off.
<G-vec00321-002-s087><drop.absetzen><de> An den Messehallen erhalten Sie von unserem Personal Instruktionen wo Sie halten und Ihre Passagiere absetzen können.
<G-vec00321-002-s087><drop.absetzen><en> Once you arrive at the exhibition halls our staff will point out where you can stop to drop off your passengers.
<G-vec00321-002-s089><drop.absetzen><de> Ein Bus nach New Haven wird Sie an der Station Union Ave absetzen.
<G-vec00321-002-s089><drop.absetzen><en> A bus ride to New Haven will drop you off at Union Ave.
<G-vec00321-002-s090><drop.absetzen><de> * Der Explorer kann Satelliten absetzen.
<G-vec00321-002-s090><drop.absetzen><en> * Can drop satellites.
<G-vec00321-002-s091><drop.absetzen><de> Inklusive: Abholung und Absetzen in Reykjavík, Tour um den Goldenen Kreis, Hochland-Abenteuer im Super Jeep, Hotelzimmer mit eigenem Badezimmer - 2 Nächte, 2 Abendessen, 2 Frühstücke und 1 Mittagessen, Schneemobil-Fahrt, Helm und Anzug, Schneeschuhe/Wanderstöcke, Minibus-Tour zur Geheimen Lagune und Eintritt zur Geheimen Lagune.
<G-vec00321-002-s091><drop.absetzen><en> Included: Pick up and drop off at hotels in Reykjavik, super jeep tour, accommodation in mountain huts and a farm, in sleeping bags (sleeping bag included), meals from dinner on Day 1 to breakfast on Day 5. Optional: We offer an exciting snowmobiling tour on Langjokull glacier as an optional extra
<G-vec00321-002-s092><drop.absetzen><de> Benutzer können ihre Kleidung im locke absetzen und jederzeit aufheben, nachdem sie gesäubert haben.
<G-vec00321-002-s092><drop.absetzen><en> Users can drop off their clothes in the locke and pick up anytime after cleaning.
<G-vec00321-002-s093><drop.absetzen><de> Für Multitasking im Alltag, ziehen Sie die Pods von der Tasche aus und befestigen sie auf dem Griff der Kinderwagen, oder absetzen sie im Kindergarten.
<G-vec00321-002-s093><drop.absetzen><en> For everyday multi-tasking simply remove the pods from the main bag and attach onto any stroller, or drop off at nursery.
<G-vec00376-002-s035><discontinue.absetzen><de> Die Medikamente konnte ich auch absetzen.
<G-vec00376-002-s035><discontinue.absetzen><en> I have also been able to discontinue my medication.
<G-vec00376-002-s036><discontinue.absetzen><de> Absetzen der Behandlung.
<G-vec00376-002-s036><discontinue.absetzen><en> Discontinue treatment.
<G-vec00595-002-s052><detach.absetzen><de> Sie sind darauf ausgelegt, in weniger als zwei Sekunden auf- oder abgesetzt zu werden.
<G-vec00595-002-s052><detach.absetzen><en> They’re designed to attach or detach in less than two seconds.
