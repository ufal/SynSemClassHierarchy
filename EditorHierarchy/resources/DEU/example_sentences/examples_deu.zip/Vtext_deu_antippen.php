<G-vec00728-002-s019><tap.antippen><de> Sie können auch eines der Länder antippen, die dargestellt sind.
<G-vec00728-002-s019><tap.antippen><en> You can also tap on any of the countries displayed.
<G-vec00728-002-s020><tap.antippen><de> Ein kurzes Antippen genügt und die Verdeckbewegung wird automatisch ausgeführt.
<G-vec00728-002-s020><tap.antippen><en> Instead, a quick tap is sufficient and the top movement is carried out automatically.
<G-vec00728-002-s021><tap.antippen><de> Den Namen von diesem Zoom Room antippen.
<G-vec00728-002-s021><tap.antippen><en> Tap the name of this Zoom Room.
<G-vec00728-002-s022><tap.antippen><de> Sie können den Sticker rotieren, vergrößern oder verkleinern, bewegen und antippen, um andere Stile auszuprobieren.
<G-vec00728-002-s022><tap.antippen><en> You can rotate, scale, move the sticker, and tap it to explore other styles
<G-vec00728-002-s023><tap.antippen><de> In unserer modernen Welt des Komforts und der Auswahl sind viele Dinge unseres alltäglichen Lebens auf Knopfdruck oder durch Antippen eines Bildschirms verfügbar.
<G-vec00728-002-s023><tap.antippen><en> In our modern world of convenience and choice, so many of the things we take for granted are available at the push of a button or the tap of a screen.
<G-vec00728-002-s024><tap.antippen><de> Zurückkehrend zum Schritt Sa7: Wenn festgestellt wird, daß die antippte Stelle sich auch nicht in der Zone für den Einfach-X-Modus befindet, so bedeutet dies, daß es sich bei dem Antippen um das konventionell ausgebildete Antippen entsprechend dem Anklicken mit der linken Taste LB handelt.
<G-vec00728-002-s024><tap.antippen><en> Returning to step Sa7: If it is determined that the tapped position not located in the zone for the single-X mode, this means that it is at the tapping to the conventionally trained tap corresponding to the click with the left button LB is.
<G-vec00728-002-s025><tap.antippen><de> Um etwa das Antippen einer Karte zu simulieren, wählen Sie die Option Antippen aus.
<G-vec00728-002-s025><tap.antippen><en> For example, to simulate a tapping card experience, select Tap.
<G-vec00728-002-s026><tap.antippen><de> Durch einfaches Antippen eines Lebensmittels öffnet sich eine detaillierte Produktansicht.
<G-vec00728-002-s026><tap.antippen><en> A simple tap on a product opens a detailed product view.
<G-vec00728-002-s027><tap.antippen><de> Die Anschlagsgeschwindigkeit, mit der Sie die Kontrollen des Geräts antippen, bestimmt die Lautstärke der von Ihnen gespielten Note.
<G-vec00728-002-s027><tap.antippen><en> The velocity at which you tap the device controls the volume of the note you're playing.
<G-vec00728-002-s028><tap.antippen><de> Es genügt ein kurzes Antippen und die Dachbewegung wird automatisch ausgeführt.
<G-vec00728-002-s028><tap.antippen><en> Just a short tap and the movement of the top is executed automatically.
<G-vec00728-002-s029><tap.antippen><de> • Schützen Sie sich – Einmal antippen und schon schützt Opera Max Ihre Hotspot-Verbindung in einem öffentlichen WLAN durch Datenverschlüsselung und Abwehr von Datenspionen.
<G-vec00728-002-s029><tap.antippen><en> • Protect yourself - With a single tap, Opera Max secures your connection on public Wi-Fi hotspots, encrypting your data and keeping you safe from data spies.
<G-vec00728-002-s030><tap.antippen><de> Wenn Sie ein Hotel antippen, dann stehen Ihnen diverse Fotos der Unterkunft und eine Vielzahl von Informationen zu Ausstattung und Lage sowie die Bewertungen anderer Reisender zur Verfügung.
<G-vec00728-002-s030><tap.antippen><en> If you tap on a Hotel, then several pictures of the accommodation, and a variety of information on facilities and location, as well as the reviews of other travellers are available to you.
<G-vec00728-002-s031><tap.antippen><de> Verwendung der Werkzeugleiste Antippen, um Werkzeugleiste zu öffnen.
<G-vec00728-002-s031><tap.antippen><en> Using the toolbar Tap to open the toolbar.
<G-vec00728-002-s032><tap.antippen><de> Wenn Sie mit Ihrer Maus über solch ein Wort fahren oder es auf Ihrem Mobilgerät antippen, werden Ihnen alle möglichen Aussprachemöglichkeiten angezeigt.
<G-vec00728-002-s032><tap.antippen><en> If you hover your cursor over such word or tap it on your mobile device, you will see all the possible pronunciations.
<G-vec00728-002-s033><tap.antippen><de> Bei zweimaligem Antippen zeigen die Leuchtpunkte des Activity Crystals die Uhrzeit und den sportliche Fortschritt an.
<G-vec00728-002-s033><tap.antippen><en> With a simple double tap, the Activity Crystal lights up to indicate the time and status of activity accomplished.
<G-vec00728-002-s034><tap.antippen><de> Du kannst das "Galerie"-Menü oben auf dem Bildschirm antippen, um einen anderen Ort auf deinem Gerät auszuwählen und dort nach Bildern zu suchen.
<G-vec00728-002-s034><tap.antippen><en> You can tap the "Gallery" menu at the top of the screen to select another location on your device to look for images.
<G-vec00728-002-s035><tap.antippen><de> Einfach antippen, um Dokumente zu drucken, zu scannen oder zu faxen – die moderne NFC-Technologie macht dies von jedem unterstützten Mobilgerät aus möglich.
<G-vec00728-002-s035><tap.antippen><en> Simply tap to print, scan or fax documents with advanced NFC technology from any supported mobile device.
<G-vec00728-002-s036><tap.antippen><de> Antippen, um einen neuen Termin zu erstellen.
<G-vec00728-002-s036><tap.antippen><en> Tap to create a new appointment.
<G-vec00728-002-s037><tap.antippen><de> Es verschwindet dann nicht von alleine, sondern erst beim Antippen, nochmaligem Betätigen des Log-Knopfs oder Wechseln der Ansicht.
<G-vec00728-002-s037><tap.antippen><en> Then it does not disappear automatically but only when you tap it, use the Log button once again, or change to another view.
