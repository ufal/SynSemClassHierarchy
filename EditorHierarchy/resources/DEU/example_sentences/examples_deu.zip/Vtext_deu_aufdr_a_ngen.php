<G-vec00743-002-s038><impose.aufdrängen><de> Leider bewirkt ein Hineinpressen in die Verbraucherrolle seitens der Wirtschaft und der gesellschaftlichen Systeme das Aufdrängen künstlicher Bedürfnisse, die stets zunehmen und in der Psyche Chaos und Verlorenheit stiften.
<G-vec00743-002-s038><impose.aufdrängen><en> Unfortunately, the Economy and social systems force him into the role of consumer, impose artificial needs, which increase in number, and that brings chaos and confusion in the psyche.
<G-vec00743-002-s039><impose.aufdrängen><de> Stattdessen wollte ich ihr meine Meinung aufdrängen.
<G-vec00743-002-s039><impose.aufdrängen><en> Instead, I wanted to impose my opinion on her.
<G-vec00743-002-s040><impose.aufdrängen><de> Er ließ sich treiben, ohne getrieben zu sein, und erliegt seit Jahren der Lust an der Vieldeutigkeit sichtbarer Rätsel, die sich ihm aufdrängen.
<G-vec00743-002-s040><impose.aufdrängen><en> He let himself drift, without being driven, and succumbs since some years to the lust in the ambiguity of visible mysteries that impose on him.
<G-vec00743-002-s041><impose.aufdrängen><de> Aber auch dem Auge bietet die Form Halt und aktiviert Raumteile, die sich dem Auge sonst weniger aufdrängen.
<G-vec00743-002-s041><impose.aufdrängen><en> But the form also affords the eye a pause, activating parts of the space that otherwise do not impose themselves on the eye.
<G-vec00743-002-s042><impose.aufdrängen><de> Die neue Ordnung will sich nicht aufdrängen und als endgültige Verabschiedung der Kontinuität behaupten.
<G-vec00743-002-s042><impose.aufdrängen><en> The new order does not impose and assert itself as an ultimate departure from continuity.
<G-vec00743-002-s043><impose.aufdrängen><de> So hört man allzuoft in den verschiedensten Formen sagen: Eine Wahrheit auferlegen, und sei es die des Evangeliums, einen Weg aufdrängen, sei es der zum Heile, ist nichts anderes als eine Vergewaltigung der religiösen Freiheit.
<G-vec00743-002-s043><impose.aufdrängen><en> Thus one too frequently hears it said, in various terms, that to impose a truth, be it that of the Gospel, or to impose a way, be it that of salvation, cannot but be a violation of religious liberty.
<G-vec00743-002-s044><impose.aufdrängen><de> Suizidgedanken und Todeswünschen, insbesondere wenn sie sich dem Patienten aufdrängen, kommt eine große Bedeutung zu.
<G-vec00743-002-s044><impose.aufdrängen><en> Suicidal thoughts and desire for death, especially when they impose themselves upon the patient, take on a great significance.
<G-vec00743-002-s045><impose.aufdrängen><de> Die Saint-Rémy Kollektion steht für schlichte Automatikuhren, die sich in Deinem Alltag nicht aufdrängen, sondern sich perfekt an das Outfit und die Situation anpassen.
<G-vec00743-002-s045><impose.aufdrängen><en> It stands for unpretentious automatic watches that don’t impose themselves on your everyday life, but adapt perfectly to your outfit and situation.
<G-vec00743-002-s046><impose.aufdrängen><de> Statt nach Selbstverwirklichung (= ich wirke / handele) zu streben, streben wir nach Selbstbehauptung (= ich behaupte mich gegen andere Menschen) - statt unsere Lebensziele selbst zu stecken, lassen wir uns von außen falsche Ziele aufdrängen.
<G-vec00743-002-s046><impose.aufdrängen><en> Instead of striving for self-realization, we strive for self-assertion - take our life goals to put themselves, we allow ourselves to impose from the outside false targets.
<G-vec00833-002-s011><huddle.aufdrängen><de> Sollte sich bei der Suche nach dem besten Online Casinos 2015 ein solcher Eindruck auch nur im Ansatz aufdrängen, ist der jeweilige Betreiber lieber zu meiden.
<G-vec00833-002-s011><huddle.aufdrängen><en> The respective operator is should find the according to the best online casinos 2015 a such impression even in the huddle up, prefer to avoid.
