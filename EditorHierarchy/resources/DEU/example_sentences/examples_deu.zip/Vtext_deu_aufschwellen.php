<G-vec00298-002-s097><swell.aufschwellen><de> Apostelgeschichte 28/6 Sie aber erwarteten, daß er aufschwellen oder plötzlich tot hinfallen würde.
<G-vec00298-002-s097><swell.aufschwellen><en> 28:6 But they were expecting that he was about to swell up or to suddenly fall down dead.
