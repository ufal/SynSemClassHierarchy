<G-vec00684-002-s033><scour.abklappern><de> Täglich klappern Martina und René das Internet ab.
<G-vec00684-002-s033><scour.abklappern><en> Martina and René scour the Internet daily.
