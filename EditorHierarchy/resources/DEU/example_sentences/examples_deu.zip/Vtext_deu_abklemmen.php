<G-vec00652-002-s019><disconnect.abklemmen><de> Prüfung: Die Batterie abklemmen und versuchen, sie ohne angeschlossene Verbraucher zu laden.
<G-vec00652-002-s019><disconnect.abklemmen><en> Test: Disconnect the battery and try to charge it without the loads.
<G-vec00652-002-s020><disconnect.abklemmen><de> Das Telefon gibt einen Alarmton aus und generiert eine Benachrichtigung, um Sie daran zu erinnern, dass Sie das Kabel vor Fahrtantritt abklemmen sollten.
<G-vec00652-002-s020><disconnect.abklemmen><en> The phone will give emit an alarm sound and generate a notification to remind you that you should disconnect the cable before you start driving.
<G-vec00652-002-s021><disconnect.abklemmen><de> Diese würde sonst als (auch nur kurzzeitiger) Spannungseinbruch im Lastkreis die zu testende Lastkomponente beeinflussen oder sogar „abklemmen“.
<G-vec00652-002-s021><disconnect.abklemmen><en> As an (albeit transient) voltage drop in the load circuit, this would influence or even disconnect the load components to the tested.
<G-vec00652-002-s022><disconnect.abklemmen><de> Prüfung: Verbraucher während des Ladevorgangs ausschalten oder abklemmen.
<G-vec00652-002-s022><disconnect.abklemmen><en> Test: Turn off or disconnect the loads when charging.
<G-vec00652-002-s059><unplug.abklemmen><de> Also setz dich bequem hin, schalte dein Handy aus, klemm die Türklingel ab und lass uns auf die Welle sexueller Energie segeln, die wir für dich vorbereitet haben.
<G-vec00652-002-s059><unplug.abklemmen><en> So just sit down comfortably, turn off your phone, unplug the door bell and let’s sail on the wave of sexual energy we prepared for you here.
