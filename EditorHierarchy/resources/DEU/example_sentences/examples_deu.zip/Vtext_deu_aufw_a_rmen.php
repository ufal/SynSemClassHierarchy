<G-vec01064-002-s019><warm.aufwärmen><de> Bei milderem / trockenem Wetter ist das alles, was Sie zum Aufwärmen Ihres Oberkörpers benötigen.
<G-vec01064-002-s019><warm.aufwärmen><en> Only what you need to warm your core in milder/drier weather.
<G-vec01064-002-s020><warm.aufwärmen><de> Und nach der Tour können Sie sich bei einem guten Gläschen aufwärmen: Jeder Besucher darf Slanes unnachahmlichen Blended Whiskey probieren, der durch die Reifung in drei Fässern – Virgin Oak, Seasoned und Sherry – sein einzigartiges Aroma bekommt.
<G-vec01064-002-s020><warm.aufwärmen><en> And once the tour ends, there’s the chance to warm up with a quick tipple: each visitor gets to sample Slane’s signature triple-casked blend whiskey, uniquely flavoured by its mix of virgin, seasoned and sherry casks. Top tips
<G-vec01064-002-s021><warm.aufwärmen><de> Wir können uns im ruhigen Hafen aufwärmen, sodass wir uns nicht sofort in den großen Wellen befinden.
<G-vec01064-002-s021><warm.aufwärmen><en> We can warm up in the quiet harbor so we do not find ourselves in the big waves immediately.
<G-vec01064-002-s022><warm.aufwärmen><de> Mit dieser Trainingsjacke für Jungs kannst du dich aufwärmen, ohne zu sehr ins Schwitzen zu geraten.
<G-vec01064-002-s022><warm.aufwärmen><en> This training jacket for junior boys helps you warm up without overheating.
<G-vec01064-002-s023><warm.aufwärmen><de> Darüber hinaus wird durch das Aufwärmen das Verletzungsrisiko minimiert.
<G-vec01064-002-s023><warm.aufwärmen><en> Moreover, the warm up routine, reduce the risk of injuries.
<G-vec01064-002-s024><warm.aufwärmen><de> Auch wenn ich die leckere Mahlzeit hier und heute erst einmal gedanklich (wieder) aufwärmen muss.
<G-vec01064-002-s024><warm.aufwärmen><en> Even though i have to warm up the delicious dish here today (at least mentally).
<G-vec01064-002-s025><warm.aufwärmen><de> Zuerst werden wir uns bei kreativen und musikalischen Workshops aufwärmen.
<G-vec01064-002-s025><warm.aufwärmen><en> First, you will warm up in creative and musical workshops.
<G-vec01064-002-s026><warm.aufwärmen><de> Gewebe tief und gleichmäßig aufwärmen, beschleunigen die Stoffwechselvorgänge in den Zellen, glätten das Relief und fördern auch die Zerstörung der Lipide.
<G-vec01064-002-s026><warm.aufwärmen><en> Fabrics deep and uniformly warm up, speeding up the metabolic processes in the cells, smoothing the relief, and also stimulating the destruction of lipids.
<G-vec01064-002-s027><warm.aufwärmen><de> Dann sollte man nach dem Kühler das Gas um mindestens 9°C aufwärmen.
<G-vec01064-002-s027><warm.aufwärmen><en> Then you should warm up the gas by at least 9 ° C after the cooler.
<G-vec01064-002-s028><warm.aufwärmen><de> 10 Minuten mobilisieren und aufwärmen.
<G-vec01064-002-s028><warm.aufwärmen><en> 10 minutes mobilise and warm up.
<G-vec01064-002-s029><warm.aufwärmen><de> Der Pool war ein wenig kalt im Dezember, aber mit der Sauna können Sie wieder aufwärmen.
<G-vec01064-002-s029><warm.aufwärmen><en> The swimming pool was a little bit cold in December, but with the sauna you can warm up again.
<G-vec01064-002-s030><warm.aufwärmen><de> Jedoch sollte man das Ganze trotzdem nicht unterschätzen und sich im Vorfeld ordentlich aufwärmen.
<G-vec01064-002-s030><warm.aufwärmen><en> However one should not underestimate the whole nevertheless and warm oneself up in the apron properly.
<G-vec01064-002-s031><warm.aufwärmen><de> Angekommen beim Bergrestaurant lädt die warme Stube zum aufwärmen und schlemmen ein.
<G-vec01064-002-s031><warm.aufwärmen><en> The mountain restaurant’s cosy dining room is a wonderful place to warm up and tuck into something delicious.
<G-vec01064-002-s032><warm.aufwärmen><de> »Hier werden wir uns erst einmal wieder aufwärmen können«, sagte der Fuchs, während er damit begann, eine Stelle des Bodens in der Nähe vom Stroh zu befreien.
<G-vec01064-002-s032><warm.aufwärmen><en> »We can warm ourselves up a bit here,« the fox said while he started to remove the straw from a spot on the floor nearby.
<G-vec01064-002-s033><warm.aufwärmen><de> Im Winter dürfen sie sich auf den urigen Bänken in der Märchenhütte aufwärmen, lachen und gruseln.
<G-vec01064-002-s033><warm.aufwärmen><en> In winter, they can enjoy the funny – but scary – shows on the warm and comfy benches of the fairytale cottages.
<G-vec01064-002-s034><warm.aufwärmen><de> Das Aufwärmen am Land vor dem Start wird ebenfalls empfohlen.
<G-vec01064-002-s034><warm.aufwärmen><en> The warm up on land is recommended.
<G-vec01064-002-s035><warm.aufwärmen><de> Wenn du mein Wasser ein bisschen aufwärmen möchtest, dann denk doch über das Spenden/Sponsoren nach.
<G-vec01064-002-s035><warm.aufwärmen><en> If you want to warm up my water a bit, think about donating something/sponsoring me.
<G-vec01064-002-s036><warm.aufwärmen><de> Russland ist berühmt für seine kalten Winter und seine steifen Drinks, die den Magen aufwärmen und die Nerven festigen.
<G-vec01064-002-s036><warm.aufwärmen><en> Russia is famous for its cold winters and stiff drinks that warm the belly and calm the nerves.
<G-vec01064-002-s037><warm.aufwärmen><de> Sie genießen außerdem ein Drei-Gänge-Ferienbrunch-Menü und können sich sogar an der heißen Schokolade an Bord aufwärmen.
<G-vec01064-002-s037><warm.aufwärmen><en> You’ll also enjoy a three-course holiday brunch menu, and can even warm up courtesy of the on-board hot chocolate bar.
<G-vec01064-002-s038><warm.aufwärmen><de> 1 Diese Heißluft-Nachbearbeitungsstation verwendet eine Heizvorrichtung, um Luft aufzuwärmen, die zum Schweißen verwendet werden kann.
<G-vec01064-002-s038><warm.aufwärmen><en> 1 This hot air rework station uses heating device to warm up air which can be used to weld.
<G-vec01064-002-s039><warm.aufwärmen><de> Es ist aber auch notwendig, die Muttermilch richtig aufzuwärmen, um den Verlust der vorteilhaften Eigenschaften zu verhindern.
<G-vec01064-002-s039><warm.aufwärmen><en> But to warm up breast milk, too, must be properly, to prevent the loss of useful properties.
<G-vec01064-002-s040><warm.aufwärmen><de> Es gibt die Möglichkeit sich im Schwimmbad von Remich aufzuwärmen.
<G-vec01064-002-s040><warm.aufwärmen><en> Yes, you can warm up in the water in a defined area.
<G-vec01064-002-s041><warm.aufwärmen><de> Diejenigen, die sie vor mir trafen, erzählten mir, wie sie in diesem Bauernhaus voller Tiere und Land arbeitete, das kultiviert werden sollte, wie sie sich um ihre Tiere kümmerte..... mit den Küken in der Tasche durch das Haus laufen, um sie an kalten Tagen aufzuwärmen.
<G-vec01064-002-s041><warm.aufwärmen><en> Those who met her before me told me about how she worked in that farmhouse full of animals and land to be cultivated, how she took care of her beasts... walking around the house with the chicks in his pocket to warm them up on cold days.
<G-vec01064-002-s042><warm.aufwärmen><de> Es hilft, Ihre Haut aufzuwärmen und ermöglicht eine schnellere Aufnahme der Formel.
<G-vec01064-002-s042><warm.aufwärmen><en> It helps warm up your skin and allow faster absorption of the formula.
<G-vec01064-002-s043><warm.aufwärmen><de> Achtet immer darauf, Euch vor dem Tanzen aufzuwärmen und geht nicht über Eure Grenzen.
<G-vec01064-002-s043><warm.aufwärmen><en> Always make sure to warm up before the dances and do not go beyond your limits.
<G-vec01064-002-s044><warm.aufwärmen><de> Diese Cam Boys verwenden Vibratoren, Dildos und Analkugeln, wenn sie alleine sind, um ihr Poloch aufzuwärmen und es so weit zu dehnen, dass es das riesige Sexspielzeug aufnehmen kann.
<G-vec01064-002-s044><warm.aufwärmen><en> These cam boys will use vibrators, bum plugs, and anal beads if they’re alone to warm up their bum hole and get it stretched enough to take the giant sex toy.
<G-vec01064-002-s045><warm.aufwärmen><de> Mit etwas Glück könntest Du von einem besonderen Auftritt von Bob Sinclar, Hot Since 82 oder Timo Maas überrascht werden, die vielleicht einfach vorbeikommen um Deine Nacht aufzuwärmen.
<G-vec01064-002-s045><warm.aufwärmen><en> Expect special appearances from the likes of Bob Sinclair, Hot Since 82, or Timo Maas, who might just drop by to warm up your night.
<G-vec01064-002-s046><warm.aufwärmen><de> Fern von den großen Städten, unter unberührter Natur ist es angenehm, in die warmen Quellen einzutauchen, ein klassisches russisches Bad zu probieren und sich in den Bottichen mit Mineralwasser aufzuwärmen.
<G-vec01064-002-s046><warm.aufwärmen><en> It is pleasant to plunge into warm springs, try classic Russian banya and warm up in vats with mineral water far from large cities, among untouched nature.
<G-vec01064-002-s047><warm.aufwärmen><de> Hauseigene Sauna und Solarium laden ein, sich nach dem Winterspaziergang aufzuwärmen und so richtig zu entspannen.
<G-vec01064-002-s047><warm.aufwärmen><en> In-house sauna facility and solarium invite you to warm up after a winter walk and fully unwind yourself.
<G-vec01064-002-s048><warm.aufwärmen><de> Und um sich beim Aufstehen aufzuwärmen, sind die Bademäntel und Morgenröcke aus Samt oder Fleece genauso kuschelig weich wie die Kuscheltiere...
<G-vec01064-002-s048><warm.aufwärmen><en> And to warm up once out of bed, fleece or velvet bathrobes that are as plush as cuddly teddy bears... Now...
<G-vec01064-002-s049><warm.aufwärmen><de> Tipps zu dieser Anlage: eventuell kann es von Vorteil sein auch die Kessel etwas aufzuwärmen.
<G-vec01064-002-s049><warm.aufwärmen><en> Tips for using this still: it could be an advantage to warm up the boiler a little.
<G-vec01064-002-s050><warm.aufwärmen><de> Falls das Wasser vor Ablauf der 20 Minuten abgekühlt ist, füge heißes Wasser hinzu, um es aufzuwärmen, oder ersetze es durch eine frische Schüssel.
<G-vec01064-002-s050><warm.aufwärmen><en> If the water cools down before 20 minutes, add hot water to warm it up or replace it with a fresh bowl.
<G-vec01064-002-s051><warm.aufwärmen><de> Das Dehnen vor und nach einem Training ist eine großartige Möglichkeit, deinen Körper aufzuwärmen und den Erholungsprozess nach dem Training zu beschleunigen.
<G-vec01064-002-s051><warm.aufwärmen><en> Stretching Stretching before and after a workout is a great way to warm your body up and accelerate the post-workout recovery process.
<G-vec01064-002-s052><warm.aufwärmen><de> Der Körper muss arbeiten, um das Wasser aufzuwärmen und verbrennt dabei ein paar zusätzliche Kalorien.
<G-vec01064-002-s052><warm.aufwärmen><en> Your body must work to warm the water up, burning a few extra calories in the process.
<G-vec01064-002-s053><warm.aufwärmen><de> Es ist schlau, deine Muskeln aufzuwärmen, bevor du mit dem Hochspringen beginnst.
<G-vec01064-002-s053><warm.aufwärmen><en> It is wise to warm up your muscles before attempting the high jump.
<G-vec01064-002-s054><warm.aufwärmen><de> Es lässt dich entspannter auf äußere Einflüsse reagieren und bietet dir die Möglichkeit dich vollständig und schonend aufzuwärmen, sowie hinterher aktiv zu regenerieren.
<G-vec01064-002-s054><warm.aufwärmen><en> It allows you to react more relaxed to external influences and offers you the possibility to warm up completely and gently as well as to regenerate actively afterwards.
<G-vec01064-002-s055><warm.aufwärmen><de> Ein Teil der thermischen Energie wird benutzt, um neues Substrat aufzuwärmen und um die Temperatur im Fermenter beizubehalten.
<G-vec01064-002-s055><warm.aufwärmen><en> Some of the thermal energy will be used to warm up new substrate and to maintain the temperature of the digester.
<G-vec01064-002-s056><warm.aufwärmen><de> Bestaunen Sie das magische Erscheinungsbild von im Schnee glitzernden Hügeln, spüren Sie, wie sich Ihre Lungen mit klarer Luft füllen und unter Ihren Füßen der Frost knirscht – außerdem ist es eine gute Ausrede dafür, sich im Anschluss mit einer heißen Schokolade wieder aufzuwärmen.
<G-vec01064-002-s056><warm.aufwärmen><en> Enjoy the magical appearance of hills glistening with snow, crisp air filling your lungs and frost crunching underfoot - plus it's a good excuse to warm up with a hot chocolate when you get back to base.
