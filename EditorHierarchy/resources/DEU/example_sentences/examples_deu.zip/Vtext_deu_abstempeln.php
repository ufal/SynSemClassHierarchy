<G-vec00858-002-s019><postmark.abstempeln><de> Beim Sonderpostamt wird eine Briefmarke entweder mit dem offiziellen Ersttags-Sonderstempel der Post abgestempelt oder, bei anderen Anlässen, mit dem passenden Sonderstempel des Veranstalters.
<G-vec00858-002-s019><postmark.abstempeln><en> At special post offices, stamps are either cancelled with the official first-day special postmark by Austrian Post or, on special occasions, the matching special postmark provided by the event organiser.
<G-vec00858-002-s024><stamp.abstempeln><de> Wenn Sie von dieser Ermäßigung profitieren möchten, lassen Sie sich bitte an der Rezeption Ihre Parkkarte abstempeln.
<G-vec00858-002-s024><stamp.abstempeln><en> Guests wishing to benefit from this discount should ask the hotel reception to stamp their parking pass.
<G-vec00858-002-s025><stamp.abstempeln><de> Für sportlich ambitionierte Wanderer ist die Grödner Wandernadel "Cristal d'Or" ein Muss: Hierzu holt man sich in den Grödner Tourismusvereinen einen Wanderpass und lässt diesen in den Schutzhütten, die man auf seinen Wegen besucht, abstempeln.
<G-vec00858-002-s025><stamp.abstempeln><en> Ambitious hikers should aim for "Cristal d'Or": Get a hiking pass at the tourist office and stamp it at every hut on the way.
<G-vec00858-002-s026><stamp.abstempeln><de> Lassen Sie Ihre Bewerbung von Ihrem ERASMUS-Koordinator an Ihrer Heimathochschule unterzeichnen und abstempeln.
<G-vec00858-002-s026><stamp.abstempeln><en> Your ERASMUS coordinator at your university has to sign and stamp the nomination/application form as well.
<G-vec00858-002-s027><stamp.abstempeln><de> Der Controller ist bestimmt nicht per se, der Erbsenzähler, als den wir ihn oftmals abstempeln.
<G-vec00858-002-s027><stamp.abstempeln><en> The controller doesn’t think of himself as the bean counters we often stamp him.
<G-vec00858-002-s028><stamp.abstempeln><de> Bei der Ausreise zeigen Sie dem Zoll an der EU-Außengrenze Ihren Einkauf und lassen sich das Tax-Free-Formular mit dem Ausreisezollstempel abstempeln.
<G-vec00858-002-s028><stamp.abstempeln><en> When departing the EU, show your purchase to the customs official at the border and have your tax-free form stamped with the outbound customs stamp.
