<G-vec00279-003-s020><drown_out.ausblenden><de> Diese Lichtschaustellungen sind sichtbar für den Menschen, wo der Glanz des Sonnenlichtes sie nicht ausblendet, da das Auge die überwältigende Teilchennatur der Lichtflut bemerkt, die unwesentliche Teilchen ablegt, die bei so viel Verzerrung anwesend sein könnten.
<G-vec00279-003-s020><drown_out.ausblenden><en> These light displays are visible to humans where the glare of sunlight does not drown them out, as the eye registers the overwhelming particle nature of the light flood, discarding minor particles that might be present as so much noise.
<G-vec00460-002-s030><disregard.ausblenden><de> Sie eignet sich für Anleger, die einen langfristigen Horizont von mehr als fünf Jahren haben und bereit sind, kurzfristige Marktschwankungen auszublenden.
<G-vec00460-002-s030><disregard.ausblenden><en> It is suitable for investors with a long investment horizon, exceeding five years, and a willingness to disregard short-term market fluctuations.
<G-vec00514-002-s115><hide.ausblenden><de> Zusätzlich ist es nun möglich Produkte ein- und auszublenden.
<G-vec00514-002-s115><hide.ausblenden><en> In addition, it is now possible to show and hide products.
<G-vec00514-002-s116><hide.ausblenden><de> Um die Bedienoberfläche des Effekt Plug-ins ein- und auszublenden, klicken Sie auf den Namen des Effekts in der Audio-Insert-Effekte Leiste.
<G-vec00514-002-s116><hide.ausblenden><en> To show or hide the effect plug-in's GUI, click on its name in the Audio Inserts rack once.
<G-vec00514-002-s117><hide.ausblenden><de> Klicken Sie auf Gitternetzlinien anzeigen, um die Gitterlinien der Tabelle ein- oder auszublenden.
<G-vec00514-002-s117><hide.ausblenden><en> Click Show Grid Lines to show or hide table grid lines.
<G-vec00514-002-s118><hide.ausblenden><de> Um den Bereich manuell ein- oder auszublenden, klicken Sie in der Aufgabenleiste auf das Symbol „Fotobereich“.
<G-vec00514-002-s118><hide.ausblenden><en> To manually show or hide the bin, click the Photo Bin taskbar icon.
<G-vec00514-002-s119><hide.ausblenden><de> Klicken Sie auf das Erweiterungssymbol (>) auf der linken Seite, um die Inhaltsebenen ein- oder auszublenden.
<G-vec00514-002-s119><hide.ausblenden><en> Click the expander icon (>) on the left side to show or hide the content levels as needed.
<G-vec00514-002-s120><hide.ausblenden><de> Lassen Sie das Feld leer, um alle Kategorien ein- oder auszublenden.
<G-vec00514-002-s120><hide.ausblenden><en> Leave blank to show or hide all categories. Remarks
<G-vec00514-002-s121><hide.ausblenden><de> Klicken Sie auf die Erweitern/Reduzieren-Symbole links von der Klasse, um Eigenschaften und Operationen ein- oder auszublenden.
<G-vec00514-002-s121><hide.ausblenden><en> Click the collapse/expand icons to the left of the class to show or hide properties and operations.
<G-vec00514-002-s122><hide.ausblenden><de> „Schrift“ > „Alter Text“ > „Kopien einblenden“ oder „Kopien ausblenden“, um die kopierten Textobjekte ein- oder auszublenden.
<G-vec00514-002-s122><hide.ausblenden><en> Type > Legacy Text > Show Copies or Hide Copies to show or hide the copied text objects.
<G-vec00514-002-s123><hide.ausblenden><de> Verwenden Sie zum Ändern der in Ihrem Diagramm angezeigten Daten Diagrammfilter, um Datenreihen ein- oder auszublenden.
<G-vec00514-002-s123><hide.ausblenden><en> To change the data that’s shown in your chart, use chart filters to show or hide data series.
<G-vec00514-002-s124><hide.ausblenden><de> Der Befehl Raster gibt Ihnen die Möglichkeit, die Rasterlinien ein- und auszublenden.
<G-vec00514-002-s124><hide.ausblenden><en> The Grid command allows you to show or hide the grid.
<G-vec00514-002-s125><hide.ausblenden><de> Bitte folgen Sie den Anweisungen unten, um die Liste der Moderatoren unten auf der Seite einer Kategorie ein- oder auszublenden.
<G-vec00514-002-s125><hide.ausblenden><en> Please follow the directions mentioned below to show or hide the list of moderators at the bottom of a category's page.
<G-vec00514-002-s126><hide.ausblenden><de> Um eine Symbolleiste ein- oder auszublenden, wählen Sie Ansicht > Symbolleisten aus, und aktivieren oder deaktivieren Sie dann die betreffende Symbolleiste.
<G-vec00514-002-s126><hide.ausblenden><en> To show or hide a toolbar, choose View > Toolbars, then select or deselect the toolbar.
<G-vec00514-002-s127><hide.ausblenden><de> Regionen können erweitert und reduziert werden, um Teile von SQL Skripts ein- oder auszublenden.
<G-vec00514-002-s127><hide.ausblenden><en> Regions can be collapsed and expanded to display or hide parts of SQL scripts.
<G-vec00514-002-s128><hide.ausblenden><de> Klicken Sie im Menü Ansicht auf Lineale, um die Lineale ein- oder auszublenden.
<G-vec00514-002-s128><hide.ausblenden><en> On the View menu, click Rulers to show or hide the rulers.
<G-vec00555-002-s060><dismiss.ausblenden><de> Die Mitteilungen werden für einen kurzen Moment oben rechts auf dem Bildschirm eingeblendet oder sie bleiben dort, bis du sie ausblendest.
<G-vec00555-002-s060><dismiss.ausblenden><en> Notifications appear briefly in the top-right corner of the screen or stay there until you dismiss them.
<G-vec00597-002-s025><collapse.ausblenden><de> Tipp: Auf dem Desktop kannst du jedes Bild ausblenden, indem du auf den Abwärtspfeil neben dem Bildtitel klickst oder den Slash-Befehl /collapse eingibst, damit alle Medien in einem Channel ausgeblendet werden.
<G-vec00597-002-s025><collapse.ausblenden><en> Tip: On desktop, you can collapse any image by clicking the down arrow next to the image title, or type the /collapse slash command to collapse all media in a channel. Awesome!
<G-vec00597-002-s026><collapse.ausblenden><de> Sie können jetzt Code ausblenden, indem Sie mit der Maus auf die Zeilennummer zeigen und auf das angezeigte Dreieck klicken.
<G-vec00597-002-s026><collapse.ausblenden><en> You can now collapse code by hovering your mouse over the line number and clicking the triangle that appears.
<G-vec00597-002-s027><collapse.ausblenden><de> Benutzer können Kategorien mit vielen Unterkategorien nach Bedarf ein- und ausblenden.
<G-vec00597-002-s027><collapse.ausblenden><en> Users can also expand and collapse categories which contain many subcategories.
<G-vec00597-002-s028><collapse.ausblenden><de> Zum Ausblenden aller Profilgruppen im Profil-Browser klicken Sie mit der rechten Maustaste (Windows) oder bei gedrückter Ctrl-Taste (Mac) auf eine beliebige Profilgruppe und wählen Sie Alle minimieren im Menü aus.
<G-vec00597-002-s028><collapse.ausblenden><en> To collapse all the profile groups in Profile Browser, right-click (Win) / Control-click (Mac) any profile group and choose Collapse All from the menu.
<G-vec00597-002-s029><collapse.ausblenden><de> Wenn Sie den Timer ausblenden, sehen Sie die Farbänderung nicht.
<G-vec00597-002-s029><collapse.ausblenden><en> If you collapse the timer, you won't see the color changes.
<G-vec00714-002-s019><hide.ausblenden><de> Den Erfahrungsbericht ausblenden - der Beitrag wird auf Ihrem Profil als „ausgeblendet“ veröffentlicht.
<G-vec00714-002-s019><hide.ausblenden><en> Hide the experience – the contribution will be published on your profile as ‘hidden’.
<G-vec00714-002-s020><hide.ausblenden><de> Anzeigen oder Ausblenden.
<G-vec00714-002-s020><hide.ausblenden><en> Show or Hide.
<G-vec00714-002-s021><hide.ausblenden><de> Sie können das Aussehen der Verknüpfungslinien ändern oder die Verknüpfungslinien ausblenden.
<G-vec00714-002-s021><hide.ausblenden><en> You can change the way link lines appear or hide the link lines.
<G-vec00714-002-s022><hide.ausblenden><de> Soll die Lesezeichen-Schaltfläche ausgeblendet werden, nachdem Sie auf ein Lesezeichen geklickt haben, wählen Sie im Optionen-Menü den Eintrag „Nach Verwendung ausblenden“.
<G-vec00714-002-s022><hide.ausblenden><en> If you want to hide the Bookmarks button after you click a bookmark, select Hide After Use from the options menu.
<G-vec00714-002-s023><hide.ausblenden><de> Sie können die Blätter mit den QuickInfo-Visualisierungen auf dieselbe Weise ausblenden wie die Blätter, die in Storys oder auf Dashboards verwendet werden.
<G-vec00714-002-s023><hide.ausblenden><en> You can now hide the sheets used for Viz in Tooltips, the same way you would for sheets used in Stories or Dashboards.
<G-vec00714-002-s024><hide.ausblenden><de> Klicken Sie zum Ausblenden einer Folie mit der rechten Maustaste auf die auszublendende Folie, und klicken Sie dann auf Folie ausblenden.
<G-vec00714-002-s024><hide.ausblenden><en> To hide a slide, right-click the slide that you want to hide, and then click Hide Slide.
<G-vec00714-002-s026><hide.ausblenden><de> Wählen Sie aus der Liste "Leere Ordner ausblenden" oder "Leere Ordner einblenden".
<G-vec00714-002-s026><hide.ausblenden><en> Select "Hide empty folders" or "Show empty folders" from the list.
<G-vec00714-002-s027><hide.ausblenden><de> Die vorinstallierten Einstellungen sind für die meisten Fälle ausreichend, also wir können die Optionen einfach ausblenden und fortfahren.
<G-vec00714-002-s027><hide.ausblenden><en> The default settings are good for the most cases so you may simply hide the options and continue.
<G-vec00714-002-s028><hide.ausblenden><de> Wir können uns im Modell bewegen, Elemente ausblenden und Bereiche innerhalb von Höhenparametern vereinfachen.
<G-vec00714-002-s028><hide.ausblenden><en> We can move around the model, hide elements and simplify areas within elevation parameters.
<G-vec00714-002-s029><hide.ausblenden><de> Schritt 4: Wählen Sie aus dieser Liste die App aus, die Sie auf Ihrem Android-Gerät ausblenden möchten.
<G-vec00714-002-s029><hide.ausblenden><en> Step 4: From that list, go ahead and choose the app that you want to hide from your Android device.
<G-vec00714-002-s030><hide.ausblenden><de> Wenn Sie das nicht möchten, können Sie diese auch ausblenden.
<G-vec00714-002-s030><hide.ausblenden><en> If you don't want this info shown, you can hide your regular routes.
<G-vec00714-002-s031><hide.ausblenden><de> Sie können die Antworten auch ausblenden, bis alle Teilnehmer ihre Antworten eingereicht haben.
<G-vec00714-002-s031><hide.ausblenden><en> You may also hide answers until all students complete their submissions.
<G-vec00714-002-s032><hide.ausblenden><de> Sie können Sie benennen, zugehörige Beschreibungen verfassen, Schriften ändern, die Größe ändern, nicht verwendete Spalten ausblenden und mehr.
<G-vec00714-002-s032><hide.ausblenden><en> You can name them, write descriptions of them, change fonts, resize them, hide unused columns, and more.
<G-vec00714-002-s033><hide.ausblenden><de> Weitere Informationen über das Anzeigen der ausgeblendeten Zeilen oder Spalten finden Sie unter Ausblenden oder Anzeigen von Zeilen und Spalten.
<G-vec00714-002-s033><hide.ausblenden><en> For more information about displaying hidden rows or columns, see Hide or display rows and columns.
<G-vec00714-002-s034><hide.ausblenden><de> iOS: Drücke auf das Einstellungssymbol in der rechten oberen Ecke und wähle "Erledigte Aufgaben ausblenden".
<G-vec00714-002-s034><hide.ausblenden><en> iOS: Press the settings icon in the top right corner and select “Hide completed tasks”.
<G-vec00714-002-s035><hide.ausblenden><de> Ausblenden von Dateien können Ihre Gigabyte Daten innerhalb von Sekunden sperren und entsperren.
<G-vec00714-002-s035><hide.ausblenden><en> Hide Files can lock and unlock your gigabytes of data within seconds.
<G-vec00714-002-s036><hide.ausblenden><de> Sie können neue Felder ganz einfach hinzufügen, ausblenden oder die Reihenfolge für Ihre Abläufe optimieren.
<G-vec00714-002-s036><hide.ausblenden><en> You can simply add new fields yourself, or hide them or optimize their sequence order for your processes.
<G-vec00714-002-s037><hide.ausblenden><de> Damit Sie sich auf bestimmte Details konzentrieren können, um Ihr Projekt zu verwalten, können Sie auch alle angezeigten Spalten ausblenden.
<G-vec00714-002-s037><hide.ausblenden><en> To help you focus on specific details to manage your project, you can also hide any columns that are shown.
<G-vec00714-002-s039><hide.ausblenden><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00714-002-s039><hide.ausblenden><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00714-002-s040><hide.ausblenden><de> In den meisten E-Mail-Programmen und Webmail-Oberflächen werden die Header der E-Mails ausgeblendet.
<G-vec00714-002-s040><hide.ausblenden><en> Most email programs and webmail interfaces hide the email header.
<G-vec00714-002-s041><hide.ausblenden><de> Außerhalb der Geschäftszeiten: Klicken Sie auf das Dropdown-Menü und wählen Sie aus, ob eine Abwesenheitsnachricht oder eine Antwortzeit angezeigt werden soll oder der Chat-Launcher ausgeblendet werden soll, wenn ein Besucher außerhalb der Geschäftszeiten Ihre Website besucht.
<G-vec00714-002-s041><hide.ausblenden><en> Outside business hours: click the dropdown menu and choose to either show an away message, show a reply time, or hide the chat launcher when a visitor comes to your site outside of business hours.
<G-vec00714-002-s042><hide.ausblenden><de> Jede Kanban-Tafel kann individuell konfiguriert werden, so dass nicht benötigte oder weniger priorisierte Felder ausgeblendet werden.
<G-vec00714-002-s042><hide.ausblenden><en> Each Kanban Board can be configured individually in order to hide fields which are not required of have a lower priority at the time.
<G-vec00714-002-s043><hide.ausblenden><de> Workspace ausgeblendet: Die SIPs des Workspaces werden nicht aufgelistet.
<G-vec00714-002-s043><hide.ausblenden><en> Hide workspace: the SIPs of the workspace are not shown in the launcher.
<G-vec00714-002-s044><hide.ausblenden><de> Mit dieser Richtlinieneinstellung können bestimmte Elemente der Systemsteuerung ausgeblendet werden.
<G-vec00714-002-s044><hide.ausblenden><en> This policy setting allows you to hide specified Control Panel items.
<G-vec00714-002-s045><hide.ausblenden><de> Mit dieser Einstellung werden keine Dokumentverknüpfungen im Dialogfeld "Öffnen" ausgeblendet.
<G-vec00714-002-s045><hide.ausblenden><en> This setting does not hide document shortcuts displayed in the Open dialog box.
<G-vec00714-002-s046><hide.ausblenden><de> Das Foto wird nun wieder angezeigt, ist jedoch weiterhin als ausgeblendet gekennzeichnet.
<G-vec00714-002-s046><hide.ausblenden><en> The photo reappears but is still marked as being in hide mode.
<G-vec00714-002-s047><hide.ausblenden><de> Mit der Filterfunktion können zudem Kommentare ausgeblendet werden.
<G-vec00714-002-s047><hide.ausblenden><en> The filter function can also be used to hide comments.
<G-vec00714-002-s048><hide.ausblenden><de> Einzelne Käufe können über iTunes ausgeblendet werden, damit andere Familienangehörige diese nicht sehen können.
<G-vec00714-002-s048><hide.ausblenden><en> Using iTunes on a computer, family members can hide any of their purchases so other family members can’t view them.
<G-vec00714-002-s049><hide.ausblenden><de> Es werden auch die globalen Fortschrittsinformationen ausgeblendet, wenn kein aktueller Fortschritt vorliegt.
<G-vec00714-002-s049><hide.ausblenden><en> It will also hide the global progress information if there isn't any current progress.
<G-vec00714-002-s050><hide.ausblenden><de> Bei der Anzeige der Bewehrungsverteilung können beispielsweise Werte, die unterhalb der ohnehin eingelegten Grundbewehrung liegen, ausgeblendet werden.
<G-vec00714-002-s050><hide.ausblenden><en> In displaying the reinforcement arrangement, you can, for example, hide values that are below the already used basic reinforcement.
<G-vec00714-002-s051><hide.ausblenden><de> Sie können mit Stay Focused ein sauberes Desktop einrichten, da dadurch ein bestimmtes Hintergrundbild festgelegt wird und alles, was sich nicht auf Ihre Arbeit während Ihrer Arbeitszeit bezieht, ausgeblendet wird.
<G-vec00714-002-s051><hide.ausblenden><en> You can set a clean desktop with Stay Focused as it will set a certain wallpaper and hide all that is not related to your work during your work hours.
<G-vec00714-002-s052><hide.ausblenden><de> So können zum Beispiel frei definierbare Attribute vergeben oder nicht benötigte Metadaten ausgeblendet werden.
<G-vec00714-002-s052><hide.ausblenden><en> For example, you can assign user-defined labels or hide certain types of metadata which are not needed.
<G-vec00714-002-s053><hide.ausblenden><de> Vor dem Hintergrund einer übersichtlicheren Benutzbarkeit können durch Benutzerrechte bestimmte Funktionen ausgeblendet werden, die von Standardnutzern nicht benötigt werden (Zugriffsberechtigung).
<G-vec00714-002-s053><hide.ausblenden><en> In line with the improved usability, it is now possible to utilize specified user rights to hide certain functions that are irrelevant for standard users (Access authorization).
<G-vec00714-002-s054><hide.ausblenden><de> Hinweise Sie können im Vorgangsinspektor für den Vorgang auch angeben, dass Warnungen ausgeblendet werden.
<G-vec00714-002-s054><hide.ausblenden><en> Remarks You can also specify to hide warnings in the Task Inspector pane for the task.
<G-vec00714-002-s055><hide.ausblenden><de> Damit sowohl Kommentare als auch Indikatoren in der gesamten Arbeitsmappe ausgeblendet werden, klicken Sie unter Für Zellen mit Kommentaren Folgendes anzeigen auf Keine Kommentare und Indikatoren.
<G-vec00714-002-s055><hide.ausblenden><en> To hide both comments and indicators throughout the workbook, under For cells with comments, show, click No comments or indicators.
<G-vec00714-002-s056><hide.ausblenden><de> Durch Aktivieren der Schaltfläche ''Privacy mode'' (mit blauem Hintergrund, wenn aktiv) werden diese Informationen ausgeblendet.
<G-vec00714-002-s056><hide.ausblenden><en> Activating the button ''Privacy mode'' (highlighted with blue background when active) on top will hide that information.
<G-vec00714-002-s057><hide.ausblenden><de> Dieser Parameter gibt Ihnen die Möglichkeit, die Schaltfläche Benutzerverwaltung aufrufen im Setup-Wizard auszublenden.
<G-vec00714-002-s057><hide.ausblenden><en> This parameter gives you the option to hide the Manage user wizard button in the Setup Wizard.
<G-vec00714-002-s058><hide.ausblenden><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00714-002-s058><hide.ausblenden><en> Clear this check box to hide these updates.
<G-vec00714-002-s059><hide.ausblenden><de> Sie haben die Möglichkeit, vertrauliche Nachrichteninhalte in der Vorschau auszublenden und vertrauliche Nachrichten beim Drucken oder Exportieren auszuschließen.
<G-vec00714-002-s059><hide.ausblenden><en> You have the option to hide confidential message content when you preview and to exclude confidential message content when you print or export messages.
<G-vec00714-002-s060><hide.ausblenden><de> Anzeige Bitte einloggen, um diese Anzeige auszublenden.
<G-vec00714-002-s060><hide.ausblenden><en> Log in or Sign up to hide all adverts.
<G-vec00714-002-s061><hide.ausblenden><de> Eine Option besteht darin, das Teilformular am Anfang als sichtbar zu markieren und es anschließend in einem auf Logik oder Daten basierenden Initialisierungsskript auszublenden.
<G-vec00714-002-s061><hide.ausblenden><en> A workaround is to mark the subform initially visible and then hide it in an initialize script based on some logic or data.
<G-vec00714-002-s062><hide.ausblenden><de> Um den Navigator auszublenden, klicken Sie auf die entsprechende Schaltfläche im unteren Bereich des Media-Editorfensters.
<G-vec00714-002-s062><hide.ausblenden><en> You can hide the Navigator by clicking its button at the bottom of the media editor window.
<G-vec00714-002-s063><hide.ausblenden><de> Sie können auch den allgemeinen Verbose-Parameter eines Cmdlet verwenden, um die ausführlichen Meldungen für einen bestimmten Befehl anzuzeigen oder auszublenden.
<G-vec00714-002-s063><hide.ausblenden><en> You can also use the Verbose common parameter of a cmdlet to display or hide the verbose messages for a specific command.
<G-vec00714-002-s064><hide.ausblenden><de> Endbenutzer können die ausgewählten Datenquellen ohne ABAP Fachkompetenz modifizieren, VirtDB ermöglicht ihnen unter anderem die vorhandenen SAP Berichte zu ändern, Felder hinzuzufügen oder zu entfernen, Werte zu ersetzen (wie zum Beispiel statt „Produktcode” „Beschreibung“), berechnete Felder zu erstellen, Daten auszublenden und noch viel mehr – alles auf der Benutzungsoberfläche ohne zu kodieren.
<G-vec00714-002-s064><hide.ausblenden><en> The selected data sources can be modified by end-users without ABAP expertise, VirtDB enables them to create or modify existing SAP reports, add or remove fields, replace values (like from “product codes” to “descriptions”), create calculated fields, hide data and many more on a graphical UI without coding. REQUEST DEMO
<G-vec00714-002-s065><hide.ausblenden><de> Setzen Sie die Auswahl zurück oder wählen Sie für das aktive Projekt die Kontextmenü-Option Alle Meilensteinnamen ausblenden, um für das ausgewählte Projekt alle Meilensteinnamen auszublenden.
<G-vec00714-002-s065><hide.ausblenden><en> Remove the selection or select the Hide All Milestone Names context menu option for the active project to hide milestone names again.
<G-vec00714-002-s066><hide.ausblenden><de> Um die Einstellungen auszublenden, klicken Sie erneut auf die Schaltfläche.
<G-vec00714-002-s066><hide.ausblenden><en> To hide the settings, click the button again.
<G-vec00714-002-s067><hide.ausblenden><de> • Um gesendete Nachrichten auszublenden, aktivieren Sie das Kontrollkästchen Gesendete Nachrichten ausblenden.
<G-vec00714-002-s067><hide.ausblenden><en> • To hide sent messages, select the Hide Sent Messages checkbox.
<G-vec00714-002-s068><hide.ausblenden><de> Klicken Sie auf das kleine Dreieck neben einer Bedienfeldgruppe, um die Gruppe ein- oder auszublenden.
<G-vec00714-002-s068><hide.ausblenden><en> Click the small triangle outside a panel group to hide or show the group.
<G-vec00714-002-s069><hide.ausblenden><de> Um die Passwörter wieder auszublenden, wählen Sie das Passwort und wählen Sie "Ausblenden".
<G-vec00714-002-s069><hide.ausblenden><en> To hide passwords once again, chose the password and select “Hide.”
<G-vec00714-002-s070><hide.ausblenden><de> Bitte klicken Sie auf "Akzeptieren", um der Verwendung von Cookies zuzustimmen und diese Nachricht dauerhaft auszublenden.
<G-vec00714-002-s070><hide.ausblenden><en> Please click on 'Accept' to agree to the usage of cookies and hide this message permanently.
<G-vec00714-002-s071><hide.ausblenden><de> Füllen Sie nun alle erforderlichen Felder aus und achten Sie darauf, dass Sie Editor einblenden/ausblenden im Inhalte- Feld anklicken, um Ihre HTML-Editor-Werkzeuge auszublenden.
<G-vec00714-002-s071><hide.ausblenden><en> Now fill out all the required fields and make sure to click Show/Hide Editor in the Content field to hide your HTML Editor tools.
<G-vec00714-002-s072><hide.ausblenden><de> Um Kommentare und Kommentarsprechblasen in Ihrer Präsentation auszublenden, klicken Sie auf der Registerkarte Überprüfen auf Kommentare anzeigen, und klicken Sie dann auf Markup anzeigen.
<G-vec00714-002-s072><hide.ausblenden><en> To hide the comments and comment balloons in your presentation, click Show Comments on the Review tab, and then click Show Markup.
<G-vec00714-002-s073><hide.ausblenden><de> • Um Freizeit in der Tagesordnungsansicht auszublenden, deaktivieren Sie das Kontrollkästchen Freizeit in Tagesordnungsansicht anzeigen.
<G-vec00714-002-s073><hide.ausblenden><en> • To hide free time in Agenda view, clear the Show Free Time in Agenda View check box.
<G-vec00714-002-s074><hide.ausblenden><de> Die Beschränkungslistenansicht hat nun die Fähigkeit die interne Ausrichtung auszublenden sowie das individuelle Ausblenden von Beschränkungen mit einem Auswahlkästchen.
<G-vec00714-002-s074><hide.ausblenden><en> Constraints List box includes ability to hide internal alignment, as well as individual hiding of constraints with a checkbox.
<G-vec00714-002-s075><hide.ausblenden><de> Um Einstellungspins vorübergehend auszublenden, drücken Sie die Taste „H“.
<G-vec00714-002-s075><hide.ausblenden><en> To temporarily hide adjustment pins, press the H key.
