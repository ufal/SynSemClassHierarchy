<G-vec00713-002-s042><jump.aufspringen><de> Bevor Trader auf dieses Signal aufspringen, um den Markt zu kaufen, ist jedoch eine zusätzliche Bestätigung nötig.
<G-vec00713-002-s042><jump.aufspringen><en> Before traders can jump on this signal to buy, additional confirmation is needed.
<G-vec00713-002-s043><jump.aufspringen><de> Er würde aufspringen, gestartet in die Küche, die Marie sucht.
<G-vec00713-002-s043><jump.aufspringen><en> He would jump up, run into the kitchen looking for Marie.
<G-vec00713-002-s044><jump.aufspringen><de> Du entscheidest, wann du aufspringen möchtest.
<G-vec00713-002-s044><jump.aufspringen><en> You decide when you want to jump onto the train.
<G-vec00713-002-s045><jump.aufspringen><de> Wann immer eines dieser Aktivitätsfenster auftritt, müssen wir aufspringen und uns an die Arbeit machen.
<G-vec00713-002-s045><jump.aufspringen><en> Whenever one of these windows of activity occurs, we need to jump up and get to work.
<G-vec00713-002-s046><jump.aufspringen><de> Wenn wir uns „zusammensetzen“ signalisiert das, dass wir uns Zeit nehmen, das wir nicht im nächsten Moment aufspringen und wegrennen.
<G-vec00713-002-s046><jump.aufspringen><en> Sitting together signals that we are taking time, that we won´t jump and run away in the next moment.
<G-vec00713-002-s047><jump.aufspringen><de> Betten zum Aufspringen, Gehwege zum Laufen.
<G-vec00713-002-s047><jump.aufspringen><en> Beds to jump on, walkways to run down.
<G-vec00713-002-s048><jump.aufspringen><de> Bevor ich mich versah, wurde ich von dem Mann, den ich aufspringen und zum Wasser hatte rennen sehen um mich zu retten, über den Stand getragen.
<G-vec00713-002-s048><jump.aufspringen><en> The next thing I knew, I was being carried up the beach by the man I had seen jump up and run toward the water to help rescue me.
<G-vec00713-002-s049><jump.aufspringen><de> Ich sehe es im Aufspringen, sehe es, während mein Körper sich schon über die Maus des Videorechners beugt, während meine Augen noch immer meiner Tastatur zugewandt sind.
<G-vec00713-002-s049><jump.aufspringen><en> I see it as I jump up, see it while my body is already bending over the mouse of the video computer, while my eyes are still on my keyboard.
<G-vec00713-002-s050><jump.aufspringen><de> Falten dürfen nicht aufspringen sondern sollten in ihrer Form bleiben, damit der Rock nicht aufträgt.
<G-vec00713-002-s050><jump.aufspringen><en> Wrinkles must not jump up, but should remain in their shape so that the skirt does not make you bulkier than you are.
<G-vec00713-002-s051><jump.aufspringen><de> Wie ein getreuer Kettenhund des Kapitalismus, so wird dieser Mammonsdiener knurren, aufspringen und bellen.
<G-vec00713-002-s051><jump.aufspringen><en> Like a faithful watchdog of capitalism, the faker will snarl, jump up and bark.
<G-vec00713-002-s052><jump.aufspringen><de> Gerade im Winter benötigen unsere Lippen eine sanfte Pflege, denn trockene Heizungsluft und die Kälte von draußen lassen die Lippen extrem austrocknen und aufspringen.
<G-vec00713-002-s052><jump.aufspringen><en> Especially in winter, our lips need a gentle care, because dry heating air and the cold outside let the lips dry out and jump up.
<G-vec00713-002-s053><jump.aufspringen><de> Aufspringen und sich an einigen der hübschesten Stellen Südseelands vorbeiführen lassen.
<G-vec00713-002-s053><jump.aufspringen><en> Jump on your bike and let yourself be led through some af South Zealands most beautiful places.
