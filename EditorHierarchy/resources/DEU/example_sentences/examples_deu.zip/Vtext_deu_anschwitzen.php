<G-vec00679-002-s019><sweat.anschwitzen><de> Den Reis hinzugeben und während 1 Minute leicht anschwitzen.
<G-vec00679-002-s019><sweat.anschwitzen><en> Add the rice and let it sweat gently for 1 minute.
<G-vec00679-002-s020><sweat.anschwitzen><de> In einer Pfanne mit einem guten Schuss Olivenöl bei mittlerer Temperatur einige Minuten farblos anschwitzen.
<G-vec00679-002-s020><sweat.anschwitzen><en> Heat a splash of olive oil in a pan and sweat the onion and garlic a couple of minutes.
<G-vec00679-002-s021><sweat.anschwitzen><de> 7 Die Butter erhitzen und die Schalotte kurz anschwitzen.
<G-vec00679-002-s021><sweat.anschwitzen><en> 7 Heat the butter and sweat the shallot briefly.
<G-vec00679-002-s022><sweat.anschwitzen><de> Jetzt kannst du die zerkleinerten Zutaten zusammen in einen Topf geben und kurz „anschwitzen“.
<G-vec00679-002-s022><sweat.anschwitzen><en> Now you can put the minced ingredients together in a pot and briefly "sweat".
<G-vec00679-002-s023><sweat.anschwitzen><de> Die Butter in einer Pfanne erhitzen, die Zwiebel und den Fenchel sehr langsam anschwitzen, ohne Färbung, bis sie weich sind.
<G-vec00679-002-s023><sweat.anschwitzen><en> Heat the butter in a pan and sweat the onion and fennel very slowly without colouring until soft.
<G-vec00679-002-s024><sweat.anschwitzen><de> 3 bis 5 Minuten anschwitzen bis die Zwiebel glasig ist.
<G-vec00679-002-s024><sweat.anschwitzen><en> Add onion and sweat for 3 – 5 minutes until soft.
<G-vec00679-002-s025><sweat.anschwitzen><de> In einem Topf mit dem Olivenöl bei mittlerer Temperatur für ein paar Minuten anschwitzen.
<G-vec00679-002-s025><sweat.anschwitzen><en> Sweat them in a pan with the olive oil at medium temperature for a few minutes.
<G-vec00679-002-s026><sweat.anschwitzen><de> Die Gemüsewürfel in Olivenöl glasig anschwitzen.
<G-vec00679-002-s026><sweat.anschwitzen><en> Sweat the vegetable cubes in olive oil until translucent.
<G-vec00679-002-s027><sweat.anschwitzen><de> Einen großen Topf oder einen Bräter mit einem Esslöffel Butterschmalz erhitzen & den gewürfelten Speck sowie die fein gehackten Zwiebeln für etwa 2 – 3 Minuten bei mittlerer Hitze anschwitzen.
<G-vec00679-002-s027><sweat.anschwitzen><en> Heat up a large pot or roasting dish adding a tablespoon of clarified butter and sweat the diced bacon and finely chopped onions for about 2-3 minutes over medium heat.
