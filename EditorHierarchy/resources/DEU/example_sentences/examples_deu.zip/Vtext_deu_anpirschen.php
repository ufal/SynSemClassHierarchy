<G-vec00665-002-s119><sneak.anpirschen><de> Wenn wir gemeinsam jagen, pirschen wir uns zusammen an die Beute an.
<G-vec00665-002-s119><sneak.anpirschen><en> When we hunt, we sneak up to the prey together.
