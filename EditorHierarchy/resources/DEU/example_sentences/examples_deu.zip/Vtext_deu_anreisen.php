<G-vec00097-001-s133><arrive.anreisen><de> Wichtige Informationen Falls Sie voraussichtlich außerhalb der Check-in-Zeiten anreisen, informieren Sie die Unterkunft bitte vorab.
<G-vec00097-001-s133><arrive.anreisen><en> Important information If you expect to arrive outside check-in hours, please inform the property in advance.
<G-vec00097-001-s134><arrive.anreisen><de> Studierende, die zu den regulären Semesterzeiten ihr Praktikum absolvieren und zu Semesterbeginn (Oktober, April) anreisen, können im Rahmen der Erasmus Welcome Week eingeschrieben und betreut werden.
<G-vec00097-001-s134><arrive.anreisen><en> Students doing the internship during regular semester dates and arrive at the beginning of the semester (October, April), might be able to join the Erasmus Welcome Week for enrolment and orientation.
<G-vec00097-001-s135><arrive.anreisen><de> Wenn Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte im Voraus, um den Check-in zu arrangieren.
<G-vec00097-001-s135><arrive.anreisen><en> If you expect to arrive outside reception opening hours, please inform the property in advance in order to arrange check-in.
<G-vec00097-001-s136><arrive.anreisen><de> Wenn Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie bitte das Hotel im Voraus und vor 19:00 Uhr.
<G-vec00097-001-s136><arrive.anreisen><en> If you expect to arrive outside reception opening hours, please inform the property in advance and within 19:00.
<G-vec00097-001-s137><arrive.anreisen><de> Für Jene, die mit dem Auto anreisen, gibt es eine vertragsgebundene Garage, des weiteren steht unser professionelles und freundliches Hotelteam für sämtliche touristischen Informationen, Buchungen für Ausflüge, Führungen und für Auskünfte über Fahrpläne der öffentlichen Verkehrsmittel zur kompletten Verfügung der Kunden.
<G-vec00097-001-s137><arrive.anreisen><en> Those of you who arrive by car can take advantage of the garage with special rates for hotel residents and you can then move around the city with the use of public transport system. For tourist information and bookings, for excursions and guided visits the courteous and professional staff will be happy to provide you with any useful advice you may require.
<G-vec00097-001-s138><arrive.anreisen><de> Wenn Sie denken, dass Sie nach 22:30 Uhr anreisen können, teilen Sie uns dies bitte vor der Buchung mit.Wenn ein Gast in Ihrer Buchung unter 18 Jahre alt ist, MÜSSEN Sie sich vor der Online-Reservierung mit uns in Verbindung setzenWenn Sie vor 14.30 Uhr anreisen, können Sie Ihre Koffer in unserem Gepäckraum kostenlos abstellen.Wir akzeptieren keine Junggesellenabschiede.
<G-vec00097-001-s138><arrive.anreisen><en> If you think you may arrive later than 10:30pm, please let us know before making your booking.If any guest within your booking is under the age of 18 you MUST contact us before making the reservation onlineIf you arrive before 2.30pm you can store your bags in our luggage storage area for free.We do not accept stag or hens parties. Check Availability Reviews & Ratings
<G-vec00097-001-s140><arrive.anreisen><de> Bitte kontaktieren Sie die Pension Regenbogen vorab, wenn Sie nach 18:00 Uhr anreisen sollten.
<G-vec00097-001-s140><arrive.anreisen><en> Please contact Pension Regenbogen in advance if you expect to arrive after 18:00.
<G-vec00097-001-s141><arrive.anreisen><de> Wenn Sie voraussichtlich außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte vorab.
<G-vec00097-001-s141><arrive.anreisen><en> If you are intending to arrive after outside the reception opening times, you must notify the property in advance.
<G-vec00097-001-s142><arrive.anreisen><de> So können Sie sich schnell und unkompliziert Ihren Parkplatz buchen, entspannt anreisen und nach dem Shuttle-Transfer bequem einchecken.
<G-vec00097-001-s142><arrive.anreisen><en> This lets you book your parking space quickly and easily so that you arrive relaxed and, after a short shuttle transfer, you can check in at your leisure.
<G-vec00097-001-s143><arrive.anreisen><de> Falls Sie später anreisen möchten, bitte melden Sie es uns vorzeitig.
<G-vec00097-001-s143><arrive.anreisen><en> If you are planning to arrive later than this, please let us know in advance.
<G-vec00097-001-s144><arrive.anreisen><de> Falls Sie voraussichtlich außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte im Voraus, um die Schlüsselübergabe zu arrangieren.
<G-vec00097-001-s144><arrive.anreisen><en> If you expect to arrive outside of office hours, please contact the property in advance to arrange key collection, using the contact details found on the booking confirmation.
<G-vec00097-001-s145><arrive.anreisen><de> Bitte informieren Sie das Hotel im Voraus, falls Sie außerhalb dieser Zeiten anreisen.
<G-vec00097-001-s145><arrive.anreisen><en> Please contact the hotel in advance if you intend to arrive outside these times.
<G-vec00097-001-s146><arrive.anreisen><de> Falls Sie voraussichtlich außerhalb der Check-in-Zeiten anreisen, informieren Sie die Unterkunft bitte im Voraus.
<G-vec00097-001-s146><arrive.anreisen><en> If you expect to arrive outside check-in hours, please inform the property in advance. Photo album
<G-vec00097-001-s147><arrive.anreisen><de> Vor allem dann, wenn Sie mit dem Zug anreisen, Aegviidu, können Sie zu Fuß das nature Trail zu Jäneda.
<G-vec00097-001-s147><arrive.anreisen><en> Especially if you arrive to Aegviidu by train, you can walk this nature trail to Jäneda.
<G-vec00097-001-s148><arrive.anreisen><de> Wichtige Informationen Wenn Sie nach 18:00 Uhr anreisen, wird eine Gebühr für einen späten Check-in in der Höhe von 150 DKK berechnet.
<G-vec00097-001-s148><arrive.anreisen><en> Important information If you expect to arrive later than 18:00, a late check-in fee of 150 DKK will apply.
<G-vec00097-001-s149><arrive.anreisen><de> Bitte kontaktieren Sie das Hotel im Voraus, falls Sie nach 18:00 Uhr anreisen.
<G-vec00097-001-s149><arrive.anreisen><en> Please contact the hotel in advance if you arrive after 18:00.
<G-vec00097-001-s150><arrive.anreisen><de> Wichtige Informationen Sollten Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Emporio Prague Apartments bitte im Voraus.
<G-vec00097-001-s150><arrive.anreisen><en> Important information If you expect to arrive outside reception opening hours, please inform Emporio Prague Apartments in advance.
<G-vec00097-001-s151><arrive.anreisen><de> Wenn Sie nach 19:00 Uhr anreisen, informieren Sie die Unterkunft bitte 3 Tage im Voraus darüber.
<G-vec00097-001-s151><arrive.anreisen><en> If you are expecting to arrive after 19:00 please let the property know 3 days in advance.
<G-vec00097-001-s171><arrive.anreisen><de> Bitte wenden Sie sich im Voraus an das CityHotel Kempten, wenn Sie erwarten, spät anzureisen.
<G-vec00097-001-s171><arrive.anreisen><en> Please contact CityHotel Kempten in advance if you expect to arrive late.
<G-vec00097-001-s172><arrive.anreisen><de> Sollten Sie planen außerhalb der Check-in-Zeiten anzureisen, informieren Sie die Unterkunft bitte mindestens 1 Woche im Voraus.
<G-vec00097-001-s172><arrive.anreisen><en> If you expect to arrive outside check-in hours, please inform the property at least 1 week in advance.
<G-vec00097-001-s173><arrive.anreisen><de> Bitte informieren Sie die Unterkunft vorab, falls Sie planen, außerhalb der Check-in-Zeiten anzureisen.
<G-vec00097-001-s173><arrive.anreisen><en> If you expect to arrive outside check-in hours, please inform the property in advance. Photo album
<G-vec00097-001-s174><arrive.anreisen><de> Es ist gut, ungefähr einen Tag früher anzureisen, wenn es möglich ist, um dir Zeit zur Erholung vom Jetlag zu gewährleisten.
<G-vec00097-001-s174><arrive.anreisen><en> You might want to arrive a day or so early, if possible, to allow you time to recover from jet lag.
<G-vec00097-001-s175><arrive.anreisen><de> Planen Sie, nach 22:00 Uhr anzureisen, so kontaktieren sie die Unterkunft bitte vorab, um den Zugangscode zu erhalten.
<G-vec00097-001-s175><arrive.anreisen><en> If you plan to arrive after 22:00, please contact the residence in advance to obtain access codes.
<G-vec00097-001-s176><arrive.anreisen><de> Falls Sie planen, außerhalb dieser Zeiten anzureisen, müssen Sie das Hotel für weitere Informationen kontaktieren.
<G-vec00097-001-s176><arrive.anreisen><en> Guests planning to arrive outside of these hours must contact the hotel in advance for further information.
<G-vec00097-001-s177><arrive.anreisen><de> Wenn Sie planen sollten später anzureisen als gebucht, weisen Sie unseren Kundenservice bitte darauf hin, damit der Vermieter nicht vergebens auf Sie warten muss.
<G-vec00097-001-s177><arrive.anreisen><en> If you are planning to arrive later than you have booked, please inform our customer service so that the owner does not have to wait for you unnecessarily.
<G-vec00097-001-s178><arrive.anreisen><de> Sollten Sie planen, nach 22:00 Uhr anzureisen, informieren Sie bitte das Hotel im Voraus.
<G-vec00097-001-s178><arrive.anreisen><en> Please contact the hotel in advance if you plan to arrive later than 22:00.
<G-vec00097-001-s179><arrive.anreisen><de> Selbstverständlich ist es auch möglich mit der Bahn oder dem eigenen Auto anzureisen.
<G-vec00097-001-s179><arrive.anreisen><en> However, it is also possible to arrive by train or by car.
<G-vec00097-001-s180><arrive.anreisen><de> Planen Sie, nach diesem Zeitpunkt anzureisen, kontaktieren Sie das Hotel bitte vor der Anreise.
<G-vec00097-001-s180><arrive.anreisen><en> If planning to arrive later than this, please contact the boarding house in advance.
<G-vec00097-001-s181><arrive.anreisen><de> Jene Besucher, die planen, in Málaga mit dem Kreuzfahrtschiff oder dem Zug anzureisen und einen Mietwagen mieten möchten, liegen hier genau richtig.
<G-vec00097-001-s181><arrive.anreisen><en> Those visitors who are planning to arrive at Malaga by cruise or by train and want to hire a car, well now's the time.
<G-vec00097-001-s182><arrive.anreisen><de> Bitte rufen Sie das Hotel im Voraus an, wenn Sie beabsichtigen, später anzureisen.
<G-vec00097-001-s182><arrive.anreisen><en> Kindly call the hotel in advance if you intend to arrive late.
<G-vec00097-001-s183><arrive.anreisen><de> Wir empfehlen Ihnen, mit dem Zug anzureisen; in Nizza oder Marseille können Sie in regionale Transportmittel umsteigen, die Sie nach Menton bringen.
<G-vec00097-001-s183><arrive.anreisen><en> We'd advise you to arrive by train; transportation hubs in Nice or Marseilles will connect you to the local lines leading to Menton.
<G-vec00097-001-s184><arrive.anreisen><de> Unsere Yoga-Woche beginnt immer montags, darum empfehlen wir, bereits am Sonntag anzureisen.
<G-vec00097-001-s184><arrive.anreisen><en> Our yoga weeks always start on Monday, which is why we recommend that you arrive on Sunday.
<G-vec00097-001-s185><arrive.anreisen><de> Es wird empfohlen, mit dem Auto anzureisen.
<G-vec00097-001-s185><arrive.anreisen><en> It is advisable to arrive by car.
<G-vec00097-001-s186><arrive.anreisen><de> Bitte informieren Sie das Hotel, falls Sie planen, nach Mitternacht anzureisen.
<G-vec00097-001-s186><arrive.anreisen><en> Please inform the hotel if you intend to arrive after 24:00.
<G-vec00097-001-s187><arrive.anreisen><de> Wenn Sie zum ersten Mal zu Buchinger kommen, empfehlen wir Ihnen, zwischen 15.00 Uhr und 17.00 Uhr anzureisen: da ist unser Empfangsteam komplett für Sie da.
<G-vec00097-001-s187><arrive.anreisen><en> If you come to the clinic Buchinger for the first time, we recommend to arrive between 2 pm and 5 pm: at this time our entire reception team is complete and can take care of you.
<G-vec00097-001-s188><arrive.anreisen><de> Bitte kontaktieren Sie das Hotel via e-mail oder telefonisch, falls Sie planen, nach 20:00 Uhr anzureisen.
<G-vec00097-001-s188><arrive.anreisen><en> If you plan to arrive after 20:00 (not later than 23:00), please contact us in advance via e-mail or telephone.
<G-vec00097-001-s189><arrive.anreisen><de> Wenn Sie planen, zwischen November und März von 14:30 bis 17:30 Uhr anzureisen, kontaktieren Sie bitte das Hotel im Voraus, da die Rezeption in dieser Zeit nicht besetzt ist.
<G-vec00097-001-s189><arrive.anreisen><en> If you plan to arrive between November and March, between 14:30 and 17:30, please contact the hotel in advance, as the hotel reception will not be manned. Contact details will be included in your confirmation e-mail. Area information
<G-vec00217-002-s209><arrive.anreisen><de> Bitte setzen Sie sich vorab mit der Unterkunft in Verbindung, falls Sie planen, nach 19:00 Uhr anzureisen.
<G-vec00217-002-s209><arrive.anreisen><en> Please contact the property in advance if you expect to arrive after 19:00.
<G-vec00217-002-s210><arrive.anreisen><de> Wir empfehlen allen Besucher*innen, mit den öffentlichen Verkehrsmitteln anzureisen (10 Minuten Gehdistanz zum Hauptbahnhof Zürich oder zur Tramhaltestelle Central).
<G-vec00217-002-s210><arrive.anreisen><en> We recommend all visitors to arrive by public transport (10 minutes walking distance to Zurich main station or to the tram stop Central).
<G-vec00217-002-s211><arrive.anreisen><de> Wichtiger Hinweis: Aufgrund unseres flexiblen Reservierungssystems besteht die Möglichkeit, nach Rücksprache mit der Rezeption auch an anderen Wochentagen als Samstag anzureisen.
<G-vec00217-002-s211><arrive.anreisen><en> Important note: Due to our flexible reservation system, it is also possible to arrive on weekdays other than Saturday, in consultation with the Holidays High Season
<G-vec00217-002-s212><arrive.anreisen><de> Wenn Sie planen, außerhalb dieser Zeiten anzureisen, folgen Sie bitte den Anweisungen, die Ihnen per E-Mail zugesandt werden, um das Gebäude mit einem personalisierten Code zu betreten.
<G-vec00217-002-s212><arrive.anreisen><en> If you plan to arrive outside these hours, please follow the instructions provided by email in order to enter the building with a personalized code.
<G-vec00217-002-s213><arrive.anreisen><de> Aufgrund der zentralen Lage lohnt es sich natürlich, mit der Bahn anzureisen.
<G-vec00217-002-s213><arrive.anreisen><en> Due to its central location it is of course worthwhile to arrive by train.
<G-vec00217-002-s214><arrive.anreisen><de> Bitte teilen Sie dem Hotel vorab mit, falls Sie nach 18:00 Uhr anzureisen gedenken.
<G-vec00217-002-s214><arrive.anreisen><en> Please inform the hotel should you wish to arrive later than 18:00.
<G-vec00217-002-s215><arrive.anreisen><de> Daher rate ich Euch großzügig zu planen, wenn Ihr das Flugticket in Anspruch nehmen möchtet und gegebenen falls schon am Vorabend anzureisen.
<G-vec00217-002-s215><arrive.anreisen><en> Therefore, I would advise you to plan generously, if you want to use the flight ticket and if necessary, arrive the evening before.
<G-vec00217-002-s216><arrive.anreisen><de> Zögern Sie auch nicht, mit dem Flugzeug anzureisen, um vor den Toren der Vogesen ab den Flughäfen Basel-Mulhouse-Freiburg, Straßburg-Entzheim und Lorraine Airport zwischen Metz und Nancy zu landen.
<G-vec00217-002-s216><arrive.anreisen><en> You can also arrive by plane and land at the gateway to the Vosges at EuroAirport Basel Mulhouse Freiburg, Strasbourg Airport or Lorraine Airport, located between Metz and Nancy.
<G-vec00217-002-s218><arrive.anreisen><de> Sie können sich aber auch dafür entscheiden, mit einem "Taxi-Boot" anzureisen, einen Tagesausflug mit einer Firma zu planen, die Sie per Speedboot oder Katamaran auf die Insel bringt (diese sind normalerweise Teil eines Tagesausflugspakets, das auch ein paar Aktivitäten und Mittagessen beinhaltet) oder wenn Sie wirklich stilvoll ankommen wollen, können Sie dies mit dem Hubschrauber tun (der Hubschrauberplatz befindet sich in der Nähe des Ile aux Cerfs Golf Club).
<G-vec00217-002-s218><arrive.anreisen><en> However, you can also opt to arrive by a “taxi boat”, plan a day trip with a company that will take you to the island via speedboat or catamaran (these are usually part of a day trip package which also includes a few activities and lunch) or if you really want to arrive in style, you can do so by helicopter (the helicopter pad is located close to the Ile aux Cerfs Golf Club).
<G-vec00217-002-s219><arrive.anreisen><de> Sollten Sie vorhaben, außerhalb der angegebenen Check-in-Zeiten anzureisen, kontaktieren Sie das Hotel bitte direkt und so bald wie möglich.
<G-vec00217-002-s219><arrive.anreisen><en> Guests who expect to arrive outside of the stated check-in times must contact the property directly as soon as possible.
<G-vec00217-002-s220><arrive.anreisen><de> Sie haben die Möglichkeit, bequem und einfach mit dem Zug anzureisen.
<G-vec00217-002-s220><arrive.anreisen><en> You have the opportunity to arrive comfortably and easily by train.
<G-vec00217-002-s221><arrive.anreisen><de> Um der Gastfamilie die Möglichkeit zu geben, sich auf die nächsten Schüler vorzubereiten, bitten wir alle Schüler, sonntags anzureisen und samstags abzureisen.
<G-vec00217-002-s221><arrive.anreisen><en> In order to allow the homestay host time to prepare for the arrival of their next students, we ask all students to try to arrive on Sunday and leave on Saturday.
<G-vec00217-002-s222><arrive.anreisen><de> Wenn Sie planen, nach 21:00 Uhr anzureisen, kontaktieren Sie bitte das Hotel direkt.
<G-vec00217-002-s222><arrive.anreisen><en> If you are planning to arrive after 21:00, please contact the hotel directly.
<G-vec00217-002-s223><arrive.anreisen><de> Nach vielen Telefonaten, E-Mails und Rücksprachen mit den Ortsansässigen, beschloss unsere Crew, Anfang August (2013) in Christchurch, Neuseeland, anzureisen, in die kleine Stadt Methven aufzubrechen und in der Arrowsmith-Bergkette unser Bestes zu versuchen.
<G-vec00217-002-s223><arrive.anreisen><en> After many phone calls, emails and consulting with the locals, our crew made the decision to arrive in Christchurch, New Zealand early August (2013), head to the small village of Methven and do our best in the Arrowsmith Mountain Range.
<G-vec00217-002-s225><arrive.anreisen><de> Bitte kontaktieren Sie das Hostel im Voraus, wenn Sie planen, nach 23:00 Uhr anzureisen.
<G-vec00217-002-s225><arrive.anreisen><en> Please contact the hostel in advance if you wish to arrive after 23:00.
<G-vec00217-002-s226><arrive.anreisen><de> Die Gastgeber waren sehr nett und flexibel was den Check-in betrifft, so war es uns möglich bereits Mittags anzureisen.
<G-vec00217-002-s226><arrive.anreisen><en> The hosts were very nice and flexible with regard to check-in, so it was already possible to arrive us at noon.
<G-vec00217-002-s227><arrive.anreisen><de> Zu unserer Freude hatte es Nadja (Ambassador der Slowenischen WRWR Gruppe) zusammen mit 2 Begleitern geschafft von der Slowenischen Seite anzureisen und so kam es zu einem denkwürdigen Foto, dass ganz sicher in die Annalen des WRWR eingehen wird.
<G-vec00217-002-s227><arrive.anreisen><en> To our joy Nadja (Ambassador of the Slovenian WRWR group) together with 2 companions had managed to arrive from the Slovenian side and so it came to a memorable photo that will surely go down in the annals of the WRWR.
<G-vec00218-002-s210><arrive.anreisen><de> Wir empfehlen allen Besucher*innen, mit den öffentlichen Verkehrsmitteln anzureisen (10 Minuten Gehdistanz zum Hauptbahnhof Zürich oder zur Tramhaltestelle Central).
<G-vec00218-002-s210><arrive.anreisen><en> We recommend all visitors to arrive by public transport (10 minutes walking distance to Zurich main station or to the tram stop Central).
<G-vec00403-002-s020><commute.anreisen><de> Insbesondere weniger wohlhabende Studierende müssen neben dem Studium arbeiten, weit anreisen oder sich verschulden.
<G-vec00403-002-s020><commute.anreisen><en> Less affluent students, in particular, have to work while studying, commute far or get into debt.
