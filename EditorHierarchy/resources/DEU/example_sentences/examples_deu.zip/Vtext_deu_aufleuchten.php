<G-vec01173-002-s019><glow.aufleuchten><de> – Jedes Mal, wenn ein Chat mit einem anderen Spieler einen eigenen Reiter erhält, wird dieser Reiter aufleuchten, sobald eine neue Nachricht eingetroffen ist.
<G-vec01173-002-s019><glow.aufleuchten><en> Any time a conversation with another player is put into its own tab, the tab will glow when a new message is received.
<G-vec01173-002-s020><glow.aufleuchten><de> Mehr Dampf in der Fluoreszenzröhre lässt diese Röhre heller aufleuchten.
<G-vec01173-002-s020><glow.aufleuchten><en> More vapor in the tube causes the tube to glow brighter.
<G-vec01173-002-s021><glow.aufleuchten><de> Auf Knopfdruck leuchten LEDs in vielen Farben auf, die den ganzen Stab hell aufleuchten lassen.
<G-vec01173-002-s021><glow.aufleuchten><en> At the press of a button, multicoloured LEDs make the stick glow in the night.
<G-vec01173-002-s022><glow.aufleuchten><de> Wenn Sie beispielsweise Google Mail als angehefteten Tab festgelegt haben und Sie einen andern Tab verwenden, während eine neue E-Mail eingeht, wird der Google-Mail-Tab aufleuchten.
<G-vec01173-002-s022><glow.aufleuchten><en> If you have Gmail set as a Pinned Tab, for example, and you are using a different tab when a new email is received, your Gmail tab will glow.
<G-vec01173-002-s023><glow.aufleuchten><de> Heiße, junge Sterne, die intensives ultraviolettes Licht abstrahlen, lassen den Nebel hell aufleuchten.
<G-vec01173-002-s023><glow.aufleuchten><en> Hot, young stars, which give off intense ultraviolet light, are responsible for making the nebula glow brightly.
<G-vec01173-002-s024><glow.aufleuchten><de> Sobald Sie Ihre Vapour 2 gegen Ihre Lippen drücken und einatmen, wird das LED-Licht an der Spitze aufleuchten, wie die Spitze einer brennenden Zigarette.
<G-vec01173-002-s024><glow.aufleuchten><en> As you hold your Vapour 2 to your lips and inhale, the LED light at the tip will glow just like the tip of a burning cigarette.
<G-vec01173-002-s025><glow.aufleuchten><de> Auch „Spectraflex“ – faseroptische Lichtleitfasern von SCHOTT – lassen bei der Deckenbeleuchtung „Bar“ viele, unterschiedlich lange Glasröhren aufleuchten.
<G-vec01173-002-s025><glow.aufleuchten><en> “Spectraflex” fiber optic light guides made by SCHOTT allow numerous glass tubes of various lengths to glow, part of the ceiling illumination of a work he named “Bar”.
