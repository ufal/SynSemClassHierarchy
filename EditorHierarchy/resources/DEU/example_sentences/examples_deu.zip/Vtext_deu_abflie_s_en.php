<G-vec00755-002-s026><drain.abfließen><de> Hervorragende Luftzirkulation und Wasserableitung - Verhindert die Bildung von kreisenden Wurzeln, beschneidet die Wurzel der Pflanze und lässt überschüssiges Wasser die Struktur abfließen.
<G-vec00755-002-s026><drain.abfließen><en> Great air circulation and water drainage – Prevents circling roots build-up, air prunes the plant’s root and allows excess water to drain structure.
<G-vec00755-002-s027><drain.abfließen><de> Topfen ist eine ganz besondere Käse-Spezialität, bei der die Käsegallerte handgeschöpft in Käseformen gefüllt wird, in denen die Molke in Ruhe abfließen kann.
<G-vec00755-002-s027><drain.abfließen><en> cheese is a special cheese where the cheese jelly is filled into cheese forms by hand and where the whey can easily drain.
<G-vec00755-002-s028><drain.abfließen><de> Die Schnecke dreht sich dabei über einem Siebboden, sodass das entweichende Wasser durch diesen abfließen kann.
<G-vec00755-002-s028><drain.abfließen><en> The screw conveyor rotates above the screen bottom so that the escaping water can drain through it.
<G-vec00755-002-s029><drain.abfließen><de> Ein elektrisch ferngesteuertes EIN-AUS-Ventil sorgt für die Einspeisung in den Flüssigkeitskreislauf der Kupplung im EIN-Modus, und für ein rasches Abfließen des Öls durch Bohrungen an der Seite der Flüssigkeitskupplung im AUS-Modus.
<G-vec00755-002-s029><drain.abfließen><en> A remote electrically operated ON-OFF valve allows the fluid coupling circuit feed when turned ON and a rapid oil drain through orifices located on the periphery of the fluid coupling when turned OFF.
<G-vec00755-002-s030><drain.abfließen><de> Regen kann die Wirkung des Zauns beeinträchtigen deshalb bitte die Rasenkante etwas schräg, vom Beet nach außen, aufstellen so, dass der meiste Regen auf der Rückseite der Rasenkante abfließen kann und die Stromleitende Elemente trocken bleiben.
<G-vec00755-002-s030><drain.abfließen><en> Rain may affect the effect of the fence, so please place the lawn edge a bit diagonally, from the bed to the outside, so that most of the rain can drain off on the back of the lawn edge and the conductive elements remain dry.
<G-vec00755-002-s031><drain.abfließen><de> Die Molke kann abfließen.
<G-vec00755-002-s031><drain.abfließen><en> The whey can drain.
<G-vec00755-002-s032><drain.abfließen><de> Sie wirkt so Spritzwasser am Boden entgegen und sorgt auch dafür, dass Flüssigkeiten von der Armaturenbank abfließen.
<G-vec00755-002-s032><drain.abfließen><en> This prevents water from spilling onto the floor and ensures that liquids drain from the tap ledge.
<G-vec00755-002-s033><drain.abfließen><de> Hierbei muss das Abwasser nach einer Nassreinigung rückstandsfrei abfließen können und die Schweißnähte müssen durchweg spaltfrei ausgeführt sein.
<G-vec00755-002-s033><drain.abfließen><en> The waste water that results from wet cleaning must naturally be able to drain off without residue and the welding seams must all be free from gaps and crevices.
<G-vec00755-002-s034><drain.abfließen><de> Zum leichteren Reinigen befindet sich in der Bodenplatte eine kleine Öffnung, so dass Flüssigkeiten abfließen können.
<G-vec00755-002-s034><drain.abfließen><en> To facilitate cleaning there is a small opening in the foot plate to allow fluids to drain. Finish High-gloss galvanised
<G-vec00755-002-s035><drain.abfließen><de> Weil Flüssigkeiten abfließen können, vermeiden Sie mit diesen Industriematten auch Rutschunfälle.
<G-vec00755-002-s035><drain.abfließen><en> Because liquids can drain off, using these industrial mats will also help prevent accidents due to slipping.
<G-vec00755-002-s036><drain.abfließen><de> Dank der feinen Perforierung auf der Oberfläche kann Regenwasser einfach abfließen und bildet keine Pfützen.
<G-vec00755-002-s036><drain.abfließen><en> Due to the perforated seat, the back is also pleasantly ventilated in summer and rainwater can easily drain off.
<G-vec00755-002-s037><drain.abfließen><de> Anschließend wird ein Instrument benutzt, um die Öffnung des Tränenkanals zu weiten, damit die Tränenflüssigkeit wieder richtig abfließen kann.
<G-vec00755-002-s037><drain.abfließen><en> An instrument will be used to widen the opening of the tear duct so that the tears can drain properly through it.
<G-vec00755-002-s038><drain.abfließen><de> ② Entferne die Schlauchkappe und lass das Wasser abfließen.
<G-vec00755-002-s038><drain.abfließen><en> ② Remove the hose cap of the drain tube and drain off water
<G-vec00755-002-s039><drain.abfließen><de> Sie besitzen keinerlei Drainagelöcher und überschüssiges Wasser kann deshalb nicht schnell genug abfließen.
<G-vec00755-002-s039><drain.abfließen><en> They don’t have any holes, so excess water would not be able to drain quickly enough.
