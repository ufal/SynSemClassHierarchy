<G-vec00555-002-s012><displace.ausbooten><de> In den USA ist es dem rechten Demagogen Donald Trump gelungen, das republikanische Establishment auszubooten, während es der Linke Bernie Sanders nicht geschafft hat, die gemäßigte Hillary Clinton zu überrunden.
<G-vec00555-002-s012><displace.ausbooten><en> In the United States, the right-wing demagogue Donald Trump has managed to displace the Republican establishment, while the leftist Bernie Sanders was unable to overtake the centrist Hillary Clinton.
<G-vec00555-002-s010><oust.ausbooten><de> Statt zusammenzuarbeiten, versuchen sie sich auszubooten.
<G-vec00555-002-s010><oust.ausbooten><en> Instead of collaborating, they try to oust each other.
