<G-vec00078-001-s019><vote.abstimmen><de> Bis Ende März werden 13 weitere Ausschüsse ihre Inputs geben, Mitte April wird das Paper diskutiert und Anfang Mai im Handelsausschuss abgestimmt werden.
<G-vec00078-001-s019><vote.abstimmen><en> 13 other committees will provide their inputs before the end of March; the paper will be discussed mid-April and the Trade Committee will vote on it at the beginning of May.
<G-vec00078-001-s020><vote.abstimmen><de> Der Richtlinienvorschlag zur Konzessionsvergabe wird in den nächsten Tagen im Ausschuss für Binnenmarkt und Verbraucherschutz (IMCO) des Europäischen Parlaments abgestimmt.
<G-vec00078-001-s020><vote.abstimmen><en> The Internal Market and Consumer Protection Committee (IMCO) of the European Parliament will vote on the proposal for a Directive on the award of concession contracts within the next few days.
<G-vec00078-001-s021><vote.abstimmen><de> Das Protokoll eines Treffen des Audit-und Risiko-Komitees, das einen Interessenkonflikt aufzeigt, soll diesen widerspiegeln und aufzeigen, dass die betroffene Person nicht anwesend bei Besprechungen war und nicht über die Angelegenheit mit abgestimmt hat.
<G-vec00078-001-s021><vote.abstimmen><en> The minutes of any Audit and Risk Committee meeting where a conflict of interest has been disclosed shall reflect that the conflict of interest was disclosed and that the interested person was not present for deliberations and did not vote on the matter.
<G-vec00078-001-s022><vote.abstimmen><de> In diesem Fall wurde ein Text präsentiert als etwas, was er nie war, der in einer einzigen Ratssitzung in aller Kürze besprochen und danach auf zweifelhafte Weise abgestimmt wurde [14].
<G-vec00078-001-s022><vote.abstimmen><en> In this case, some parliaments and governments have expressed their disagreement with the text, which was presented as something it was not, was agreed upon in the fly, by a dubious vote[14] in a single Meeting of Ministers.
<G-vec00078-001-s023><vote.abstimmen><de> Nach der Sommerpause soll über den Bericht und Änderungsvorschläge im Ausschuss abgestimmt werden.
<G-vec00078-001-s023><vote.abstimmen><en> The Committee will vote on the Report and any Amendment Proposals after the summer recess.
<G-vec00078-001-s024><vote.abstimmen><de> Laut jetziger Zeitplanung soll im Oktober im Ausschuss über den Parlamentsbericht abgestimmt werden, das Votum im Plenum ist für Dezember 2012 geplant.
<G-vec00078-001-s024><vote.abstimmen><en> According to the current time schedule, the Committee will vote on the Parliamentary report in October; the vote in the plenum has been scheduled for December 2012.
<G-vec00078-001-s025><vote.abstimmen><de> Nach guter benediktinischer Tradition wurde nicht sofort abgestimmt.
<G-vec00078-001-s025><vote.abstimmen><en> But in good Benedictine tradition, the vote was not taken immediately.
<G-vec00078-001-s026><vote.abstimmen><de> Also wurde wieder abgestimmt, wie es in solchen Fällen in Children's World immer wieder geschieht.
<G-vec00078-001-s026><vote.abstimmen><en> So again we put the issue to a vote, as we used to do before in such cases in Children's World.
<G-vec00078-001-s027><vote.abstimmen><de> Zuerst die Einordnung, über was in dem Referendum abgestimmt wird.
<G-vec00078-001-s027><vote.abstimmen><en> First, the classification on which proposal the referendum's participants vote.
<G-vec00078-001-s028><vote.abstimmen><de> Mittels einer Befragung unter der Bevölkerung derjenigen Gemeinden, in denen über das Projekt abgestimmt wurde, wurden die Wahrnehmungen, Einstellungen und potenziellen Determinanten der Akzeptanz respektive Ablehnung der direkt betroffenen Bevölkerung im Hinblick auf das Projekt Parc Adula quantitativ untersucht.
<G-vec00078-001-s028><vote.abstimmen><en> By means of a survey among the population of the municipalities in which the project was subject to a vote; the perceptions, attitudes and potential determinants of acceptance or rejection of the directly affected population were quantitatively examined regarding the project Parc Adula.
<G-vec00078-001-s029><vote.abstimmen><de> Es wird schriftlich abgestimmt, wenn es die Versammlung so beschliesst.
<G-vec00078-001-s029><vote.abstimmen><en> Upon the decision of the General Meeting voting are by written vote.
<G-vec00078-001-s030><vote.abstimmen><de> Nachdem der Wähler abgestimmt hat, sendet ihm das System einen so genannten Verifikations-Code zurück.
<G-vec00078-001-s030><vote.abstimmen><en> Once the voter has cast his or her vote, the system sends back what is called a verification code.
<G-vec00078-001-s031><vote.abstimmen><de> Über alle anderen Fragen hat der Board nicht abgestimmt, da sie einer weiteren Erörterung bedürfen.
<G-vec00078-001-s031><vote.abstimmen><en> The Board did not vote on any other questions on grounds that they need further discussion.
<G-vec00078-001-s032><vote.abstimmen><de> Demnächst wird über die Verabschiedung der Gesetzesvorlage selbst abgestimmt.
<G-vec00078-001-s032><vote.abstimmen><en> Thus, in the near future a vote will be taken on the adoption of the bill itself.
<G-vec00078-001-s033><vote.abstimmen><de> Bereits im Dezember soll über die Änderungsvorschläge zu den Dienstleistungskonzessionen und zur öffentlichen Vergabe in den federführenden Ausschüssen abgestimmt werden.
<G-vec00078-001-s033><vote.abstimmen><en> The competent committees will vote on the amendment proposals for service concessions and public procurement as early as December.
<G-vec00078-001-s034><vote.abstimmen><de> Es wird durch Handzeichen abgestimmt.
<G-vec00078-001-s034><vote.abstimmen><en> A vote was taken by show of hands.
<G-vec00078-001-s035><vote.abstimmen><de> Wenn ihr zur Umfrage kommt und die Seite euch sagt, dass bereits jemand abgestimmt hat, war jemand mit eurer IP-Adresse schon vor euch auf der Seite.
<G-vec00078-001-s035><vote.abstimmen><en> When you visit the poll, if the page indicates a vote has already been made, then someone else at your IP address has visited the page before you.
<G-vec00078-001-s036><vote.abstimmen><de> Es kann jeden Tag einmal abgestimmt werden.
<G-vec00078-001-s036><vote.abstimmen><en> You can vote once every day.
<G-vec00078-001-s037><vote.abstimmen><de> Wenn noch niemand abgestimmt hat, können Nutzer (die die Umfrage erstellt haben) ihre Umfrage bearbeiten oder löschen.
<G-vec00078-001-s037><vote.abstimmen><en> If no one has cast a vote then users can delete the poll or edit any poll option.
<G-vec00078-001-s038><vote.abstimmen><de> So hatten zum Beispiel während des Referendums im März die meisten Ägypter keine Ahnung, was genau ihre Stimme bei der Abstimmung bewirken würde, beziehungsweise, über welche Änderungen der Verfassung sie nun zu welchem Zweck abstimmen sollten.
<G-vec00078-001-s038><vote.abstimmen><en> Take the March referendum for instance: most Egyptians had no clue what their vote would do or for what changes in the Constitution they should vote and why.
<G-vec00078-001-s039><vote.abstimmen><de> Gerade heute werden griechische Abgeordnete über dieses Thema abstimmen.
<G-vec00078-001-s039><vote.abstimmen><en> Just today, Greek MPs will vote on this issue.
<G-vec00078-001-s040><vote.abstimmen><de> Deine potenziellen und bereits bestehenden Kunden können dann für ihr Lieblingsprodukt abstimmen.
<G-vec00078-001-s040><vote.abstimmen><en> Your potential and existing customers get to vote for their favorite among a few different products.
<G-vec00078-001-s041><vote.abstimmen><de> Zu diesem Zweck, Aktionäre bei den jährlichen Hauptversammlungen abstimmen dürfen oder sogar gewählt als Direktor innerhalb des Unternehmens zu dienen, aber eine Obligationsinhaber kann nicht beides tun.
<G-vec00078-001-s041><vote.abstimmen><en> To this end, shareholders are permitted to vote at annual AGMs or even elected to serve as director within the company, but a debenture-holder cannot do both.
<G-vec00078-001-s042><vote.abstimmen><de> Sie können abstimmen, bis 17 oktober.
<G-vec00078-001-s042><vote.abstimmen><en> You can vote until 17 October.
<G-vec00078-001-s043><vote.abstimmen><de> Im September werden die MdEP ein weiteres Mal abstimmen, um entweder 1. das Mandat auf Basis des Gesetzentwurfs des Rechtsausschusses zu erteilen, 2. den Gesetzesvorschlag abzuändern oder 3. den Vorschlag vollständig zu verwerfen.
<G-vec00078-001-s043><vote.abstimmen><en> In September, MEPs will once again vote in plenary to either 1) confirm the mandate as proposed by the committee, 2) amend it, or 3) reject it entirely.
<G-vec00078-001-s044><vote.abstimmen><de> Wenn du dann voten kannst gibt es drei wesentliche Dinge zu beachten: Du kannst nur einmal am Tag für die gleiche Lady abstimmen, du kannst nicht für deine Lady selbst abstimmen und wenn eine Lady schon alle Preise in einem Wettbewerb gewonnen hat kannst du dort nicht mehr abstimmen bei dieser Lady.
<G-vec00078-001-s044><vote.abstimmen><en> When you are already able to vote, there are three main things you should remember – you can’t vote for one and the same lady more than once in a day, you can’t vote for yourself, and once a lady wins all the rewards in one of the contests, you won’t be able to vote for her for this contest.
<G-vec00078-001-s047><vote.abstimmen><de> Schon als großer Fan, sehe ich Raum in seinem Spiel zu wachsen und letztlich Ich denke, das ist, warum viele für Suter abstimmen wird.
<G-vec00078-001-s047><vote.abstimmen><en> Even as a huge fan, I see room to grow in his game and ultimately I think this is why many will vote for Suter.
<G-vec00078-001-s048><vote.abstimmen><de> Es soll nun über einen Vorschlag der Gläubiger abstimmen, der nicht mehr zur Debatte steht, weil es die Tsipras-Regierung versäumt hat ernsthafte Verhandlungen zu führen.
<G-vec00078-001-s048><vote.abstimmen><en> It is taking the Greek people hostage as it demands for a vote on a text that does not even exist, because it was unable to conclude negotiations correctly with its creditors.
<G-vec00078-001-s049><vote.abstimmen><de> Einfach wählen Sie Inhaltstyp Abstimmung x-mal zu entsperren und legen Sie dann total Nein Stimmen zu entsperren, das Bild oder die Url und die Einschränkung für einen Benutzer, die nicht, nach XX Minuten Stimmen wie derselbe Benutzer kann nicht noch einmal abstimmen, bis es die Beschränkung der Abstimmung erreicht.
<G-vec00078-001-s049><vote.abstimmen><en> Simple select content type vote x times to unlock and then set total no of votes to unlock the image or url and set the restriction for a user who cannot vote after XX minute like same user cannot vote again until it reaches the restriction limit of vote.
<G-vec00078-001-s050><vote.abstimmen><de> Nur anwesende Mitglieder können in Sitzungen der Generalversammlung abstimmen.
<G-vec00078-001-s050><vote.abstimmen><en> Only delegates attending the meeting of the General Assembly can vote.
<G-vec00078-001-s051><vote.abstimmen><de> Du kannst sie über diese Seite hören und abstimmen welche du am liebsten magst.
<G-vec00078-001-s051><vote.abstimmen><en> You can listem them from this page, and vote on them, to show us which of them is the best.
<G-vec00078-001-s052><vote.abstimmen><de> Auf der begleitenden Mitgliederversammlung, werden die Mitglieder über zwei Resolutionen abstimmen, die den Weg zu einem nachhaltigerem Europa weisen.
<G-vec00078-001-s052><vote.abstimmen><en> At the accompanying general assembly, members will vote on two key resolutions pointing the way toward a more sustainable Europe.
<G-vec00078-001-s053><vote.abstimmen><de> Wahlen finden regelmäßig statt, und die BÃ1⁄4rger Ã1⁄4ber 18 Jahren abstimmen.
<G-vec00078-001-s053><vote.abstimmen><en> Elections are regularly held, and citizens over 18 years of age may vote.
<G-vec00078-001-s054><vote.abstimmen><de> "Sehen Sie die aktuellen Ergebnisse einer Umfrage vor, die Sie abstimmen, indem Sie auf ""Ergebnisse Anzeigen"" - link."
<G-vec00078-001-s054><vote.abstimmen><en> You can see the current results for a poll before you vote by clicking the 'View Results' link.
<G-vec00078-001-s055><vote.abstimmen><de> Abstimmen heißt auswählen.
<G-vec00078-001-s055><vote.abstimmen><en> To vote is to choose.
<G-vec00078-001-s056><vote.abstimmen><de> Sie können für die beste Video-Präsentation auf der offiziellen Website der MITT Ausstellung abstimmen.
<G-vec00078-001-s056><vote.abstimmen><en> You can vote for the best video presentation on the official website of the MITT exhibition.
<G-vec00078-001-s090><vote.abstimmen><de> Neben den Lesern der AUTO ZEITUNG in Deutschland, Ã sterreich und in der Schweiz waren in den vergangenen Wochen auch die Leser der Bauer-Automotive-Titel in UK, Australien, Polen, Niederlande, Spanien, USA und Südafrika dazu aufgerufen, über die weltweit besten Autos aller Klassen in 15 Kategorien abzustimmen.
<G-vec00078-001-s090><vote.abstimmen><en> Aside from the readers of AUTO ZEITUNG in Germany, Austria and Switzerland, in recent weeks the readers of Bauer automotive magazines in the UK, Australia, Poland, the Netherlands, Spain, the USA and South Africa were also called upon to vote on the world's best automobiles of all classes in 15 categories.
<G-vec00078-001-s091><vote.abstimmen><de> Wir wären Ihnen sehr dankbar, wenn Sie sich die Zeit nehmen würden, um für uns abzustimmen.
<G-vec00078-001-s091><vote.abstimmen><en> We would be very grateful if you would take the time to cast your vote for us in your favourite category.
<G-vec00078-001-s092><vote.abstimmen><de> Einfach und ortsungebunden Befragungen durchführen Die Mobile Response-Mobile-App ermöglicht es, einfach und ortsungebunden über Entscheidungsvorschläge abzustimmen oder das Meinungsbild einer größeren Gruppe in sehr kurzer Zeit in Erfahrung zu bringen und unmittelbar graphisch darzustellen.
<G-vec00078-001-s092><vote.abstimmen><en> The Mobile Response App makes it possible to vote about proposals easily and without reference to location, or to gauge the opinion of a large group in a very short time and portray this directly in graphic form.Â
<G-vec00078-001-s093><vote.abstimmen><de> Wir leben in der Schweiz, wir haben das Recht für alles Mögliche abzustimmen, nutze diese Möglichkeit.
<G-vec00078-001-s093><vote.abstimmen><en> We live in Switzerland, we have the right to vote on all sorts of things, so use that possibility.
<G-vec00078-001-s094><vote.abstimmen><de> Nun, wir können beginnen, indem wir die Organisation von Volksentscheiden auf allen Ebenen der Gesellschaft unterstützen, sodass alle Menschen ihr Recht ausüben können, über globale, nationale, bundesstaatliche und lokale Anliegen abzustimmen.
<G-vec00078-001-s094><vote.abstimmen><en> Well, we can start by promoting the organization of people’s referendums at all levels of society, so all people can exercise their right to vote on world, national, state and local matters.
<G-vec00078-001-s095><vote.abstimmen><de> Die Hauptaufgabe der Abgeordnetenkammer besteht darin, über Gesetzentwürfe der Regierung oder eigene Gesetzesvorlagen abzustimmen .
<G-vec00078-001-s095><vote.abstimmen><en> The main function of the Chamber is to vote on government and parliament bills .
<G-vec00078-001-s096><vote.abstimmen><de> PK wahrscheinlich zu viele Schlagzeilen in dieser Saison aus anderen Gründen als sein Spiel auf dem Eis, die immer wirkt mit den Schriftstellern, die für diese Auszeichnungen abzustimmen.
<G-vec00078-001-s096><vote.abstimmen><en> PK probably made too many headlines this season for reasons other than his play on the ice, which always has an effect with the writers who vote for these awards.
<G-vec00078-001-s097><vote.abstimmen><de> """Die Leute in der Schweiz tendieren dazu, nicht einfach aus Wut oder zu ihrem eigenen Vorteil abzustimmen, sondern sind offener, ein Argument für das Gemeinwohl in Betracht zu ziehen."
<G-vec00078-001-s097><vote.abstimmen><en> """Swiss people tend not to only vote out of anger or just for their own benefit, but are more open to consider an argument regarding the common good,"" he said."
<G-vec00078-001-s098><vote.abstimmen><de> Beide großen Blöcke im irakischen Parlament verurteilten den Besuch und forderten eine Dringlichkeitssitzung, um sich über die Ausweisung von US-Truppen aus dem Land abzustimmen.
<G-vec00078-001-s098><vote.abstimmen><en> The two major blocs in the Iraqi parliament denounced the visit and called for an emergency session to vote on expelling US troops from the country.
<G-vec00078-001-s099><vote.abstimmen><de> "Um teilzunehmen und abzustimmen, es ist wirklich einfach: Finden Sie Ihre bevorzugte Plätze mit der Suchmaschine und sobald Sie es auf ""Vote"" klicken: Ihre ausgewählten Orten wird eine zusätzliche Stimme erhalten und Sie werden die Wahrscheinlichkeit von ihnen ist in dieser Seite aufgeführten erhöhen der Top zehn Hotels in [COMMUNITY]."
<G-vec00078-001-s099><vote.abstimmen><en> "To participate and vote, it's really simple: find your preferred places by using the search engine and once you find it click on ""Vote"": Your selected places will receive one additional vote and you will increase the likelihood of them being listed in this page of the Top ten Hotels in [COMMUNITY]."
<G-vec00078-001-s100><vote.abstimmen><de> Für die Möglichkeit, über etwas abzustimmen und ähnliches.
<G-vec00078-001-s100><vote.abstimmen><en> For the possibility to vote on something and the like.
<G-vec00078-001-s101><vote.abstimmen><de> Sie haben aber ein Verteidigungsmittel: bei den Gemeindewahlen abzustimmen; sie machen jedoch keinen Gebrauch davon, zur großen Erleichterung der jüdischen Extremisten.
<G-vec00078-001-s101><vote.abstimmen><en> They have a means of defence: to vote in the municipal elections; but they do not use it, to great relief of the Jewish extremists.
<G-vec00078-001-s102><vote.abstimmen><de> """Flüchtlinge, die in den Südsudan zurückkehren könnten sich dazu gezwungen sehen, bei einer zukünftigen Volksabstimmung über die umstrittenen Regionen zugunsten der Zentralregierung abzustimmen""."
<G-vec00078-001-s102><vote.abstimmen><en> """Refugees returning south could be convinced to vote for the government in a possible referendum on disputed border regions"" local source told Fides"
<G-vec00078-001-s103><vote.abstimmen><de> Der Vorsitzende schlug vor, zuerst einmal über die Frage wie im Papier gestellt abzustimmen.
<G-vec00078-001-s103><vote.abstimmen><en> The Chairman suggested, as a first instance, to vote on the question as posed in the paper.
<G-vec00078-001-s104><vote.abstimmen><de> Der Nactus Award 2007 wäre nicht so ein großer Erfolg gewesen, wenn diese tausenden von Menschen sich nicht die Zeit genommen hätten, um die Exo Terra Website zu besuchen und für ihr Lieblingsfoto abzustimmen.
<G-vec00078-001-s104><vote.abstimmen><en> The 2007 Nactus Award would not have been the huge success it was if it weren't for the thousands of people who took the time to visit the Exo Terra web site to view, and vote for, their favourite nominee.
<G-vec00078-001-s105><vote.abstimmen><de> Bisher konzentrierten wir unsere Initiative auf die Forderung, dass alle Bürger umgehend die Möglichkeit erhalten sollten, in einem Referendum über den Vertrag von Lissabon abzustimmen.
<G-vec00078-001-s105><vote.abstimmen><en> Previously, our headline campaign demanded that all citizens should immediately be given the opportunity to vote in referendums on the Lisbon Treaty.
<G-vec00078-001-s106><vote.abstimmen><de> Fast 90% glauben, dass die Politiker von der Korruption einen Nutzen haben und 18% sagen, ihnen sei Geld angeboten, um bei den Wahlen 2012 abzustimmen.
<G-vec00078-001-s106><vote.abstimmen><en> About 90% of citizens believe that politicians benefit from corruption, and 18% of respondents said that they were offered bribes to vote in elections held in May 2012.
<G-vec00078-001-s107><vote.abstimmen><de> Inzwischen jetzt meine Schwester aufgeregt, dass ich gehen kann und für ihre Schule das Budget abzustimmen, damit ihre Klasse ein Eis sozialen (lacht) gewinnen können.
<G-vec00078-001-s107><vote.abstimmen><en> Meanwhile, now my sister is excited I can go and vote for her school's budget so her class can win an ice cream social (laughs).
<G-vec00078-001-s108><vote.abstimmen><de> Danach werden wir schon sehr bald die Gelegenheit haben, darüber im Plenum abzustimmen.
<G-vec00078-001-s108><vote.abstimmen><en> After that, we will very soon have the chance to vote it in the plenary.
<G-vec00078-001-s229><vote.abstimmen><de> Über die Hälfte der libanesischen Bevölkerung lebt in Beirut, doch weniger als ein Viertel der Wahlberechtigten durften ihre Stimme in BeirutÂ abgeben.
<G-vec00078-001-s229><vote.abstimmen><en> Thus in Beirut, home of more than half the population, less than a fourth of eligible voters could vote without returning to their usually remote districts of origin.
<G-vec00078-001-s230><vote.abstimmen><de> – Ich habe nicht einmal eine Stimme abgeben.
<G-vec00078-001-s230><vote.abstimmen><en> – I did not vote even once.
<G-vec00078-001-s231><vote.abstimmen><de> Bitte beachten Sie, dass Sie nur eine Stimme abgeben können.
<G-vec00078-001-s231><vote.abstimmen><en> Please note that you may only vote once.
<G-vec00078-001-s232><vote.abstimmen><de> "„Wir wollen den Bürgern verständlich machen, dass sie vor den Herausforderungen nicht fliehen sondern sich ihnen mutig stellen sollen und zwar auf konkrete Weise durch eine auf Informationen basierende Stimmabgabe: wir müssen die Kandidaten und deren Parteien und Wahlprogramme kennen … und unsere Stimme verantwortungsvoll abgeben"", so Bischof Lira Rugarcía."
<G-vec00078-001-s232><vote.abstimmen><en> """The idea is to invite all to understand that we have to face challenges with courage, without escaping, but by participating, and doing it in a very concrete way: we need to know the candidates, parties, what they propose, in order to reflect and communicate well with the community, and then give a free and responsible vote"", said Mgr. Lira Rugarcía."
<G-vec00078-001-s233><vote.abstimmen><de> Die Einhaltung dieser Formalien soll dafür Sorge tragen, dass nur Wahlberechtigte wählen und dass diese auch nur einmal ihre Stimme abgeben können.
<G-vec00078-001-s233><vote.abstimmen><en> Compliance with these formalities should ensure, that select only eligible voters and that this also can vote only once.
<G-vec00078-001-s234><vote.abstimmen><de> Sie können für diese CDs hier Ihre Stimme abgeben.
<G-vec00078-001-s234><vote.abstimmen><en> To help these discs win, please cast your vote here.
<G-vec00078-001-s235><vote.abstimmen><de> Eure geschätzte Stimme könnt ihr nach wie vor hier abgeben.
<G-vec00078-001-s235><vote.abstimmen><en> Your much appreciated vote can still be given here.
<G-vec00078-001-s236><vote.abstimmen><de> Im Jahre 2001 kam der MuVi-Publikumspreis hinzu: Per Streaming kann man sich die nominierten Videos einen Monat lang ansehen und seine Stimme abgeben.
<G-vec00078-001-s236><vote.abstimmen><en> In 2001, a new MuVi Audience Prize was added. Each year, the nominated videos can be viewed for one month and users can vote for the best clip.
<G-vec00078-001-s237><vote.abstimmen><de> In diesem Fall enthält die Bescheinigung auf Grund der Erklärung des Stimmberechtigten die Ortschaft, in der er seine Stimme abgeben will.
<G-vec00078-001-s237><vote.abstimmen><en> In this case, the certificate contains on the grounds of the voter’s statement the settlement where he/she intends to vote.
<G-vec00078-001-s238><vote.abstimmen><de> Die an dieser Tapas-Route teilnehmt, kann für die besten Tapa stimmen und ihre Stimme abgeben in 31 teilnehmende Bars und Restaurants.
<G-vec00078-001-s238><vote.abstimmen><en> The public participating in this Tapas Route, will be able to vote for the best tapa stamping their vote in 31 of the participating bars and restaurants.
<G-vec00078-001-s239><vote.abstimmen><de> Jeder Mitarbeiter konnte pro Kategorie für jeweils eine Idee aus den fünf nominierten Ideen seine Stimme abgeben.
<G-vec00078-001-s239><vote.abstimmen><en> Each employee could vote for one idea per category from the five on each short list.
<G-vec00078-001-s240><vote.abstimmen><de> Vermutlich können sie eine intelligentere Stimme abgeben, wenn sie häufig Nachrichten Artikel über allgemeine Beamte oder die Ausgaben, die in politische Kampagnen angehoben werden lesen.
<G-vec00078-001-s240><vote.abstimmen><en> Presumably, they can cast a more intelligent vote if they often read news articles about public officials or issues raised in political campaigns.
<G-vec00078-001-s241><vote.abstimmen><de> Wir werden sehen, was in Zukunft passieren wird, denn die Zweifelnden werden auch dieses Mal ihre Stimme abgeben.
<G-vec00078-001-s241><vote.abstimmen><en> Let us see, what will happen in the future, because the fearful will vote again.
<G-vec00078-001-s242><vote.abstimmen><de> Mit diesem Infobrief möchten wir auch eine Stimme abgeben - vielleicht im Kontrast, dennoch nicht im Gegensatz zu dem, was im letzten Infobrief geschrieben wurde.
<G-vec00078-001-s242><vote.abstimmen><en> With this information letter we also want to give a vote – perhaps in contrast to, but not contrary to what has been written in the last letter. We now want to call for a campaign.
<G-vec00078-001-s243><vote.abstimmen><de> Es ist entscheidend, dass sich die Bürgerinnen und Bürger der Europäischen Union (EU) am demokratischen Prozess beteiligen und am Wahltag ihre Stimme abgeben.
<G-vec00078-001-s243><vote.abstimmen><en> It is essential that EU citizens participate in the democratic process through casting their vote on polling day.
<G-vec00078-001-s244><vote.abstimmen><de> 3 Millionen junge Menschen dürfen erstmals bei der Bundestagswahl ihre Stimme abgeben.
<G-vec00078-001-s244><vote.abstimmen><en> 3 million young people are entitled to vote for the first time in the Bundestag election.
<G-vec00078-001-s245><vote.abstimmen><de> Im Falle einer Stimmengleichheit wird der Tagungsleiter die entscheidende zusätzliche Stimme abgeben.
<G-vec00078-001-s245><vote.abstimmen><en> In case of a tie the person chairing the meeting will cast the deciding additional vote.
<G-vec00078-001-s246><vote.abstimmen><de> Bei der zweiten Abstimmung, wo es über die Abschaffung der Radio- und Fernsehgebühren ging, war ich in Bern und sehr froh, dass ich meine Stimme abgeben konnte.
<G-vec00078-001-s246><vote.abstimmen><en> For the second vote, which was on the abolition of the licence fee for public broadcasting, I was in Bern and I was very happy to be able to cast my vote.
<G-vec00078-001-s247><vote.abstimmen><de> Abwesende Mitglieder des Prüfungsausschusses können an der Beschlussfassung teilnehmen, indem sie eine schriftliche Stimmabgabe durch ein anderes Mitglied des Prüfungsausschusses überreichen lassen oder ihre Stimme fernmündlich oder mit Hilfe sonstiger Mittel der Telekommunikation abgeben.
<G-vec00078-001-s247><vote.abstimmen><en> Absent members of the Audit Committee may participate in a decision by submitting a written vote via another member of the Audit Committee or by casting a vote by telephone or other means of telecommunication.
<G-vec00250-002-s019><match.abstimmen><de> Die Venture Boxen sind zudem abgestimmt auf den Einsatz mit unserer neuen Horizon Mischpult-Serie.
<G-vec00250-002-s019><match.abstimmen><en> As a premium range product, the Venture cabs are a perfect system match for our new Horizon mixer range.
<G-vec00250-002-s020><match.abstimmen><de> Mit unseren In-Text-Links entdecken unsere User Produktangebote, die optimal auf Ihren Content abgestimmt sind.
<G-vec00250-002-s020><match.abstimmen><en> Our in-text links will help your readers discover the best product offers that match your content.
<G-vec00250-002-s021><match.abstimmen><de> Auf dieser Grundlage entwickeln wir Design und Layout der Website und verbessern ihren Content, damit das Angebot kontinuierlich besser auf die Interessen unserer Website-Benutzer abgestimmt wird.
<G-vec00250-002-s021><match.abstimmen><en> We monitor customer traffic patterns and site usage to help us develop the design and layout of the site, and to improve the content of our website to better match the interests of our website users.
<G-vec00250-002-s022><match.abstimmen><de> Astar Tintenpatronen sind auf die Anforderungen der jeweiligen Printer perfekt abgestimmt.
<G-vec00250-002-s022><match.abstimmen><en> Astar ink cartridges perfectly match the requirements of any printer.
<G-vec00250-002-s023><match.abstimmen><de> In die neuen Kits – farblich abgestimmt auf die SWISS Kabinenumgebung – integrierten die Designer Teile von Flugzeug-Sitzgurten.
<G-vec00250-002-s023><match.abstimmen><en> For the new SWISS amenity kits, which are coloured to match the cabin décor, the designers have also incorporated elements of the inflight seat belt.
<G-vec00250-002-s024><match.abstimmen><de> Vom schlichten, natürlichen Aussehen bis hin zu verblüffenden Spiegel- und Linseneffekten: Wir verfügen über ein ganzes Arsenal an Etikettendrucktechniken, die auf Ihre Marke und Ziele abgestimmt sind.
<G-vec00250-002-s024><match.abstimmen><en> From simply natural looks to stunning mirror and lense effects, we have a full arsenal of label printing techniques to match your brand and your goals.
<G-vec00250-002-s025><match.abstimmen><de> • Kindgerechte Proportionen abgestimmt auf die motorischen Fähigkeiten der empfohlenen Altersklasse.
<G-vec00250-002-s025><match.abstimmen><en> • An appropriate size to match the level of motor skills of a child in the recommended age range.
<G-vec00250-002-s026><match.abstimmen><de> Glatter, bequemer Kragen, der auf die Konturen des Halses abgestimmt ist.
<G-vec00250-002-s026><match.abstimmen><en> Smooth, comfortable collar designed to match the contours of the neck and provide a great seal and feel.
<G-vec00250-002-s027><match.abstimmen><de> Diese Schlüsselhülle aus hochwertigem weissen Leder ist exklusiv auf die Innenausstattung Ihres Volvo abgestimmt.
<G-vec00250-002-s027><match.abstimmen><en> This key fob shell in high-quality white leather is exclusively designed to match the interior of your Volvo.
<G-vec00250-002-s028><match.abstimmen><de> Für ein perfektes Arrangement sollten auch die grünen Protagonisten aufeinander abgestimmt sein.
<G-vec00250-002-s028><match.abstimmen><en> For a perfect arrangement, the herbs should also match each other.
<G-vec00250-002-s029><match.abstimmen><de> Durch Edge-Blending und Skalierung werden die Projektionen perfekt in Helligkeit und Farbe aufeinander abgestimmt, ohne sichtbare Übergänge zu erzeugen.
<G-vec00250-002-s029><match.abstimmen><en> Edge blending and scaling perfectly match each image in terms of brightness and colour, with no visible joins.
<G-vec00250-002-s030><match.abstimmen><de> Erstellen Sie schnell faire und zuverlässige Dienstpläne, die auf Ihre Geschäftsabläufe abgestimmt sind.
<G-vec00250-002-s030><match.abstimmen><en> Quickly create fair, reliable and intelligent schedules optimized to match your business practices.
<G-vec00250-002-s031><match.abstimmen><de> Dieses Sweatshirt mit Rundhalsausschnitt präsentiert sich in einem edlen Gemisch aus Baumwolle, Seide und Kaschmir und verfügt über einen kontrastfarbenen Kragen und farbige Akzente im Rippenbereich, die auf die emblematische Louis Vuitton Stickerei abgestimmt sind.
<G-vec00250-002-s031><match.abstimmen><en> Writing Books this crew neck sweater features a contrasting collar and highlights on the ribs that match Louis Vuitton's emblematic embroidery.
<G-vec00250-002-s032><match.abstimmen><de> Unsere durchdachten und bewährten Organisationsstrukturen mit Projektleitern und eingespielten Arbeitsgruppen erlauben uns eine flexible Ressourcenplanung, die genau auf das jeweilige Bauvorhaben abgestimmt ist.
<G-vec00250-002-s032><match.abstimmen><en> Our carefully thought-out and proven organisational structure with project managers and well-coordinated work groups enables us to plan resources flexibly and match them perfectly with the construction project in question.
<G-vec00250-002-s033><match.abstimmen><de> Die Einstiegsversionen sind preislich auf die Kosten von ein oder zwei Gesangsstunden abgestimmt und sind für Gesangs- und Instrumentalübungen gedacht.
<G-vec00250-002-s033><match.abstimmen><en> The entry-level editions are priced to match the cost of one or two voice lessons and are intended for vocal and instrumental practice.
<G-vec00250-002-s034><match.abstimmen><de> Es wird perfekt mit Trikots in der gleichen Farbe abgestimmt.
<G-vec00250-002-s034><match.abstimmen><en> It will perfectly match with the leotards in the same color.
<G-vec00250-002-s035><match.abstimmen><de> Die Treppenstufen sind in Farbton und Struktur auf unsere Naturholzböden abgestimmt und ergeben ein harmonisches Erscheinungsbild.
<G-vec00250-002-s035><match.abstimmen><en> The stairs match our natural wood floors in terms of both colour and structure to create a harmonious visual appearance.
<G-vec00250-002-s036><match.abstimmen><de> Das gesis® IP+ System ist genau auf diese rauen Anforderungen abgestimmt.
<G-vec00250-002-s036><match.abstimmen><en> The gesis® IP+ system is the perfect match to these rugged
<G-vec00250-002-s037><match.abstimmen><de> Ob Sie nun bereits ein iGrafx-Kunde sind, oder einfach nur von unserer prämierten Software gehört haben und gerne wissen möchten, wie Sie diese nutzen könnten, unsere Berater erarbeiten Lösungen für Sie, die auf Ihre Projekte und Ziele abgestimmt sind und die Sie in Ihrem Unternehmen nachgestalten und nutzen können.
<G-vec00250-002-s037><match.abstimmen><en> Whether you are an existing iGrafx customer or have heard about our award- winning software and would like to see how it can improve what you do, our consultants match your projects and goals to solutions you can re-create and deploy throughout your company. Custom Modeling Assistance Custom Solutions
<G-vec00260-002-s023><insure.abstimmen><de> Wir achten hierbei darauf, dass die Komponenten optimal aufeinander abgestimmt sind, um bestmögliche Ergebnisse zu erzielen.
<G-vec00260-002-s023><insure.abstimmen><en> We make sure that all equipment fits together in order to insure best possible results.
<G-vec00318-002-s019><align.abstimmen><de> Genau so wichtig sind Datenschutzstandards, die auf die Unternehmensziele und Kundenerwartungen abgestimmt sind.
<G-vec00318-002-s019><align.abstimmen><en> Then they need to develop privacy standards that align with their business goals and customer expectations.
<G-vec00318-002-s020><align.abstimmen><de> Dadurch wird die Performance der Gebotsanpassungen von Anzeigenzeitplänen erhöht, da sie besser auf den Zeitpunkt des Klicks abgestimmt werden können, anstatt den Abschluss zugrunde zu legen.
<G-vec00318-002-s020><align.abstimmen><en> This will improve the performance of ad schedule bid modifiers, as they align better to the time of the click, instead of the conversion.
<G-vec00318-002-s021><align.abstimmen><de> Mit den Vorschriften von IFRS 17 «Versicherungsverträge» wird die Darstellung von Erlösen auf jene anderer Branchen abgestimmt.
<G-vec00318-002-s021><align.abstimmen><en> Requirements in IFRS 17 Insurance Contracts align the presentation of revenue with other industries.
<G-vec00318-002-s022><align.abstimmen><de> Passen Sie die Farben mit der Benutzer-LUT (Lookup-Tabelle) an, abrufbar über die Dell UltraSharp Farbkalibrierungssoftware, für hoch präzise Farbdarstellung, die perfekt auf den Dell UltraSharp 32 Monitor abgestimmt ist.
<G-vec00318-002-s022><align.abstimmen><en> Customize colors with the user LUT (look-up table), accessible via the Dell UltraSharp Color Calibration Solution software, for precise colors that align perfectly on the Dell UltraSharp 32 Monitor.
<G-vec00250-003-s019><match_up.abstimmen><de> Die Venture Boxen sind zudem abgestimmt auf den Einsatz mit unserer neuen Horizon Mischpult-Serie.
<G-vec00250-003-s019><match_up.abstimmen><en> As a premium range product, the Venture cabs are a perfect system match for our new Horizon mixer range.
<G-vec00250-003-s020><match_up.abstimmen><de> Mit unseren In-Text-Links entdecken unsere User Produktangebote, die optimal auf Ihren Content abgestimmt sind.
<G-vec00250-003-s020><match_up.abstimmen><en> Our in-text links will help your readers discover the best product offers that match your content.
<G-vec00250-003-s021><match_up.abstimmen><de> Auf dieser Grundlage entwickeln wir Design und Layout der Website und verbessern ihren Content, damit das Angebot kontinuierlich besser auf die Interessen unserer Website-Benutzer abgestimmt wird.
<G-vec00250-003-s021><match_up.abstimmen><en> We monitor customer traffic patterns and site usage to help us develop the design and layout of the site, and to improve the content of our website to better match the interests of our website users.
<G-vec00250-003-s022><match_up.abstimmen><de> Astar Tintenpatronen sind auf die Anforderungen der jeweiligen Printer perfekt abgestimmt.
<G-vec00250-003-s022><match_up.abstimmen><en> Astar ink cartridges perfectly match the requirements of any printer.
<G-vec00250-003-s023><match_up.abstimmen><de> In die neuen Kits – farblich abgestimmt auf die SWISS Kabinenumgebung – integrierten die Designer Teile von Flugzeug-Sitzgurten.
<G-vec00250-003-s023><match_up.abstimmen><en> For the new SWISS amenity kits, which are coloured to match the cabin décor, the designers have also incorporated elements of the inflight seat belt.
<G-vec00250-003-s024><match_up.abstimmen><de> Vom schlichten, natürlichen Aussehen bis hin zu verblüffenden Spiegel- und Linseneffekten: Wir verfügen über ein ganzes Arsenal an Etikettendrucktechniken, die auf Ihre Marke und Ziele abgestimmt sind.
<G-vec00250-003-s024><match_up.abstimmen><en> From simply natural looks to stunning mirror and lense effects, we have a full arsenal of label printing techniques to match your brand and your goals.
<G-vec00250-003-s025><match_up.abstimmen><de> • Kindgerechte Proportionen abgestimmt auf die motorischen Fähigkeiten der empfohlenen Altersklasse.
<G-vec00250-003-s025><match_up.abstimmen><en> • An appropriate size to match the level of motor skills of a child in the recommended age range.
<G-vec00250-003-s026><match_up.abstimmen><de> Glatter, bequemer Kragen, der auf die Konturen des Halses abgestimmt ist.
<G-vec00250-003-s026><match_up.abstimmen><en> Smooth, comfortable collar designed to match the contours of the neck and provide a great seal and feel.
<G-vec00250-003-s027><match_up.abstimmen><de> Diese Schlüsselhülle aus hochwertigem weissen Leder ist exklusiv auf die Innenausstattung Ihres Volvo abgestimmt.
<G-vec00250-003-s027><match_up.abstimmen><en> This key fob shell in high-quality white leather is exclusively designed to match the interior of your Volvo.
<G-vec00250-003-s028><match_up.abstimmen><de> Für ein perfektes Arrangement sollten auch die grünen Protagonisten aufeinander abgestimmt sein.
<G-vec00250-003-s028><match_up.abstimmen><en> For a perfect arrangement, the herbs should also match each other.
<G-vec00250-003-s029><match_up.abstimmen><de> Durch Edge-Blending und Skalierung werden die Projektionen perfekt in Helligkeit und Farbe aufeinander abgestimmt, ohne sichtbare Übergänge zu erzeugen.
<G-vec00250-003-s029><match_up.abstimmen><en> Edge blending and scaling perfectly match each image in terms of brightness and colour, with no visible joins.
<G-vec00250-003-s030><match_up.abstimmen><de> Erstellen Sie schnell faire und zuverlässige Dienstpläne, die auf Ihre Geschäftsabläufe abgestimmt sind.
<G-vec00250-003-s030><match_up.abstimmen><en> Quickly create fair, reliable and intelligent schedules optimized to match your business practices.
<G-vec00250-003-s031><match_up.abstimmen><de> Dieses Sweatshirt mit Rundhalsausschnitt präsentiert sich in einem edlen Gemisch aus Baumwolle, Seide und Kaschmir und verfügt über einen kontrastfarbenen Kragen und farbige Akzente im Rippenbereich, die auf die emblematische Louis Vuitton Stickerei abgestimmt sind.
<G-vec00250-003-s031><match_up.abstimmen><en> Writing Books this crew neck sweater features a contrasting collar and highlights on the ribs that match Louis Vuitton's emblematic embroidery.
<G-vec00250-003-s032><match_up.abstimmen><de> Unsere durchdachten und bewährten Organisationsstrukturen mit Projektleitern und eingespielten Arbeitsgruppen erlauben uns eine flexible Ressourcenplanung, die genau auf das jeweilige Bauvorhaben abgestimmt ist.
<G-vec00250-003-s032><match_up.abstimmen><en> Our carefully thought-out and proven organisational structure with project managers and well-coordinated work groups enables us to plan resources flexibly and match them perfectly with the construction project in question.
<G-vec00250-003-s033><match_up.abstimmen><de> Die Einstiegsversionen sind preislich auf die Kosten von ein oder zwei Gesangsstunden abgestimmt und sind für Gesangs- und Instrumentalübungen gedacht.
<G-vec00250-003-s033><match_up.abstimmen><en> The entry-level editions are priced to match the cost of one or two voice lessons and are intended for vocal and instrumental practice.
<G-vec00250-003-s034><match_up.abstimmen><de> Es wird perfekt mit Trikots in der gleichen Farbe abgestimmt.
<G-vec00250-003-s034><match_up.abstimmen><en> It will perfectly match with the leotards in the same color.
<G-vec00250-003-s035><match_up.abstimmen><de> Die Treppenstufen sind in Farbton und Struktur auf unsere Naturholzböden abgestimmt und ergeben ein harmonisches Erscheinungsbild.
<G-vec00250-003-s035><match_up.abstimmen><en> The stairs match our natural wood floors in terms of both colour and structure to create a harmonious visual appearance.
<G-vec00250-003-s036><match_up.abstimmen><de> Das gesis® IP+ System ist genau auf diese rauen Anforderungen abgestimmt.
<G-vec00250-003-s036><match_up.abstimmen><en> The gesis® IP+ system is the perfect match to these rugged
<G-vec00250-003-s037><match_up.abstimmen><de> Ob Sie nun bereits ein iGrafx-Kunde sind, oder einfach nur von unserer prämierten Software gehört haben und gerne wissen möchten, wie Sie diese nutzen könnten, unsere Berater erarbeiten Lösungen für Sie, die auf Ihre Projekte und Ziele abgestimmt sind und die Sie in Ihrem Unternehmen nachgestalten und nutzen können.
<G-vec00250-003-s037><match_up.abstimmen><en> Whether you are an existing iGrafx customer or have heard about our award- winning software and would like to see how it can improve what you do, our consultants match your projects and goals to solutions you can re-create and deploy throughout your company. Custom Modeling Assistance Custom Solutions
<G-vec00425-002-s083><coordinate.abstimmen><de> E-Health erleichtert beispielsweise den Informationsaustausch zwischen medizinischen Akteuren, sodass Vorsorge, Diagnose und Behandlungen besser und schneller aufeinander abgestimmt werden können.
<G-vec00425-002-s083><coordinate.abstimmen><en> They facilitate the exchange of information between healthcare professionals, thus making it easier and faster for them to coordinate preventive care, diagnoses and treatments.
<G-vec00425-002-s084><coordinate.abstimmen><de> Dazu gehört sowohl die nachhaltigere Nutzung von Ressourcen, indem Verkehrsflüsse durch intelligente Systeme aufeinander abgestimmt werden oder auch die Digitalisierung von Bürgerdiensten, so dass Services, für die bisher eine persönliche Vorsprache notwendig war, zukünftig auch online durchgeführt werden können.
<G-vec00425-002-s084><coordinate.abstimmen><en> That includes making more sustainable use of resources by deploying intelligent systems to coordinate traffic flows or digitizing public services so that residents can use them online instead of having to visit officials in person.
<G-vec00425-002-s085><coordinate.abstimmen><de> Denn um die gestellte Aufgabe der Personensuche zu meistern, müssen Hund & Mensch gut aufeinander abgestimmt zusammenarbeiten.
<G-vec00425-002-s085><coordinate.abstimmen><en> Because in order to master the task of searching for people, dog & man must coordinate working well together.
<G-vec00425-002-s086><coordinate.abstimmen><de> Wir bieten Ihnen Gesamtlösungen aus einer Hand und geben Ihnen so die Sicherheit, dass alle Komponenten aufeinander abgestimmt sind.
<G-vec00425-002-s086><coordinate.abstimmen><en> PSG offers you holistic solutions from one source, which guarantees that all components coordinate.
<G-vec00499-002-s019><complement.abstimmen><de> Pflege Die erfolgreiche Kultivierung von Chinaschilf basiert auf einem Geflecht von Pflegemaßnahmen, die aufeinander abgestimmt sind.
<G-vec00499-002-s019><complement.abstimmen><en> Care The successful cultivation of Miscanthus sinensis, Chinese silver grass is based on a mesh of care measures which complement each other.
<G-vec00499-002-s020><complement.abstimmen><de> MEHR ENTDECKEN Ein erfrischendes Hautpflegeprodukt von BOSS, das speziell auf die Bedürfnisse der männlichen Haut abgestimmt ist.
<G-vec00499-002-s020><complement.abstimmen><en> Complement the A refreshing skincare product from BOSS, specially designed to meet the specific requirements of men’s skin.
<G-vec00499-002-s021><complement.abstimmen><de> Die Oberflächen-Veredelungen Mocha Finish und Dark Chestnut sind harmonisch aufeinander abgestimmt.
<G-vec00499-002-s021><complement.abstimmen><en> The Mocha Finish and Dark Chestnut options complement each other perfectly.
<G-vec00499-002-s022><complement.abstimmen><de> Originalteile von FG Wilson sind perfekt auf die anderen Komponenten in Ihrem Stromaggregat abgestimmt; sie optimieren die Produktleistung, den Kraftstoffverbrauch und die Lebensdauer.
<G-vec00499-002-s022><complement.abstimmen><en> FG Wilson Genuine Parts are designed to complement the other components of your generator set, optimising product performance, fuel efficiency and life span.
<G-vec00499-002-s023><complement.abstimmen><de> Zehnder Zenia ist in klassischem Weiß und edlem Schwarz erhältlich und damit ideal auf die aktuellen Farbwelten der großen Badkeramik-Hersteller abgestimmt.
<G-vec00499-002-s023><complement.abstimmen><en> Zehnder Zenia is available in classic white and sophisticated black, making it the perfect complement to the contemporary colour schemes produced by major bathroom ceramics manufacturers.
<G-vec00499-002-s024><complement.abstimmen><de> Darüber hinaus sind alle Küchen-Einbaugeräte der neuen Generation 5000 hinsichtlich Design und Bedienkomfort perfekt aufeinander abgestimmt.
<G-vec00499-002-s024><complement.abstimmen><en> Additionally, all new Generation 5000 built-in kitchen appliances complement each other perfectly in terms of design and ease of use.
<G-vec00499-002-s025><complement.abstimmen><de> Leicht zu befüllen und abgestimmt auf die Eingabestation wird das Entleeren zur Leichtigkeit für Ihre Mitarbeiter.
<G-vec00499-002-s025><complement.abstimmen><en> Easy to fill and a perfectly complement the input station, emptying waste is made easy for your employees.
<G-vec00020-002-s019><vote.abstimmen><de> Danach wird in den einzelnen Ländern abgestimmt, und es findet jeweils eine Talkshow statt.
<G-vec00020-002-s019><vote.abstimmen><en> Afterwards, the individual countries will vote and the play will be discussed in a talk show.
<G-vec00020-002-s020><vote.abstimmen><de> Aber das Gefährlichste ist, wenn sie nicht mal mehr zu den Wahlen kommen; wie die jungen Menschen im Vereinigten Königreich, die das Brexit-Referendum verloren haben, weil sie nicht abgestimmt haben.
<G-vec00020-002-s020><vote.abstimmen><en> But the most dangerous thing is when they no longer come to the ballot boxes like the young people in the UK which lost Brexit because they did not vote.
<G-vec00020-002-s021><vote.abstimmen><de> Am Ende wird in der Gruppe das Gewinnerteam abgestimmt.
<G-vec00020-002-s021><vote.abstimmen><en> In the end, the group will vote the winning team.
<G-vec00020-002-s022><vote.abstimmen><de> Nach den vorgezogenen Wahlen soll im Juni im Europäischen Parlament über eine Entschließung zum Kosovo-Bericht 2016 abgestimmt werden.
<G-vec00020-002-s022><vote.abstimmen><en> In June, following the early election in Kosovo, the European Parliament is due to vote on a resolution on Kosovo's 2016 report.
<G-vec00020-002-s023><vote.abstimmen><de> Es wird mit einfacher Mehrheit abgestimmt.
<G-vec00020-002-s023><vote.abstimmen><en> Decisions by vote require a simple majority.
<G-vec00020-002-s024><vote.abstimmen><de> Im März 1946 wurde vom IOC per Briefwahl die Vergabe für 1948 abgestimmt, wobei London für die Sommer- und St. Moritz für die Winterspiele als Sieger hervorgingen.
<G-vec00020-002-s024><vote.abstimmen><en> In May 1946 the IOC, through a postal vote, gave the summer Games to London and the winter competition to St Moritz.
<G-vec00020-002-s025><vote.abstimmen><de> „Wir danken allen Lesern, die beim Worldofparks-Award für den HANSA-PARK, Deutschlands einzigen Erlebnis-und Themenpark am Meer abgestimmt haben.
<G-vec00020-002-s025><vote.abstimmen><en> “Our heartfelt thanks go to all readers who supported HANSA-PARK, Germany’s only event and theme park by the sea, in the World of Parks Award vote.
<G-vec00020-002-s027><vote.abstimmen><de> Zu gewinnen gibt es Preise zwischen 100 und 300 Euro sowie einen Publikumspreis, über den im Juni online abgestimmt werden kann.
<G-vec00020-002-s027><vote.abstimmen><en> There will be prizes between 100 and 300 Euro as well as a public's choice award on which you are invited to vote online in June.
<G-vec00020-002-s028><vote.abstimmen><de> Damyan Ivanov Bittet die DAMs, die Änderungen zu verschieben, bis abgestimmt oder Konsens erreicht wurde.
<G-vec00020-002-s028><vote.abstimmen><en> Choice 1: Ask the DAMs to postpone the changes until vote or consensus.
<G-vec00020-002-s029><vote.abstimmen><de> Es wird noch am ersten Tag einstimmig abgestimmt.
<G-vec00020-002-s029><vote.abstimmen><en> The members of the Duma will vote on the first day unanimously.
<G-vec00020-002-s030><vote.abstimmen><de> Allerdings haftet solchen Referenden zumindest der Beigeschmack von Demokratiebeugung an, da über eine Frage offenbar so lange abgestimmt wird, bis das Resultat mit den Vorstellungen der politischen Eliten übereinstimmt.
<G-vec00020-002-s030><vote.abstimmen><en> However, such referendums are considered to be at least close to bending democracy as voters seem to be demanded to vote on an issue until the result is in line with political elites’ preferences.
<G-vec00020-002-s031><vote.abstimmen><de> Er hatte so abgestimmt, auf die Art, wie seines Wissens sein Volk abgestimmt hätte.
<G-vec00020-002-s031><vote.abstimmen><en> He had voted that way, the way he knew his own people would vote.
<G-vec00020-002-s032><vote.abstimmen><de> In der abschließenden öffentlichen Voting-Phase konnte dann für den Siegernamen abgestimmt werden.
<G-vec00020-002-s032><vote.abstimmen><en> In the final round of the campaign, a shortlist of three favorites was put to the public vote.
<G-vec00020-002-s034><vote.abstimmen><de> Sollten die Räumlichkeiten nicht für alle Gruppen genügend Platz bieten, wird abgestimmt.
<G-vec00020-002-s034><vote.abstimmen><en> If we do not have enough space to cater for all groups, we might have to vote.
<G-vec00020-002-s035><vote.abstimmen><de> d) hat das Parlament über die Änderungsanträge zum Standpunkt des Rates abgestimmt, kann eine weitere Abstimmung über den Text in seiner Gesamtheit nur gemäß Artikel 68 Absatz 2 erfolgen.
<G-vec00020-002-s035><vote.abstimmen><en> (d) where Parliament has held a vote with a view to amending the Council's position, a further vote on the text as a whole may only be taken in accordance with Rule 68(2).
<G-vec00020-002-s037><vote.abstimmen><de> Anschließend wird abgestimmt, welche Antwort die beste war, und die Person mit den meisten Stimmen pro Runde erhält einen Punkt.
<G-vec00020-002-s037><vote.abstimmen><en> The other guests must then vote which was the best answer, and the person with the most votes per round scores one point.
<G-vec00020-002-s038><vote.abstimmen><de> Plebiszite, die mit der Absicht veranstaltet werden, die Herrschaft von Tyrannen zu bestätigen, funktionieren besonders gut, wenn die Bürger voneinander getrennt werden können; aber eine nachdenkliche Demokratie verlangt, daß die Bürger öffentlich abstimmen und gewillt sind, ihre Position in einer öffentlichen Versammlung zu verteidigen (oder daß sie wenigstens in der Öffentlichkeit abstimmen, um irgendeine Form öffentlicher Kontrolle zu spüren).
<G-vec00020-002-s038><vote.abstimmen><en> Plebiscites intended to ratify the rule of tyrants work particularly well when citizens can be separated from one another; but deliberative democracy demands that citizens vote in public, and remain willing to defend their position in a public assembly (or at least vote in public where they can feel some sense of public scrutiny).
<G-vec00020-002-s039><vote.abstimmen><de> Das Europäische Parlament soll auf seiner Plenarsitzung im Dezember über das Übereinkommen abstimmen.
<G-vec00020-002-s039><vote.abstimmen><en> The European Parliament is scheduled to vote on the agreement during its plenary session in December.
<G-vec00020-002-s040><vote.abstimmen><de> Sollte es erneut abgelehnt werden, soll das Parlament zwei Tage später über eine Verschiebung des Austritts abstimmen, um einen ungeregelten Brexit zu vermeiden.
<G-vec00020-002-s040><vote.abstimmen><en> If the deal is rejected the parliament is to vote two days later on postponing the country's exit from the EU in order to avoid a disorderly Brexit.
<G-vec00020-002-s041><vote.abstimmen><de> Zwölf Tage lang konnten die Facebook-Fans über die schönsten Designs abstimmen.
<G-vec00020-002-s041><vote.abstimmen><en> You've voted! Twelve days the facebook fans could vote on the best designs.
<G-vec00020-002-s042><vote.abstimmen><de> Dies würde ich hier in der Umfrage abstimmen lassen.
<G-vec00020-002-s042><vote.abstimmen><en> I would let this vote here in the poll.
<G-vec00020-002-s043><vote.abstimmen><de> Keine Eintragung zur Wahlteilnahme im Heimatland Nicht belgische Unionsbürgerinnen und -bürger sollten sich an ihre belgische Wohnsitzgemeinde wenden, um den Behörden mitzuteilen, wo sie bei den Wahlen zum Europäischen Parlament abstimmen werden.
<G-vec00020-002-s043><vote.abstimmen><en> To inform the authorities where they will vote for European Parliament elections, foreign EU citizens should contact.................
<G-vec00020-002-s044><vote.abstimmen><de> In den kommenden Monaten wird das Repräsentantenhaus über eine Gesetzesvorlage abstimmen, die die Angriffe der Bundesregierung auf Patienten in Staaten mit medizinischen Cannabisgesetzen beenden würde.
<G-vec00020-002-s044><vote.abstimmen><en> In the coming months, the House of Representatives will vote on an amendment that would end the federal government's attacks on patients in states with medical cannabis laws.
<G-vec00020-002-s045><vote.abstimmen><de> Im neuen Monat können Sie wieder von neuem abstimmen und Ihr Lieblingsplakat zum APG|SGA Poster of the Month wählen.
<G-vec00020-002-s045><vote.abstimmen><en> Place 2: Interprofession du month you can vote once again and vote for your favourite poster to become APG|SGA Poster of the Month.
<G-vec00020-002-s046><vote.abstimmen><de> Da die Angelegenheit in die Zuständigkeit des Rats fällt, muss der Kongress nicht mehr darüber abstimmen.
<G-vec00020-002-s046><vote.abstimmen><en> As a consequence, the Congress will not need to vote on this item, since it falls under the competence of the Council.
<G-vec00020-002-s047><vote.abstimmen><de> Sie können persönlich bei einem Wahllokal, per Fax, per Post oder - und das ist in diesem Jahr neu - per Internet abstimmen.
<G-vec00020-002-s047><vote.abstimmen><en> They can go to a polling center, vote by fax, by mail – and new this year – they can vote via the internet.
<G-vec00020-002-s048><vote.abstimmen><de> Ein effizientes System dafür ist ein Zeitplan für jeden Schritt der Konsultation: Es ermöglicht Transparenz in Bezug auf den Entscheidungsprozess sowie die Definition von Zeiträumen, in denen die Bürger gemäß Ihrer Agenda diskutieren, abstimmen und Ideen austauschen können .
<G-vec00020-002-s048><vote.abstimmen><en> An efficient system for this is a timeline of each steps of the consultation: it allows transparency regarding the decision-making process, as well as the definition of periods of time when the citizens can discuss, vote, and share ideas, according to your agenda.
<G-vec00020-002-s049><vote.abstimmen><de> Arbeiter und Jugendliche, aber auch die über 450.000 SPD-Mitglieder, die in den kommenden Wochen über den Koalitionsvertrag abstimmen, haben ein Recht zu wissen, was genau vereinbart wurde.
<G-vec00020-002-s049><vote.abstimmen><en> Workers and young people, but also the over 450,000 SPD members who are due to vote on the coalition pact in the coming weeks, have a right to know exactly what was agreed.
<G-vec00020-002-s051><vote.abstimmen><de> Gut zwei Wochen vor Afghanistans nächsten Wahlen fragen sich viele Afghanen immer noch, worüber genau sie abstimmen und ob alle von ihnen die Chance dazu haben werden.
<G-vec00020-002-s051><vote.abstimmen><en> With just over a fortnight to go for Afghanistan’s next election, many Afghans are still wondering what exactly they will vote for and whether all of them will.
<G-vec00020-002-s052><vote.abstimmen><de> "Die Schweiz ist das einzige Land weltweit, wo man über eine utopische Idee abstimmen kann", sagt er.
<G-vec00020-002-s052><vote.abstimmen><en> “”Switzerland is the only country in the world where you can have a vote about an utopian idea,” he says.
<G-vec00020-002-s053><vote.abstimmen><de> Nur diejenigen Mitglieder des IRBs / der unabhangigen Ethik-Kommission, die von Prufer und Sponsor der klinischen Prufung unabhangig sind, sollten in prufungsbezogenen Fragen abstimmen / ihre Bewertung abgeben.
<G-vec00020-002-s053><vote.abstimmen><en> Only those IRB/IEC members who are independent of the investigator and the sponsor of the trial should vote/provide opinion on a trial-related matter.
<G-vec00020-002-s054><vote.abstimmen><de> Sie erhalten eine doppelte Stimme, wenn Sie über Produktideen in unseren Foren abstimmen.
<G-vec00020-002-s054><vote.abstimmen><en> Be heard Get double votes when you vote on product ideas in our forums.
<G-vec00020-002-s055><vote.abstimmen><de> Personen in der gleichen Familie/Haus/Büro können über mobile Daten (mit einem Smartphone) abstimmen.
<G-vec00020-002-s055><vote.abstimmen><en> Individuals in the same family/home/office can also vote via mobile data (using a smartphone).
<G-vec00020-002-s056><vote.abstimmen><de> Gemäss den heute geltenden Regeln kann die Anzahl der Personen, die elektronisch abstimmen dürfen, maximal 10% der Stimm-berechtigten in der Schweiz und 30% der Stimmberechtigten eines Kantons betragen.
<G-vec00020-002-s056><vote.abstimmen><en> According to the current rules, the number of people authorised to vote electronically can only reach 10% of the Swiss electorate and 30% of the electorate of a canton. Technical glitch
<G-vec00020-002-s086><vote.abstimmen><de> Ihr habt jeweils in der Kategorie "Dance/For the Feet" und "Smooth/ For the heart" die Möglichkeit abzustimmen.
<G-vec00020-002-s086><vote.abstimmen><en> Below you have the chance to vote your favorite in the categories 'Dance - For the Feet" and "Smooth - For the Heart".
<G-vec00020-002-s087><vote.abstimmen><de> Wir haben unsere Kreditgeber gebeten, über diese Refinanzierungsoption abzustimmen.
<G-vec00020-002-s087><vote.abstimmen><en> We have asked our lenders to vote on this refinancing operation.
<G-vec00020-002-s088><vote.abstimmen><de> Der schwierigste Teil dieser Tour kommt am Ende, wenn Sie aufgefordert werden, über Ihr Lieblingsstück abzustimmen.
<G-vec00020-002-s088><vote.abstimmen><en> The hardest part of this tour comes at the end, when you'll be asked to vote on your favorite slice.
<G-vec00020-002-s089><vote.abstimmen><de> In Ausnahmefällen behält sich die Universität aber vor, über einen verpflichtenden Wechsel abzustimmen (z.
<G-vec00020-002-s089><vote.abstimmen><en> In exceptional cases, Ulm University reserves the right to vote on a compulsory change (e.g.
<G-vec00020-002-s090><vote.abstimmen><de> In ihren Berichten, aus denen hervorgeht, dass keine wesentlichen Bedenken oder Probleme im Bereich der Betriebsführung bestehen, empfehlen ISS und GL den Aktionären zugunsten aller Beschlüsse und der zur Wahl aufgestellten Kandidaten abzustimmen.
<G-vec00020-002-s090><vote.abstimmen><en> In both reports, ISS and GL recommend shareholders vote FOR all the resolutions and nominees, stating that there are no significant governance concerns or issues.
<G-vec00020-002-s091><vote.abstimmen><de> Anfang 2013 werden CENTURY MEDIA RECORDS das neue DEEZ NUTS Album "Bout It" veröffentlichen und ihr habt die einmalige Gelegenheit bei dem Entstehungsprozess dabei zu sein und für euer favorisiertes Album Format abzustimmen.
<G-vec00020-002-s091><vote.abstimmen><en> In early 2013 CENTURY MEDIA RECORDS is going to release the new DEEZ NUTS album "Bout It" and you have the once in a lifetime chance to be a part of the album creating process and vote for your favorite album format!
<G-vec00020-002-s092><vote.abstimmen><de> Um die Wahrnehmung der Aktionärsrechte zu erleichtern, bietet die Gesellschaft allen Aktionären, die ihre Stimmrechte nicht selbst ausüben können oder wollen, an, über einen weisungsgebundenen Stimmrechtsvertreter in der Hauptversammlung abzustimmen.
<G-vec00020-002-s092><vote.abstimmen><en> To make it easier for shareholders to exercise their rights, the company offers all shareholders who cannot or do not want to exercise their voting rights themselves the opportunity to vote at the Shareholders’ Meeting via a proxy who is bound by instructions.
<G-vec00020-002-s093><vote.abstimmen><de> Die Klägerinnen machen unter anderem geltend, sie seien nicht berechtigt, über das Referendum abzustimmen, da sie sich im Ausland aufhalten, und die angefochtene Entscheidung habe unmittelbare Folgen für ihre Rechte aus dem EU-Vertrag.
<G-vec00020-002-s093><vote.abstimmen><en> The applicants claim, inter alia, that they are not entitled to vote on the referendum as they reside abroad and that the contested decision has direct consequences for their rights under the EU Treaty.
<G-vec00020-002-s094><vote.abstimmen><de> Über die Entlastung eines einzelnen Mitglieds ist gesondert abzustimmen, wenn die Hauptversammlung es beschließt oder eine Minderheit es verlangt, deren Anteile zusammen den zehnten Teil des Grundkapitals oder den anteiligen Betrag von einer Million Euro erreichen.
<G-vec00020-002-s094><vote.abstimmen><en> A separate vote is to be taken regarding the approval of the actions by an individual member, and the discharge granted to same, should the general meeting resolve that this be done, or should a minority so demand whose shares of stock, in the aggregate, are at least equivalent to one tenth of the share capital, or to a stake of one million euros.
<G-vec00020-002-s095><vote.abstimmen><de> Auch in diesem Jahr hatte der Verlag seine Leser gebeten, über ihre Lieblingsprodukte aus den Bereichen Digital-TV, Heimkino, Audio, Entertainment und Weiße Ware abzustimmen.
<G-vec00020-002-s095><vote.abstimmen><en> Once again this year, the publishers asked their readers to vote on their favourite products for the digital TV, home theatre, audio, entertainment and white goods.
<G-vec00020-002-s096><vote.abstimmen><de> Der kommende HISTORY-AWARD ist ein weiterer Beweis, dass Geschichte und Geschichtsfernsehen nicht antiquiert und pseudowissenschaftlich daherkommen muss, sondern durchaus unterhaltsam sein kann und darf.“ Nun hat die interessierte Öffentlichkeit die Möglichkeit, über die eingereichten Schülerprojekte online abzustimmen.
<G-vec00020-002-s096><vote.abstimmen><en> The upcoming HISTORY AWARD is further proof that history and historical television does not have to be antiquated and pseudo-scientific, but certainly can and should be entertaining." Now, the general public is invited to vote for the submitted student projects online.
<G-vec00020-002-s097><vote.abstimmen><de> Vergessen Sie nicht, für einen der Teilnehmer abzustimmen.
<G-vec00020-002-s097><vote.abstimmen><en> Remember to vote for participants you like.
<G-vec00020-002-s098><vote.abstimmen><de> Du musst dich einloggen um abzustimmen.
<G-vec00020-002-s098><vote.abstimmen><en> You need to log in to vote.
<G-vec00020-002-s099><vote.abstimmen><de> Wir würden gerne mehr Leuten die Möglichkeit geben, abzustimmen und Onlineabstimmungen dafür verwirklichen.
<G-vec00020-002-s099><vote.abstimmen><en> We want more people to be able to vote, online voting would accommodate that.
<G-vec00020-002-s100><vote.abstimmen><de> Themen der Plenartagung Das Parlament tritt regelmäβig zu Plenartagungen in Brüssel oder in Straßburg zusammen, um zu debattieren und abzustimmen.
<G-vec00020-002-s100><vote.abstimmen><en> The Parliament meets regularly to vote and debate at its plenary session, in Brussels or Strasbourg.
<G-vec00020-002-s101><vote.abstimmen><de> Nach ihm, wenn Anfang 2014 die Führung der Volksrepublik Donezk hat sich für ein Referendum genannt, einige der Mitarbeiter des Unternehmens verabschiedete sich und ging in Donetsk, um abzustimmen.
<G-vec00020-002-s101><vote.abstimmen><en> According to him, when in early 2014 the leadership of Donetsk People’s Republic has called for a referendum, some of the company’s employees took leave and went to Donetsk to vote.
<G-vec00020-002-s102><vote.abstimmen><de> Fans auf der ganzen Welt sind aufgefordert, so oft wie möglich auf NHL.com/CoverVote abzustimmen, um dafür zu sorgen, dass es ihr Lieblingsspieler in die jeweils nächste Runde schafft.
<G-vec00020-002-s102><vote.abstimmen><en> Fans can vote for their favorite player to represent their team in the next round. NHL 13 Cover Athlete Voting Schedule:
<G-vec00020-002-s103><vote.abstimmen><de> In einem Publikumsvoting hatte die Öffentlichkeit in den vergangenen Wochen die Möglichkeit für ihr bevorzugtes Unternehmen abzustimmen.
<G-vec00020-002-s103><vote.abstimmen><en> In open voting over the past few weeks, the public had the opportunity to vote for their favorite businesses.
<G-vec00020-002-s104><vote.abstimmen><de> Bitte beachtet, dass beim Versuch mehrfach in einer Runde abzustimmen alle Eure Stimmabgaben ungültig werden.
<G-vec00020-002-s104><vote.abstimmen><en> Please note that if you vote more than once then all your votes will automatically be discounted.
<G-vec00696-002-s019><adjust.abstimmen><de> Für den Einzelhandel stehen Ihnen zum Beispiel aufmerksamkeitsstarke Zweitplatzierungen und weitere Maßnahmen zur Verfügung, die wir gerne kundenindividuell mit Ihnen abstimmen.
<G-vec00696-002-s019><adjust.abstimmen><en> For retailers, for example, we have eye-catching secondary placements and other solutions available, which we will gladly adjust to meet your individual needs.
<G-vec00696-002-s020><adjust.abstimmen><de> So können wir die Inhalte unserer Internetseiten gezielter auf Ihre Bedürfnisse abstimmen und somit unser Angebot für Sie verbessern.
<G-vec00696-002-s020><adjust.abstimmen><en> We can therefore adjust the content of our websites tailored to your requirements, and thus improve our site for you.
<G-vec00696-002-s021><adjust.abstimmen><de> Wir machen Ihnen dieses Versprechen, weil wir Ihre Bedürfnisse und Erwartungen kennen und jeden Schritt im Auswahlprozess darauf abstimmen.
<G-vec00696-002-s021><adjust.abstimmen><en> We promise this because we know your needs and expectations and adjust every step of the selection process accordingly.
<G-vec00696-002-s023><adjust.abstimmen><de> Er kann außerdem die Geschwindigkeiten der einzelnen Krankomponenten abstimmen oder ändern, indem er den Teleskopausschub während des Arbeitsgangs von Hand steuert.
<G-vec00696-002-s023><adjust.abstimmen><en> They can also adjust the speed between various boom parts or change it by using the extension boom manually during operation.
<G-vec00696-002-s024><adjust.abstimmen><de> Sie können die Abdeckung auf Ihre Bedürfnisse abstimmen.
<G-vec00696-002-s024><adjust.abstimmen><en> You can adjust the amount of coverage to your needs.
<G-vec00696-002-s025><adjust.abstimmen><de> Du kannst das Ambiente auf jeden Anlass abstimmen: ein großes Fest, ein romantisches Abendessen oder ein lauschiger Sommerabend.
<G-vec00696-002-s025><adjust.abstimmen><en> You can adjust the ambience to any occasion: a big party, an intimate dinner or a moment of relaxation on a late summer night.
<G-vec00696-002-s026><adjust.abstimmen><de> Im Einzelunterricht bist Du außerdem nicht an Kurszeiten gebunden, damit Du den Unterricht flexibel auf Deine Arbeit und Freizeit abstimmen kannst.
<G-vec00696-002-s026><adjust.abstimmen><en> Full Flexibility With private lessons you are not bound to specific time tables and you can also adjust your schedule to your work and free time.
<G-vec00696-002-s027><adjust.abstimmen><de> Diese blinken gemeinsam, um in Summe sichtbarer zu sein und verwenden Tricks, die es ermöglichen, dass sie sich immer wieder aufeinander abstimmen.
<G-vec00696-002-s027><adjust.abstimmen><en> These flash together, achieving greater overall visibility, and they use tricks that allow them to continuously adjust to each other.
<G-vec00696-002-s028><adjust.abstimmen><de> Sie sollte global Verantwortung übernehmen und eine Politik zum Wohle aller Menschen abstimmen.
<G-vec00696-002-s028><adjust.abstimmen><en> They have to take on global responsibility and adjust politics to ensure the well-being of all people.
<G-vec00696-002-s029><adjust.abstimmen><de> Theoretische Kompetenzen werden somit direkt in die Praxis umgesetzt, so dass wir das Training ganz auf Ihre Anforderungen, Ihre Verhandlungserfahrung sowie Ihre Sprachkenntnisse abstimmen können.
<G-vec00696-002-s029><adjust.abstimmen><en> We take the theory and immediately put it into practice, so we can adjust the training to your needs and your negotiation experience and language skills.
<G-vec00696-002-s030><adjust.abstimmen><de> In der Folge können wir die Inhalte unserer Webseite gezielter auf die Bedürfnisse unserer Nutzer abstimmen und unser Angebot optimieren.
<G-vec00696-002-s030><adjust.abstimmen><en> As a result, we can adjust the content of our website to the requirements of our users in a targeted manner and optimise what we have on offer.
<G-vec00696-002-s031><adjust.abstimmen><de> Mit diesen Informationen kann Quality Stores Online B.V. die Seite und Dienste auf die Wünsche der Benutzer abstimmen.
<G-vec00696-002-s031><adjust.abstimmen><en> With this information, Quality Stores Online B.V. is able to adjust the site and services to the requirements of the users.
<G-vec00696-002-s032><adjust.abstimmen><de> Mit dem umfangreich einstellbaren Dämpfersetup kannst Du das Fahrverhalten Deines Fahrzeugs präzise abstimmen, egal ob sortlich straff oder auf Wunsch mit gesteigertem Restfahrkomfort.
<G-vec00696-002-s032><adjust.abstimmen><en> With the extensively adjustable damper setup, you can precisely adjust the driving behavior of your car, no matter if sporty tight or on request with increased residual driving comfort.
<G-vec00696-002-s033><adjust.abstimmen><de> Mit diesem Plugin können Sie die Darstellung Ihres Blogs anpassen und auf Ihren Shop abstimmen.
<G-vec00696-002-s033><adjust.abstimmen><en> With this plugin you can customize the appearance of your blog and adjust it to your shop design.
