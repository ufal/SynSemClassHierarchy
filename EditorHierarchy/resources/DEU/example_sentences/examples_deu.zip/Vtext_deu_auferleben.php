<G-vec00364-002-s153><relive.auferleben><de> Er versucht zu horchen und den Klang eines "Ich liebe dich" im Ohr wieder aufzuerleben.
<G-vec00364-002-s153><relive.auferleben><en> He tries to listen and to relive the sound of an "I love you" in his ear.
