<G-vec00626-002-s019><drift.abdriften><de> Die Steuerung erfolgt über Hubmast und Hangausgleich, wodurch eine gleichmäßige Benetzung und minimale Abdrift durch konsequentes Einhalten des Zielflächenabstandes gewährleistet wird.
<G-vec00626-002-s019><drift.abdriften><en> As the system is controlled via the lift mast and slope compensation, BoomCommand ensures even wetting quality and minimises drift by reliably maintaining a consistent distance to the target surface.
<G-vec00626-002-s020><drift.abdriften><de> Das Risiko der direkten Abdrift auf sensible Randbereiche und angrenzende Kulturen wird durch eine extreme Verringerung des Feintropfenanteils gerade auch bei ungünstigeren Applikationsbedingungen auf ein Minimum reduziert.
<G-vec00626-002-s020><drift.abdriften><en> The risk of direct spray drift to sensitive border areas and adjacent crops is reduced by an extreme reduction of the fine droplets share especially in unfavorable application conditions to a minimum.
<G-vec00626-002-s021><drift.abdriften><de> In den verfremdeten Bildern zeigt Marker den unumgänglichen Abstand zu dem unmittelbaren Ereignis, den unser Gedächtnis inzwischen längst, als unbewusste Not-Operation, eingenommen hat: die Abdrift der Bilder.
<G-vec00626-002-s021><drift.abdriften><en> In the manipulated images Marker shows the inevitable distance to the unmediated event, which our memory has long since taken as an unconscious non-operation: the drift of the images.
<G-vec00626-002-s022><drift.abdriften><de> Eine verstopfungsunempfindliche Pralldüse für niedrige Spritzhöhen mit geringer Abdrift, auch ideal für Rückenspritzen und zur Zwischenreihenbehandlung.
<G-vec00626-002-s022><drift.abdriften><en> Blockage insensitive impaction nozzle for low spray heights low-drift, also ideal for knapsack sprayers and interrow treatment.
<G-vec00626-002-s023><drift.abdriften><de> Unterstützt werden zur Zeit Wind, Windstärke, Lateralwiderstand, Vortrieb, Abdrift und einiges mehr.
<G-vec00626-002-s023><drift.abdriften><en> Supported are currently wind, wind speed, lateral resistor, tunneling, drift and more.
<G-vec00626-002-s024><drift.abdriften><de> Eine variable Tropfengröße ermöglicht es dem Anwender, die Tropfengröße der einzelnen Spritzaufgabe anzupassen und eine optimale Deckung und eine geringe Abdrift zu gewährleisten.
<G-vec00626-002-s024><drift.abdriften><en> Variable droplet size will enable users to adapt the droplet size to the particular spraying job while providing optimal coverage and low drift.
<G-vec00626-002-s025><drift.abdriften><de> Hecke und Injektordüsen reduzierten die Abdrift je um rund 75 %, ein Hagelnetz über der Obstanlage um rund 65 %.
<G-vec00626-002-s025><drift.abdriften><en> Windbreak hedges or injector nozzles reduced drift by approx. 75 % each, a hail net on the top of the orchard by approx.
<G-vec00626-002-s026><drift.abdriften><de> Steigende Windgeschwindigkeiten führen zu verstärkter Abdrift.
<G-vec00626-002-s026><drift.abdriften><en> Increased wind speeds cause increased spray drift.
<G-vec00626-002-s027><drift.abdriften><de> Zeige den Winkel und die Geschwindigkeit des wahren und des scheinbaren Winds an sowie Abdrift und Strömung.
<G-vec00626-002-s027><drift.abdriften><en> Show the angle and the speed of the true and the apparent wind as well as drift and current.
<G-vec00626-002-s028><drift.abdriften><de> Beginnen Sie jeden Morgen zu atemberaubenden Sonnenaufgänge im Osten und abdriften jede Nacht mit ruhigen Klängen der Natur zu schlafen.
<G-vec00626-002-s028><drift.abdriften><en> Wake up each morning to awe-inspiring sunrises in the East and drift off to sleep each night with tranquil sounds of nature.
<G-vec00626-002-s029><drift.abdriften><de> Nach rechts und links (horizontal) können die Augen bis zu 45 Grad abweichen, allerdings dürfen sie dabei nicht nach oben oder unten (vertikal) abdriften.
<G-vec00626-002-s029><drift.abdriften><en> To the right and left (horizontal), one's eyes can move up to 45 degrees, although they can't drift up or down (vertically).
<G-vec00626-002-s030><drift.abdriften><de> Leider können BYFROST das Niveau der Anfangsstücke nicht ganz halten, so dass sie nach starkem Beginn am Ende doch ein wenig in die Mittelmäßigkeit abdriften.
<G-vec00626-002-s030><drift.abdriften><en> Unfortunately BYFROST cannot keep up the high level of the first songs and drift away into mediocrity.
<G-vec00626-002-s031><drift.abdriften><de> Wenn also auf der Autobahn die Konzentration nachlässt, erkennt der Spurhalte-Assistent ein Abdriften und passt die Lenkung automatisch an – lässt dem Fahrer aber stets die volle Kontrolle.
<G-vec00626-002-s031><drift.abdriften><en> So if you lose concentration on the motorway, Lane Assist recognises when you start to drift and automatically adjusts the steering while leaving you in control at all times.
<G-vec00626-002-s032><drift.abdriften><de> Oder unterm Monocrom Color Dome in visuelle Welten abdriften.
<G-vec00626-002-s032><drift.abdriften><en> Or drift away in visual worlds under the Monocrom Color Dome.
<G-vec00626-002-s033><drift.abdriften><de> Auch kann es sein, dass eine Justierung im Laufe der Zeit unumgänglich wird, da auch Messgeräte und deren Sensoren im Laufe der Zeit abdriften können.
<G-vec00626-002-s033><drift.abdriften><en> It is also possible that recalibration becomes necessary later on, due to the drift pyrometers and their sensors can experience over time.
<G-vec00626-002-s034><drift.abdriften><de> Wichtig sei, dass man qualitätsvolle Beschäftigung schafft, damit die Menschen auch am Leben teilhaben können und nicht in die Armut trotz Arbeit abdriften.
<G-vec00626-002-s034><drift.abdriften><en> However, it was important to create quality jobs so that people could participate in life and not drift into poverty in spite of having a job.
<G-vec00626-002-s035><drift.abdriften><de> Aber wenn ich versuchen würde, sie in Worte zu fassen, würde ich ganz schnell in Klischees abdriften und ihr nicht gerecht werden.
<G-vec00626-002-s035><drift.abdriften><en> But if I tried to put it into words, I would quickly drift into stereotypes and not do justice to her.
<G-vec00626-002-s036><drift.abdriften><de> Du wirst dadurch nicht nur unwahrscheinlicher abdriften, dein Lehrer wird auch von deiner Mitarbeit beeindruckt sein.
<G-vec00626-002-s036><drift.abdriften><en> Not only will this make you less likely to drift off, but your teacher will be impressed by your participation.
<G-vec00626-002-s037><drift.abdriften><de> Mal drohte der charismatische Ex-General, seine Männer könnten "aus Dummheit" zu rechtsextremen Parteien abdriften, wenn sich die SPD nicht für sie einsetze.
<G-vec00626-002-s037><drift.abdriften><en> On one occasion, the charismatic former general threatened that his men could drift into extremist right-wing parties "out of stupidity," unless the SPD championed their cause.
<G-vec00626-002-s038><drift.abdriften><de> Ein unschönes Abdriften ins Grün gehört dadurch der Vergangenheit an.
<G-vec00626-002-s038><drift.abdriften><en> The unwanted drift to green is thus a thing of the past.
<G-vec00626-002-s039><drift.abdriften><de> Das Motorboot wurde von den amerikanischen Seeleuten losgeschnitten und dem Abdriften überlassen.
<G-vec00626-002-s039><drift.abdriften><en> The motor boat was cut off by the Yankee sailors and let to drift off.
<G-vec00626-002-s040><drift.abdriften><de> Allerdings sollten Sie - je nach Laufstrecke - nicht auf einen Sicherheitsgurt verzichten: Dieser verbindet Sie sicher mit dem Wagen, sodass dieser nicht in eine unerwartete Richtung abdriften kann.
<G-vec00626-002-s040><drift.abdriften><en> However – according to the mileage – you should not to waive on a safety belt: This one will connect you safe to the stroller so that it cannot drift to another direction unexpectedly.
<G-vec00626-002-s041><drift.abdriften><de> Versäumnis, die Verlangsamung der Erde zu erklären (und gelegentliche Beschleunigung), würde bedeuten, dass UTC nicht mehr synchron mit GMT und Mittag, wenn die Sonne traditionell am höchsten am Himmel ist, abdriften würde.
<G-vec00626-002-s041><drift.abdriften><en> Failing to account for the Earth’s slowing in its rotation (and occasional speeding up) would mean that UTC would fall out of synchronisation with GMT and noon, when the sun is traditionally the highest in the sky would drift.
<G-vec00626-002-s054><drift.abdriften><de> Es ist erstaunlich, wie einfach es ist, sogar einige Komfort unseres täglichen Lebens so weit abzudriften.
<G-vec00626-002-s054><drift.abdriften><en> It’s amazing how easy it is to drift off even so far some the comforts of our daily lives.
<G-vec00626-002-s055><drift.abdriften><de> 6 min 4 March, 2019 Wie Du Cannabis Für Besseren Schlaf Verwendest Marihuana ist seit langem verwendet worden, um den Menschen zu helfen, in den Schlaf abzudriften und die jüngsten Forschungsergebnisse legen sogar nahe, daß das Endocannabinoid System eine Rolle bei der Schlafregulation spielt.
<G-vec00626-002-s055><drift.abdriften><en> 5 min 4 March, 2019 How To Use Cannabis For Improving Your Sleep Marijuana has long been used to help people drift off to sleep. Recent research even suggests that the endocannabinoid system plays a role in sleep regulation.
<G-vec00626-002-s056><drift.abdriften><de> Hier kam [mit Modi] die größte Demokratie der Welt nach Davos - eine Demokratie, die in einer Weise in den Nationalismus abzudriften droht, dass die ganze Region alarmiert ist.
<G-vec00626-002-s056><drift.abdriften><en> The world's biggest democracy had come to Davos - a democracy that threatens to drift into nationalism in a way that has left the entire region alarmed.
<G-vec00626-002-s057><drift.abdriften><de> Es hat das Potenzial, Dir zu helfen in den Schlaf abzudriften und Deine Träume zu erkunden.
<G-vec00626-002-s057><drift.abdriften><en> It has the potential to help you drift off to sleep and explore your dreams.
<G-vec00626-002-s058><drift.abdriften><de> Wenn Du Hilfe im Kampf gegen die Symptome der Schlaflosigkeit suchst, solltest Du Dich anderweitig umsehen, denn der zerebrale Rausch wird Dir nicht helfen in den Schlaf abzudriften.
<G-vec00626-002-s058><drift.abdriften><en> If you are looking to help fight the symptoms of insomnia then you may want to look else where, the cerebral buzz will not help you drift off to sleep.
