<G-vec00547-001-s342><bother.ärgern><de> Sie müssen nicht ärgern über Phen375 Verteilung an Ihre Adresse aufgrund der Tatsache, dass derzeit Phen375 steht zur Verfügung, in der alle Bereich oder Stadt in Cyprus.
<G-vec00547-001-s342><bother.ärgern><en> You do not have to bother with Phen375 delivery to your address because currently Phen375 is available in the all Region or City in Cyprus.
<G-vec00547-001-s343><bother.ärgern><de> Gesunde und ausgewogene Individuen haben absolut nichts über die Verwendung phen375 bedenkt, dass dieser Artikel hat die schlechten phen375 negativen Auswirkungen erhalten und ersetzte sie durch eine der mächtigsten Fettschmelz Formel ärgern.
<G-vec00547-001-s343><bother.ärgern><en> Healthy people have absolutely nothing to bother with making use of phen375 considering that this product has actually secured the bad phen375 negative effects and also changed it with one of the most powerful fat burning formula.
<G-vec00547-001-s344><bother.ärgern><de> Dies bedeutet, Frauen dieses Medikament verwenden können, ohne dass über den Erhalt männliche Züge, wie viel tiefer Gesang Akkorde, klitorale Augmentation und erhöhte Körperhaarwachstum zu ärgern.
<G-vec00547-001-s344><bother.ärgern><en> This means females can use this medication without having to bother with obtaining masculine qualities, such as further vocal chords, clitoral augmentation and raised body hair growth.
<G-vec00547-001-s345><bother.ärgern><de> Vulcano wartet auf eine günstige Gelegenheit um Akeem zu ärgern.
<G-vec00547-001-s345><bother.ärgern><en> Vulcano is waiting for a convenious opportunity to bother Akeem.
<G-vec00547-001-s346><bother.ärgern><de> [14] Und wenn andere den Tathagata für das beleidigen, missbrauchen, necken, ärgern und belästigen, fühlt er keinen Haß, ist nicht verärgert, nicht Unzufrieden im Herzen, wegen dem.
<G-vec00547-001-s346><bother.ärgern><en> [14] And if others insult, abuse, taunt, bother, & harass the Tathagata for that, he feels no hatred, no resentment, no dissatisfaction of heart because of that.
<G-vec00547-001-s347><bother.ärgern><de> Sie brauchen sich nicht zu ärgern über Clenbuterol Steroide Verteilung an Ihre Adresse aufgrund der Tatsache, dass derzeit Clenbuterol Steroide ist verfügbar, in der alle Bereich oder Stadt in Djibouti.
<G-vec00547-001-s347><bother.ärgern><en> You do not have to bother with Clenbuterol Steroids distribution to your address because presently Clenbuterol Steroids is available in the all Area or City in Djibouti.
<G-vec00547-001-s348><bother.ärgern><de> Sie brauchen sich nicht zu ärgern über Anavar Steroide Verteilung an Ihre Adresse aufgrund der Tatsache, die derzeit Anavar Steroide ist verfügbar, in der alle Gegend oder Stadt in Greenland.
<G-vec00547-001-s348><bother.ärgern><en> You do not have to bother with Anavar Steroids distribution to your address due to the fact that presently Anavar Steroids is available in the all Region or City in Greenland.
<G-vec00547-001-s349><bother.ärgern><de> Sie brauchen nicht darüber zu ärgern PhenQ Gewichtsverlust Pillen Verteilung da gerade Ihre Adresse PhenQ Weight Loss Pills Versand ist verfügbar auf allen Gebieten oder Städten Vatican City.
<G-vec00547-001-s349><bother.ärgern><en> You do not need to bother with PhenQ Weight Loss Pills distribution to your address because presently PhenQ Weight Loss Pills shipment is available to all areas or cities throughout Vatican City.
<G-vec00547-001-s350><bother.ärgern><de> Sie ärgern müssen nicht über die Verfügbarkeit in Ihrer Nähe.
<G-vec00547-001-s350><bother.ärgern><en> You need not bother with accessibility in your area in Sheffield UK.
<G-vec00547-001-s351><bother.ärgern><de> Sie müssen nicht ärgern über Green Coffee Bean Extract Verteilung an Ihre Adresse aufgrund der Tatsache, dass gegenwärtig in allen Region oder Stadt in Ashmore And Cartier Islands Green Coffee Bean Extract ist verfügbar .
<G-vec00547-001-s351><bother.ärgern><en> You do not need to bother with Saffron Extract shipment to your address because currently Saffron Extract is available in the all Area or City in Ashmore And Cartier Islands.
<G-vec00547-001-s352><bother.ärgern><de> Sie müssen nicht ärgern über Winstrol Steroid-Versand an Ihre Adresse aufgrund der Tatsache, dass gegenwärtig Winstrol Steroid ist verfügbar in allen Region oder Stadt in Tanzania.
<G-vec00547-001-s352><bother.ärgern><en> You do not need to bother with Winstrol Steroid shipment to your address due to the fact that presently Winstrol Steroid is available in the all Region or City in Tanzania.
<G-vec00547-001-s353><bother.ärgern><de> Sie müssen nicht ärgern über Green Coffee Bean Extract Lieferung an Ihre Adresse aufgrund der Tatsache, dass derzeit alle Gegend oder Stadt in Cyprus Green Coffee Bean Extract ist verfügbar .
<G-vec00547-001-s353><bother.ärgern><en> You do not need to bother with Forskolin Extract distribution to your address due to the fact that currently Forskolin Extract is available in the all Area or City in Cyprus .
<G-vec00547-001-s354><bother.ärgern><de> Sie brauchen nicht darüber zu ärgern Phen375 Phentermine 37,5 mg Tabletten Verteilung an Ihre Adresse aufgrund der Tatsache, dass zur Zeit Phen375 Phentermine 37,5 mg Tabletten Versand ist verfügbar auf allen Gebieten oder Städten Saint Helena.
<G-vec00547-001-s354><bother.ärgern><en> You do not have to bother with Phen375 Phentermine 37.5 Mg Pills shipment to your address because currently Phen375 Phentermine 37.5 Mg Pills shipping is available to all regions or cities throughout Saint Helena.
<G-vec00547-001-s355><bother.ärgern><de> Es ist ohne Zweifel die effektivste anabole Steroide zur Verfügung, wenn Sie ein paar Ihrer Körpergewicht fallen zu lassen suchen und auch einen Muskel Körper zu bekommen, ohne dass über Dimension oder Robustheit Einschränkungen zu ärgern.
<G-vec00547-001-s355><bother.ärgern><en> It is without a doubt the most effective anabolic steroid out there if you are planning to drop several of your bodyweight and acquire a muscle body without having to bother with size or durability constraints.
<G-vec00547-001-s356><bother.ärgern><de> Sie brauchen sich nicht zu ärgern über Clenbuterol Steroide Verteilung an Ihre Adresse aufgrund der Tatsache, dass derzeit Clenbuterol Steroide ist verfügbar, in der alle Bereich oder Stadt in Norfolk Island.
<G-vec00547-001-s356><bother.ärgern><en> You do not have to bother with Clenbuterol Steroids shipment to your address due to the fact that currently Clenbuterol Steroids is available in the all Region or City in Taitung City.
<G-vec00547-001-s038><vex.ärgern><de> ... solche Zweifel und Punkte des Lernens, wie man cumber und ärgern ihre Köpfe [und] Lernen [würde] wunderbar sein fortgeschritten.
<G-vec00547-001-s038><vex.ärgern><en> ... such doubts and points of learning, as might cumber and vex their heads [and] learning [would] wonderfully be advanced.
<G-vec00547-001-s039><vex.ärgern><de> Es gibt alle Arten von Geheimnissen hier mich zu ärgern, dass kein Ende.
<G-vec00547-001-s039><vex.ärgern><en> There are all sorts of mysteries here that vex me to no end.
<G-vec00547-001-s040><vex.ärgern><de> Für die meisten konzeptionellen Zwecke, bewirkt dies keine Probleme mit dem Verständnis Strom, aber im Denken von Strom als fließende Einheit, ist es leicht ärgern.
<G-vec00547-001-s040><vex.ärgern><en> For most conceptual purposes, this causes no problems with understanding electricity; however, in thinking of electricity as a flowing entity, it does vex slightly.
<G-vec00547-001-s562><worry.ärgern><de> Sie müssen nicht ärgern über Green Coffee Bean Extract Verteilung an Ihre Adresse aufgrund der Tatsache, dass derzeit alle Gegend oder Stadt in Akrotiri Green Coffee Bean Extract ist verfügbar .
<G-vec00547-001-s562><worry.ärgern><en> You do not have to worry about Moringa Capsules shipment to your address due to the fact that presently Moringa Capsules is available in the all Area or City in Akrotiri .
<G-vec00547-001-s563><worry.ärgern><de> Sie brauchen sich nicht zu ärgern über Clenbuterol Steroide Lieferung an Ihre Adresse aufgrund der Tatsache, dass gegenwärtig Clenbuterol Steroide ist verfügbar in allen Region oder Stadt in Svalbard.
<G-vec00547-001-s563><worry.ärgern><en> You do not have to worry about Clenbuterol Steroids distribution to your address since currently Clenbuterol Steroids is available in the all Region or City in Svalbard.
<G-vec00547-001-s564><worry.ärgern><de> Gesunde Personen haben nichts über die Verwendung phen375 gegeben, dass dieser Punkt tatsächlich gesichert ist, die schlechten phen375 Nebenwirkungen und verändert sie mit einer der effektivsten Fettschmelz Formel ärgern.
<G-vec00547-001-s564><worry.ärgern><en> Healthy and balanced people have nothing to worry about utilizing phen375 because this item has taken out the bad phen375 side effects and changed it with the most effective fat melting formula.
<G-vec00547-001-s565><worry.ärgern><de> Sie brauchen sich nicht zu ärgern über Steroide Dianabol Versand an Ihre Adresse aufgrund der Tatsache, dass derzeit in der alle Gegend oder Stadt in Akrotiri Steroide Dianabol ist verfügbar .
<G-vec00547-001-s565><worry.ärgern><en> You do not need to worry about Raspberry Ketones shipment to your address due to the fact that presently Raspberry Ketones is available in the all Area or City in Akrotiri .
<G-vec00547-001-s566><worry.ärgern><de> Sie müssen nicht ärgern über Winstrol Steroid-Versand an Ihre Adresse aufgrund der Tatsache, dass gegenwärtig Winstrol Steroid ist verfügbar in allen Region oder Stadt in Tanzania.
<G-vec00547-001-s566><worry.ärgern><en> You do not need to worry about Winstrol Steroid distribution to your address since presently Winstrol Steroid is available in the all Area or City in Tanzania.
<G-vec00547-001-s567><worry.ärgern><de> Dies bedeutet, Frauen dieses Medikament verwenden können, ohne dass über den Erhalt männliche Züge, wie viel tiefer Gesang Akkorde, klitorale Augmentation und erhöhte Körperhaarwachstum zu ärgern.
<G-vec00547-001-s567><worry.ärgern><en> This indicates females can utilize this medicine without needing to worry about obtaining masculine traits, such as much deeper vocal chords, clitoral augmentation and raised body hair development.
<G-vec00547-001-s568><worry.ärgern><de> Absolut nichts zu ärgern über.
<G-vec00547-001-s568><worry.ärgern><en> Nothing to worry about.
<G-vec00547-001-s569><worry.ärgern><de> In 2 Monaten, werden Sie sicherlich werden mir danken, wenn Sie sich wohl fühlen in Ihrem persönlichen Haut, auf der Suche sehr gut und auch zuversichtlich, Empfindung, nicht brauchen, um über Ihre physischen Körper Foto nicht mehr ärgern.
<G-vec00547-001-s569><worry.ärgern><en> In 2 months time, you will be thanking me when you are comfortable in your own skin, looking terrific as well as feeling confident, not needing to worry about your body picture any longer.
<G-vec00547-001-s041><vex.ärgern><de> 3:21 Ihr Väter, ärgert eure Kinder nicht, auf daß sie nicht mutlos werden.
<G-vec00547-001-s041><vex.ärgern><en> 3:21 Fathers, do not vex your children, to the end that they be not disheartened.
<G-vec00243-002-s147><fret.ärgern><de> Aber es gibt keine Notwendigkeit sich zu ärgern.
<G-vec00243-002-s147><fret.ärgern><en> But there is no need to fret.
<G-vec00243-002-s148><fret.ärgern><de> Token sind erforderlich, um private Cam-Sessions mit diesen geheimnisvollen Schönheiten zu haben, aber ärgern Sie sich nicht, denn wir bieten unsere Tokens in sehr attraktiven Paketen an.
<G-vec00243-002-s148><fret.ärgern><en> Tokens are needed to have private cam sessions with these wicked beauties, but don't fret, because we offer our tokens in very attractive packages.
<G-vec00243-002-s149><fret.ärgern><de> Nicht ärgern, wenn E-Mails in deinem Entwürfe-Ordner verschwinden, kannst du E-Mails einfach wiederherstellen.
<G-vec00243-002-s149><fret.ärgern><en> Do not fret if emails disappears in your drafts folder, you can restore emails easily.
<G-vec00243-002-s150><fret.ärgern><de> Wenn Ihr Gerät wegen eines verlorenen oder vergessenen Passworts gesperrt ist, oder es wurde zerschlagen, ins Wasser geworfen, beschädigt oder sogar gebrochen, keine Notwendigkeit zu ärgern.
<G-vec00243-002-s150><fret.ärgern><en> If your device is locked because of a lost or forgotten password, or it got smashed, dropped into water, damaged, or even broken, no need to fret.
<G-vec00547-002-s222><bother.ärgern><de> Bringen Sie Ihre 4 Hasen ins Ziel, ohne sich vom Gegner ärgern zu lassen.
<G-vec00547-002-s222><bother.ärgern><en> Get your 4 rabbits to the finish and don't let your opponents bother you.
<G-vec00547-002-s223><bother.ärgern><de> Die erhöhten Strafen für Menschenschmuggel in der Türkei ärgern ihn zwar, doch halten sie ihn nicht davon ab, weiter nach potentiellen Kunden Ausschau zu halten.
<G-vec00547-002-s223><bother.ärgern><en> The increased penalties for human trafficking in Turkey bother him, yet still they don't keep him from looking for prospective clients.
<G-vec00547-002-s021><unsettle.ärgern><de> “Ich habe mir vorgenommen Kobayashi ein wenig zu ärgern und das ist mir gelungen.
<G-vec00547-002-s021><unsettle.ärgern><en> "I set out to unsettle Kobayashi a little bit, and I succeeded.
<G-vec00547-002-s314><upset.ärgern><de> Wenn ihr anfangt euch zu ärgern, seid ihr mit ihnen im Einklang.
<G-vec00547-002-s314><upset.ärgern><en> When you become upset, you are resonating with them.
<G-vec00547-002-s315><upset.ärgern><de> Zu jeder Zeit kannst du etwas ein Kind ärgern, nur weil du seiner Hand am nächsten warst, und er brauchte dringend eine Entladung.
<G-vec00547-002-s315><upset.ärgern><en> At any time, you can pinch something a child upset, just because you were closest to his hand, and he just urgently needed a discharge.
<G-vec00547-002-s316><upset.ärgern><de> Trotzdem lohnt es sich aber auch hier, genauer hinzuschauen, denn Sie wollen sich an Ihren Karten erfreuen und sich nicht jedes Mal ärgern, wenn Sie sie betrachten.
<G-vec00547-002-s316><upset.ärgern><en> Nevertheless it does not harm to take a closer look in this case. You want to enjoy you cards and do not want to be upset every time you look at them.
<G-vec00547-002-s317><upset.ärgern><de> Seit Anfang 2008 erweitert Depesche sein Angebot um die Trendserie Dark Dudes – das sind rachsüchtige Fieslinge, die keine Chance auslassen, sich zu ärgern oder ihren Unmut auszudrücken.
<G-vec00547-002-s317><upset.ärgern><en> Since the beginning of 2008 Depesche has expanded its range of articles to do with the Dark Dudes – these are vengeful little meanies, who never pass up an opportunity to get upset about something or express their dissatisfaction.
<G-vec00701-002-s005><annoy.ärgern><de> Andererseits, wenn Sie der geselligere Spieler sind, werden öffentliche Tische Sie mit der Gelegenheit versorgen, zu plaudern, mit anderen Spielern zu interagieren und vielleicht andere Zahler zu ärgern.
<G-vec00701-002-s005><annoy.ärgern><en> On the other hand, if you’re the more sociable gambler, public tables will provide you with the opportunity to chat, interact with, and possibly annoy other payers.
<G-vec00701-002-s013><annoy.ärgern><de> Mit Ablenkungen und/oder harmlosen Streichen kannst du diese Pläne aber durchkreuzen und deinen Lehrer gleichzeitig ärgern.
<G-vec00701-002-s013><annoy.ärgern><en> You can thwart their efforts, and annoy them in the process, with tangents and/or harmless pranks.
<G-vec00701-002-s019><annoy.ärgern><de> Hovercraft Ein hartnäckiger Plagegeist mit einem Hochgeschwindigkeitsantrieb, der sich am liebsten aus einem toten Winkel heranpirscht um einen mit seinem kurzen Stummel von hinten zu ärgern.
<G-vec00701-002-s019><annoy.ärgern><en> Hovercraft A persistent pest with a highspeed power unit that likes to sneak up from the dead angle to annoy one with his short stump from behind.
<G-vec00701-002-s038><annoy.ärgern><de> Scheußliche, mutierte flammenspeiende Maulwürfe haben den ganzen Garten befallen und graben überall Tunnel, nur um Rex zu ärgern.
<G-vec00701-002-s038><annoy.ärgern><en> Nasty mutated flame spewing moles have infested the place and dig tunnels just to annoy him.
<G-vec00701-002-s063><annoy.ärgern><de> Epic kann einen Teilnehmer von der Teilnahme am Wettbewerb oder das Gewinnen von Preisen disqualifizieren, sollte Epic nach eigenem Ermessen bestimmen, dass dieser Teilnehmer den rechtmäßigen Ablauf des Wettbewerbs beeinträchtigt sei es durch Cheaten, Hacking, Täuschung oder jedwede andere Spielpraktiken, die andere Spieler oder die Stellvertreter des Wettbewerbs ärgern, missbrauchen, bedrohen oder belästigen.
<G-vec00701-002-s063><annoy.ärgern><en> Epic may disqualify any Contestant from participating in the Contest or winning a prize if, in its sole discretion, it determines such Entrant is attempting to undermine the legitimate operation of the Contest by cheating, hacking, deception, or any other unfair playing practices intending to annoy, abuse, threaten, undermine, or harass any other players or Epic’s representatives.
<G-vec00701-002-s064><annoy.ärgern><de> • Eine andere Person schikanieren, beunruhigen, in Verlegenheit bringen, erschrecken oder ärgern.
<G-vec00701-002-s064><annoy.ärgern><en> Be likely to harass, upset, embarrass, alarm or annoy any other person.
<G-vec00701-002-s065><annoy.ärgern><de> "Ich habe immer darauf geachtet, damit niemanden zu ärgern oder zu langweilen".
<G-vec00701-002-s065><annoy.ärgern><en> "I have always been careful not to annoy or bother anyone".
<G-vec00701-002-s066><annoy.ärgern><de> Um einen Mann zu ärgern, heiratet Scarlett einen Ungeliebten.
<G-vec00701-002-s066><annoy.ärgern><en> To annoy a man, Scarlett marries an unloved one.
<G-vec00701-002-s067><annoy.ärgern><de> Sie können so viel Freunde ohne Problem haben, da sie keine Schäden machen und Sie nicht ärgern.
<G-vec00701-002-s067><annoy.ärgern><en> You can have friends without problem as far as they don't make damages and you don't annoy. Availability
<G-vec00701-002-s068><annoy.ärgern><de> Auf mich wirkt das so, als hätten der für das Stauen zuständige Bootsmann oder der Smutt einen Rochus auf den Kapitän und wollten ihn ärgern, denn anderswo ist noch viel Platz.
<G-vec00701-002-s068><annoy.ärgern><en> I think that this acts as if the charge of stevedoring boatman or a Smutt Rochus to the captain and wanted to annoy him, because elsewhere is still a lot of space. 3.
<G-vec00701-002-s069><annoy.ärgern><de> Er sagt Dinge, die mich ärgern.
<G-vec00701-002-s069><annoy.ärgern><en> He says things that annoy me.
<G-vec00701-002-s070><annoy.ärgern><de> Nach diesen Unannehmlichkeiten, die ein Bewohner von ahnungslosen Städten ärgern kann, wir hatten eine tolle Zeit.
<G-vec00701-002-s070><annoy.ärgern><en> Past these annoyances that can annoy an inhabitant of unsuspecting cities, we had a great time.
<G-vec00701-002-s071><annoy.ärgern><de> Wenn wir sie ärgern wollen, singen wir "Was kostet der Dorgi dort im Fenster".
<G-vec00701-002-s071><annoy.ärgern><en> When we want to annoy them, we sing 'How Much Is that Dorgi in the Window'.
<G-vec00701-002-s072><annoy.ärgern><de> Joseph Beuys wollte niemanden ärgern, im Gegenteil: Er wollte über seine Kunst mit möglichst vielen Menschen ins Gespräch kommen.
<G-vec00701-002-s072><annoy.ärgern><en> Joseph Beuys didn´t want to annoy anybody - on the contrary – using his art he wanted to communicate with as many people as possible.
<G-vec00701-002-s073><annoy.ärgern><de> Ich fühle mich immer wie der Buhmann, der sich in seinem Zimmerchen lauter Sachen ausdenkt, um die Gruppe zu ärgern.
<G-vec00701-002-s073><annoy.ärgern><en> I always feel like the bogeyman, who imagines himself in his little room louder things to annoy the group.
<G-vec00701-002-s074><annoy.ärgern><de> (Video) Aileen möchte in Ruhe ihre Banane essen, da kommt Donna ins Zimmer und fängt an Aileen zu ärgern.
<G-vec00701-002-s074><annoy.ärgern><en> (Video) Aileen would like to eat a banana, as Donna comes into the room to annoy Aileen.
<G-vec00701-002-s075><annoy.ärgern><de> Vorbei ist also die Zeit, in der ich mit Hilfe der IKEA Place App noch meine Schwiegermutter ärgern konnte.
<G-vec00701-002-s075><annoy.ärgern><en> So the time when I could still annoy my mother-in-law using the IKEA Place App is gone.
<G-vec00701-002-s076><annoy.ärgern><de> In Wirklichkeit beginnt diese Adware bald um die Benutzer mit einen konstanten Strom von Werbung und Popups zu ärgern.
<G-vec00701-002-s076><annoy.ärgern><en> In reality, this adware soon starts to annoy the users with a constant flow of advertisements and pop-ups.
<G-vec00701-002-s077><annoy.ärgern><de> Nur das Rauschen des Windes in den Bäumen oder dem Gesang der Vögel werden Sie "ärgern".
<G-vec00701-002-s077><annoy.ärgern><en> Only the sound of the wind in the trees or the birds singing you will "annoy".
<G-vec00701-002-s078><annoy.ärgern><de> Dass Versicherungen verkauft werden, bei denen sich die Kunden beim Ablauf nur ärgern, spielt keine Rolle.
<G-vec00701-002-s078><annoy.ärgern><en> The fact that insurances that do nothing but annoy the customers in the end are often sold is irrelevant.
<G-vec00701-002-s079><annoy.ärgern><de> Hör auf, dich auf deiner Geschäftsreise über den schlecht ausgestatteten Fitnessraum im Hotel zu ärgern.
<G-vec00701-002-s079><annoy.ärgern><en> Stop it, you annoy on your business trip over the badly-equipped gym at the hotel.
<G-vec00701-002-s080><annoy.ärgern><de> Das lässt sich unter anderem so erklären: Wenn Menschen von Menschen Aufgaben zugeteilt bekommen, die sie nicht so gerne ausführen, denken sie sich, dass ihre Vorgesetzten sie nicht mögen, idiotisch seien und das nur machen, um sie zu ärgern.
<G-vec00701-002-s080><annoy.ärgern><en> One explanation for this is: When people have other people assign them tasks that they don’t really like to do, they think that their supervisors don’t like them, that they’re idiots and only do this to annoy them.
<G-vec00701-002-s081><annoy.ärgern><de> »Ich dachte, der würde Ron am meisten ärgern«, erwiderte Hermine sachlich.
<G-vec00701-002-s081><annoy.ärgern><en> “I thought he’d annoy Ron most,” said Hermione dispassionately.
<G-vec00701-002-s082><annoy.ärgern><de> Alle Leute, die mich hier besuchen, gehen immer zur Geschäftsstelle, machen ein Bild mit dem Weltpokal, und ärgern die Fans von Cruzeiro damit zu Hause.
<G-vec00701-002-s082><annoy.ärgern><en> All people visiting me here in Dortmund are always entering Borussia's office, take a picture of the world cup to annoy the Cruzeiro fans at home.
<G-vec00701-002-s083><annoy.ärgern><de> Erkennen, dass all die Dinge nicht nur da sind, um uns zu ärgern, oder uns das Leben schwer zu machen, sondern eben auch wunderbare kleine Geschenke.
<G-vec00701-002-s083><annoy.ärgern><en> Recognize that not all things in life are there to annoy us or to make life difficult, but also wonderful little presents.
<G-vec00701-002-s084><annoy.ärgern><de> Auch wenn es diesmal nicht so viele Postkarten sein werden und die Bürokratie versuchen wird, diese zu unterschlagen, wollen wir Euch genau diesen Vorschlag unterbreiten, denn es ärgert die Unterschläger doch.
<G-vec00701-002-s084><annoy.ärgern><en> Even if this time there will not be such a great number of postcards and the authorities will try to suppress them, this is exactly what we want to propose to you, for this will annoy the suppressors nevertheless.
<G-vec00701-002-s085><annoy.ärgern><de> Er hat mir unter anderem erzählt, dass er gerne „andere Menschen ärgert“.
<G-vec00701-002-s085><annoy.ärgern><en> Among other things, he told me that he likes to “annoy others”.
<G-vec00736-002-s084><offend.ärgern><de> 8:11 Wenn ihr aber also sündigt an den Brüdern, und schlagt ihr schwaches Gewissen, so sündigt ihr an Darum, so die Speise meinen Bruder ärgert, wollt ich nimmermehr Fleisch essen, auf daß ich meinen Bruder nicht ärgere.
<G-vec00736-002-s084><offend.ärgern><en> 8:12 But when all of you sin so against the brethren, and wound their weak conscience, Wherefore, if food make my brother to offend, I will eat no flesh while the world stands, lest I make my brother to offend.
<G-vec00736-002-s118><offend.ärgern><de> 42 (ELB) Und wer irgend einen der Kleinen, die an mich glauben, ärgern wird, dem wäre besser, wenn ein Mühlstein um seinen Hals gelegt, und er ins Meer geworfen würde.
<G-vec00736-002-s118><offend.ärgern><en> 42 (UKJV) And whosoever shall offend one of these little ones that believe in me, it is better for him that a millstone were hanged about his neck, and he were cast into the sea.
<G-vec00736-002-s119><offend.ärgern><de> 27 Auf daß aber wir sie nicht ärgern, so gehe hin an das Meer und wirf die Angel, und den ersten Fisch, der herauffährt, den nimm; und wenn du seinen Mund auftust, wirst du einen Stater finden; den nimm und gib ihnen für mich und dich.
<G-vec00736-002-s119><offend.ärgern><en> 27 Notwithstanding, lest we should offend them, go thou to the sea and cast a hook, and take up the fish that first cometh up. And when thou hast opened his mouth, thou shalt find a piece of money. That take, and give unto them for Me and thee."
<G-vec00736-002-s120><offend.ärgern><de> 42 Und wer der Kleinen einen ärgert, die an mich glauben, dem wäre es besser, daß ihm ein Mühlstein an seinen Hals gehängt und er ins Meer geworfen würde.
<G-vec00736-002-s120><offend.ärgern><en> ↑ Mk 9 42 And whosoever shall offend one of these little ones that believe in me, it is better for him that a millstone were hanged about his neck, and he were cast into the sea. ↓
<G-vec00736-002-s121><offend.ärgern><de> 43 So dich aber deine Hand ärgert, so haue sie ab.
<G-vec00736-002-s121><offend.ärgern><en> 43 Wherefore, if thy hand offend thee, cut him off.
<G-vec00736-002-s122><offend.ärgern><de> Der Entschluss bestand darin, dass die Gläubigen aus den Heiden dem Gesetz des Mose nicht würden gehorchen müssen, aber sie baten sie gegenüber der jüdischen Bevölkerung um sie herum einfühlsam zu sein, damit sie diese nicht ärgerten und dass sie moralisch rein leben sollten.
<G-vec00736-002-s122><offend.ärgern><en> The determination was that Gentile believers would not have to obey Moses, but they asked they be sensitive to the Jewish population around them so as not to offend them, and to be morally pure.
<G-vec00785-002-s089><aggravate.ärgern><de> Im Großen und Ganzen hängt alle davon ab, wie man wählt, es zu sehen: entweder als eine Chance, für uns alle verbundener zu sein, oder etwas, darüber sich zu ärgern.
<G-vec00785-002-s089><aggravate.ärgern><en> In the end, it all depends on how one chooses to see it: either as a chance for us all to become more connected, or something over which to aggravate one’s self.
