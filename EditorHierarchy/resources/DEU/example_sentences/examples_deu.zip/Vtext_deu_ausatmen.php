<G-vec00959-002-s194><breathe_out.ausatmen><de> Halten Sie nun die Spannung der Muskeln einige Sekunden, während Sie weiter normal ein- und ausatmen.
<G-vec00959-002-s194><breathe_out.ausatmen><en> Try then to hold a contraction for a few seconds while you continue to breathe in and out as normal.
<G-vec00959-002-s195><breathe_out.ausatmen><de> Ihr könnt auch einige Minuten weisses Licht einatmen und alles ausatmen, was euch nicht dient.
<G-vec00959-002-s195><breathe_out.ausatmen><en> You can also breathe in white light and breathe out what doesn’t serve you for a few minutes.
<G-vec00959-002-s196><breathe_out.ausatmen><de> Während des Kampfes sollten Sie mit der Nase tief durchatmen und dann mit dem Mund ausatmen.
<G-vec00959-002-s196><breathe_out.ausatmen><en> During the bout, you should take a deep breath with your nose, and then breathe out with your mouth.
<G-vec00959-002-s197><breathe_out.ausatmen><de> Jedesmal wenn ich hustete, lief Wasser aus meinem Hals, und ich konnte nur ein winzige Menge einatmen, ich konnte nicht ausatmen.
<G-vec00959-002-s197><breathe_out.ausatmen><en> Every time I coughed, water poured out of my throat I could only breathe back a tiny amount, I couldn't breathe out.
<G-vec00959-002-s198><breathe_out.ausatmen><de> Nur zu Übungszwecken: Vollständig ausatmen durch Anspannen der Bauchmuskulatur und diese angespannt lassen.
<G-vec00959-002-s198><breathe_out.ausatmen><en> During practise only: Breathe out completely by pulling the abdomen in and keeping the abdominal muscles tensed.
<G-vec00959-002-s199><breathe_out.ausatmen><de> Atmung: Einatmen, wenn Sie den Oberkörper nach links oder rechts beugen und ausatmen, wenn Sie in die Mitte zurückkehren.
<G-vec00959-002-s199><breathe_out.ausatmen><en> Breathing: Breathe in as you bend your torso to the left or to the right, and breathe out as you come back to the centre.
<G-vec00959-002-s200><breathe_out.ausatmen><de> Beim Ausatmen fühle ich Dankbarkeit für meinen Magen und dafür, dass er immer für mich da ist.
<G-vec00959-002-s200><breathe_out.ausatmen><en> As I breathe out, I feel so thankful for my stomach, that is always there for me.
<G-vec00959-002-s201><breathe_out.ausatmen><de> Wichtig ist das Ausatmen, denn wer beim Joggen zu schnell und zu tief einatmet, riskiert, zu hyperventilieren.
<G-vec00959-002-s201><breathe_out.ausatmen><en> Breathing out is important, as those who breathe in too quickly and deeply when jogging run the risk of hyperventilating.
<G-vec00959-002-s202><breathe_out.ausatmen><de> Wenn wir ausatmen, fühlen wir, wie unser Bauch sich wieder senkt.
<G-vec00959-002-s202><breathe_out.ausatmen><en> When we breathe out, we feel our tummy go down again.
<G-vec00959-002-s203><breathe_out.ausatmen><de> Atmung: Ausatmen wenn Sie den Po heben und den Arm nach oben strecken, dann einatmen wenn Sie lockern.
<G-vec00959-002-s203><breathe_out.ausatmen><en> Breathing: Breathe out as you lift up your glutes and stretch your arm upwards, and then breathe in as you let go.
<G-vec00959-002-s204><breathe_out.ausatmen><de> Er übt sich selbst: ‘Ich werde empfindsam, gegenüber dem gesamten Körper, einatmen’;[7] er übt sich selbst ‘Ich werde empfindsam, gegenüber dem gesamten Körper, ausatmen’.
<G-vec00959-002-s204><breathe_out.ausatmen><en> [3] He trains himself, 'I will breathe in sensitive to the entire body'; he trains himself, 'I will breathe out sensitive to the entire body.'
<G-vec00959-002-s014><exhale.ausatmen><de> Für große und dichte Clouds solltet ihr also langsam ausatmen.
<G-vec00959-002-s014><exhale.ausatmen><en> For large and dense clouds you should exhale slowly.
<G-vec00959-002-s017><exhale.ausatmen><de> Atme aus und gehe in eine stehende Vorwärtsbeuge über.
<G-vec00959-002-s017><exhale.ausatmen><en> Exhale and hinge into standing forward bend.
<G-vec00959-002-s018><exhale.ausatmen><de> - Nimm am Ende des Kampfes einen vollen Atemzug (Bauch und Brust), atme langsam bis zum Ende aus und drücke deinen Bauch (voller Atem).
<G-vec00959-002-s018><exhale.ausatmen><en> - At the end of the fight, take a full breath (belly and chest), slowly exhale to the end, straining your stomach (full breath).
<G-vec00959-002-s019><exhale.ausatmen><de> Wenn du die Gewichte beim Bankdrücken nach oben drückst, atme aus und strecke deine Arme wie Flügel aus, bis die Gewichte auf Schulterhöhe sind.
<G-vec00959-002-s019><exhale.ausatmen><en> When you push the weights upwards for the bench press, exhale, and spread out your arms like wings until the weights are level with your shoulders.
<G-vec00959-002-s020><exhale.ausatmen><de> Atme vollständig aus, was im Yoga Rechaka genannt wird.
<G-vec00959-002-s020><exhale.ausatmen><en> Exhale completely, which is called Rechaka in yoga.
<G-vec00959-002-s021><exhale.ausatmen><de> Kreuze deine Arme vor deine Brust oder hinter deinem Kopf, spanne deine Bauchmuskeln an und atme langsam aus, während du deinen Oberkörper vom Boden anhebst.
<G-vec00959-002-s021><exhale.ausatmen><en> Place your hands across your chest or behind your head, engage your ab muscles, and exhale as you slowly raise your upper torso off of the floor.
<G-vec00959-002-s022><exhale.ausatmen><de> Atme ein und atme aus; konzentriere dich dabei auf die Position deiner Hände.
<G-vec00959-002-s022><exhale.ausatmen><en> Inhale and exhale, focus on the position of your hands as you do so.
<G-vec00959-002-s023><exhale.ausatmen><de> Atme aus und senke deinen linken Arm wieder, bis er parallel zum Boden liegt.
<G-vec00959-002-s023><exhale.ausatmen><en> Exhale as you lower your left arm back down so it is parallel to the ground and in front of your body.
<G-vec00959-002-s024><exhale.ausatmen><de> Tip | Atme bei jeder Wiederholung in der konzentrischen Phase aus und in der exzentrischen Phase ein.
<G-vec00959-002-s024><exhale.ausatmen><en> Tip | Exhale on the concentric contraction and inhale on the eccentric contraction of each repetition
<G-vec00959-002-s025><exhale.ausatmen><de> Atme aus und senke die Beine wieder in die Ausgangsposition.
<G-vec00959-002-s025><exhale.ausatmen><en> Exhale and lower your legs back to starting position.
<G-vec00959-002-s026><exhale.ausatmen><de> Atme aus und zähle dabei laut von eins bis fünf während nur eines Atemzugs.
<G-vec00959-002-s026><exhale.ausatmen><en> Exhale, counting aloud from one to five with a single breath.
<G-vec00959-002-s027><exhale.ausatmen><de> Atme langsam in deinen Astralkörper ein … und atme vollständig aus.
<G-vec00959-002-s027><exhale.ausatmen><en> Slowly breathe into your astral body… and fully exhale.
<G-vec00959-002-s028><exhale.ausatmen><de> Atme aus, mache einen Schritt zurück und senke dich in den Chatturanga Dansasana ab.
<G-vec00959-002-s028><exhale.ausatmen><en> Exhale, step back, and lower into chatturanga dandasana.
<G-vec00959-002-s029><exhale.ausatmen><de> Wenn du Probleme mit dem Einschlafen hast, dann versuch diese Übung: Schließe deine Augen und atme komplett aus.
<G-vec00959-002-s029><exhale.ausatmen><en> If you are having trouble falling asleep try this exercise: Close your eyes, and exhale completely.
<G-vec00959-002-s030><exhale.ausatmen><de> Ziehe mit gespitzten Lippen, als wenn du pfeifen wolltest, etwas Luft in deinen Mund und atme durch die Nase aus.
<G-vec00959-002-s030><exhale.ausatmen><en> With your lips pursed as if you were to whistle, draw some air into your mouth and exhale through your nose.
<G-vec00959-002-s031><exhale.ausatmen><de> Atme aus und schau, was das Maßband zeigt.
<G-vec00959-002-s031><exhale.ausatmen><en> Exhale and then check the measurement on the tape.
<G-vec00959-002-s032><exhale.ausatmen><de> Ich hole noch einmal tief Luft… Ich atme aus… und ich sage mir, egal was heute passiert, egal wie stark sich meine Symptome entwickeln, ich glaube, dass jede Zelle, jeder Muskel, jedes Gewebe, jeder Nerv, jedes System und jede Funktion meines Körpers erneuert wird … Ich weiß, dass ich heile.
<G-vec00959-002-s032><exhale.ausatmen><en> I take another deep breath… I exhale… and I tell myself that no matter what unfolds today, no matter how intense my symptoms are, I choose to believe that every cell, muscle, tissue, nerve, fibre, system and function of my body is being renewed… I know that I am healing.
<G-vec00959-002-s038><exhale.ausatmen><de> Du musst das Kohlendioxid loswerden!“ Also schwimmt ihr an die Oberfläche und atmet das Kohlendioxid aus.
<G-vec00959-002-s038><exhale.ausatmen><en> Get rid of it.” So you swim up to the surface and exhale, getting rid of the carbon dioxide.
<G-vec00959-002-s039><exhale.ausatmen><de> Giftgas: Cerberus atmet giftiges Gas aus, das alle Ziele vergiftet.
<G-vec00959-002-s039><exhale.ausatmen><en> Poison Gas: Cerberus will exhale toxic gas to its targets, inflicting Poison to all targets.
<G-vec00959-002-s040><exhale.ausatmen><de> Ihr atmet regelmäßig, macht langes Einatmen und atmet aus, macht wieder ein langes Einatmen und atmet aus; so pumpt ihr ständig reichlich Sauerstoff in den Körper.
<G-vec00959-002-s040><exhale.ausatmen><en> You regularly respire, take long inhalations and exhale, again take a long inhalation and exhale like that you keep an pumping into the body with abundant oxygen.
<G-vec00959-002-s041><exhale.ausatmen><de> Sie atmete ganz leicht ein und atmete fast unmerklich aus, und erst nach 30 Sekunden kam ein weiterer Atemzug.
<G-vec00959-002-s041><exhale.ausatmen><en> She’d take in a wisp of air and exhale almost imperceptibly and then another thirty seconds later, another breath.
<G-vec00959-002-s053><exhale.ausatmen><de> Dazu kommt noch die ungeheure Überproduktion von Tieren, die als Nahrungsmittel für den Menschen gezüchtet werden und die Unmengen von Methan und anderen Gasen ausatmen und durch Winde ablassen.
<G-vec00959-002-s053><exhale.ausatmen><en> In addition to that is still the enormous overproduction of animals, which are bred as means of nourishment for the humans and which exhale, and release from the colon, horrendous amounts of methane and other gasses.
<G-vec00959-002-s054><exhale.ausatmen><de> Halten Sie Ihren Atem kurz an und entspannen Sie die Muskeln wieder, während Sie ausatmen.
<G-vec00959-002-s054><exhale.ausatmen><en> Briefly hold your breath and relax the muscles again as you exhale.
<G-vec00959-002-s055><exhale.ausatmen><de> Körperseite — “ausatmen” (3 bis 4 Mal).
<G-vec00959-002-s055><exhale.ausatmen><en> Muladhara — ‘inhale’, anahata — ‘exhale’ (3-4 times).
<G-vec00959-002-s056><exhale.ausatmen><de> Die Position der Unterstützung "unter der Brust" leichtes Schwingen zu machen und dann entlang dem Tank hin und her schieben.Wiggle ist nützlich, zu lernen, in dem Rhythmus des Kindes Atmung zu produzieren: Inspirations - oben auf dem Ausatmen - nach unten.Um die erste Atemluft eines Kindes besser hören kann ihm lehnen enger.
<G-vec00959-002-s056><exhale.ausatmen><en> The position of support "under the breast" to make smooth swinging and then sliding along the tank back and forth.Wiggle is useful to learn to produce in the rhythm of the child's breathing: inspiratory - up on the exhale - down.In order to better hear the first breath of a child can lean close to him.
<G-vec00959-002-s057><exhale.ausatmen><de> Führen Sie Neigungen zu den Seiten und versuchen Sie, den Ellenbogen bis zum Knie zu erreichen: Während Sie nach unten atmen, ausatmen, in seine ursprüngliche Position zurückkehren, einatmen.
<G-vec00959-002-s057><exhale.ausatmen><en> Perform inclinations to the sides, trying to reach the elbow to the knee: while breathing down, exhale, returning to its original position, inhale.
<G-vec00959-002-s058><exhale.ausatmen><de> Sieh wie diese Amateur Babes den süßen Rauch in ihre Lungen ein- und ausatmen.
<G-vec00959-002-s058><exhale.ausatmen><en> See how these amateur babes inhale and exhale the sweet smoke from their lungs.
<G-vec00959-002-s059><exhale.ausatmen><de> Ich fühlte ein Gefühl von Bewegung mit diesem Ausatmen.
<G-vec00959-002-s059><exhale.ausatmen><en> I felt a sensation of movement with this exhale.
<G-vec00959-002-s060><exhale.ausatmen><de> Tief ausatmen durchs rechte Nasenloch und gleich wieder durch das selbe einatmen.
<G-vec00959-002-s060><exhale.ausatmen><en> Exhale deeply through the right nostril and immediately inhale again through the same.
<G-vec00959-002-s061><exhale.ausatmen><de> Jetzt leitet die Gebärmutter selbst langsam das Kind nach vorne, während die Frau sich vollständig entspannen, den Mund öffnen und schnell ein- und ausatmen soll.
<G-vec00959-002-s061><exhale.ausatmen><en> Now the uterus itself slowly directs the child forward, while the woman should completely relax, open her mouth and begin to inhale and exhale quickly.
<G-vec00959-002-s062><exhale.ausatmen><de> Beide Geschlechter nutzen den Rüssel um Feuchtigkeit beim Ausatmen zu resorbieren – dies ist während des Fastens in der Paarungszeit wichtig.
<G-vec00959-002-s062><exhale.ausatmen><en> Both males and females use it as a rebreather of sorts – it reabsorbs moisture when the seals exhale, which is important during their fasts during mating season.
<G-vec00959-002-s063><exhale.ausatmen><de> Dieses gibt nicht nur ein befriedigend reiches und komplexes Aroma, sondern produziert auch ein unglaublich glattes Ausatmen von den beiden Hauptgeschmacksnotizen, die heiraten und einen erdigen Nachgeschmack erzeugen.
<G-vec00959-002-s063><exhale.ausatmen><en> This not only gives a satisfyingly rich and complex flavor but also produces an incredibly smooth exhale from the two main flavor notes marrying and producing an earthy aftertaste.
<G-vec00959-002-s064><exhale.ausatmen><de> Der Geschmack ist eine saubere, Kiefer-frisches Gefühl bei jedem Treffer, gefolgt von einem feinen Zitrus-Aroma, wenn Sie ausatmen.
<G-vec00959-002-s064><exhale.ausatmen><en> The taste is a clean, pine-fresh feeling with every hit followed, by a subtle citrus flavour when you exhale.
<G-vec00959-002-s065><exhale.ausatmen><de> Einatmen, Ausatmen, Staunen: Der Gerzkopf ist ein wahres Natur(schutz)juwel inmitten der Fritztaler Grasberge, das Sie während Ihres Urlaubs in Eben im Pongau definitiv nicht verpassen dürfen.
<G-vec00959-002-s065><exhale.ausatmen><en> Inhale, exhale, be amazed: The nature reserve Gerzkopf in the middle of the Fritztaler Grasberge is truly a natural treasure, which you should definitely not miss during your holiday in Eben im Pongau.
<G-vec00959-002-s066><exhale.ausatmen><de> Muladhara von unten — “einatmen”, Anahata — “ausatmen” vorwärts in die Kugel.
<G-vec00959-002-s066><exhale.ausatmen><en> “Muladhara — ‘inhale’ from below, anahata — ‘exhale’ into the ball.
<G-vec00959-002-s067><exhale.ausatmen><de> Ausatmen kann sie immer, aber das scheint sie nur sehr sparsam zu tun.
<G-vec00959-002-s067><exhale.ausatmen><en> Exhale she can at all times, but in this she seems economical.
<G-vec00959-002-s068><exhale.ausatmen><de> Durch die Aufmerksamkeit auf den Atem—tiefen Atemzug, langsam ausatmen,—wir pflegen eine Widerstandskraft, die es uns erlaubt, anwesend zu sein, wenn eine Stresssituation entsteht.
<G-vec00959-002-s068><exhale.ausatmen><en> By paying attention to the breath—deep breath in, slow exhale out—we cultivate a resilience that allows us to be present when a stressful situation arises.
<G-vec00959-002-s069><exhale.ausatmen><de> Dieser Sauerstoff wiederum dient als Lebensgrundlage aller Tiere auf der Erde, die wiederum CO2 ausatmen, welches die Pflanzen für die Photosynthese nutzen.
<G-vec00959-002-s069><exhale.ausatmen><en> This oxygen sustains the life of all animals on earth. They, in turn, exhale CO2 which the plants use for photosynthesis.
<G-vec00959-002-s070><exhale.ausatmen><de> Wir könne mit dem Atmen aufhören, wir können schneller einatmen, oder tiefer, oder wir können auf jede gewünschte Weise ausatmen.
<G-vec00959-002-s070><exhale.ausatmen><en> We can stop breathing, we can inhale quicker, or more deeply or we can exhale in every way we choose.
<G-vec00959-002-s071><exhale.ausatmen><de> Um die Kraft der Atemmuskulatur zu messen, lässt man die zu testende Person kräftig gegen einen Druckmesser ein- und ausatmen.
<G-vec00959-002-s071><exhale.ausatmen><en> The strength of the respiratory muscles can be measured by having the person forcibly inhale and exhale against a pressure gauge.
<G-vec00959-002-s072><exhale.ausatmen><de> Wenn Sie nun ausatmen, stellen Sie sich vor, daß Sie das Außen von innen her erreichen können.
<G-vec00959-002-s072><exhale.ausatmen><en> Now as you exhale, imagine that you can reach outside from within.
<G-vec00959-002-s073><exhale.ausatmen><de> B. Ausatmen und die Beine mit dem Ball zu dir hinziehen und auf dem Ball balancieren.
<G-vec00959-002-s073><exhale.ausatmen><en> B. Exhale and pull the legs with the ball in towards you and balance on the ball.
<G-vec00959-002-s074><exhale.ausatmen><de> Atme ein, hebe den rechten Arm und drehe Dich ausatmend nach rechts rüber.
<G-vec00959-002-s074><exhale.ausatmen><en> Breathe in, lift your right arm and then rotate and lean to the right as your exhale.
<G-vec00959-002-s075><exhale.ausatmen><de> Von quasireligiösen Motiven – etwa dem gegenseitigen Einhauchen von Atem – bis zu geatmeten Gruppendiskussionen, die den Variantenreichtum des Ein- und Ausatmens abbilden, reicht das Spektrum.
<G-vec00959-002-s075><exhale.ausatmen><en> The spectrum ranges from quasi-religious motifs – such as breathing into each other’s mouths – to breathed group discussions that reflect the rich variety of ways to inhale and exhale.
<G-vec00959-002-s076><exhale.ausatmen><de> Wenn Du für das nächste Stadium bereit bist, öffne die Augen nur während des Ausatmens und halte den Blick auf die Unendlichkeit gerichtet.
<G-vec00959-002-s076><exhale.ausatmen><en> When you are ready for the next stage, open your eyes on the exhale only, keeping the glance set at infinity.
<G-vec00959-002-s077><exhale.ausatmen><de> Und indem du ausatmest, stell dir vor, du atmest alles aus, was du loslassen möchtest.
<G-vec00959-002-s077><exhale.ausatmen><en> And as you exhale, imagine you are exhaling. . . anything you want to let go of.
<G-vec00959-002-s078><exhale.ausatmen><de> Mache ein "Uuh"-Geräusch, wenn du ausatmest.
<G-vec00959-002-s078><exhale.ausatmen><en> When you exhale, make a “woo” sound.
<G-vec00959-002-s079><exhale.ausatmen><de> Glück ist etwas, was du ausatmest, nicht etwas, was du einatmest.
<G-vec00959-002-s079><exhale.ausatmen><en> Happiness is something you exhale, not something you inhale.
<G-vec00959-002-s080><exhale.ausatmen><de> Laß es mich so sagen: wann immer du einatmest, ist es Leben, und wann immer du ausatmest, ist es der Tod.
<G-vec00959-002-s080><exhale.ausatmen><en> Let me put it this way: whenever you inhale, it is life, and whenever you exhale, it is death.
<G-vec00959-002-s081><exhale.ausatmen><de> Ich verstand nicht was mit mir passierte, aber plötzlich war alles blockiert, ich konnte nicht mehr atmen, und ein großes Rasseln kam aus meinem Hals anstelle von Luft, wie man normalerweise ausatmet.
<G-vec00959-002-s081><exhale.ausatmen><en> I didn't understand what was happening to me, but suddenly everything was blocked, I couldn't breathe, and a great rattle came out of my throat instead of air, the way one would normally exhale.
<G-vec00959-002-s085><exhale.ausatmen><de> Den Patienten auffordern, durch das Mundstück ein- und auszuatmen, bis die Behandlung beendet ist.
<G-vec00959-002-s085><exhale.ausatmen><en> Ask the patient to inhale and exhale through the mouthpiece until the treatment is finished.
<G-vec00959-002-s086><exhale.ausatmen><de> Ich habe mich fallen lassen, bin ganz ins Gefühl von Entspannung und Erholung gekommen, habe einfach mir selber erlaubt, auszuatmen, loszulassen, still zu werden.
<G-vec00959-002-s086><exhale.ausatmen><en> I let myself go, entering a deep state of relaxation and recuperation, and allowed myself to exhale, to let go, to enter into stillness.
<G-vec00959-002-s087><exhale.ausatmen><de> Beginnen Sie, langsam auszuatmen, während Sie sich nach links beugen.
<G-vec00959-002-s087><exhale.ausatmen><en> Start to exhale slowly while you bend to the left.
<G-vec00959-002-s088><exhale.ausatmen><de> Höre auf deine Atmung, versuche tief und langsam einzuatmen und auszuatmen.
<G-vec00959-002-s088><exhale.ausatmen><en> Listen to your breathing, try to inhale and exhale deeply and slowly.
<G-vec00959-002-s089><exhale.ausatmen><de> Als Folge scheint der 'Sarg' langsam ein- und auszuatmen, je nachdem ob der CO2-Gehalt zu- oder abnimmt.
<G-vec00959-002-s089><exhale.ausatmen><en> "He has arrived." (breathe out), As a result, the 'coffin' seems to slowly inhale and exhale as the CO2 level goes up and down.
<G-vec00959-002-s090><exhale.ausatmen><de> In den Intervallen zwischen ihnen ist es ratsam, einen tiefen Atemzug zu nehmen und auszuatmen, beruhigen Sie Ihren Atem und ruhen Sie sich bis zum nächsten Kampf aus.
<G-vec00959-002-s090><exhale.ausatmen><en> In the intervals between them, it is recommended to take a deep breath and exhale, calm your breathing and rest until the next fight.
<G-vec00959-002-s092><exhale.ausatmen><de> Franco's hat einen sehr zitronigen Geruch mit dem typischen Käsegeschmack beim Ausatmen.
<G-vec00959-002-s092><exhale.ausatmen><en> Franco's has a very lemony smell with the typical cheese taste on the exhale.
<G-vec00959-002-s093><exhale.ausatmen><de> Der Geschmack kann als kühler fruchtiger Mentholgeschmack mit einem Hauch von Zitrone, Kiefer und Moschus beschrieben werden, der beim Ausatmen würzig und ölig wird.
<G-vec00959-002-s093><exhale.ausatmen><en> The flavor can be described as a cool menthol fruity taste with a touch of pine and lemon that turns musky, spicy and oily on the exhale.
<G-vec00959-002-s094><exhale.ausatmen><de> Heben Sie den Körper beim Ausatmen leicht an und senken Sie ihn dann langsam in seine ursprüngliche Position ab.
<G-vec00959-002-s094><exhale.ausatmen><en> As you exhale, slightly raise the body, and then slowly lower it to its original position.
<G-vec00959-002-s095><exhale.ausatmen><de> Zieh beim Ausatmen deinen Bauch ein, damit du möglichst viel Luft herausdrückst.
<G-vec00959-002-s095><exhale.ausatmen><en> As you exhale, pull your stomach in to help expel as much air as you can.[7]
<G-vec00959-002-s096><exhale.ausatmen><de> Entspann beim Ausatmen Dein Gesicht.
<G-vec00959-002-s096><exhale.ausatmen><en> Relax your face on the exhale.
<G-vec00959-002-s097><exhale.ausatmen><de> Dies führt zu einem sehr angenehmen Geschmack und Geschmeidigkeit sowohl beim Einatmen als auch beim Ausatmen.
<G-vec00959-002-s097><exhale.ausatmen><en> This translates into a very nice taste and smoothness on both the inhale and exhale.
<G-vec00959-002-s101><exhale.ausatmen><de> Übe das projizieren von deinem Zwerchfell, indem du deinen Magen einziehst, um auszuatmen, während du sprichst.
<G-vec00959-002-s101><exhale.ausatmen><en> Practice projecting from your diaphragm by pulling your stomach in to exhale as you speak.
<G-vec00959-002-s113><exhale.ausatmen><de> Bei der entschleunigten Atmung wird vier Sekunden lang eingeatmet und sechs Sekunden lang ausgeatmet.
<G-vec00959-002-s113><exhale.ausatmen><en> Slow paced breathing uses a four seconds inhale and six seconds exhale breathing pattern.
<G-vec00959-002-s116><exhale.ausatmen><de> Mit dem nächsten Ausatmen bewegt Ihr den Oberkörper nach vorn bis er sich zwischen Euren Oberschenkeln befindet.
<G-vec00959-002-s116><exhale.ausatmen><en> Now, exhale and move your torso forward until it rests between your thighs.
<G-vec00959-002-s117><exhale.ausatmen><de> Wenn die Phase der Inhalation und des bewussten Wahrnehmens abgeschlossen ist, dann musst Du (mit Porenatmung des ganzen Körpers) dieselbe Menge des Elements magisch ausatmen, die Du zuvor inhaliert hattest.
<G-vec00959-002-s117><exhale.ausatmen><en> When this phase of inhalation and contemplation is complete, you must then magically exhale (with the whole body pore breathing) the same amount of the Element that you inhaled.
<G-vec00959-002-s120><exhale.ausatmen><de> Ungefähr 98% aller Raucher weisen ein spezielles Atmungsverhalten auf, indem sie Zigarettenrauch inhalieren, in der Lunge behalten und ihn dann wieder gründlich ausatmen.
<G-vec00959-002-s120><exhale.ausatmen><en> About 98% of all smokers breathe in a particular way, in that they inhale cigarette smoke, keep it in the lungs and then exhale it thoroughly.
<G-vec00959-002-s121><exhale.ausatmen><de> Konzentrieren Sie sich nun auf Ihren Atem – spüren Sie, wie Sie langsam ein- und wieder ausatmen.
<G-vec00959-002-s121><exhale.ausatmen><en> Now concentrate on your breathing – feel how you slowly inhale and exhale.
<G-vec00959-002-s123><exhale.ausatmen><de> Es geht jetzt darum, Licht zunächst über die Beine “einzuatmen” und über das Muladhara nach vorn wieder “auszuatmen” und dabei alles hinausstoßen, was seine Bewegung behindert.
<G-vec00959-002-s123><exhale.ausatmen><en> ‘Inhale’ the light through the legs and ‘exhale’ it through muladhara forward, pushing out everything that hinders its flow.
<G-vec00959-002-s124><exhale.ausatmen><de> Während der Übung muss ich häufig heftig ausatmen – werde nach jeder Ausatmung größer.
<G-vec00959-002-s124><exhale.ausatmen><en> During this process I feel the need repeatedly to exhale heavily – and am growing bigger with each exhalation.
<G-vec01019-002-s194><breathe.ausatmen><de> Halten Sie nun die Spannung der Muskeln einige Sekunden, während Sie weiter normal ein- und ausatmen.
<G-vec01019-002-s194><breathe.ausatmen><en> Try then to hold a contraction for a few seconds while you continue to breathe in and out as normal.
<G-vec01019-002-s195><breathe.ausatmen><de> Ihr könnt auch einige Minuten weisses Licht einatmen und alles ausatmen, was euch nicht dient.
<G-vec01019-002-s195><breathe.ausatmen><en> You can also breathe in white light and breathe out what doesn’t serve you for a few minutes.
<G-vec01019-002-s196><breathe.ausatmen><de> Während des Kampfes sollten Sie mit der Nase tief durchatmen und dann mit dem Mund ausatmen.
<G-vec01019-002-s196><breathe.ausatmen><en> During the bout, you should take a deep breath with your nose, and then breathe out with your mouth.
<G-vec01019-002-s197><breathe.ausatmen><de> Jedesmal wenn ich hustete, lief Wasser aus meinem Hals, und ich konnte nur ein winzige Menge einatmen, ich konnte nicht ausatmen.
<G-vec01019-002-s197><breathe.ausatmen><en> Every time I coughed, water poured out of my throat I could only breathe back a tiny amount, I couldn't breathe out.
<G-vec01019-002-s198><breathe.ausatmen><de> Nur zu Übungszwecken: Vollständig ausatmen durch Anspannen der Bauchmuskulatur und diese angespannt lassen.
<G-vec01019-002-s198><breathe.ausatmen><en> During practise only: Breathe out completely by pulling the abdomen in and keeping the abdominal muscles tensed.
<G-vec01019-002-s199><breathe.ausatmen><de> Atmung: Einatmen, wenn Sie den Oberkörper nach links oder rechts beugen und ausatmen, wenn Sie in die Mitte zurückkehren.
<G-vec01019-002-s199><breathe.ausatmen><en> Breathing: Breathe in as you bend your torso to the left or to the right, and breathe out as you come back to the centre.
<G-vec01019-002-s200><breathe.ausatmen><de> Beim Ausatmen fühle ich Dankbarkeit für meinen Magen und dafür, dass er immer für mich da ist.
<G-vec01019-002-s200><breathe.ausatmen><en> As I breathe out, I feel so thankful for my stomach, that is always there for me.
<G-vec01019-002-s201><breathe.ausatmen><de> Wichtig ist das Ausatmen, denn wer beim Joggen zu schnell und zu tief einatmet, riskiert, zu hyperventilieren.
<G-vec01019-002-s201><breathe.ausatmen><en> Breathing out is important, as those who breathe in too quickly and deeply when jogging run the risk of hyperventilating.
<G-vec01019-002-s202><breathe.ausatmen><de> Wenn wir ausatmen, fühlen wir, wie unser Bauch sich wieder senkt.
<G-vec01019-002-s202><breathe.ausatmen><en> When we breathe out, we feel our tummy go down again.
<G-vec01019-002-s203><breathe.ausatmen><de> Atmung: Ausatmen wenn Sie den Po heben und den Arm nach oben strecken, dann einatmen wenn Sie lockern.
<G-vec01019-002-s203><breathe.ausatmen><en> Breathing: Breathe out as you lift up your glutes and stretch your arm upwards, and then breathe in as you let go.
<G-vec01019-002-s204><breathe.ausatmen><de> Er übt sich selbst: ‘Ich werde empfindsam, gegenüber dem gesamten Körper, einatmen’;[7] er übt sich selbst ‘Ich werde empfindsam, gegenüber dem gesamten Körper, ausatmen’.
<G-vec01019-002-s204><breathe.ausatmen><en> [3] He trains himself, 'I will breathe in sensitive to the entire body'; he trains himself, 'I will breathe out sensitive to the entire body.'
