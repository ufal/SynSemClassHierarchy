<G-vec01141-002-s097><anchor.ankern><de> Ithaka ist die kleinere der beiden Inseln und hat atemberaubende Buchten zum Ankern.
<G-vec01141-002-s097><anchor.ankern><en> Ithaca is the smaller one of both and has gorgeous bays to anchor in.
<G-vec01141-002-s098><anchor.ankern><de> Man kann in einer Bucht ankern und von dort aus die berühmten Schatzhöhlen erkunden.
<G-vec01141-002-s098><anchor.ankern><en> You can anchor at the Bight and then explore the famous treasure caves.
<G-vec01141-002-s099><anchor.ankern><de> Wir fahren flussaufwärts und ankern in Skradin, kurz vor den berühmten Krka-Wasserfällen.
<G-vec01141-002-s099><anchor.ankern><en> We go upriver and anchor in Skradin, shortly before the famous Krka waterfalls.
<G-vec01141-002-s100><anchor.ankern><de> Ankern ist im Umfeld von 200 Metern vom Kaikopf verboten, um der Steuerung der öffentlichen Schiffsverkehrmittel nicht im Wege zu sein; Freizeitsegler können an der Nordseite des Kais entlang anlegen.
<G-vec01141-002-s100><anchor.ankern><en> Within a distance of 200m around the pier it is prohibited to drop anchor so as not to hinder the passing of public transportation.
<G-vec01141-002-s101><anchor.ankern><de> Nach dem zweiten Törntag dürfen auch führerscheinfreie Crews über den Plauer See fahren und neben der Stadt Brandenburg die idyllische Seenkette der Beetzsee-Riewendsee-Wasserstraße erkunden und dort zum Beispiel zum Baden ankern.
<G-vec01141-002-s101><anchor.ankern><en> After the second Törntag also driving licence-free crews over the Plauer lake there may drive and beside the city Brandenburg the idyllische sea-chain of the Beetzsee Riewendsee water way explore and for example for bathing anchor.
<G-vec01141-002-s102><anchor.ankern><de> Um nahe des Strandes verweilen zu können, ankern wir meist etwas am Rand vor Salinas vor dem Beachclub Sa Trinxa.
<G-vec01141-002-s102><anchor.ankern><en> In order to stay near the beach, we usually anchor at the edge of Salinas, in front of Sa Trinxa.
<G-vec01141-002-s103><anchor.ankern><de> Die Musik war beim Ankern, wo wir eigentlich ein bisschen Ruhe wollten, etwas zu laut.
<G-vec01141-002-s103><anchor.ankern><en> The music was at anchor, where we wanted to rest a bit, a bit too loud.
<G-vec01141-002-s104><anchor.ankern><de> Auf unserer Rückfahrt haben wir vielleicht noch Gelegenheit, dem Hafen von Ocumare einen Besuch abzustatten, oder in der Bucht von Cata zu ankern, bevor wir gegen 17.00 Uhr wieder nach Puerto Colombia zurückkehren.
<G-vec01141-002-s104><anchor.ankern><en> On our way back we maybe have the opportunity to visit the harbour of "Ocumare de la Costa" or we anchor in the bay of Cata.
<G-vec01141-002-s105><anchor.ankern><de> Am Ende eines langen Tages ankern wir in der Moonlight Cove, einer kleinen Bucht kurz vor dem Ausgang des Mc Carty Fjords.
<G-vec01141-002-s105><anchor.ankern><en> At the end of a long day we anchor in the Moonlight Cove, a small bay at the eastern side of the Mc Carty Fiord.
<G-vec01141-002-s106><anchor.ankern><de> Am fruehen Nachmittag ankern wir mit Hilfe der Brueder Idelfonso und Venancio gegenueber dem Dock von Mormake Dupu.
<G-vec01141-002-s106><anchor.ankern><en> In the early afternoon we work our way in between the shallows and anchor off Mormake Dupu village dock with the help of the brothers Idelfonso and Venancio in their dugout.
<G-vec01141-002-s107><anchor.ankern><de> Bevor wir in den Hafen von Sali einlaufen, ankern wir natürlich in einer der zahlreichen Buchten mit glasklarem Wasser, um ein erfrischendes Bad zu nehmen.
<G-vec01141-002-s107><anchor.ankern><en> Before we reach the port in Sali, we shall naturally drop anchor in one of the coves and take a swimming break. DAY 4
<G-vec01141-002-s108><anchor.ankern><de> Den Skippern wird empfohlen, in der unmittelbaren Umgebung der kleinen Inseln zu ankern.
<G-vec01141-002-s108><anchor.ankern><en> The navigator is recommended to anchor in the surroundings of the small island.
<G-vec01141-002-s109><anchor.ankern><de> Am nächsten Tag segeln wir durch ein Gewirr an Fischerbooten hindurch an einer schönen Mangrovenküste vorbei und ankern im Nordwesten von Penang.
<G-vec01141-002-s109><anchor.ankern><en> On the next day we sail through lots of fishing boats and nets past a wonderful mangrove forest and anchor in the northwest of Penang.
<G-vec01141-002-s110><anchor.ankern><de> Wir ankern in einer kleinen Bucht vor dem Ort Chacala.
<G-vec01141-002-s110><anchor.ankern><en> We anchor in a little bay off the small town Chacala.
<G-vec01141-002-s111><anchor.ankern><de> Jetzt ankern wir in einer Bucht mit Marina und viel Tourismus.
<G-vec01141-002-s111><anchor.ankern><en> We’ve dropped anchor in a bay next to a marina and a lot of tourism.
<G-vec01141-002-s112><anchor.ankern><de> Fahren Sie nach Curieuse und ankern Sie für die Nacht in Baie Laraie, Ostküste, oder gehen Sie zurück zu Baie Sainte Anne, falls Sie Wasser benötigen.
<G-vec01141-002-s112><anchor.ankern><en> Make for Curieuse and anchor for the night in Laraie Bay, on the east coast, or head back to Baie Ste Anne if you need supplies.
<G-vec01141-002-s113><anchor.ankern><de> Die halbtägige Bootstour ab Formenteras Hafen in La Savina führt Sie entlang der felsigen Westküste zu einer wunderschönen Sandbucht, in der Sie ankern werden, um das vorbereitete Essen und das Meer genießen zu können.
<G-vec01141-002-s113><anchor.ankern><en> The half day boat trip from Formentera's port in La Savina takes you along the rocky west coast to a beautiful sandy bay where you will anchor to enjoy the prepared food and the sea.
<G-vec01141-002-s114><anchor.ankern><de> Der Einsatz eines Aquascopes würde diese Operation erleichtern, und wir könnten sicher feststellen, über welcher Oberfläche wir ankern wollen.
<G-vec01141-002-s114><anchor.ankern><en> The use of a depth gauge will facilitate this operation and we can confirm on what surface we are intending to anchor.
<G-vec01141-002-s115><anchor.ankern><de> - Nun geht es zurück in die Lagune, wo das Wasser türkisblau ist und wir werden an einem neuen besonderen Ort auf dem Riff für einen weiteren Schnorchel ankern.
<G-vec01141-002-s115><anchor.ankern><en> - Now we head back inside the lagoon where the water is turquoise blue and anchor up at a new special spot on the reef for another snorkel.
