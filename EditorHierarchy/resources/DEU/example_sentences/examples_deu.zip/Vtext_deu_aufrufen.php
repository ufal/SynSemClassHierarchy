<G-vec00092-001-s209><call.aufrufen><de> Point.Show End; Compiler Links aufrufen zu statisch Punkt Subroutine.
<G-vec00092-001-s209><call.aufrufen><en> Point.Show End; Compiler links statically call to subroutine point.
<G-vec00092-001-s210><call.aufrufen><de> MyMail ist nicht wirklich das, was man ein MailChimp Plugin aufrufen.
<G-vec00092-001-s210><call.aufrufen><en> MyMail is not really what you would call a MailChimp plugin.
<G-vec00092-001-s211><call.aufrufen><de> Beachten Sie, dass der Trigger beim Aufrufen von SAVE RECORD und nicht beim Erstellen aktiv wird.
<G-vec00092-001-s211><call.aufrufen><en> Note that the trigger is invoked at the moment you call SAVE RECORD, not when it is created.
<G-vec00092-001-s212><call.aufrufen><de> Das bedeutet, dass Sie vor einem Durchlauf von foreach reset() nicht aufrufen müssen.
<G-vec00092-001-s212><call.aufrufen><en> This means that you do not need to call reset() before a foreach loop.
<G-vec00092-001-s213><call.aufrufen><de> Beim Aufrufen und der Nutzung unserer Website erheben wir die personenbezogenen Daten, die dein Browser automatisch an unseren Server übermittelt.
<G-vec00092-001-s213><call.aufrufen><en> Whenever you call up and use our website, we collect the personal data automatically. Your browser then transmits this to our server.
<G-vec00092-001-s214><call.aufrufen><de> Frauen, die glauben, dass mit einen eleganten und sinnlichen Duft notwendig ist, die romantische Atmosphäre Erhöhung und Bedeutung der jede Gelegenheit sollte Relief in der Tatsache, dass sie haben die Möglichkeit, mit einen Duft, den sie wirklich ihre eigenen aufrufen können.
<G-vec00092-001-s214><call.aufrufen><en> Women who believe that having an elegant and sensuous fragrance is necessary to boost the romantic feel and meaning of any occasion should take relief in the fact that they have the option of using a fragrance that they can truly call their own.
<G-vec00092-001-s215><call.aufrufen><de> Da das Komprimieren sehr langsam abläuft, ist damit das regelmäßige Aufrufen einer Prozedur zum Verfolgen des Pack-Prozesses möglich.
<G-vec00092-001-s215><call.aufrufen><en> As the compression is (relatively) slow, it's possible to call a procedure at regular time to follow the packing progress.
<G-vec00092-001-s216><call.aufrufen><de> Nach dem Motto Gemeinsam sind wir stark möchte die Rennstrecke Motorsportler, Fans sowie Besucher des Nürburgrings und der Region dazu aufrufen, auch im öffentlichen Straßenverkehr als gutes Beispiel voran zu gehen.
<G-vec00092-001-s216><call.aufrufen><en> True to the motto Together we are strong, the race track aims to call on racing professionals and fans as well as visitors of the Nürburgring and the region to be a role model also on public roads.
<G-vec00092-001-s217><call.aufrufen><de> Die Veranstaltung sollte die Aufmerksamkeit der britischen Bürger auf die Chinesen im Festland China lenken, die unter der brutalen kommunistischen Diktatur leiden und gleichzeitig die Chinesen aufrufen, aus der KP Chinas und ihren angegliederten Organisationen auszutreten.
<G-vec00092-001-s217><call.aufrufen><en> This event was to encourage UK people to show concern for the Chinese people in mainland China who have been suffering under a brutal communist dictatorship, and was also to call on the Chinese people to quit the CCP and its related organisations.
<G-vec00092-001-s218><call.aufrufen><de> Wenn Sie jetzt Library-Befehle mit Eintreten aufrufen, springt der Programmzeiger zwar nicht in die Library, kann aber in Ihrer Callback-Routine landen, wenn diese gerade von der Library aus aufgerufen wird.
<G-vec00092-001-s218><call.aufrufen><en> If you now call library commands using [Step into], the program pointer does not jump into the library but could land in your callback routine if this is just now being called from within the library.
<G-vec00092-001-s219><call.aufrufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00092-001-s219><call.aufrufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00092-001-s220><call.aufrufen><de> Bei ausgeschalteter Zündung können Sie die Anzeige auch mit der Taste SET aufrufen Link.
<G-vec00092-001-s220><call.aufrufen><en> You can also call up the display when the ignition is switched off by pressing the SET button Link.
<G-vec00092-001-s221><call.aufrufen><de> int MyFunction (char *); Dies definiert eine Funktion vom Typ int, die ein char * empfangen kann, die Funktion selbst kann jetzt sonst wo stehen, sie ist definiert, der Compiler meckert nicht wenn wir sie aufrufen und beim Aufruf wird die echte Funktion verwendet, egal wo sie steht.
<G-vec00092-001-s221><call.aufrufen><en> int MyFunction (char *); This defines a function of type int which can receive a char * for input, the actual function can now be put anywhere else, it is defined, so the compiler won ́t complain if we call it, and upon calling it the compiler will use the actual function instead of the prototype, no matter where it is located.
<G-vec00092-001-s222><call.aufrufen><de> Tipp: Zu einer Formularvorlage können Sie eine Übersicht - analog zum internen Formulargenerator - aufrufen, in der die Datenfelder je Formularabschnitt aufgelistet sind (Menüpunkt Funktion | Felder).
<G-vec00092-001-s222><call.aufrufen><en> Tip: For a form template, you can call up an overview – analogous to the internal form builder – in which the data fields are listed per form section (Function | Fields menu item).
<G-vec00092-001-s223><call.aufrufen><de> Damit Benutzer auf Ihrem Terminal nicht ähnliche Funktionen aufrufen können, sollten Sie die Option eingeschaltet lassen.
<G-vec00092-001-s223><call.aufrufen><en> In order to prevent your users from being able to call up similar functions, you should leave this option turned on.
<G-vec00092-001-s224><call.aufrufen><de> Zusätzlich zum internen Mapping von logischen Schnittstellen mittels 'id_str', kann wpa_action externe Mapping-Scripts aufrufen.
<G-vec00092-001-s224><call.aufrufen><en> In addition to the internal mapping of logical interfaces via 'id_str', wpa_action can call external mapping scripts.
<G-vec00092-001-s225><call.aufrufen><de> Sollten Sie diese Website aufrufen und/oder Inhalte herunterladen, so sind Sie selbst dafür verantwortlich, dass dies mit den in Ihrem Aufenthaltsort geltenden lokalen Gesetzen vereinbar ist.
<G-vec00092-001-s225><call.aufrufen><en> Should you call up this website or download contents, please note that it is your own responsibility to ensure that you act in compliance with local legislation applicable in that place.
<G-vec00092-001-s226><call.aufrufen><de> Aber brauchen manchmal Sie nur wenig Motivatoren; vielleicht ein hübsch sagen auf einem Plakat zu machen, Sie fühlen, wie Sie an die macht Ihre eigenen Aufnahmen aufrufen.
<G-vec00092-001-s226><call.aufrufen><en> However, sometimes you only need little motivators; maybe a cute saying on a poster, to make you feel like you have to power to call your own shots.
<G-vec00092-001-s227><call.aufrufen><de> Sie können REST-Dienste über einen beliebigen REST-Client aufrufen.
<G-vec00092-001-s227><call.aufrufen><en> You can call REST services by using any REST client.
<G-vec00092-001-s247><call.aufrufen><de> Es gibt verschiedene Wege, den Farb-Dialog aufzurufen, nachdem das zu färbende Bauteil ausgewählt wurde.
<G-vec00092-001-s247><call.aufrufen><en> There are several ways to call up the Color dialog once the part has been selected:
<G-vec00092-001-s248><call.aufrufen><de> Die Resolution fordert die Zentralregierung dringlich auf, die Vereinten Nationen, die internationalen Menschenrechtsorganisationen und die Weltgesundheitsorganisationen dazu aufzurufen, Delegationen nach China zu schicken, Untersuchungen anzustellen und die Ergebnisse zu veröffentlichen, damit die grundlegenden Menschenrechte gewahrt bleiben und die KPC dazu aufgefordert wird, diese Brutalität sofort zu beenden.
<G-vec00092-001-s248><call.aufrufen><en> The resolution urged the central government to call for the United Nations, international human right organisations and world health organisations to send delegates to China to investigate and publish reports to safeguard basic human rights, and to demand the CCP to immediately stop the brutality.
<G-vec00092-001-s249><call.aufrufen><de> Um Flöhe mit hohen Temperaturen auszubrennen, ist es sinnvoll, Spezialteams aufzurufen: Sie werden die Aufgabe schnell und mit garantierten Ergebnissen erledigen (sie verwenden leistungsstarke Heißluftgebläse).
<G-vec00092-001-s249><call.aufrufen><en> To “burn out” fleas with high temperatures, it is rational to call up special teams: they will cope with the task quickly and with guaranteed results (they use powerful heat guns).
<G-vec00092-001-s250><call.aufrufen><de> Es reicht nicht, nur zum Sturz dieser Regierung aufzurufen.
<G-vec00092-001-s250><call.aufrufen><en> It is not enough to call for the fall of this government.
<G-vec00092-001-s251><call.aufrufen><de> Mobile Apps können Ajax-Anforderungen absetzen, um Prozeduren aufzurufen.
<G-vec00092-001-s251><call.aufrufen><en> Mobile apps can call these procedures by issuing AJAX requests.
<G-vec00092-001-s252><call.aufrufen><de> Ich kenne jeden von euch beim Namen und kam vom Himmel um euch zur Bekehrung aufzurufen.
<G-vec00092-001-s252><call.aufrufen><en> I know each of you by name and I come from Heaven to call you to conversion.
<G-vec00092-001-s253><call.aufrufen><de> Der 'Balance'-Wert wird für den #Sound gespeichert - deshalb ist es nicht nötig, diesen jedes Mal aufzurufen.
<G-vec00092-001-s253><call.aufrufen><en> The pan value is saved for the #Sound, so it's not needed to call it every time.
<G-vec00092-001-s254><call.aufrufen><de> Im Unterschied zum CWI stellt Workers Power zutreffend fest, dass „die HDP keine Partei der Arbeiterklasse, sondern eine kleinbürgerliche Organisation ist“ – um dann trotzdem zur Stimmabgabe für sie aufzurufen.
<G-vec00092-001-s254><call.aufrufen><en> Unlike the CWI, Workers Power rightly notes that “the HDP is not a working class party but a petty bourgeois organisation”—only to call for a vote for them anyway.
<G-vec00092-001-s255><call.aufrufen><de> Aufzurufen ist wichtig, und gerechtes Sagen hallo zu Ihren Mitfranchisenehmern, weil sie sie erinnert, daß Sie immer nahe vorbei sind.
<G-vec00092-001-s255><call.aufrufen><en> It is important to call up and just say hi to your fellow franchisees because it will remind them that you are always near by.
<G-vec00092-001-s256><call.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00092-001-s256><call.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00092-001-s257><call.aufrufen><de> Gott hat zu jedem Volk einen Propheten gesandt, meistens einen der ihren, um sie dazu aufzurufen, Gott allein zu dienen und falsche Götter zu meiden.
<G-vec00092-001-s257><call.aufrufen><en> God sent to every nation a prophet, mostly from amongst them, to call them to worship God alone and to shun false gods.
<G-vec00092-001-s258><call.aufrufen><de> Die Veranstaltung war organisiert als Teil einer weltweiten Aktion, um Aufmerksamkeit auf die fortwährende Menschenrechtskrise des gewaltsamen Verschwindenlassens in Mexiko zu richten und die mexikanische Regierung aufzurufen, diese Krise zu beenden.
<G-vec00092-001-s258><call.aufrufen><en> The event was organised as part of a global action to raise awareness of the ongoing human rights crisis of forced disappearances in Mexico, and to call on the Mexican Government to end it.
<G-vec00092-001-s259><call.aufrufen><de> Geliebte Kinder, Ich kam vom Himmel um euch zu einer edlen Mission aufzurufen: Jesus allen zu verkuendigen welche Ihn noch nicht kennen.
<G-vec00092-001-s259><call.aufrufen><en> Dear children, I came from Heaven to call you to a noble mission: announce Jesus to all those who do not yet know Him.
<G-vec00092-001-s260><call.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00092-001-s260><call.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00092-001-s261><call.aufrufen><de> Ich bin heute nacht zu euch gekommen um euch aufzurufen um Wiedergutmachung am Fest der Heiligen Unschuldigen Kinder zu machen und in die Heilige Familie einzutreten - am Festtag der Heiligen Familie.
<G-vec00092-001-s261><call.aufrufen><en> I come to you this night to call you to make reparation on the Feast of the Holy Innocents and to step inside the Holy Family on the Feast of the Holy Family. When you belong to a family there are family obligations.
<G-vec00092-001-s262><call.aufrufen><de> "Nachdem die Praktizierenden ihr erklärt hatten, daß solche Folterungen gerade jetzt in China gegen Falun Gong Praktizierender geschehen, und unsere Aktivität dem Zweck diente, zu einem Ende der Verfolgung gegen unschuldige Menschen aufzurufen, verstand die alte Frau und unterschrieb unsere Petition zur ""Unterstützen Sie Falun Gong Praktizierender in China, verurteilen Sie die Verfolgung gegen Falun Gong""."
<G-vec00092-001-s262><call.aufrufen><en> After practitioners explained to her that these tortures are occurring right now in China against Falun Gong practitioners and our activity here today was to call for the end of persecution against innocent people, the old lady understood the truth and signed our petition to “Support Falun Gong Practitioners in China, Denounce the Persecution Against Falun Gong”.
<G-vec00092-001-s263><call.aufrufen><de> Um die Plugin-Version aufzurufen, wählen Sie den Befehl Datei -> Automatisieren -> AKVIS Magnifier in Photoshop.
<G-vec00092-001-s263><call.aufrufen><en> To call this plugin: in Adobe Photoshop select the menu item File -> Automate -> AKVIS Magnifier;
<G-vec00092-001-s264><call.aufrufen><de> Aber die Gewerkschaftsbürokratie wirkt weiterhin als Bremser, deutlich sichtbar an ihrem Zögern, zum Generalstreik aufzurufen.
<G-vec00092-001-s264><call.aufrufen><en> But the trade union bureaucracy continues to act as a brake, as we can see from their slowness to call a general strike.
<G-vec00092-001-s265><call.aufrufen><de> Dabei wird den Rettungskräften über eine seit Anfang 2013 verfügbare Online-Kennzeichenabfrage die Möglichkeit geboten, sehr schnell das jeweils zutreffende Rettungsdatenblatt eines verunfallten Fahrzeuges online aufzurufen und die speziellen fahrzeugbezogenen Angaben bei der Rettungsarbeit zu berücksichtigen.
<G-vec00092-001-s265><call.aufrufen><en> Since the beginning of 2013, emergency rescue personnel can now use an online license plate look-up service to quickly call up the pertinent rescue data sheet for a vehicle that has been involved in an accident and to thus take into account the specific vehicle-related information in their rescue work.
<G-vec00364-002-s129><recall.aufrufen><de> Die auf Ihrem Computer oder Mobilgerät gespeicherten Cookies können nicht verwendet werden, um irgendwelche Daten von Ihrer Festplatte aufzurufen, Informatikviren zu übertragen, Ihre E-Mail zu erkennen und zu benutzen.
<G-vec00364-002-s129><recall.aufrufen><en> The cookies stored in your computer or mobile device cannot be used to recall any of the data stored in your hard disk, transmit viruses, identify and use your e-mail address, or for purposes other than those described above.
<G-vec00364-002-s130><recall.aufrufen><de> Um einen gespeicherten Sender aufzurufen, drücken Sie kurz die Taste auf der Fernbedienung oder PRESET am Gerät, wählen diesen anhand der Tasten ▲/▼ auf der Fernbedienung oder mit dem NAVIGATE-Knopf am Gerät aus und bestätigen mit OK.
<G-vec00364-002-s130><recall.aufrufen><en> To recall a stored frequency, press the button on the remote control or the PRESET button on the unit once to view the preset list, select the desired station using the ▲/▼ buttons on the remote control or the NAVIGATE knob on the unit and press OK to play that station.
<G-vec00364-002-s131><recall.aufrufen><de> Wenn Sie beispielsweise Seiten von Spotlio personalisieren oder sich auf der Webseite von Spotlio oder für Dienstleistungen registrieren, hilft ein Cookie Spotlio, Ihre spezifischen Informationen bei nachfolgenden Besuchen aufzurufen.
<G-vec00364-002-s131><recall.aufrufen><en> For example, if you personalize Chartwell Gallery pages, or register with Chartwell Gallery site or services, a cookie helps Chartwell Gallery to recall your specific information on subsequent visits.
<G-vec00364-002-s132><recall.aufrufen><de> Und es macht so viel Spaß, beim Virtuellen Soundcheck einen Song aufzurufen (ich nehme meist ‚Paradise Circus‘), die Kanäle zu aktivieren und sofort fast genau den Sound zu hören, den man haben will.
<G-vec00364-002-s132><recall.aufrufen><en> It’s such a joy to recall a song for Virtual Soundcheck, I usually use ‘Paradise Circus’, unmute the channels and hear almost exactly what you want from the get-go.
<G-vec00272-003-s266><call_for.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00272-003-s266><call_for.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00272-003-s267><call_for.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00272-003-s267><call_for.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00272-003-s268><call_for.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00272-003-s268><call_for.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00272-003-s269><call_for.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00272-003-s269><call_for.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00272-003-s270><call_for.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00272-003-s270><call_for.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00272-003-s271><call_for.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00272-003-s271><call_for.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00272-003-s272><call_for.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00272-003-s272><call_for.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00272-003-s273><call_for.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00272-003-s273><call_for.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00272-003-s274><call_for.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00272-003-s274><call_for.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00272-003-s275><call_for.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00272-003-s275><call_for.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00272-003-s276><call_for.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00272-003-s276><call_for.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00272-003-s277><call_for.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00272-003-s277><call_for.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00272-003-s278><call_for.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00272-003-s278><call_for.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00272-003-s279><call_for.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00272-003-s279><call_for.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00272-003-s280><call_for.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00272-003-s280><call_for.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00272-003-s281><call_for.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00272-003-s281><call_for.aufrufen><en> Tried to call a removed routine.
<G-vec00272-003-s282><call_for.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00272-003-s282><call_for.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00272-003-s283><call_for.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00272-003-s283><call_for.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00272-003-s284><call_for.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00272-003-s284><call_for.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00361-003-s266><call_on.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00361-003-s266><call_on.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00361-003-s267><call_on.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00361-003-s267><call_on.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00361-003-s268><call_on.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00361-003-s268><call_on.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00361-003-s269><call_on.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00361-003-s269><call_on.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00361-003-s270><call_on.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00361-003-s270><call_on.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00361-003-s271><call_on.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00361-003-s271><call_on.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00361-003-s272><call_on.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00361-003-s272><call_on.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00361-003-s273><call_on.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00361-003-s273><call_on.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00361-003-s274><call_on.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00361-003-s274><call_on.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00361-003-s275><call_on.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00361-003-s275><call_on.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00361-003-s276><call_on.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00361-003-s276><call_on.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00361-003-s277><call_on.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00361-003-s277><call_on.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00361-003-s278><call_on.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00361-003-s278><call_on.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00361-003-s279><call_on.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00361-003-s279><call_on.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00361-003-s280><call_on.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00361-003-s280><call_on.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00361-003-s281><call_on.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00361-003-s281><call_on.aufrufen><en> Tried to call a removed routine.
<G-vec00361-003-s282><call_on.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00361-003-s282><call_on.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00361-003-s283><call_on.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00361-003-s283><call_on.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00361-003-s284><call_on.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00361-003-s284><call_on.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00485-002-s266><call.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00485-002-s266><call.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00485-002-s267><call.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00485-002-s267><call.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00485-002-s268><call.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00485-002-s268><call.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00485-002-s269><call.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00485-002-s269><call.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00485-002-s271><call.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00485-002-s271><call.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00485-002-s272><call.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00485-002-s272><call.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00485-002-s274><call.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00485-002-s274><call.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00485-002-s275><call.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00485-002-s275><call.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00485-002-s276><call.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00485-002-s276><call.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00485-002-s277><call.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00485-002-s277><call.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00485-002-s278><call.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00485-002-s278><call.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00485-002-s279><call.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00485-002-s279><call.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00485-002-s280><call.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00485-002-s280><call.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00485-002-s281><call.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00485-002-s281><call.aufrufen><en> Tried to call a removed routine.
<G-vec00485-002-s282><call.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00485-002-s282><call.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00485-002-s283><call.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00485-002-s283><call.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00485-002-s284><call.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00485-002-s284><call.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00485-002-s266><call_in.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00485-002-s266><call_in.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00485-002-s267><call_in.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00485-002-s267><call_in.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00485-002-s268><call_in.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00485-002-s268><call_in.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00485-002-s269><call_in.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00485-002-s269><call_in.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00485-002-s270><call_in.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00485-002-s270><call_in.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00485-002-s271><call_in.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00485-002-s271><call_in.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00485-002-s272><call_in.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00485-002-s272><call_in.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00485-002-s273><call_in.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00485-002-s273><call_in.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00485-002-s274><call_in.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00485-002-s274><call_in.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00485-002-s275><call_in.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00485-002-s275><call_in.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00485-002-s276><call_in.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00485-002-s276><call_in.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00485-002-s277><call_in.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00485-002-s277><call_in.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00485-002-s278><call_in.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00485-002-s278><call_in.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00485-002-s279><call_in.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00485-002-s279><call_in.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00485-002-s280><call_in.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00485-002-s280><call_in.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00485-002-s281><call_in.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00485-002-s281><call_in.aufrufen><en> Tried to call a removed routine.
<G-vec00485-002-s282><call_in.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00485-002-s282><call_in.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00485-002-s283><call_in.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00485-002-s283><call_in.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00485-002-s284><call_in.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00485-002-s284><call_in.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00485-002-s266><call_upon.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00485-002-s266><call_upon.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00485-002-s267><call_upon.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00485-002-s267><call_upon.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00485-002-s268><call_upon.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00485-002-s268><call_upon.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00485-002-s269><call_upon.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00485-002-s269><call_upon.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00485-002-s270><call_upon.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00485-002-s270><call_upon.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00485-002-s271><call_upon.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00485-002-s271><call_upon.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00485-002-s272><call_upon.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00485-002-s272><call_upon.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00485-002-s273><call_upon.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00485-002-s273><call_upon.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00485-002-s274><call_upon.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00485-002-s274><call_upon.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00485-002-s275><call_upon.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00485-002-s275><call_upon.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00485-002-s276><call_upon.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00485-002-s276><call_upon.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00485-002-s277><call_upon.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00485-002-s277><call_upon.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00485-002-s278><call_upon.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00485-002-s278><call_upon.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00485-002-s279><call_upon.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00485-002-s279><call_upon.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00485-002-s280><call_upon.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00485-002-s280><call_upon.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00485-002-s281><call_upon.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00485-002-s281><call_upon.aufrufen><en> Tried to call a removed routine.
<G-vec00485-002-s282><call_upon.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00485-002-s282><call_upon.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00485-002-s283><call_upon.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00485-002-s283><call_upon.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00485-002-s284><call_upon.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00485-002-s284><call_upon.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00510-002-s098><sprout_up.aufrufen><de> Es soll sogar Weisheit in uns aufrufen.
<G-vec00510-002-s098><sprout_up.aufrufen><en> It can even make wisdom sprout in us.”
<G-vec00519-002-s228><link.aufrufen><de> Wenn Sie Adv Cash EUR in Perfect Money USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s228><link.aufrufen><en> If you want to convert Adv Cash EUR to Perfect Money EUR with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s229><link.aufrufen><de> Wenn Sie Ethereum in FasaPay IDR mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s229><link.aufrufen><en> If you want to convert Ethereum to FasaPay USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s230><link.aufrufen><de> Wenn Sie Payeer EUR in Litecoin mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s230><link.aufrufen><en> If you want to convert Payeer EUR to Litecoin with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s231><link.aufrufen><de> Nicht nur zum Dom, sondern zu jeder Sehenswürdigkeit gibt es ausführlichere Infos, die per internem Link aufgerufen werden können.
<G-vec00519-002-s231><link.aufrufen><en> To every sight - not only the Cathedral - you can find additional information; you get access by clicking to an internal link.
<G-vec00519-002-s232><link.aufrufen><de> Wenn Sie Adv Cash USD in Ethereum Classic mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s232><link.aufrufen><en> If you want to convert Adv Cash USD to Ethereum Classic with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s233><link.aufrufen><de> Wenn Sie Exmo USD in Payeer USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s233><link.aufrufen><en> If you want to convert Exmo USD to Payeer USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s234><link.aufrufen><de> Wenn Sie Stellar in Solid Trust Pay USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s234><link.aufrufen><en> If you want to convert Stellar to Solid Trust Pay USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s235><link.aufrufen><de> Wird ein Fragebogen mit Zugriffsbeschränkung „Seriennummer“ ohne Seriennummer im Link aufgerufen, fragt der Fragebogen danach.
<G-vec00519-002-s235><link.aufrufen><en> If the survey is opened with the access restriction “serial number” without serial number in the link, the survey will ask about it.
<G-vec00519-002-s236><link.aufrufen><de> Wenn Sie Wire Transfer EUR in Exmo EUR mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s236><link.aufrufen><en> If you want to convert Adv Cash EUR to Exmo EUR with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s237><link.aufrufen><de> Wenn Sie Bitcoin in Adv Cash USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s237><link.aufrufen><en> If you want to convert Litecoin to Adv Cash USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s238><link.aufrufen><de> Wenn Sie Yandex Money in Exmo EUR mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s238><link.aufrufen><en> If you want to convert Yandex Money to Exmo EUR with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s239><link.aufrufen><de> Wenn Sie Dash in WMZ mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s239><link.aufrufen><en> If you want to convert Dash to WMZ with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s240><link.aufrufen><de> Wenn Sie Zcash in WEX USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s240><link.aufrufen><en> If you want to convert MoneyPolo EUR to Exmo USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s241><link.aufrufen><de> Wenn Sie Ripple in Wire Transfer USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s241><link.aufrufen><en> If you want to convert Ripple to Exmo USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s242><link.aufrufen><de> Wenn Sie MoneyGram USD in PayPal USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s242><link.aufrufen><en> If you want to convert MoneyGram USD to PayPal USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s243><link.aufrufen><de> Wenn Sie Ripple in Bitcoin mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s243><link.aufrufen><en> If you want to convert Ripple to Bitcoin with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s245><link.aufrufen><de> Wenn Sie Adv Cash EUR in Bank Card USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s245><link.aufrufen><en> If you want to convert Adv Cash EUR to Bank Card USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00519-002-s246><link.aufrufen><de> Wenn Sie NEO in Payeer USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00519-002-s246><link.aufrufen><en> If you want to convert NEO to Payeer USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00057-002-s247><call_up.aufrufen><de> Wenn Sie eine Webseite unseres Internetauftritts aufrufen, die ein solches Plugin enthält, baut Ihr Browser eine direkte Verbindung mit den Servern von Facebook auf.
<G-vec00057-002-s247><call_up.aufrufen><en> Whenever you call up a page from our website that contains one of these plugins, your browser establishes a connection directly with Facebook servers.
<G-vec00057-002-s248><call_up.aufrufen><de> Ein Spieler, der Zugang zu einer solchen Datenbank hat, kann detaillierte Informationen über jeden einzelnen Gegner aufrufen, ohne dass er jemals selbst gegen diesen Gegner gespielt hat.
<G-vec00057-002-s248><call_up.aufrufen><en> A player with access to such a database can call up detailed information about every one of his opponents without ever playing against those opponents himself.
<G-vec00057-002-s249><call_up.aufrufen><de> Solange diese Grausamkeiten nicht enden, werden Praktizierende weiterhin zu einer Beendigung der Verfolgung aufrufen.
<G-vec00057-002-s249><call_up.aufrufen><en> As long as this atrocity has not ended, practitioners will continue to call for and end to the persecution.
<G-vec00057-002-s250><call_up.aufrufen><de> Oft gehört die API aus Modul A, die man von Modul B aufrufen wollte, doch eher in ein neues Modul C, weil Module B und A eigentlich nichts mit einander zu tun haben.
<G-vec00057-002-s250><call_up.aufrufen><en> APIs from module A, that you tried to call from module B will be better placed in their own module C a lot of times because module A and B don’t have anything to do with one another.
<G-vec00057-002-s251><call_up.aufrufen><de> Sie können diese Daten jederzeit ohne spezielle Programmeinstellungen aufrufen.
<G-vec00057-002-s251><call_up.aufrufen><en> Users can call out these data at any time without any special program setting.
<G-vec00057-002-s252><call_up.aufrufen><de> Der Antragsteller und jeder Befürworter eines Beschlusses können zu einer Abstimmung über diesen Beschluss und alle damit zusammenhängenden Abänderungen aufrufen.
<G-vec00057-002-s252><call_up.aufrufen><en> The proposer of a motion may call for a vote on any or all of the amendments individually or together; the proposer of an amendment may call for a vote only on that amendment and related amendments.
<G-vec00057-002-s253><call_up.aufrufen><de> Um diese Klasse zu verwenden, müssen Sie sie nur instanziieren, den Pfad zu einer Datei voller Fragen kennen und dann die Methode get_question_from_file aufrufen.
<G-vec00057-002-s253><call_up.aufrufen><en> Ultimately, to use this class, you simply need to instantiate it, know the path to a file full of questions, and then call the get_question_from_file method.
<G-vec00057-002-s254><call_up.aufrufen><de> Über F1 kann man das Hauptmenü mit Speicher- oder Ladefunktion aufrufen.
<G-vec00057-002-s254><call_up.aufrufen><en> Through F1 one can call the main menu with save and load function.
<G-vec00057-002-s255><call_up.aufrufen><de> Wenn Sie eine Seite unseres Webauftritts aufrufen, die ein solches Plugin enthält, stellt Ihr Browser eine direkte Verbindung zu den Servern von AddThis her.
<G-vec00057-002-s255><call_up.aufrufen><en> If you call up a page on our website that contains such a plugin, your browser makes a direct connection to the AddThis server.
<G-vec00057-002-s256><call_up.aufrufen><de> Das Ziel einer Konversation muss nicht BEGIN DIALOG CONVERSATION aufrufen.
<G-vec00057-002-s256><call_up.aufrufen><en> The target of a conversation does not need to call BEGIN DIALOG CONVERSATION.
<G-vec00057-002-s257><call_up.aufrufen><de> Notfallhelfer können Bilder, Grundrisse und GPS-Koordinaten aufrufen, um jede Situation umfassend einzuschätzen, noch bevor Sie am Schauplatz des Geschehens ankommen.
<G-vec00057-002-s257><call_up.aufrufen><en> Emergency responders can call up pictures, floor plans and GPS coordinates to get a clear understanding of any situation before they even arrive on the scene.
<G-vec00057-002-s258><call_up.aufrufen><de> • Als Mitarbeiter können Sie ganz einfach die Zähl-Aufträge in der App aufrufen.
<G-vec00057-002-s258><call_up.aufrufen><en> • As an employee, you can easily call the Count jobs in the app.
<G-vec00057-002-s259><call_up.aufrufen><de> Wenn Sie eine Seite unseres Webauftritts aufrufen, die ein solches Plugin enthält, stellt Ihr Browser eine direkte Verbindung zu den Servern von Facebook her.
<G-vec00057-002-s259><call_up.aufrufen><en> When you call up a page on our website that contains such a plug-in, your browser creates a direct connection to the servers of Facebook.
<G-vec00057-002-s260><call_up.aufrufen><de> In der nächsten Übung erfahren Sie, wo Sie Ihren Dienstcode, d. h. Ihre Server-seitigen Klassendateien, ablegen müssen, damit Ihre Flex-Applikation sie aufrufen kann.
<G-vec00057-002-s260><call_up.aufrufen><en> In the next tutorial, you will learn where you need to place your service code, your server-side class files, so the Flex application can call them.
<G-vec00057-002-s261><call_up.aufrufen><de> Das ist möglich, weil im Cookie gespeichert ist, welche Produkte Sie sich zuletzt angeschaut haben und entsprechende Alternativen oder Ergänzungen herausgesucht werden, sobald Sie die Seite aufrufen.
<G-vec00057-002-s261><call_up.aufrufen><en> This is possible because is stored in the cookie, what products you have recently looked at and appropriate alternatives or additions to be picked as soon as you call up the page.
<G-vec00057-002-s262><call_up.aufrufen><de> Abbildung 2 zeigt, was passiert, wenn Sie den Basis-CLI-Befehl Azure aufrufen.
<G-vec00057-002-s262><call_up.aufrufen><en> Figure 2 shows what happens when you call the base CLI command Azure.
<G-vec00057-002-s263><call_up.aufrufen><de> Die Plakate sind bewusst provokant gestaltet und sollen Aufmerksamkeit erregen – und die Mitarbeiterinnen und Mitarbeiter der Telekom aufrufen, Verstöße gegen den Menschrechtskodex der Deutschen Telekom umgehend zu melden.
<G-vec00057-002-s263><call_up.aufrufen><en> The posters are intentionally provocative, intended to capture the attention – and to call upon Telekom employees to immediately support violations against the Deutsche Telekom Code of Human Rights.
<G-vec00057-002-s264><call_up.aufrufen><de> Sie können Daten austauschen, Methoden aufrufen und Benutzerdialoge des aufgerufenen Systems direkt vom Benutzer innerhalb des Remote-Aufrufs bearbeiten lassen.
<G-vec00057-002-s264><call_up.aufrufen><en> You can interchange data, call methods remotely and process user dialogs in the remote system.
<G-vec00057-002-s265><call_up.aufrufen><de> Eine Messung der Daten und anschließende Zuordnung zu dem jeweiligen Client- Identifier ist daher auch dann möglich, wenn Sie andere Webseiten aufrufen, die ebenfalls das Messverfahren („SZMnG“) der INFOnline GmbH nutzen.
<G-vec00057-002-s265><call_up.aufrufen><en> A measurement of the data and subsequent assignment to the respective client identifier is therefore also possible if you call up other websites that also use the INFOnline GmbH measurement method („SZMnG“).
<G-vec00057-002-s266><call_up.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00057-002-s266><call_up.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00057-002-s267><call_up.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00057-002-s267><call_up.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00057-002-s268><call_up.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00057-002-s268><call_up.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00057-002-s269><call_up.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00057-002-s269><call_up.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00057-002-s270><call_up.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00057-002-s270><call_up.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00057-002-s271><call_up.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00057-002-s271><call_up.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00057-002-s272><call_up.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00057-002-s272><call_up.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00057-002-s273><call_up.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00057-002-s273><call_up.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00057-002-s274><call_up.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00057-002-s274><call_up.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00057-002-s275><call_up.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00057-002-s275><call_up.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00057-002-s276><call_up.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00057-002-s276><call_up.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00057-002-s277><call_up.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00057-002-s277><call_up.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00057-002-s278><call_up.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00057-002-s278><call_up.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00057-002-s279><call_up.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00057-002-s279><call_up.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00057-002-s280><call_up.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00057-002-s280><call_up.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00057-002-s281><call_up.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00057-002-s281><call_up.aufrufen><en> Tried to call a removed routine.
<G-vec00057-002-s282><call_up.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00057-002-s282><call_up.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00057-002-s283><call_up.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00057-002-s283><call_up.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00057-002-s284><call_up.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00057-002-s284><call_up.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
