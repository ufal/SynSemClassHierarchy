<G-vec01070-002-s035><amuse.amüsieren><de> Die halbe Stunde, in der sie sich dort mit allen abkömmlichen Krankenschwestern und Therapeutinnen amüsieren, ist für sie ein besonderer Höhepunkt.
<G-vec01070-002-s035><amuse.amüsieren><en> The half hour when they can amuse themselves there – together with all the nurses and therapists who don’t have other duties at that time – is a real highpoint for everyone.
<G-vec01070-002-s036><amuse.amüsieren><de> Ihr Meisterwerk kann schwarz-weiß oder in Farbe sein.In nur ein paar Mausklicks können Sie einen Mini-Comic machen und Ihre Freunde damit amüsieren und überraschen.
<G-vec01070-002-s036><amuse.amüsieren><en> Your masterpiece can be in black and white or in color.Just a few clicks of the mouse and you will easily make a mini-comic, thereby amuse and amaze your friends.
<G-vec01070-002-s037><amuse.amüsieren><de> Ja, leider gibt es solche Frauen, die ihr Ego einfach nur amüsieren.
<G-vec01070-002-s037><amuse.amüsieren><en> Yes, unfortunately, there are such women who thus simply amuse their ego.
<G-vec01070-002-s038><amuse.amüsieren><de> Im U4 kann man sein, wer man ist, kann sich amüsieren, ohne das Gesicht zu verlieren.
<G-vec01070-002-s038><amuse.amüsieren><en> In the U4 you can be who you are, you can amuse yourself without losing face.
<G-vec01070-002-s039><amuse.amüsieren><de> Ein begabter Autor, seine Geschichten über das Meer, seine Geschäftsjahre mit Revlon und seine Tätigkeit als Limbo-Tänzer werden Sie mit Sicherheit amüsieren, unterhalten und unterhalten.
<G-vec01070-002-s039><amuse.amüsieren><en> A gifted raconteur, his stories of the sea, his corporate years with Revlon and stint as a limbo dancer are sure to amuse enlighten and entertain.
<G-vec01070-002-s040><amuse.amüsieren><de> Traditionelle Transvestiten-Shows, Singing Queens, Miss Div kann entweder amüsieren oder enttäuschen.
<G-vec01070-002-s040><amuse.amüsieren><en> Traditional transvestite show-programs, Singing Queens, Miss Div also can either amuse or disappoint.
<G-vec01070-002-s041><amuse.amüsieren><de> Die Presse ist nicht deshalb das einzige Geschäft, das durch die Verfassung spezifisch geschützt wird, um zu amüsieren und Leser zu gewinnen, nicht um das Triviale und Sentimale zu fördern, nicht um das Publikum immer das zu geben, was es gerade will, sondern um über Gefahren und Möglichkeiten zu informieren, um aufzurütten und zu reflektieren, um unsere Krisen festzustellen und unsere Möglichkeiten aufzuzeigen, um zu führen, zu formen, zu bilden, und manchmal sogar die öffentliche Meinung herauszufordern.
<G-vec01070-002-s041><amuse.amüsieren><en> And that is why our press was protected by the First Amendment– the only business in America specifically protected by the Constitution- -not primarily to amuse and entertain, not to emphasize the trivial and the sentimental, not to simply "give the public what it wants"–but to inform, to arouse, to reflect, to state our dangers and our opportunities, to indicate our crises and our choices, to lead, mold, educate and sometimes even anger public opinion.
<G-vec01070-002-s042><amuse.amüsieren><de> Das Spiel wird Sie nicht nur amüsieren, aber Ihre Raumeinbildungskraft ebenso entwickeln.
<G-vec01070-002-s042><amuse.amüsieren><en> The Game will not only amuse you but develop your spatial imagination as well.
<G-vec01070-002-s043><amuse.amüsieren><de> Für einen großen Ring ist der Schnuller einfach zu halten, das Baby kann es betrachten, es in Stifte drehen, es winken - als Antwort wird es leise "klingen" und so das Kind amüsieren.
<G-vec01070-002-s043><amuse.amüsieren><en> For a large ring pacifier is easy to hold, the baby can look at it, twirl it in pens, wave it - in response it will quietly "sound" and thus amuse the child.
<G-vec01070-002-s044><amuse.amüsieren><de> Sie amüsieren sich, indem sie sich über diejenigen, die der wahren Religion folgen, lustig machen, indem sie diesen vorwerfen, einer Gehirnwäsche unterzogen worden zu sein.
<G-vec01070-002-s044><amuse.amüsieren><en> They amuse themselves by making fun of those who follow the true religion by accusing them of being brainwashed.
<G-vec01070-002-s045><amuse.amüsieren><de> Vertreter der Evolutionstheorie amüsieren mich wirklich.
<G-vec01070-002-s045><amuse.amüsieren><en> Evolutionists really amuse me.
<G-vec01070-002-s046><amuse.amüsieren><de> Amüsieren Sie sich in einem der erstklassigen Freizeitparks.
<G-vec01070-002-s046><amuse.amüsieren><en> Amuse yourself at any one of the world-class theme parks.
<G-vec01070-002-s047><amuse.amüsieren><de> Unterhalten Sie Ihre ganze Familie mit ihren Urlaubsfotos auf Picasa oder amüsieren Sie sich mit lustigen YouTube-Videos.
<G-vec01070-002-s047><amuse.amüsieren><en> Entertain your family with your holiday photos on Picasa or amuse yourself with funny YouTube videos.
<G-vec01070-002-s048><amuse.amüsieren><de> Sie scheint ihn inzwischen zu amüsieren, nach all den Jahren in China.
<G-vec01070-002-s048><amuse.amüsieren><en> It seems to amuse him now, after so many years in China.
<G-vec01070-002-s049><amuse.amüsieren><de> David wusste schon damals, dass eine solche Idee viele der anderen Leute, die er kannte, die nicht katholisch waren, amüsieren oder in manchen Fällen sogar skandalisieren würde.
<G-vec01070-002-s049><amuse.amüsieren><en> David knew even then, though, such an idea would amuse or, in some cases, perhaps scandalize many of the other people he knew who weren’t Catholic.
<G-vec01070-002-s050><amuse.amüsieren><de> Die Stelle, wo Sie sich amüsieren können, auch wenn Sie vorsichtig sein müssen.
<G-vec01070-002-s050><amuse.amüsieren><en> The place where you can amuse yourselves even if you must be careful.
<G-vec01070-002-s051><amuse.amüsieren><de> Wir wissen, dass es heutzutage eine Menge Chats für Erwachsene gibt, die Websites anbieten, aber keiner von ihnen gleicht uns, weil wir die Qualität und Quantität haben, die Sie definitiv amüsieren und Ihren Schwanz verdammt steif machen.
<G-vec01070-002-s051><amuse.amüsieren><en> We know that there are lots of adult chat providing websites in today’s times, but none of them are like us, because we have the kind of quality and the quantity that will definitely amuse you and make your dick damn hard.
<G-vec01070-002-s052><amuse.amüsieren><de> Es ist eine gute Wahl für ein Familienschwimmbad, ideal für die Sommerferien, um ein Schwimmbad für die Kinder zu haben, um herumzulaufen und wenn Sie und Ihre Familie im Sommer in diesem Sommer viel Zeit verbringen, während die Olympischen Spiele dann sind Die Metallrahmen-Pool ist die ideale Ergänzung zu Ihrer Liste von "Essentials", die die Kinder und Erwachsene in diesem Sommer amüsieren wird.
<G-vec01070-002-s052><amuse.amüsieren><en> Metal Frame Swimming Pools are a great choice for a family swimming pool, perfect for the summer holidays to have a swimming pool for the kids to mess around in and if you and your family spend a lot of time in the garden this summer whilst the Olympics are on then the Metal Frame Pool is the ideal addition to your list of “essentials” that will amuse the kids and adults this Summer.
<G-vec01070-002-s053><amuse.amüsieren><de> Aber ich dachte, du wolltest dich mit mir nur amüsieren...
<G-vec01070-002-s053><amuse.amüsieren><en> But I thought you just wanted to amuse yourself with me.
<G-vec01070-002-s054><amuse.amüsieren><de> In diesem seltsamen Zazen präsentiere ich den Zuschauern einfach unsere Praxis, indem ich versuche, sie aufzuklären, zu amüsieren, zu erstaunen.
<G-vec01070-002-s054><amuse.amüsieren><en> During this strange zazen, I simply presented our practice to the spectators, trying to enlighten, amuse and intrigue them.
<G-vec01070-002-s055><amuse.amüsieren><de> Hier amüsiert sich Zero, Fluxus, Pop.
<G-vec01070-002-s055><amuse.amüsieren><en> Where ZERO, Fluxus, and Pop amuse themselves.
<G-vec01070-002-s056><amuse.amüsieren><de> Da hielt Abu Abdillah a.s. ihn nahe an sich, umarmte ihn und sagte zu ihm: Möge mein Vater und meine Mutter für dich hingegeben werden, oh du, der sich weder amüsiert noch spielt”.
<G-vec01070-002-s056><amuse.amüsieren><en> So Abu Abdillah (a.s.) held him close to him embracing him and said to him: "May my father and mother be ransomed for you, O you who does not amuse nor play”.
<G-vec01070-002-s076><amuse.amüsieren><de> Natürlich wird der Odessa-Humor Sie amüsieren und sicherlich Ihre Stimmung heben.
<G-vec01070-002-s076><amuse.amüsieren><en> Of course, the Odessa humor will amuse you and will certainly lift your spirits.
<G-vec01070-002-s077><amuse.amüsieren><de> Die Stärke Fos liegt darin, daß er Texte schafft, die gleichzeitig amüsieren, engagieren und Perspektiven vermitteln.
<G-vec01070-002-s077><amuse.amüsieren><en> Fo's strength is in the creation of texts that simultaneously amuse, engage and provide perspectives.
