<G-vec00730-002-s095><escalate.abrüsten><de> Es ist an der Zeit für die britische Regierung rhetorisch abzurüsten.
<G-vec00730-002-s095><escalate.abrüsten><en> It is time for the British government to de-escalate its rhetoric.
