<G-vec00198-002-s018><invalidate.annulieren><de> Um mehrere Cache IDs mit einer Operation zu entfernen/annulieren, kann die clean() Methode benutzt werden.
<G-vec00198-002-s018><invalidate.annulieren><en> To remove or invalidate several cache ids in one operation, you can use the clean() method.
<G-vec00198-002-s027><undo.annulieren><de> Annulieren und Wiederholen: Diese zwei Pfeile annulieren oder wiederholen deine letzte Eingabe.
<G-vec00198-002-s027><undo.annulieren><en> Undo and Redo: These two arrows will undo or redo your last action.
