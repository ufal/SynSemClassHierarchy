<G-vec00230-002-s030><fault.ansetzen><de> Die restlichen Kollegen sind ebenfalls durchaus technisch gut am jeweiligen Instrument, und auch an Sänger Damians Gekreisch gibt es nicht viel auszusetzen.
<G-vec00230-002-s030><fault.ansetzen><en> Also his fellow musicians seem to be technically skilled; as well singer Damians work is not to fault.
<G-vec00230-002-s031><fault.ansetzen><de> Dieses Angebot ergeht, wie gesagt, nicht bloß an die Protagonisten der herrschenden politökonomischen Interessen, sondern ebenso an die Vertreter der in Lohnabhängigkeit verstrickten Mehrheit des Volkes; und es wird auch allseits gerne wahrgenommen, von der Lobby der ‚Besserverdienenden‘ ebenso wie von den politischen Anwälten des ‚einfachen Volkes‘, die allesamt an den jeweils Regierenden einiges auszusetzen haben.
<G-vec00230-002-s031><fault.ansetzen><en> This offer is made, as mentioned, not only to the protagonists of the prevailing political-economic interests, but also to the representatives of the majority of the people enmeshed in wage dependency; and it is readily taken up by all, by the lobby of the ‘better-off’ and by the political advocates of the ‘common people,’ all of whom find plenty of fault with those in office.
<G-vec00230-002-s032><fault.ansetzen><de> Wir haben am Hotel nichts auszusetzen und kann es gar nicht genug empfehlen.
<G-vec00230-002-s032><fault.ansetzen><en> We couldn't fault this place and can't recommend it highly enough.
<G-vec00230-002-s033><fault.ansetzen><de> Ich konnte wirklich nichts auszusetzen.
<G-vec00230-002-s033><fault.ansetzen><en> I really could not find fault.
<G-vec00230-002-s034><fault.ansetzen><de> Schöne Wohnung, könnte es nichts auszusetzen und genau wie erwartet.
<G-vec00230-002-s034><fault.ansetzen><en> Nice apartment, could not fault it and exactly as expected.
<G-vec00230-002-s035><fault.ansetzen><de> „ Es bestehet (die gute Gestalt eines Pferdes) hauptsächlich darinn, daß alle Theile in einer guten Proportion sich gegen einander verhalten … Es ist zwar wahr, daß selten ein Pferd zu finden, an welchem das Urtheil der Kenner nicht etwas auszusetzen hat, doch sind einige bey hohen Potentaten anzutreffen, welche die Probe halten … “ (Ridinger).
<G-vec00230-002-s035><fault.ansetzen><en> “ (The good build of a horse) mainly lies in that all parts are in good proportion against each other … It is indeed true that there is rarely a horse with which the judgement of the experts finds no fault, but there are some to be found with high potentates, which stand the test … ” (Ridinger).
<G-vec00230-002-s036><fault.ansetzen><de> Wenn ich mich voller Frieden fühle, dann werde ich nichts an dir auszusetzen haben oder mit dir streiten.
<G-vec00230-002-s036><fault.ansetzen><en> If I feel peaceful, then I shall not find fault with you or quarrel with you.
<G-vec00230-002-s037><fault.ansetzen><de> Wir haben nichts auszusetzen und würde Villa Rodi zu unseren Freunden und Familie empfehlen.
<G-vec00230-002-s037><fault.ansetzen><en> We could not fault anything & would highly recommend Villa Rodi to our friends & family.
<G-vec00230-002-s038><fault.ansetzen><de> Sogar meine Kinder, die immer was auszusetzen haben, waren verzaubert.
<G-vec00230-002-s038><fault.ansetzen><en> Even my children, who usually always find fault, they were enchanted.
<G-vec00230-002-s039><fault.ansetzen><de> Sie finden an den Andachtsübungen zur allerseligsten Jungfrau, welchen sich ihre guten Kinder und treuen Diener mit Freuden hingeben, um von ihr wieder geliebt zu werden, immer etwas auszusetzen, weil sie diese Andacht nicht für notwendig halten.
<G-vec00230-002-s039><fault.ansetzen><en> Nevertheless, they cannot bear to see anyone love her tenderly, for they do not have for her any of the affection of Jacob; they find fault with the honour which her good children and servants faithfully pay her to win her affection.
