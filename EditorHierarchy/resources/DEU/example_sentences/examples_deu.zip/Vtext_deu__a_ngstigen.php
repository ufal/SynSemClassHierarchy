<G-vec00251-003-s220><scare_away.ängstigen><de> Es ist sehr wichtig, die Rennmaus richtig zu halten, damit du sie nicht ängstigst oder verletzt.
<G-vec00251-003-s220><scare_away.ängstigen><en> It’s very important to handle your gerbil properly so that you don’t scare or injure him.
<G-vec00251-003-s220><scare_off.ängstigen><de> Es ist sehr wichtig, die Rennmaus richtig zu halten, damit du sie nicht ängstigst oder verletzt.
<G-vec00251-003-s220><scare_off.ängstigen><en> It’s very important to handle your gerbil properly so that you don’t scare or injure him.
<G-vec00740-002-s065><afflict.ängstigen><de> 18 Denn so spricht der HERR: Siehe, ich will die Bewohner des Landes diesmal wegschleudern und will sie ängstigen, damit sie sich finden lassen.
<G-vec00740-002-s065><afflict.ängstigen><en> 18 For thus saith the Lord: Behold I will cast away far off the inhabitants of the land at this time: and I will afflict them, so that they may be found.
<G-vec00740-002-s066><afflict.ängstigen><de> 17 Und ich werde die Menschen ängstigen, und sie werden einhergehen wie die Blinden, weil sie gegen Jehova gesündigt haben; und ihr Blut wird verschüttet werden wie Staub, und ihr Fleisch wie Kot; 18 auch ihr Silber, auch ihr Gold wird sie nicht erretten können am Tage des Grimmes Jehovas; und durch das Feuer seines Eifers wird das ganze Land verzehrt werden.
<G-vec00740-002-s066><afflict.ängstigen><en> 17 And I will greatly afflict the men, and they shall walk as blind men, because they have sinned against the Lord; therefore He shall pour out their blood as dust, and their flesh as dung. 18 And their silver and their gold shall by no means be able to rescue them in the day of the Lord's wrath; but the whole land shall be devoured by the fire of His jealously; for He will bring a speedy destruction on all them that inhabit the land.
<G-vec00761-002-s090><frighten.ängstigen><de> Lasst euch nicht ins Schwanken bringen, was immer auch die Kabalen tun mögen, um euch zu verwirren und zu ängstigen.
<G-vec00761-002-s090><frighten.ängstigen><en> Do not be swayed by whatever the Cabal does to confuse or frighten you.
<G-vec00761-002-s216><scare.ängstigen><de> * Die Wirkungsdauer von 'Eiskältefalle' und 'Wildtier ängstigen' gegen PvP-Ziele wurde auf 10 Sekunden verringert.
<G-vec00761-002-s216><scare.ängstigen><en> * Freezing Trap and Scare Beast duration against PvP targets has been reduced to 10 seconds.
<G-vec00761-002-s217><scare.ängstigen><de> Dies beweist vollständig, dass, wenn Menschen die Wahrheit erkennen, sie dann keine Bedrohungen erschrecken oder ängstigen können.
<G-vec00761-002-s217><scare.ängstigen><en> This fully proves that when people find the truth, no threat or fright could scare them.
<G-vec00761-002-s218><scare.ängstigen><de> Wenn hingegen ein spiritueller Durchschnittsmensch einen Angriff einer negativen Wesenheit erlebt, geschieht dies meist, um ihn zu ängstigen oder eine Geben-Nehmen-Rechnung zu begleichen.
<G-vec00761-002-s218><scare.ängstigen><en> In contrast when an average person experiences a negative energy attack it is mostly to scare him or settle a give-and-take account.
<G-vec00761-002-s219><scare.ängstigen><de> Und Ruth Ware aus England wird dich mit ihrem Psycho-Thriller ängstigen.
<G-vec00761-002-s219><scare.ängstigen><en> And England’s Ruth Ware will scare your socks off with her psychological thriller.
<G-vec00761-002-s220><scare.ängstigen><de> Es ist sehr wichtig, die Rennmaus richtig zu halten, damit du sie nicht ängstigst oder verletzt.
<G-vec00761-002-s220><scare.ängstigen><en> It’s very important to handle your gerbil properly so that you don’t scare or injure him.
<G-vec00761-002-s014><terrify.ängstigen><de> Eine Ausnahme bildet ein Papyrusstück mit einer Zeile von Vergils Aeneis: „Anna, wie ängstigen mich, o Schwester, so quälende Träume!“ (IV, 9).
<G-vec00761-002-s014><terrify.ängstigen><en> An exception is a scrap of papyrus containing a line from Virgil's Aeneid, "Anna, sister, how my dreams terrify me and leave me hanging!” (IV.9).
