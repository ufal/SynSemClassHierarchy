<G-vec00503-001-s015><concede.abzugeben><de> Die Mitgliedsstaaten sind zögerlich, Mittel an die EU abzugeben, besonders in der gegenwärtigen ökonomischen Krise.
<G-vec00503-001-s015><concede.abzugeben><en> Member states are reluctant to concede their resources to the EU, especially during the current economic crisis.
