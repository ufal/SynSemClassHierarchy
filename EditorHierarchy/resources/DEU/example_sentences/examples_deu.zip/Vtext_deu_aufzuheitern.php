<G-vec00135-001-s083><cheer.aufzuheitern><de> Doch er wusste, dass das ein vergeblicher Versuch sein würde, sich selbst aufzuheitern.
<G-vec00135-001-s083><cheer.aufzuheitern><en> It was a futile attempt at cheer, as he knew it would be.
<G-vec00135-001-s084><cheer.aufzuheitern><de> Die Szene beschreibt detailliert die Schritte, die zu befolgen sind, um zu wissen, wie man einen Mann verführt, um ihn aufzuheitern.
<G-vec00135-001-s084><cheer.aufzuheitern><en> The scene tells in great detail the steps to follow to know how to seduce a man so cheer up.
<G-vec00135-001-s085><cheer.aufzuheitern><de> - Diese Worte hatte Frank seinem treuen Gefährten Florian, einem braunen Airedale-Terrier, mit spaßiger Geste vordeklamiert, um ihn etwas aufzuheitern.
<G-vec00135-001-s085><cheer.aufzuheitern><en> - This was the wisdom which Frank declaimed to his faithful companion Florian, a brown Airedale terrier, gesticulating comically in order to cheer him up.
<G-vec00135-001-s086><cheer.aufzuheitern><de> Meine Mutter versuchte, mich mit dem Versprechen aufzuheitern, mir Bananen und Orangen zu kaufen, wenn wir in unserer neuen Heimat ankamen.
<G-vec00135-001-s086><cheer.aufzuheitern><en> My mom tried to cheer me up by promising to buy bananas and oranges for me when we arrived in our new home.
<G-vec00135-001-s087><cheer.aufzuheitern><de> Wenn ein Geranienöl Spray und atmen Sie den Duft, das Gefühl haben, eine wunderbare Ausbruch von Energie muss aufzuheitern und um den Geist zu klären.
<G-vec00135-001-s087><cheer.aufzuheitern><en> If a geranium oil spray and inhale the aroma, you feel a miraculous burst of energy, must cheer up and to clarify the mind.
<G-vec00135-001-s088><cheer.aufzuheitern><de> Paco versucht sein Bestes, um das Publikum aufzuheitern.
<G-vec00135-001-s088><cheer.aufzuheitern><en> Paco is trying his level best to cheer up the crowd.
<G-vec00135-001-s089><cheer.aufzuheitern><de> Eine lustige Person namens Paco hat beschlossen, das Publikum mit seiner Mariachi-Band aufzuheitern.
<G-vec00135-001-s089><cheer.aufzuheitern><en> A funny character called Paco has decided to cheer up the crowd with his Mariachi band.
<G-vec00135-001-s090><cheer.aufzuheitern><de> Helft, einen anderen Freund aufzuheitern.
<G-vec00135-001-s090><cheer.aufzuheitern><en> Help cheer up a different friend.
<G-vec00135-001-s091><cheer.aufzuheitern><de> Sie weiß nun, dass sie ihn auch liebt, und obwohl Sophie versucht sie aufzuheitern, ist sie voller Vorahnungen.
<G-vec00135-001-s091><cheer.aufzuheitern><en> She knows now that she loves him too and though Sophie tries to cheer her, she is full of foreboding.
<G-vec00135-001-s092><cheer.aufzuheitern><de> Brooke bringt Peyton ins Tric, um sie aufzuheitern.
<G-vec00135-001-s092><cheer.aufzuheitern><en> Brooke takes Peyton to Tric to cheer her up.
