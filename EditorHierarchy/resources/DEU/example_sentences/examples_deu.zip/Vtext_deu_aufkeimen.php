<G-vec00510-002-s178><sprout_up.aufkeimen><de> Um die Pflanze zu ziehen, weicht man einfach die Samen ein und lässt sie aufkeimen.
<G-vec00510-002-s178><sprout_up.aufkeimen><en> To grow the plants, simply soak the seeds and let them sprout.
