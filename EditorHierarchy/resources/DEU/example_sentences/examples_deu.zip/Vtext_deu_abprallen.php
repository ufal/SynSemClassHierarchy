<G-vec00390-003-s024><bounce_back.abprallen><de> Es wird bald ein Teil von ihnen werden und negative Beeinflussungen werden einfach von Ihnen abprallen, sogar Ihre eigenen negativen Suggestionen.
<G-vec00390-003-s024><bounce_back.abprallen><en> It will soon become part of you and negative suggestions will just bounce off you, even your own negative suggestions.
<G-vec00390-003-s025><bounce_back.abprallen><de> Einzelne Moleküle könnten aufeinander stoßen und wie Billardkugeln abprallen, ohne auf irgendeine Art deformiert zu werden.
<G-vec00390-003-s025><bounce_back.abprallen><en> Individual molecules may strike one another and bounce off like billiard balls without being deformed in any way.
<G-vec00390-003-s026><bounce_back.abprallen><de> Deine Ziele kannst du mit einem direkten Treffer zerstören oder verschiedene Oberflächen verwenden, von denen die Kugel abprallen kann.
<G-vec00390-003-s026><bounce_back.abprallen><en> You can destroy the target with direct hit or use various surfaces to make the bullet bounce according to the needed trajectory.
<G-vec00390-003-s027><bounce_back.abprallen><de> In einem Downtrend kann der Kurs bis/nahe an den Pivot heran reichen und dann in Richtung der Unterstützungslevel als Tagesprofitziel abprallen.
<G-vec00390-003-s027><bounce_back.abprallen><en> In a downtrend, price can come up to or near the pivot and then bounce off and head towards the Support levels as a daily profit target.
<G-vec00390-003-s028><bounce_back.abprallen><de> Automatisierungssensoren können manchmal auch von einer Basis abprallen, wenn sie nicht texturiert sind.
<G-vec00390-003-s028><bounce_back.abprallen><en> Automation sensors can also sometimes bounce off a base if it’s not textured.
<G-vec00390-003-s029><bounce_back.abprallen><de> Es sendet Impulse aus, die dann abprallen und dann zurück kommen.
<G-vec00390-003-s029><bounce_back.abprallen><en> It emits impulses, which then bounce off and then come back.
<G-vec00390-003-s030><bounce_back.abprallen><de> Die Granate kann an Wänden abprallen und nutzt MP.
<G-vec00390-003-s030><bounce_back.abprallen><en> The grenade can bounce off walls and uses mp.
<G-vec00390-003-s031><bounce_back.abprallen><de> Es gibt keine exakte Wissenschaft, die bestimmt, ab welchem Level der Kurs oder ob der Kurs überhaupt von einem dieser Levels abprallen wird.
<G-vec00390-003-s031><bounce_back.abprallen><en> There is no exact science to determine which level price will bounce or if price will bounce off any of the levels at all.
<G-vec00390-003-s032><bounce_back.abprallen><de> Die schädlichen emotionalen Energien, die in Deine Richtung geworfen werden, werden abprallen und Dir helfen, die Ruhe zu bewahren.
<G-vec00390-003-s032><bounce_back.abprallen><en> The harmful emotional energies thrown at you will bounce off and help to keep you calm.
<G-vec00390-003-s033><bounce_back.abprallen><de> Verwendung von TPU– reduziert die Wasserabsorption und erhöht die Flexibilität der äußeren Fußball-Schicht, was ein gutes Abprallen gewährleistet.
<G-vec00390-003-s033><bounce_back.abprallen><en> The use of thermoplastic polyurethane – reduces absorption of water and improves elasticity of the external surface of the ball, which ensures the right bounce.
<G-vec00390-003-s034><bounce_back.abprallen><de> Ihr, und alle, die euch anhören und Mir dienen wollen, werden nun reden mit Engelszungen, und an ihnen wird alles abprallen, denn nun wissen sie auch, daß sie nur eine kurze Zeit ausharren müssen, um selig zu werden, sie wissen, daß wohl alles Äußerliche wanken kann, niemals aber die Kirche, die Jesus Christus auf Erden gegründet hat - die wahre Kirche, die nicht von den Pforten der Hölle überwunden werden kann.
<G-vec00390-003-s034><bounce_back.abprallen><en> You and all who listen to you and want to serve me will now speak with tongues of angels and everything will bounce off them because now they also know that they have to hold out only a short time to be blessed; they know that well all formalities can stagger but never the church that Jesus Christ founded on earth - the true church, that cannot be conquered by the gates of hell.
<G-vec00390-003-s035><bounce_back.abprallen><de> Ist der Eintrittswinkel in die Thermosphäre dagegen zu klein, kann das Raumschiff auch abprallen und wieder in den Weltraum fliegen wie ein Kiesel, den man flach über das Wasser wirft.
<G-vec00390-003-s035><bounce_back.abprallen><en> Conversely, if an incoming vehicle hit the thermosphere at too shallow an angle, it could well bounce back into space, like a pebble skipped across water.
<G-vec00390-003-s036><bounce_back.abprallen><de> Wenn die Geschwindigkeit der Physik Animation auf Grund von Objekten, die abprallen oder Objekten, die von einem Kinematischen Rigid Body getroffen werden, zu schnell ist, kann es zu dem Durchdringen der Fläche kommen.
<G-vec00390-003-s036><bounce_back.abprallen><en> When the physics animation speed is too fast, caused by objects that bounce off or objects that are hit by any Kinematic rigid body, then plane penetration may occur.
<G-vec00390-003-s037><bounce_back.abprallen><de> Bei Kreaturen mit gezielten Sprüngen führt ein erneuter Druck auf den Sprung in der Luft dazu, dass das Gezähmte geradewegs nach unten fällt (um fehlerhafte Fälle zu vermeiden, in denen der Dino unbeabsichtigt unbeabsichtigt unangenehm abprallen kann).
<G-vec00390-003-s037><bounce_back.abprallen><en> For creatures with targeted jumps, pressing jump again in midair will result in the tame falling straight down (to prevent erroneous cases where the dino may unintentionally bounce awkwardly)
<G-vec00390-003-s038><bounce_back.abprallen><de> Physik Objekte mit einem größeren Masse Wert können verursachen, dass Objekte mit geringerer Masse, abprallen, wenn beide zusammenstoßen.
<G-vec00390-003-s038><bounce_back.abprallen><en> Physics objects with higher Mass value can cause the ones with lower Mass value to bounce off more when they bump each other.
<G-vec00390-003-s039><bounce_back.abprallen><de> Obwohl einige Granaten von der Frontplatte abprallen können, ist es ziemlich riskant, sich darauf zu verlassen.
<G-vec00390-003-s039><bounce_back.abprallen><en> Even though the frontal plate may bounce some shells, relying on it is risky at best.
