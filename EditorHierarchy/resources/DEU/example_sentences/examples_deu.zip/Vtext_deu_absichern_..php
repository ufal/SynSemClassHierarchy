<G-vec00178-001-s026><insure.absichern_.><de> Der Umgang mit Risiken wird individuell festgelegt: akzeptieren, reduzieren, vorsorgen oder absichern.
<G-vec00178-001-s026><insure.absichern_.><en> The response to each risk is determined: accept as-is, reduce, provision, or insure
