<G-vec00365-003-s237><wipe_out.abwischen><de> 4 Verwenden Sie ein Mikrofasertuch, um alle restlichen Spuren von Feuchtigkeit oder Nässe vom USB-Anschluss abzuwischen.
<G-vec00365-003-s237><wipe_out.abwischen><en> 4 Use a micro-fibre cloth to wipe away any remaining moisture from the USB port. 10
<G-vec00365-003-s238><wipe_out.abwischen><de> Im getrockneten Bouquet gibt es etwas vom Modischen jetzt Retro, jedoch ist es wert, sich zu erinnern, dass solche Interieurdekorationen ziemlich schnell stauben, und es ist sehr schwierig, sie abzuwischen, ohne sie zu beschädigen.
<G-vec00365-003-s238><wipe_out.abwischen><en> In the dried bouquet there is something from the fashionable now retro, however it is worth remembering that such interior decorations quite quickly dust, and it is very difficult to wipe them without damaging them.
<G-vec00365-003-s239><wipe_out.abwischen><de> Verwenden Sie ein weiches Tuch, um überschüssiges Produkt vorsichtig abzuwischen.
<G-vec00365-003-s239><wipe_out.abwischen><en> Use a soft cloth to gently wipe the spills off the cupboard door.
<G-vec00923-002-s037><wipe_away.abwischen><de> Und als Ergänzung kannst Du die Blende abwischen und die Rückstände mischen, um Dein eigenes Cannabis-Öl herzustellen.
<G-vec00923-002-s037><wipe_away.abwischen><en> As an added bonus, you can wipe down the screen and mix the residue to make your own cannabis oil.
<G-vec00923-002-s038><wipe_away.abwischen><de> 4 Und Gott wird abwischen alle Tränen von ihren Augen.
<G-vec00923-002-s038><wipe_away.abwischen><en> 4 He will wipe every tear from their eyes.
<G-vec00923-002-s039><wipe_away.abwischen><de> Stimme der Christenheit: Der Herr wird die Tränen von allen Angesichtern abwischen, denn der Herr hat es gesagt.
<G-vec00923-002-s039><wipe_away.abwischen><en> Voice of Christianity: The Lord will wipe away the tears from all our faces, because the Lord has spoken.
<G-vec00923-002-s040><wipe_away.abwischen><de> Revelation 7:17 denn das Lamm mitten im Stuhl wird sie weiden und leiten zu den lebendigen Wasserbrunnen, und Gott wird abwischen alle Tränen von ihren Augen.
<G-vec00923-002-s040><wipe_away.abwischen><en> Revelation 7:17 Because the Lamb in the midst of the throne will tend them, and will lead them to fountains of waters of life. And God will wipe away every tear from their eyes.
<G-vec00923-002-s041><wipe_away.abwischen><de> Auf Grund der Furchen muss Ihr Sockel durch ein gelegentliches Abwischen mit einem Tuch sauber gehalten werden.
<G-vec00923-002-s041><wipe_away.abwischen><en> The grooves require you to keep your base clean with an occasional wipe of a cloth.
<G-vec00923-002-s042><wipe_away.abwischen><de> Die Hebamme oder Krankenschwester wird alles abwischen, und Ihr Baby wird wunderschön geboren.
<G-vec00923-002-s042><wipe_away.abwischen><en> The midwife or nurse will wipe everything off, and your baby will be born beautiful.
<G-vec00923-002-s043><wipe_away.abwischen><de> Nachdem dein Hund überschüssige Flüssigkeit ausgeschüttelt hat, solltest du die Ohren noch einmal mit Verbandsmull oder einem Wattebausch abwischen.
<G-vec00923-002-s043><wipe_away.abwischen><en> After your dog has shaken out any excess liquid, give the ears another wipe with gauze or cotton balls.
<G-vec00923-002-s044><wipe_away.abwischen><de> Wasserresistent damit man ihn einfach abwischen kann.
<G-vec00923-002-s044><wipe_away.abwischen><en> Water resistant so you can just wipe it.
<G-vec00923-002-s045><wipe_away.abwischen><de> Über die nächste Serviette ziehen und den Penis abwischen - ohne Druck, Anstrengung, ohne die Vorhaut zu bewegen.
<G-vec00923-002-s045><wipe_away.abwischen><en> Pull over the next napkin and wipe the penis - without pressure, effort, without moving the foreskin.
<G-vec00923-002-s046><wipe_away.abwischen><de> Nach dem Husten sollten Sie Schleimrückstände immer sorgfältig abwischen, damit die Haftwirkung erhalten bleibt und Hautreizungen vermieden werden.
<G-vec00923-002-s046><wipe_away.abwischen><en> After coughing, you should also wipe off mucus carefully, to make sure the adhesive does not loosen and your skin does not become irritated.
<G-vec00923-002-s047><wipe_away.abwischen><de> Sie können einfach das Innere der Ohren mit einem feuchten Wattestäbchen abwischen.
<G-vec00923-002-s047><wipe_away.abwischen><en> You can simply wipe the inside of your ears with a moist cotton swab.
<G-vec00923-002-s048><wipe_away.abwischen><de> Meine Mutter musste mir immer den Mund abwischen, weil ich vor lauter Aufregung vergaß zu schlucken.
<G-vec00923-002-s048><wipe_away.abwischen><en> My mother used to wipe of my slobber because out of excitement I forgot to swallow.
<G-vec00923-002-s049><wipe_away.abwischen><de> „Und ich sah einen neuen Himmel und eine neue Erde […]Und er wird bei ihnen wohnen, und sie werden seine Völker sein […] und Gott wird abwischen alle Tränen von ihren Augen, und der Tod wird nicht mehr sein, noch Leid noch Geschrei noch Schmerz wird mehr sein.
<G-vec00923-002-s049><wipe_away.abwischen><en> Kingdom of God—Utopia—Renewal “Then I saw a new heaven and a new earth. … He will dwell with them as their God; they will be his people … and God will wipe every tear from their eyes.
<G-vec00923-002-s050><wipe_away.abwischen><de> Wenn du das im Unterricht tust, dann bringe dir ein kleines Handtuch mit, damit du Wasser darauf geben und dir damit das Gesicht abwischen kannst.
<G-vec00923-002-s050><wipe_away.abwischen><en> If you do this in class, bring a small towel with you that you can dampen with water to wipe on your face.
<G-vec00923-002-s051><wipe_away.abwischen><de> Gudrun muss im Unglück Aschenbrödel werden, sie soll selber, obgleich eine Königin, Brände schüren und den Staub mit dem eigenen Haar abwischen: sogar Schläge muss sie dulden; vergl.
<G-vec00923-002-s051><wipe_away.abwischen><en> Gudrun in her misfortunes has to become an Aschenbrödel; she herself although a queen, has to clean the hearth and wipe up the dust with her hair, or else she is beaten.
<G-vec00923-002-s052><wipe_away.abwischen><de> 16Sie werden nicht mehr hungern, auch werden sie nicht mehr dürsten, noch wird je die Sonne auf sie fallen, noch irgend eine Glut; 17denn das Lamm, das in der Mitte des Thrones ist, wird sie weiden und sie leiten zu Quellen der Wasser des Lebens, und Gott wird jede Träne abwischen von ihren Augen.
<G-vec00923-002-s052><wipe_away.abwischen><en> 16They shall hunger no more, neither thirst anymore; the sun shall not strike them, nor any scorching heat. 17For the Lamb in the midst of the throne will be their shepherd, and he will guide them to springs of living water, and God will wipe away every tear from their eyes.”
<G-vec00923-002-s053><wipe_away.abwischen><de> Sehr wichtig ist die richtige Pflege, Sie müssen ständig die Kratzer reiben, mit Wachs abwischen.
<G-vec00923-002-s053><wipe_away.abwischen><en> Very important is the proper care, you need to constantly rub the scratches, wipe with wax.
<G-vec00923-002-s054><wipe_away.abwischen><de> Mit einem weichen Tuch sanft abwischen.
<G-vec00923-002-s054><wipe_away.abwischen><en> Wipe gently with a soft cloth.
<G-vec00923-002-s055><wipe_away.abwischen><de> Pflegehinweise: den Staub mithilfe des weichen Stoffes oder Pinsels abwischen.
<G-vec00923-002-s055><wipe_away.abwischen><en> Recommendations for care: wipe the product with a piece of soft suede or flannel.
<G-vec00923-002-s056><wipe_away.abwischen><de> Mir wird gesagt, genau hinzusehen und zu beachten, dass Becky und ich ein weißes Tuch benutzen, um unsere Gesichter und unsere Vorderseite, sowie unsere Schuhe abzuwischen.
<G-vec00923-002-s056><wipe_away.abwischen><en> I am told to look closely and notice that Becky and I use a white cloth to wipe our faces and the front of ourselves as well as our shoes.
<G-vec00923-002-s057><wipe_away.abwischen><de> Verwende eine Bürste, um Dreck oder Schweiß von deinem Ellbogen abzuwischen.
<G-vec00923-002-s057><wipe_away.abwischen><en> Use a brush to wipe off the dirt or sweat trapped in your elbow before applying this mixture.
<G-vec00923-002-s058><wipe_away.abwischen><de> Es ist auch periodisch nötig, die Gesimse, die Ringe (die Haken) abzuwischen, von denen sich der Staub auf den Texturen absetzen kann.
<G-vec00923-002-s058><wipe_away.abwischen><en> Also periodically it is necessary to wipe cornices, rings (hooks) from which dust can settle on tissues.
<G-vec00923-002-s059><wipe_away.abwischen><de> Benutze ein Handtuch oder ein anderes saugfähiges Tuch, um den Schweiß und die Feuchtigkeit abzuwischen.
<G-vec00923-002-s059><wipe_away.abwischen><en> Use a towel or oil blotting papers to wipe off sweat and other moisture.
<G-vec00923-002-s060><wipe_away.abwischen><de> Mache kreisende Bewegungen und achte darauf, überschüssiges Pflegemittel abzuwischen.
<G-vec00923-002-s060><wipe_away.abwischen><en> Use circular motions and take care to wipe up excess conditioner.
<G-vec00923-002-s061><wipe_away.abwischen><de> Wasserdicht, Anti-Flammen; Bleiben Sie sauber und ordentlich mit einem feuchten Tuch, um es direkt abzuwischen.
<G-vec00923-002-s061><wipe_away.abwischen><en> Waterproof, Anti-flaming; keep clean and neat by wet cloth to wipe it directly.
<G-vec00923-002-s062><wipe_away.abwischen><de> 1.Wenn Sie Elektrizität verwenden, berühren Sie nicht die elektrischen Teile des Chassis von Hand oder verwenden Sie ein feuchtes Tuch, um mit Wasser abzuwischen und zu spülen.
<G-vec00923-002-s062><wipe_away.abwischen><en> 1.When using electricity,do not touch the electrical parts of the chassis by hand or use a damp cloth to wipe and rinse with water.
<G-vec00923-002-s063><wipe_away.abwischen><de> Experten-Tipps Unser wichtigster Tipp zur Fleckentfernung: Reiben Sie den Fleck nicht und versuchen Sie ihn nicht abzuwischen, solange der Dreck noch nass ist, denn so wird er nur verschmiert.
<G-vec00923-002-s063><wipe_away.abwischen><en> Mud & Soil Stain Removal Tips Our top stain removal tip is: Do not rub the stain or try to wipe it whilst mud is wet, this will lead to smearing.
<G-vec00923-002-s064><wipe_away.abwischen><de> Unsere Baby-Futternapf sorgt nicht nur dafür, dass Verschüttungen und Würfe reduziert werden, sondern ist auch sehr einfach abzuwischen und zu reinigen.
<G-vec00923-002-s064><wipe_away.abwischen><en> Our baby feeding bowl not only helps ensure that spills and throws are reduced, but it is also very easy to wipe and clean.
<G-vec00923-002-s065><wipe_away.abwischen><de> Sein chemikalienbeständiges Edelstahlgehäuse ist einfach zu reinigen/abzuwischen und so gestaltet, dass Stellen, die als Partikelfallen wirken könnten, minimiert werden.
<G-vec00923-002-s065><wipe_away.abwischen><en> It features a chemical-resistant, stainless-steel case that is easy to clean/wipe down and is designed to minimize particle traps.
<G-vec00923-002-s066><wipe_away.abwischen><de> Um einen Nip des Kindes abzuwischen, das eine Rhinitis erleidet, ist es besser weiches Papier oder Lumpenschals, die nach Gebrauch ausgeworfen oder auf reinem ersetzt werden sollten.
<G-vec00923-002-s066><wipe_away.abwischen><en> To wipe a nip of the kid, suffering a rhinitis, it is better soft paper or rag shawls which after use should be thrown out or replaced on pure.
<G-vec00923-002-s067><wipe_away.abwischen><de> 9.Use ein weicher Stoff oder ein Schwamm befeuchtet mit Wasser, um hinunter die Maschine selbst abzuwischen.
<G-vec00923-002-s067><wipe_away.abwischen><en> 9.Use a soft cloth or sponge moistened with water to wipe down the machine itself.
<G-vec00923-002-s068><wipe_away.abwischen><de> Unser wichtigster Tipp zur Fleckentfernung: Reiben Sie den Fleck nicht und versuchen Sie ihn nicht abzuwischen, solange der Dreck noch nass ist, denn so wird er nur verschmiert.
<G-vec00923-002-s068><wipe_away.abwischen><en> Our top stain removal tip is: Do not rub the stain or try to wipe it whilst mud is wet, this will lead to smearing.
<G-vec00923-002-s069><wipe_away.abwischen><de> Ansonsten reicht es, das Stativ mit einem leicht feuchten Tuch abzuwischen.
<G-vec00923-002-s069><wipe_away.abwischen><en> In other cases, it is sufficient to wipe the tripod with a slightly damp cloth.
<G-vec00923-002-s070><wipe_away.abwischen><de> Reinigungstuch - Dieses wird verwendet, um die Kamera oder das Objektiv abzuwischen.
<G-vec00923-002-s070><wipe_away.abwischen><en> Cleaning cloth - This is used to wipe off dust and dirt on the camera body or lens.
<G-vec00923-002-s071><wipe_away.abwischen><de> Die meisten Radsportler reinigen ihr Rad nicht nach jeder Fahrt, es ist jedoch kein großer Aufwand, die Kette mit einem sauberen Lappen abzuwischen und die Kettenblätter sauber zu halten.
<G-vec00923-002-s071><wipe_away.abwischen><en> While most cyclists don't clean their bike after every ride, it's not hard to wipe your chain off with a clean rag and keep the chain rings clean.
<G-vec00923-002-s072><wipe_away.abwischen><de> TippsBearbeiten Mache es dir zum Prinzip, deine Badewanne regelmäßig abzuwischen (idealerweise einmal alle paar Wochen), damit du später nicht die Zeit für eine Tiefenreinigung aufbringen musst.
<G-vec00923-002-s072><wipe_away.abwischen><en> Make it a point to wipe down your bathtub regularly (ideally once every couple of weeks) so that you won’t have to dedicate the time to deep-cleaning later on.
<G-vec00923-002-s073><wipe_away.abwischen><de> Wenn der Kinderarzt die Nachtfütterung verordnet hat, vergessen Sie nach dem Essen nicht, die Zähne des Babys mit in Wasser getränkter Gaze und Fingerwunde abzuwischen.
<G-vec00923-002-s073><wipe_away.abwischen><en> If the pediatrician prescribed night feeding, after the meal do not forget to wipe the baby's teeth with gauze soaked in water and wound on the finger.
<G-vec00923-002-s074><wipe_away.abwischen><de> Ultrasuede Schweiß abzuwischen.
<G-vec00923-002-s074><wipe_away.abwischen><en> Ultrasuede to wipe sweat.
<G-vec00923-002-s109><wipe_away.abwischen><de> Pflege Mit einem weichen Tuch abwischen.
<G-vec00923-002-s109><wipe_away.abwischen><en> Care Wipe with soft dry cloth
<G-vec00923-002-s110><wipe_away.abwischen><de> Mit einem feuchten Tuch abwischen.
<G-vec00923-002-s110><wipe_away.abwischen><en> Wipe with damp cloth Properties
<G-vec00923-002-s111><wipe_away.abwischen><de> Mit einem trockenen Tuch abwischen, damit keine Flüssigkeit auf den Kontaktanschlüssen verbleibt.
<G-vec00923-002-s111><wipe_away.abwischen><en> Wipe off with dry cloth so that no liquid remains on the contact terminals.
<G-vec00923-002-s112><wipe_away.abwischen><de> Mit einem nassen Schwamm, Handtuch oder Tuch abwischen.
<G-vec00923-002-s112><wipe_away.abwischen><en> Wipe clean with wet sponge, towel or cloth.
<G-vec00923-002-s113><wipe_away.abwischen><de> Pflege: Mit einem feuchten Tuch abwischen, nicht im Geschirrspüler oder Eintauchen in Wasser.
<G-vec00923-002-s113><wipe_away.abwischen><en> CARE: Wipe clean with damp cloth, do not put in dishwasher or submerge in water.
<G-vec00923-002-s237><wipe_away.abwischen><de> 4 Verwenden Sie ein Mikrofasertuch, um alle restlichen Spuren von Feuchtigkeit oder Nässe vom USB-Anschluss abzuwischen.
<G-vec00923-002-s237><wipe_away.abwischen><en> 4 Use a micro-fibre cloth to wipe away any remaining moisture from the USB port. 10
<G-vec00923-002-s238><wipe_away.abwischen><de> Im getrockneten Bouquet gibt es etwas vom Modischen jetzt Retro, jedoch ist es wert, sich zu erinnern, dass solche Interieurdekorationen ziemlich schnell stauben, und es ist sehr schwierig, sie abzuwischen, ohne sie zu beschädigen.
<G-vec00923-002-s238><wipe_away.abwischen><en> In the dried bouquet there is something from the fashionable now retro, however it is worth remembering that such interior decorations quite quickly dust, and it is very difficult to wipe them without damaging them.
<G-vec00923-002-s239><wipe_away.abwischen><de> Verwenden Sie ein weiches Tuch, um überschüssiges Produkt vorsichtig abzuwischen.
<G-vec00923-002-s239><wipe_away.abwischen><en> Use a soft cloth to gently wipe the spills off the cupboard door.
<G-vec00923-002-s355><wipe_away.abwischen><de> Wenn der Trainingscomputer verschmutzt ist, wische den Schmutz mit einem feuchten Papierhandtuch ab.
<G-vec00923-002-s355><wipe_away.abwischen><en> Use a damp paper towel to wipe dirt from the training device.
<G-vec00923-002-s356><wipe_away.abwischen><de> Wische den LCD Bilschirm mit dem Isopropylalkohol ab.
<G-vec00923-002-s356><wipe_away.abwischen><en> Wipe down the LCD with the isopropyl alcohol.
<G-vec00923-002-s357><wipe_away.abwischen><de> Wische deine Tränen ab.
<G-vec00923-002-s357><wipe_away.abwischen><en> Wipe your tears.
<G-vec00923-002-s358><wipe_away.abwischen><de> Wische das Produkt mit einem Lappen oder Papiertuch ab.
<G-vec00923-002-s358><wipe_away.abwischen><en> Use a rag or paper towel to wipe off the product.
<G-vec00923-002-s359><wipe_away.abwischen><de> Wische den Rahmen ab.
<G-vec00923-002-s359><wipe_away.abwischen><en> Wipe down the frame.
<G-vec00923-002-s360><wipe_away.abwischen><de> Wische ihn mit dem Schmutzradierer mit langen, gleichmäßigen Streichbewegungen ab.
<G-vec00923-002-s360><wipe_away.abwischen><en> Use the magic eraser to wipe it down using long, even strokes.
<G-vec00923-002-s361><wipe_away.abwischen><de> Sprühe das Kupfer nochmal leicht mit dem Fensterreiniger ein, aber wische es diesmal nicht ab.
<G-vec00923-002-s361><wipe_away.abwischen><en> Spray the copper lightly with the window cleaner again, but do not wipe it off this time.
<G-vec00923-002-s362><wipe_away.abwischen><de> Solltest du dich dafür entscheiden, wische mögliche Überreste mit Nagellackentferner ab, bevor du mit dem Lackieren der Nägel beginnst.
<G-vec00923-002-s362><wipe_away.abwischen><en> If you do this, just be sure you wipe off any residue with nail polish remover before you begin painting the nails.
<G-vec00923-002-s363><wipe_away.abwischen><de> Tränke die Ecke eines weichen Tuchs mit Essig und wische die Oberfläche ab.
<G-vec00923-002-s363><wipe_away.abwischen><en> Soak the corner of a soft cloth in vinegar and wipe the surface.
<G-vec00923-002-s364><wipe_away.abwischen><de> Wische vorsichtig die Innenseite der Taste und den Steckplatz ab, von dem sie entfernt wurde.
<G-vec00923-002-s364><wipe_away.abwischen><en> Carefully wipe the inside of the button and the slot from which it was removed.
<G-vec00923-002-s365><wipe_away.abwischen><de> Wische die Anbauteile deiner Spüle ab.
<G-vec00923-002-s365><wipe_away.abwischen><en> Wipe the basin and fixtures of the sink.
<G-vec00923-002-s366><wipe_away.abwischen><de> Wische staubige Oberflächen mit deinen alten, durchlöcherten Socken ab, bevor Du sie wegwirfst.
<G-vec00923-002-s366><wipe_away.abwischen><en> Wipe dusty surfaces with old socks that have worn into holes before you bin them.
<G-vec00923-002-s367><wipe_away.abwischen><de> Leere deine Mülleimer regelmäßig und wische die Deckel und Oberflächen mit Bleiche ab.
<G-vec00923-002-s367><wipe_away.abwischen><en> Clean out your indoor garbage containers regularly and wipe down the lid and surfaces with bleach.
<G-vec00923-002-s368><wipe_away.abwischen><de> Wische nach ein paar Minuten die überschüssige Versiegelung ab.
<G-vec00923-002-s368><wipe_away.abwischen><en> Wipe off excess sealer after a few minutes.
<G-vec00923-002-s369><wipe_away.abwischen><de> Wische Schmiere und Schmutz von der Oberfläche des Schuhs ab.
<G-vec00923-002-s369><wipe_away.abwischen><en> Wipe grease and grime from the shoe’s surface.
