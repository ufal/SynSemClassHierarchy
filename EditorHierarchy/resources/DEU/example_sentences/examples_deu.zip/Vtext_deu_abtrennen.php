<G-vec00595-002-s051><detach.abtrennen><de> Sie können eine angehängte Formel von einer Liste auf mehrere Arten abtrennen.
<G-vec00595-002-s051><detach.abtrennen><en> You can detach (clear) a formula from a list name in several ways.
