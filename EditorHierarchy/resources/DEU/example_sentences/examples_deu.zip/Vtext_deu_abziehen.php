<G-vec00321-002-s033><pull.abziehen><de> Entfernen sie die Treibstoffleitung und die Druckleitung, sie können diese einfach abziehen.
<G-vec00321-002-s033><pull.abziehen><en> Remove the fuel lines from the fuel tank, they will simply pull off.
<G-vec00321-002-s034><pull.abziehen><de> Spannen Sie den Nippel in den Schraubstock ein und spreizen Sie die einzelnen Drähte der Seele mit dem Schraubendreher auseinander, sodass sich der Nippel nicht mehr so leicht abziehen lässt – das macht die Lötstelle später stabil.
<G-vec00321-002-s034><pull.abziehen><en> Clamp the nipple in a vice and spread the individual wires of the core with the screwdriver so that the nipple is not as easy to pull off. This makes for a more robust soldering point later.
<G-vec00321-002-s035><pull.abziehen><de> Ein einfaches Handwerkzeug zur Unterstützung der Arbeiten an Steckverbindungen besteht aus einem Grundkörper mit einem offenen Kanal für die Aufnahme des Kabels, einer Buchse und einer Hülse zur Arretierung von Greifkrallen zum Abziehen von Kabelverbindungen.
<G-vec00321-002-s035><pull.abziehen><en> A simple hand tool for support of the connection and disconnection of plug couplings consists of an open channel in a base for the cable, a socket and a movable shell for the fixation of gripping claws to pull out a plug.
<G-vec00321-002-s036><pull.abziehen><de> 6) Die BLAUE Deckfolie am Klebestreifen anfassen und von der Schutzfolie abziehen.
<G-vec00321-002-s036><pull.abziehen><en> 6) Hold the BLUE cover film on the adhesive strips and pull off from the protective film.
<G-vec00321-002-s037><pull.abziehen><de> Per Knopfdruck lässt sich der Absatz/Mantel vom Kern abziehen.
<G-vec00321-002-s037><pull.abziehen><en> Via touch of a button you can pull of the heel/ coat from the core.
<G-vec00321-002-s038><pull.abziehen><de> MONTAGEANLEITUNGEN Achtung: Achtung: Vor der Durchführung irgendwelcher Arbeiten am motorisierten Sprühgerät immer erst den Motor ausschalten und den Kerzenstecker von der Zündkerze abziehen.
<G-vec00321-002-s038><pull.abziehen><en> ASSEMBLY INSTRUCTIONS CAUTION: Before performing any work on the power sprayer, always switch off the motor and pull the spark plug connectors off the spark plug.
<G-vec00321-002-s039><pull.abziehen><de> Die längere Schutzkappe abziehen.
<G-vec00321-002-s039><pull.abziehen><en> Pull off the longer protection cap.
<G-vec00321-002-s040><pull.abziehen><de> Durch die Verspannung werden jedoch die Klemmelemente so verklemmt, daß ein Abziehen der Teile des Implantates von der Halteeinrichtung stark erschwert oder gar unmöglich ist.
<G-vec00321-002-s040><pull.abziehen><en> However, the clamping elements are clamped due to the bracing such that it is very difficult or even impossible to pull off the parts of the implant from the holding means.
<G-vec00321-002-s041><pull.abziehen><de> Gegebenenfalls den unteren Sprüharm 23 nach oben abziehen.
<G-vec00321-002-s041><pull.abziehen><en> If necessary, pull the lower arm 23 upwards and lift it off.
<G-vec00321-002-s042><pull.abziehen><de> Schutzkappe abziehen.
<G-vec00321-002-s042><pull.abziehen><en> Pull off the cap.
<G-vec00321-002-s043><pull.abziehen><de> Es ist eine große Amp, abziehen können viele Töne.
<G-vec00321-002-s043><pull.abziehen><en> It's a great amp that can pull off many tones.
<G-vec00321-002-s044><pull.abziehen><de> Ich konnte einen von meiner Wange abziehen, aber er hinterließ kleine Rückstände.
<G-vec00321-002-s044><pull.abziehen><en> I was able to pull one off my cheek, but it left a little residue.
<G-vec00321-002-s045><pull.abziehen><de> Pads auf das geschlossene Augenlid legen, kurz einwirken lassen und nach unten abziehen.
<G-vec00321-002-s045><pull.abziehen><en> Place pad on closed eyelid, leave to work briefly and then pull downwards.
<G-vec00321-002-s046><pull.abziehen><de> Damit Sie in Zukunft Ihre Rollenware leicht und einfach abziehen können, bieten wir einen Bodenständer aus weiß lackier-tem Metall an.
<G-vec00321-002-s046><pull.abziehen><en> To let you easily pull off your rolls in future we offer a storage rack made of white painted metal.
<G-vec00321-002-s047><pull.abziehen><de> Das 24K Gold Augenpatch entfernen und die Maske von den äußeren Rändern her sanft abziehen.
<G-vec00321-002-s047><pull.abziehen><en> Remove the 24K gold eye patch and gently pull the mask off the outer edges.
<G-vec00321-002-s048><pull.abziehen><de> Ein weiterer Trick, den einige Casinos abziehen, ist es, die Vollendung der Bonus-Wettanforderungen auf bestimmte Spiele zu limitieren, und zwar in der Regel auf diejenigen, die einen sehr hohen Hausvorteil besitzen.
<G-vec00321-002-s048><pull.abziehen><en> Another trick some casinos pull is to limit the completion of bonus wagering requirements to certain games, typically those with a very high house edge.
<G-vec00321-002-s049><pull.abziehen><de> Service Rund um Ihren Extruder bieten wir Ihnen verschiedene Serviceleistungen an, wodurch Sie zum Beispiel frühzeitig den Verschleißzustand der Gehäuse erkennen, die Elemente schnell und sicher von den Kernwellen abziehen und Ihre Gehäuse effizient und kostengünstig reparieren lassen können.
<G-vec00321-002-s049><pull.abziehen><en> For all aspects of your extruder, we offer a variety of services that you can use, for example, to detect the level of wear on the housing at an early stage, pull off the elements quickly and safely from the shafts and have your housing repaired efficiently and cost-effectively.
<G-vec00321-002-s050><pull.abziehen><de> Zum Austausch einfach den Bürstenkopf abziehen und durch einen neuen ersetzen.
<G-vec00321-002-s050><pull.abziehen><en> To change, simply pull off used brush head and replace it with a new one.
<G-vec00321-002-s051><pull.abziehen><de> Der G2 ist völlig vielseitig und kann viele Looks und Styles abziehen.
<G-vec00321-002-s051><pull.abziehen><en> The G2 is completely versatile and can pull off many looks and styles.
<G-vec00321-002-s057><withdraw.abziehen><de> In Abunimahs Perspektive, dass die Bewegung für BDS durch „offen erklärte Apartheid“ Auftrieb erfährt, zeigt sich das Wesentliche von der Strategie dieser Bewegung, die versucht, Uni-Verwaltungen und amerikanische Unternehmen durch moralisches Zureden dazu zu bringen, Kapitalanlagen aus Israel abzuziehen, und gleichzeitig den Boykott von Aktivitäten israelischer Akademiker und Kulturschaffender zu organisieren.
<G-vec00321-002-s057><withdraw.abziehen><en> Abunimah’s perspective of seeing “openly declared apartheid” as a boost to BDS goes straight to the heart of that movement’s strategy, which seeks to employ moral suasion to pressure campus administrations and American corporations to withdraw investments from Israel, while organizing boycotts of Israeli academic and cultural activities.
<G-vec00321-002-s058><withdraw.abziehen><de> In einem zuvor stattgefundenen Telefonat zwischen Trump und dem türkischen Amtskollegen Recep Tayyip Erdogan fiel offenbar die Entscheidung des US-Präsidenten, die US-Einheiten aus Syrien abzuziehen.
<G-vec00321-002-s058><withdraw.abziehen><en> But with US President Donald Trump's decision in December to withdraw US forces from Syria, Turkey has repeatedly threatened to attack the YPG.
<G-vec00321-002-s059><withdraw.abziehen><de> In Neu-Delhi widersetzt Walter sich den Anweisungen seines Arztes und trifft sich mit dem indischen Außenminister, um diesen zu bitten, seine Truppen abzuziehen.
<G-vec00321-002-s059><withdraw.abziehen><en> Unrated CC In New Delhi, Walter defies doctor's orders and meets with the Indian Foreign Minister to urge him to withdraw his troops.
<G-vec00321-002-s060><withdraw.abziehen><de> Um die Sicherheit der Gruppe zu gewährleisten werden Kriegschefs ernannt: sie werden mit den Arbeiten der Vorbeugung der Gewaltrisiken beauftragt, und sie verfügen über die Streitkräfte, um die Verbrecher gefangenzunehmen, die Waffen der feindlichen Hände abzuziehen.
<G-vec00321-002-s060><withdraw.abziehen><en> To ensure the safety of the group, of the chiefs of war are named: they are in charge of work of prevention of the risks of violence and they have the force armed to capture the criminals, to withdraw the weapons of the enemy hands.
<G-vec00321-002-s061><withdraw.abziehen><de> Bei dem deutsch-französischem Krieg von 1870 war Frankreich gezwungen, seine Legion abzuziehen, die das Land für den Schutz des Papstes in Rom stationiert hatte.
<G-vec00321-002-s061><withdraw.abziehen><en> In the Franco-German War of 1870, France was forced to withdraw its legion, which had stationed the country for the protection of the pope in Rome.
<G-vec00321-002-s062><withdraw.abziehen><de> Er erhielt die Erlaubnis, mit seiner Garnison und einem Teil seiner Artillerie abzuziehen.
<G-vec00321-002-s062><withdraw.abziehen><en> He was allowed to withdraw with his garrison and part of his artillery.
<G-vec00321-002-s063><withdraw.abziehen><de> Anleger können etwas bewirken, weil sie die Macht haben, Kapital aus Unternehmen, die ihrer Umweltverantwortung nicht gerecht werden, abzuziehen oder erst gar nicht in solche zu investieren.
<G-vec00321-002-s063><withdraw.abziehen><en> Investors matter because they have the power to withhold or withdraw capital from businesses that fail to take their environmental responsibilities seriously.
<G-vec00321-002-s064><withdraw.abziehen><de> Die globalen Gewerkschaften übergaben dem Botschafter ein Schreiben mit der Aufforderung an China, seine Truppen aus der Umgebung abzuziehen, und an die Verwaltung von Hongkong, unverzüglich in einen Dialog mit der Demokratiebewegung einzutreten.
<G-vec00321-002-s064><withdraw.abziehen><en> The global unions delivered a letter to the Ambassador calling on China to withdraw its troops from the vicinity and the Hong Kong administration to immediately enter into dialogue with the democracy movement.
<G-vec00321-002-s065><withdraw.abziehen><de> »Mir blieb nichts übrig, als abzuziehen, so wenig ich dies Benehmen unseres Freundes begriff.
<G-vec00321-002-s065><withdraw.abziehen><en> "I could do nothing but withdraw, although I could not understand the behaviour of our friend.
<G-vec00321-002-s066><withdraw.abziehen><de> Zweitens bietet der Sekundärmarkt die Möglichkeit, Investitionen schneller zu beenden, wenn ein unerwarteter Bedarf besteht, das Geld aus diesen Investitionen abzuziehen.
<G-vec00321-002-s066><withdraw.abziehen><en> Second, the secondary market gives investors the opportunity to exit investments faster in case of an unexpected need to withdraw money from these kinds of investments.
<G-vec00321-002-s067><withdraw.abziehen><de> Frankreich erklärte sich bereit, seine Truppen aus dem industriellen Ruhrgebiet abzuziehen, um die deutsche Produktion dort wieder aufzunehmen und zu erholen.
<G-vec00321-002-s067><withdraw.abziehen><en> France agreed to withdraw its troops from the industrial Ruhr region, allowing German production there to recommence and recover.
<G-vec00555-002-s033><pull_off.abziehen><de> Entfernen sie die Treibstoffleitung und die Druckleitung, sie können diese einfach abziehen.
<G-vec00555-002-s033><pull_off.abziehen><en> Remove the fuel lines from the fuel tank, they will simply pull off.
<G-vec00555-002-s034><pull_off.abziehen><de> Spannen Sie den Nippel in den Schraubstock ein und spreizen Sie die einzelnen Drähte der Seele mit dem Schraubendreher auseinander, sodass sich der Nippel nicht mehr so leicht abziehen lässt – das macht die Lötstelle später stabil.
<G-vec00555-002-s034><pull_off.abziehen><en> Clamp the nipple in a vice and spread the individual wires of the core with the screwdriver so that the nipple is not as easy to pull off. This makes for a more robust soldering point later.
<G-vec00555-002-s035><pull_off.abziehen><de> Ein einfaches Handwerkzeug zur Unterstützung der Arbeiten an Steckverbindungen besteht aus einem Grundkörper mit einem offenen Kanal für die Aufnahme des Kabels, einer Buchse und einer Hülse zur Arretierung von Greifkrallen zum Abziehen von Kabelverbindungen.
<G-vec00555-002-s035><pull_off.abziehen><en> A simple hand tool for support of the connection and disconnection of plug couplings consists of an open channel in a base for the cable, a socket and a movable shell for the fixation of gripping claws to pull out a plug.
<G-vec00555-002-s036><pull_off.abziehen><de> 6) Die BLAUE Deckfolie am Klebestreifen anfassen und von der Schutzfolie abziehen.
<G-vec00555-002-s036><pull_off.abziehen><en> 6) Hold the BLUE cover film on the adhesive strips and pull off from the protective film.
<G-vec00555-002-s037><pull_off.abziehen><de> Per Knopfdruck lässt sich der Absatz/Mantel vom Kern abziehen.
<G-vec00555-002-s037><pull_off.abziehen><en> Via touch of a button you can pull of the heel/ coat from the core.
<G-vec00555-002-s038><pull_off.abziehen><de> MONTAGEANLEITUNGEN Achtung: Achtung: Vor der Durchführung irgendwelcher Arbeiten am motorisierten Sprühgerät immer erst den Motor ausschalten und den Kerzenstecker von der Zündkerze abziehen.
<G-vec00555-002-s038><pull_off.abziehen><en> ASSEMBLY INSTRUCTIONS CAUTION: Before performing any work on the power sprayer, always switch off the motor and pull the spark plug connectors off the spark plug.
<G-vec00555-002-s039><pull_off.abziehen><de> Die längere Schutzkappe abziehen.
<G-vec00555-002-s039><pull_off.abziehen><en> Pull off the longer protection cap.
<G-vec00555-002-s040><pull_off.abziehen><de> Durch die Verspannung werden jedoch die Klemmelemente so verklemmt, daß ein Abziehen der Teile des Implantates von der Halteeinrichtung stark erschwert oder gar unmöglich ist.
<G-vec00555-002-s040><pull_off.abziehen><en> However, the clamping elements are clamped due to the bracing such that it is very difficult or even impossible to pull off the parts of the implant from the holding means.
<G-vec00555-002-s041><pull_off.abziehen><de> Gegebenenfalls den unteren Sprüharm 23 nach oben abziehen.
<G-vec00555-002-s041><pull_off.abziehen><en> If necessary, pull the lower arm 23 upwards and lift it off.
<G-vec00555-002-s042><pull_off.abziehen><de> Schutzkappe abziehen.
<G-vec00555-002-s042><pull_off.abziehen><en> Pull off the cap.
<G-vec00555-002-s043><pull_off.abziehen><de> Es ist eine große Amp, abziehen können viele Töne.
<G-vec00555-002-s043><pull_off.abziehen><en> It's a great amp that can pull off many tones.
<G-vec00555-002-s044><pull_off.abziehen><de> Ich konnte einen von meiner Wange abziehen, aber er hinterließ kleine Rückstände.
<G-vec00555-002-s044><pull_off.abziehen><en> I was able to pull one off my cheek, but it left a little residue.
<G-vec00555-002-s045><pull_off.abziehen><de> Pads auf das geschlossene Augenlid legen, kurz einwirken lassen und nach unten abziehen.
<G-vec00555-002-s045><pull_off.abziehen><en> Place pad on closed eyelid, leave to work briefly and then pull downwards.
<G-vec00555-002-s046><pull_off.abziehen><de> Damit Sie in Zukunft Ihre Rollenware leicht und einfach abziehen können, bieten wir einen Bodenständer aus weiß lackier-tem Metall an.
<G-vec00555-002-s046><pull_off.abziehen><en> To let you easily pull off your rolls in future we offer a storage rack made of white painted metal.
<G-vec00555-002-s047><pull_off.abziehen><de> Das 24K Gold Augenpatch entfernen und die Maske von den äußeren Rändern her sanft abziehen.
<G-vec00555-002-s047><pull_off.abziehen><en> Remove the 24K gold eye patch and gently pull the mask off the outer edges.
<G-vec00555-002-s048><pull_off.abziehen><de> Ein weiterer Trick, den einige Casinos abziehen, ist es, die Vollendung der Bonus-Wettanforderungen auf bestimmte Spiele zu limitieren, und zwar in der Regel auf diejenigen, die einen sehr hohen Hausvorteil besitzen.
<G-vec00555-002-s048><pull_off.abziehen><en> Another trick some casinos pull is to limit the completion of bonus wagering requirements to certain games, typically those with a very high house edge.
<G-vec00555-002-s049><pull_off.abziehen><de> Service Rund um Ihren Extruder bieten wir Ihnen verschiedene Serviceleistungen an, wodurch Sie zum Beispiel frühzeitig den Verschleißzustand der Gehäuse erkennen, die Elemente schnell und sicher von den Kernwellen abziehen und Ihre Gehäuse effizient und kostengünstig reparieren lassen können.
<G-vec00555-002-s049><pull_off.abziehen><en> For all aspects of your extruder, we offer a variety of services that you can use, for example, to detect the level of wear on the housing at an early stage, pull off the elements quickly and safely from the shafts and have your housing repaired efficiently and cost-effectively.
<G-vec00555-002-s050><pull_off.abziehen><de> Zum Austausch einfach den Bürstenkopf abziehen und durch einen neuen ersetzen.
<G-vec00555-002-s050><pull_off.abziehen><en> To change, simply pull off used brush head and replace it with a new one.
<G-vec00555-002-s051><pull_off.abziehen><de> Der G2 ist völlig vielseitig und kann viele Looks und Styles abziehen.
<G-vec00555-002-s051><pull_off.abziehen><en> The G2 is completely versatile and can pull off many looks and styles.
<G-vec00595-002-s045><detach.abziehen><de> Komfortable Anfasslaschen ermöglichen dabei ein einfaches Handling der beiden Lagen und erleichtern auch das Abziehen der Teiletiketten, selbst mit Handschuhen.
<G-vec00595-002-s045><detach.abziehen><en> Convenient starter tabs simplify the handling of both layers and also make it easier to detach the label parts, even when wearing gloves.
<G-vec00649-002-s020><deduct.abziehen><de> Es wird berichtet, dass Benutzer nur 1 Yuan auf der Hauptseite der APP-Aktivität von Tujia B & B ausgeben müssen, um ab Juni einen "schreienden roten Umschlag" im Wert von 100 Yuan zu kaufen 30 Tage vor der Buchung einer bestimmten Homestay-Bestellung kann der rote Umschlag verwendet werden, um Zimmerpreise abzuziehen, wenn ein bestimmter Betrag erreicht ist.
<G-vec00649-002-s020><deduct.abziehen><en> It is reported that users only need to spend 1 yuan on the main page of the Tujia B&B APP activity to buy a "screaming red envelope" worth 100 yuan, as of June 30 days before booking a designated homestay order, the red envelope can be used to deduct room rates when a certain amount is reached.
<G-vec00649-002-s021><deduct.abziehen><de> Für nicht eingenommenes Abendessen werden bei vorzeitiger Bekanntgabe €.10,00 abgezogen.
<G-vec00649-002-s021><deduct.abziehen><en> For a non-consumed dinner we deduct € 10,00 in case of an early announcement.
<G-vec00649-002-s022><deduct.abziehen><de> Krankheitskosten Wenn die aus eigener Tasche bezahlten Gesundheitskosten einen bestimmten Anteil am Einkommen übersteigen, können diese abgezogen werden.
<G-vec00649-002-s022><deduct.abziehen><en> If any medical costs paid for out of your own pocket exceed a certain portion of your income, you can deduct them from your tax return.
<G-vec00649-002-s031><deduct.abziehen><de> Um den Betrag, den ein Gläubiger zahlen sollte, zu ermitteln, muss er zuerst etwaige Schulden und Kosten, die er haben mag, abziehen und neunzehn Prozent vom Rest seines Kapitals zahlen, wenn dieses mindestens neunzehn Mithqál Gold entspricht.
<G-vec00649-002-s031><deduct.abziehen><en> In determining the amount a believer should pay, he should first deduct any debts and expenses he may have, and pay nineteen per cent of the remainder of his capital if it is equal to at least nineteen mithqals of gold.
<G-vec00649-002-s032><deduct.abziehen><de> Da wir Gebühren an der Quelle abziehen, sind keine Gelder fällig, für die wir Rechnungen stellen könnten.
<G-vec00649-002-s032><deduct.abziehen><en> Since we deduct fees at source, no funds are owed to invoice for.
<G-vec00649-002-s033><deduct.abziehen><de> Sie können unsere Geschäft `s andere Produkte zusammen mischen, geradeSende mir Nachricht per Posteingang oder füge Bemerkung Artikelcode / Größe / Farbe hinzuIn der Reihenfolge, wir werden die Versandkosten für Sie von Hand abziehen.
<G-vec00649-002-s033><deduct.abziehen><en> You can mix our store`s other products together,just send me message by inbox or add remark item code/size/colorin order,we will deduct shipping fee for you by hand.
<G-vec00649-002-s034><deduct.abziehen><de> Das französische Finanzamt verlangt einen festen Nachweis für die Kosten; So müssen Sie die Rechnungen aller Kosten, die Sie abziehen möchten, zeigen.
<G-vec00649-002-s034><deduct.abziehen><en> The French tax Office does require solid proof for the costs; so you need to show the invoices of all the costs you want to deduct.
<G-vec00649-002-s035><deduct.abziehen><de> Arbeitnehmer, die bei einer Pensionskasse versichert sind, dürfen einen definierten Maximalbetrag vom steuerbaren Einkommen abziehen – derzeit 6'768 Franken.
<G-vec00649-002-s035><deduct.abziehen><en> During the accumulation period, employees who are insured with a pension fund can deduct a defined maximum amount from their taxable income, currently CHF 6,768.
<G-vec00649-002-s036><deduct.abziehen><de> Bei Ermangelung eines Formulars wird Dreamstime LLC 30% Quellensteuer abziehen.
<G-vec00649-002-s036><deduct.abziehen><en> In the absence of a form, Dreamstime LLC will deduct 30% withholding tax.
<G-vec00649-002-s037><deduct.abziehen><de> Der Vorteil liegt darin, dass Ihnen bei der Bezahlung per Vorauskasse 3% Skonto zustehen, welche Sie sich bei Ihrer Überweisung vom Rechnungsbetrag abziehen dürfen.
<G-vec00649-002-s037><deduct.abziehen><en> The advantage lies in the fact that you receive a 3% discount for pre-payment, which you can deduct from yoour invoice amount when you make the payment.
<G-vec00649-002-s038><deduct.abziehen><de> Sie können Ihre Spende von Ihrem steuerbaren Einkommen abziehen.
<G-vec00649-002-s038><deduct.abziehen><en> You can deduct your donation from your taxable income.
<G-vec00649-002-s039><deduct.abziehen><de> Pegasus kann diese Verluste von dem gesamten vom Gast bezahlten Betrag für den nicht in Anspruch genommenen Teil der Reise oder für andere Produkte und Dienstleistungen abziehen, die unter das Ticket fallen.
<G-vec00649-002-s039><deduct.abziehen><en> Pegasus is authorized to deduct any such losses from payments made by the Passenger in respect of Ticketed but unused Flights or other products and services purchased from Pegasus.
<G-vec00649-002-s040><deduct.abziehen><de> (3) neues Attribut "auf Lager" ermöglicht das Arbeiten ohne Aktion und ein Attribut, das den Gesamtbestand abziehen wird eine Aktie zuweisen.
<G-vec00649-002-s040><deduct.abziehen><en> (3) new attribute "stock" that allows to work without action and assign a stock to an attribute that will deduct the total stock.
<G-vec00649-002-s041><deduct.abziehen><de> Sie müssen 20% des Wertes des Bonus vorstrecken, indem Sie ihn am Ende des Jahres von Ihrer Steuererklärung abziehen, während das Hotel erwartet den 80%.und dann von Ihrer Einkommenssteuer abziehen.
<G-vec00649-002-s041><deduct.abziehen><en> You will have to advance 20% of the value of the bonus by deducting it at the end of the year from your tax return, while the hotel is anticipating the 80%.and then deduct it from your income tax.
<G-vec00649-002-s042><deduct.abziehen><de> Der Besitzer oder Vorgesetzte kann zusätzliche Kosten berechnen (und von der Kaution abziehen), falls mehr gereinigt werden muss, als nach einem normalen Aufenthalt erwartet werden kann.
<G-vec00649-002-s042><deduct.abziehen><en> The owner or supervisor can charge extra costs (and deduct from the deposit) in case more needs to be cleaned than can be expected after a normal stay.
<G-vec00649-002-s043><deduct.abziehen><de> Dabei können Sie alle Ihre Verluste aus demselben Jahr von diesen Gewinnen abziehen.
<G-vec00649-002-s043><deduct.abziehen><en> You can also deduct any losses in the same year from these winnings.
<G-vec00649-002-s044><deduct.abziehen><de> Es ist wichtig, die richtigen Mehrwertsteuercodes im Jahresabschluss zu verwenden, um sicherzustellen, dass Ihr Unternehmen einen korrekten Mehrwertsteuerabzug erhält, und gleichzeitig sicherzustellen, dass Sie nicht zu viel abziehen, da dies Nachzahlung, Zinsen und strafrechtliche Konsequenzen bedeuten kann.
<G-vec00649-002-s044><deduct.abziehen><en> It is important to use the correct VAT codes in the financial statements to ensure that your business receives a correct VAT deduction and at the same time ensure that you do not deduct too much, as this could mean post-pay, interest and have penal consequences.
<G-vec00649-002-s045><deduct.abziehen><de> Steuern: Sie sparen Steuern, da Sie Ihre Einzahlungen vom steuerbaren Einkommen abziehen können.
<G-vec00649-002-s045><deduct.abziehen><en> Taxes: you’ll save on taxes, as you can deduct your deposits from your taxable income.
<G-vec00649-002-s046><deduct.abziehen><de> Wir werden ab dem letzten Tag der Frist und dann alle dreißig (30) Tage im Einklang mit dem Ablaufplan der Gebühr für inaktive Konten einen Betrag von Ihrem Kontoguthaben abziehen.
<G-vec00649-002-s046><deduct.abziehen><en> We may deduct an amount up to the Inactive Account Fee from your account balance commencing on the last day of the Grace Period and then every thirty (30) days thereafter in accordance with the Inactive Account Fee Schedule.
<G-vec00649-002-s047><deduct.abziehen><de> Wenn wir den Vertrag gemäß den Umständen in Klausel 8.1 beenden, werden wir Ihnen jegliche Summe zurückerstatten, die Sie uns als Vorauszahlung für Waren bezahlt haben, die wir nicht geliefert haben, aber wir können eventuell eine Gebühr abziehen oder als angemessene Entschädigung für die Nettogebühren, die aus dem Vertragsbruch resultieren, aufrechnen.
<G-vec00649-002-s047><deduct.abziehen><en> If we end the contract in the situations set out in clause 8.1 we will refund any money you have paid in advance for products we have not provided but we may deduct or charge you reasonable compensation for the net costs we will incur as a result of your breaking the contract 8.3 We may withdraw the product.
<G-vec00649-002-s048><deduct.abziehen><de> Steuern sparen: Den einbezahlten Betrag dürfen Sie von Ihrem steuerbaren Einkommen abziehen.
<G-vec00649-002-s048><deduct.abziehen><en> Save taxes: You may deduct the paid-in amount from your taxable income.
<G-vec00649-002-s049><deduct.abziehen><de> 2 Nicht zurückerstattet werden zu viel erhobene, nicht geschuldete sowie wegen nachträglicher Veranlagung der Gegenstände nach den Artikeln 34 und 51 Absatz 3 ZG1 oder wegen deren Wiederausfuhr nach den Artikeln 49 Absatz 4, 51 Absatz 3, 58 Absatz 3 und 59 Absatz 4 ZG nicht mehr geschuldete Steuern, wenn der Importeur oder die Importeurin im Inland als steuerpflichtige Person eingetragen ist und die der EZV zu entrichtende oder entrichtete Steuer als Vorsteuer nach Artikel 28 abziehen kann.
<G-vec00649-002-s049><deduct.abziehen><en> 2 Not refunded are excess taxes imposed, taxes not due and taxes no longer due as a result of a subsequent assessment of the goods under Articles 34 and 51 paragraph 3 CustA1 or because of their re-export under Articles 49 paragraph 4, 51 paragraph 3, 58 paragraph 3 and 59 paragraph 4 CustA if the importer is registered on Swiss territory as a taxable person and may deduct the tax payable or paid to the FCA as input tax under Article 28.
<G-vec00649-002-s050><deduct.abziehen><de> Wir können es abziehen, nachdem Sie die Bestellung aufgegeben haben.
<G-vec00649-002-s050><deduct.abziehen><en> We could deduct it after you place the order.
<G-vec00649-002-s051><deduct.abziehen><de> Diesen Betrag können Sie dann von den Steuern abziehen, wenn er nicht den einbezahlten Betrag von 6'768 Franken überschreitet.
<G-vec00649-002-s051><deduct.abziehen><en> You can deduct all paid-in amounts from your taxes as long as they add up to no more than CHF 6,768.
<G-vec00649-002-s052><deduct.abziehen><de> Es handelt sich um Kosten, die der Kapitalanlagegesellschaft entstehen, und die diese vom Fondsvermögen abzieht.
<G-vec00649-002-s052><deduct.abziehen><en> These are costs that the investment company incurs and will deduct from the fund assets.
<G-vec00649-002-s053><deduct.abziehen><de> Mit gleicher E-Mail teilt ZEGNA den Betrag mit, den sie vom Rückerstattungsbetrag abzieht; es sei denn, der Kunde wünscht, dass die Ware auf seine Kosten und im gleichen Zustand, in dem sie bei ZEGNA einging, wieder an ihn zurückgeschickt wird.
<G-vec00649-002-s053><deduct.abziehen><en> By the same mail, EZI shall also notify the amount that it will deduct from the amount to be refunded, unless Customer elects to have, at its own expense, the products sent back to him/her in the same conditions in which they were returned to EZI.
<G-vec00649-002-s054><deduct.abziehen><de> (4) Außerdem hat VERWAY das Recht, den Brand Ambassador-Vertrag außerordentlich zu kündigen, sofern der Brand Ambassador nicht die jährliche Lizenz- und Wartungsgebühr im Sinne des § 6 (2) zahlt, wobei VERWAY bei entsprechendem Provisionsguthaben die Lizenz- und Wartungsgebühr im Sinne des § 6 (2) unmittelbar von diesem Guthaben abzieht.
<G-vec00649-002-s054><deduct.abziehen><en> (4) In addition, VERWAY has the right to terminate the brand ambassador agreement if brand ambassadors fail to pay the annual licensing and maintenance fee as defined in §6(2), although VERWAY will first attempt to deduct said fees from any commission balance.
<G-vec00649-002-s066><deduct.abziehen><de> Ein Arbeitgeber ist verpflichtet, die auf das Gehalt eines Arbeitnehmers zu zahlende Steuer monatlich abzuziehen.
<G-vec00649-002-s066><deduct.abziehen><en> An employer is obligated to deduct on a monthly basis the tax payable on an employee's salary.
<G-vec00649-002-s067><deduct.abziehen><de> Wir behalten uns das Recht vor, eine RMA-Gebühr vom endgültigen Erstattungsbetrag für Bestellungen abzuziehen, die zum Zeitpunkt der Lieferung unzustellbar sind oder bei denen die Annahme verweigert wird.
<G-vec00649-002-s067><deduct.abziehen><en> We reserve the right to deduct a RMA fee from the final refund amount on orders that are unclaimed or refused at point of delivery.
<G-vec00649-002-s068><deduct.abziehen><de> Somit steht der Gesellschaft kein Recht zu die Vorsteuer in demselben Zeitraum abzuziehen, in dem die Umsatzsteuer ausgewiesen wird, unabhängig von der Tatsache, dass die Korrektur der Umsatzsteuererklärung später eingereicht wird als innerhalb von drei Monaten nach Ablauf des Monats, in dem die Steuerpflicht entstanden ist.
<G-vec00649-002-s068><deduct.abziehen><en> So the company has no right to deduct the input tax in the same period in which the output tax is disclosed, regardless of the fact that correction of the VAT return will be filed later than within three months from expiry of the tax point month.
<G-vec00649-002-s069><deduct.abziehen><de> Du stimmst zu, dass wir berechtigt sind, unsere Gebühren, jegliche Rückbuchungen und/oder andere Beträge, die Du uns schuldest, von Deinem Borderless-Konto abzuziehen.
<G-vec00649-002-s069><deduct.abziehen><en> You agree that we are authorised to deduct our fees, any applicable reversal amounts, and/or any amounts you owe us from your TransferWise Account.
<G-vec00649-002-s070><deduct.abziehen><de> Stornierung beim Check-in oder bei Nichterscheinen: Die gesamte Reservierung wird in Rechnung gestellt (und Sie berechtigen Rent4All dazu, die Summe der nicht reservierten Reservierungsdetails von der Kredit- oder Debitkarte abzuziehen, die Sie bei der Reservierung angegeben haben).
<G-vec00649-002-s070><deduct.abziehen><en> Cancellation on the check-in date or not showing: the total booking is charged (and you hereby authorize Rent4All to deduct such sums from the credit or debit card details which you supplied when making booking). Cancellation Policy Home
<G-vec00649-002-s071><deduct.abziehen><de> Wenn Canva aus irgendeinem Grund eine Überzahlung für Lizenzgebühren oder eine andere Entschädigung an Sie leistet, hat Canva das Recht, den Betrag dieser Überzahlung von Ihren ausstehenden Lizenzgebühren abzuziehen oder die sofortige Rückzahlung dieser überbezahlten Lizenzgebühren oder sonstigen Leistungen zu verlangen.
<G-vec00649-002-s071><deduct.abziehen><en> If Canva makes an overpayment of royalties or other compensation to you for any reason, Canva shall have the right to deduct the amount of such overpayment from your accrued royalties or to demand the immediate repayment of such overpaid royalties or other compensation.
<G-vec00649-002-s072><deduct.abziehen><de> Die Amazon-Parteien behalten jedoch das Recht, jegliche anfallenden Steuern von Beträgen, die Ihnen von den Parteien geschuldet werden, abzuziehen oder zurückzubehalten, und die Ihnen geschuldeten Beträge, reduziert um diese Abzüge oder Zurückbehaltungen, gelten als vollständige Zahlung und Verrechnung Ihnen gegenüber.
<G-vec00649-002-s072><deduct.abziehen><en> The Amazon parties maintain the right, however, to deduct or withhold any and all applicable taxes from amounts due by them to you, and the amounts due, as reduced by those deductions or withholdings, will constitute full payment and settlement to you.
<G-vec00649-002-s073><deduct.abziehen><de> Wenn die Papiere in der Mitte des Jahres zur Verfügung gestellt wurden und das Recht, 1 Kind abzuziehen, von Januar erschien, werden die Berechnungen noch vom Anfang des Jahres durchgeführt.
<G-vec00649-002-s073><deduct.abziehen><en> If the papers were provided in the middle of the year, and the right to deduct 1 child appeared from January, the calculations are still carried out from the beginning of the year.
<G-vec00649-002-s074><deduct.abziehen><de> Die Regierung fördert diesen Übergang, indem sie Unternehmen erlaubt, einen Teil des Kaufbetrags von der Steuer abzuziehen.
<G-vec00649-002-s074><deduct.abziehen><en> The government encourages this transition by allowing companies to deduct part of the purchase amount from the tax.
<G-vec00649-002-s075><deduct.abziehen><de> TuneCore behält sich das Recht vor, Zahlungen einzubehalten oder abzuziehen, solange die angemessene Untersuchung der vorstehenden Punkte oder die Nichteinhaltung der Servicebedingungen durch Sie anhalten.
<G-vec00649-002-s075><deduct.abziehen><en> TuneCore reserves the right to withhold or deduct payment, if applicable, pending TuneCore’s reasonable investigation of any of the foregoing or any breach of the Terms of Service by you.
<G-vec00649-002-s076><deduct.abziehen><de> Wenn du nichts abzuziehen hast, erfasst taxx.lu automatisch alle Pauschalen.
<G-vec00649-002-s076><deduct.abziehen><en> If you have nothing to deduct, then taxx.lu records all deductible packages automatically.
<G-vec00649-002-s077><deduct.abziehen><de> 28) das in Artikel 167 der EU-MwSt-Richtlinie 2006/112/EG verankerte Recht von Steuerpflichtigen bestätigt, die auf erworbene Gegenstände und empfangene Dienstleistungen berechnete Mehrwertsteuer abzuziehen.
<G-vec00649-002-s077><deduct.abziehen><en> 28) has confirmed the right of taxable persons to deduct the VAT charged on goods purchased and services received as provided for by Article 167 of the EU VAT Directive 2006/112/EC.
<G-vec00649-002-s078><deduct.abziehen><de> Im Zentrum der Kritik standen die Auslagerung von fast 600 festen Arbeitsplätzen, der Unwille des Unternehmens, die Gewerkschaftsbeiträge von über 100 Außendienstlern direkt von der Lohnsumme abzuziehen - mehr als 200 Beschäftigte arbeiten in dieser Funktion im ganzen Land -, und die Weigerung, über Arbeitsbedingungen zu verhandeln, mit der Begründung, man könne dem Unternehmen vertrauen.
<G-vec00649-002-s078><deduct.abziehen><en> The most crucial points under discussion included the outsourcing outsourcing See contracting-out of almost 600 permanent posts, the company’s unwillingness to deduct at source the trade union dues of over 100 pre-sales employees – out of over 200 working for the company across the country – and the refusal to negotiate their working conditions, arguing that they hold positions of trust.
<G-vec00649-002-s079><deduct.abziehen><de> Anderenfalls ist der Verkäufer berechtigt, die Schadenshöhe abzuziehen, die ihm durch die Beschädigung der Ware entstanden ist, wobei dieser Schaden auch dem Kaufpreis der Ware entsprechen kann.
<G-vec00649-002-s079><deduct.abziehen><en> 5.5 The seller is entitled to unilaterally deduct the claims for damage caused to the goods against the Buyer's claim for refund of the purchase price.
<G-vec00649-002-s088><deduct.abziehen><de> Wenn Microsoft Ihre App oder Ihr In-App-Produkt aufgrund eines Verstoßes gegen diese Vereinbarung oder als Reaktion auf den Vorwurf der Verletzung geistiger Eigentumsrechte aus dem Microsoft Store und/oder von Kundengeräten entfernt, ist Microsoft berechtigt, von den App-Erlösen Kosten abzuziehen, die in Verbindung mit der Entfernung der App oder des In-App-Produkts entstanden sind.
<G-vec00649-002-s088><deduct.abziehen><en> If Microsoft removes your App or In-App Product from the Store and/or any Customer's device(s) for breach of this Agreement or in response to an allegation of intellectual property infringement, Microsoft may deduct any costs incurred in connection with the removal of such App or In-App Product from any App Proceeds.
<G-vec00649-002-s090><deduct.abziehen><de> Der überzahlte Betrag wird vom Urlaubsgeld abgezogen.
<G-vec00649-002-s090><deduct.abziehen><en> In that case, we will deduct the amount overpaid from the holiday allowance.
<G-vec00649-002-s091><deduct.abziehen><de> Sollte es zu Beschädigungen kommen, die Ihrem Aufenthalt zuzuschreiben sind, wird der Betrag für die Reparatur von Ihrer Kaution abgezogen.
<G-vec00649-002-s091><deduct.abziehen><en> In the event that there is damage attributable to your stay, we will deduct the cost of repair from the deposit.
<G-vec00649-002-s092><deduct.abziehen><de> Wenn Sie dies tun, wird der Vertrag sofort beendet und wir erstatten alle von Ihnen bezahlten Beträge für nicht gelieferte Produkte zurück, wir können jedoch von dieser Rückerstattung einen angemessenen Betrag für die uns als Folge der Beendigung des Vertrages entstandenen Kosten abziehen oder (wenn Sie keine Vorauszahlung geleistet haben) in Rechnung stellen.
<G-vec00649-002-s092><deduct.abziehen><en> If you do this the contract will end immediately and we will refund any sums paid by you for products not provided but we may deduct from that refund (or, if you have not made an advance payment, charge you) reasonable compensation for the net costs we will incur as a result of your ending the contract.
<G-vec00649-002-s095><deduct.abziehen><de> Ihr Arbeitgeber wird automatisch jeden Monat die Einkommensteuer in Form der Lohnsteuer von Ihrem Bruttoarbeitslohn abziehen und für Sie an das Finanzamt überweisen.
<G-vec00649-002-s095><deduct.abziehen><en> Your employer will automatically deduct the income tax from your gross wage every month in the form of wage tax and will transfer it to the tax office for you.
<G-vec00649-002-s102><deduct.abziehen><de> Vor dieser Übergabe sind jedoch die Behörden des Staates, dessen Flagge das Schiff führt, berechtigt, von dem Nachlaß alle benötigten Beträge abzuziehen, um Forderungen von Personen zu befriedigen, die nicht in dem Staat ansässig sind, dem der Verstorbene angehörte, wenn sie diese Forderungen für begründet halten.
<G-vec00649-002-s102><deduct.abziehen><en> The authorities of the State of the flag shall, however, be entitled, before making such transfer, to deduct from the said estate any sums necessary to meet debts to persons not resident in the State of the deceased if they are satisfied that such debts are legally valid.
<G-vec00649-002-s103><deduct.abziehen><de> Diesen Betrag dürfen sie ebenfalls vom steuerbaren Einkommen abziehen.
<G-vec00649-002-s103><deduct.abziehen><en> They too can deduct this amount from their taxable income.
<G-vec00649-002-s112><deduct.abziehen><de> Der Reiseveranstalter darf von dem zu erstattenden Mehrbetrag die ihm tatsächlich entstandenen Verwaltungsausgaben abziehen.
<G-vec00649-002-s112><deduct.abziehen><en> The tour operator is allowed to deduct administrative expenses actually incurred from this reimbursable surplus amount.
<G-vec00649-002-s113><deduct.abziehen><de> Wir behalten uns vor, Ersatz für mögliche Beschädigungen/möglichen Wertverlust der Produkte vom zu erstattenden Kaufpreis abzuziehen.
<G-vec00649-002-s113><deduct.abziehen><en> We reserve the right to deduct compensation from the refunded price for possible damage / possible loss of value of the Products.
<G-vec00649-002-s114><deduct.abziehen><de> - Zuerst musst du die durchsichtige Folie auf der Rückseite der Farbkleckse abziehen.
<G-vec00649-002-s114><deduct.abziehen><en> - First you have the transparent film on the back of the drop of blood deduct.
<G-vec00649-002-s116><deduct.abziehen><de> Daraus folgernd werden wir zunächst automatisch die Provisionen von jeder Zahlung an einen Designer/Creative abziehen.
<G-vec00649-002-s116><deduct.abziehen><en> Accordingly, We will first automatically deduct the Commission Fees from any payment a Designer / Creative receives.
<G-vec00649-002-s117><deduct.abziehen><de> Zu diesem Zeitpunkt musst Du nichts für das Paket bezahlen - wir werden die Versandkosten vom Gewinnerlös abziehen, sobald Du Artikel verkauft hast.
<G-vec00649-002-s117><deduct.abziehen><en> You don’t have to pay for the parcel at this point – we will deduct the standard delivery cost from your sales account once your items have been sold.
<G-vec00649-002-s120><deduct.abziehen><de> Kunden können die Kosten für einen externen Vorverkauf in der Höhe von 10% pauschal auch bei Kleinkonzerten abziehen, sofern sie die entsprechenden Belege einreichen.
<G-vec00649-002-s120><deduct.abziehen><en> Customers may also deduct the costs for external ticket sales up to a lump-sum of 10%, even for small concerts, if they submit the relevant supporting documents.
<G-vec00649-002-s121><deduct.abziehen><de> Sofern der Besteller Zahlung innerhalb von 14 Tagen nach Eingang der Ware leistet, ist er berechtigt, 3% Skonto abzuziehen.
<G-vec00649-002-s121><deduct.abziehen><en> If the ordering party pays within 14 days of receiving the goods, he is entitled to deduct 3 % discount.
<G-vec00649-002-s125><deduct.abziehen><de> (5) Erfolgt die Zahlung innerhalb von 14 Tagen ab Rechnungsdatum, so ist der Kunde berechtigt, von der Nettorechnungssumme 2 % Skonto abzuziehen.
<G-vec00649-002-s125><deduct.abziehen><en> (5) If the customer should pay within 14 days from the invoice date, he shall be entitled to deduct 2 % discount from the net amount invoiced.
<G-vec00649-002-s126><deduct.abziehen><de> Wir werden die Kurierkosten von Ihrer Probebestellung abziehen.
<G-vec00649-002-s126><deduct.abziehen><en> We will deduct the courier costs from your trial order.
<G-vec00649-002-s127><deduct.abziehen><de> Leihe ich mir dagegen das Geld von der Bank, dann muss ich – wenn ich seriös rangehe – von den Mieteinnahmen nur die Zinsen abziehen.
<G-vec00649-002-s127><deduct.abziehen><en> If, on the other hand, I borrow the money from the bank, then I only have to deduct the interest from the rental income – if I am serious about it.
<G-vec00649-002-s128><deduct.abziehen><de> In derselben E-Mail informiert VALENTINO den Kunden auch über den Betrag, der von dem Rückzahlungsbetrag abgezogen wird, sofern sich der Kunde nicht für eine erneute Zustellung der Produkte entscheidet, und zwar in demselben Zustand, in dem die Produkte an VALENTINO retourniert wurden.
<G-vec00649-002-s128><deduct.abziehen><en> By the same mail, VALENTINO shall also notify the amount that it will deduct from the amount to be refunded, unless Customer elects to have, at its own expense, the products sent back to him/her in the same conditions in which they were returned to VALENTINO.
<G-vec00649-002-s132><deduct.abziehen><de> Die Steuerbehörde würde die Privatperson über die Feststellung der Steuer nur in dem Fall benachrichtigen, wenn entdeckt wird, dass der Betrag der Steuer, Steuervorauszahlung vom Arbeitgeber nicht den Bestimmungen der Rechtsvorschriften entsprechend festgestellt und abgezogen wurde und aus dem bei der Privatperson eine Differenz ergibt.
<G-vec00649-002-s132><deduct.abziehen><en> The tax authority would only notify the individual of the establishment of the tax if it determines that the employer did not assess and deduct the amount of the tax or tax advance in compliance with legal regulations and this generates a tax difference for the individual.
<G-vec00649-002-s137><deduct.abziehen><de> Denn mit dem Steuervereinfachungsgesetz wird auch die bisher geltende 75-56-Regelung abgeschafft: Bislang konnte ein Vermieter, der zu mindestens 75 Prozent der Marktmiete vermietet hat, die Kosten aus der Vermietung vollständig als Werbungskosten abziehen.
<G-vec00649-002-s137><deduct.abziehen><en> The so-called 75-56 rule which applied until now has been abolished under the Tax Simplification Law: Up until now, landlords who rented out their property at a minimum of 75 percent of the market level were allowed to deduct their entire costs associated with the tenancy as income-related expenses.
<G-vec00649-002-s138><deduct.abziehen><de> Gegenüber den Niederlanden würde dann ein seit langem bestehender Nachteil entfallen und Importeure könnten künftig sofort die Vorsteuer abziehen.
<G-vec00649-002-s138><deduct.abziehen><en> This would eliminate a long-standing disadvantage vis-à-vis the Netherlands, with importers in future able to deduct Import Tax immediately.
<G-vec00649-002-s139><deduct.abziehen><de> Ein Steuerpflichtiger darf von seiner Steuerschuld die für die Lieferung eines Gebrauchtfahrzeugs durch einen steuerpflichtigen Wiederverkäufer geschuldete oder entrichtete Mehrwertsteuer nicht als Vorsteuer abziehen, wenn die Lieferung dieses Gegenstands durch den steuerpflichtigen Wiederverkäufer gemäß dieser Übergangsregelung besteuert wurde.
<G-vec00649-002-s139><deduct.abziehen><en> Taxable persons may not deduct from the VAT for which they are liable the VAT due or paid in respect of second-hand means of transport supplied to them by a taxable dealer, in so far as the supply of those goods by the taxable dealer is subject to VAT in accordance with these transitional arrangements.
<G-vec00649-002-s151><deduct.abziehen><de> 2 Sterne ziehe ich ab, weil ich eine temperamentvolle Mitarbeiterin erwischt habe, die unter diesen Stresssituation einen Kunden falsch behandelt hatt.
<G-vec00649-002-s151><deduct.abziehen><en> I deduct 2 stars because I caught a spirited employee who treated a customer incorrectly under this stressful situation.
<G-vec00649-002-s152><deduct.abziehen><de> So jemand könnte hieraus den Schluß ziehen, daß wenn er nicht das richtige Leben führt, er dann aber trotzdem sicher dadurch ist, daß er sich einfach nicht hypnotisieren läßt.
<G-vec00649-002-s152><deduct.abziehen><en> So somebody might deduct from this that if he does not really live the right Way then he will be save by simply not allowing anybody to hypnotize him.
<G-vec00649-002-s153><deduct.abziehen><de> Dennoch ziehen wir für die Aussetzer in der Bedienung und die Inkompatibilität mit vielen Benchmarks und damit wohl auch einigen Apps einen Prozentpunkt in der Gesamtwertung ab.
<G-vec00649-002-s153><deduct.abziehen><en> Nevertheless, we deduct one percent point in the total rating for the lags in operation and the incompatibility with many benchmarks.
<G-vec00649-002-s154><deduct.abziehen><de> Wir ziehen den Nachlass vom Buchungsbetrag nach Buchung ab und schicken Ihnen die angepasste Rechnung zu.
<G-vec00649-002-s154><deduct.abziehen><en> We deduct the discount from the booking amount after booking and send you the adjusted invoice. Living room
<G-vec00649-002-s155><deduct.abziehen><de> Wenn sich Ihre Bestellung während des Transports umkehren lässt, können wir Ihre Bestellung stornieren, ziehen jedoch die ursprüngliche Versandgebühr von Family Cares sowie alle Gebühren für das Abfangen des Pakets ab.
<G-vec00649-002-s155><deduct.abziehen><en> If your order can be turned around, in transit, we can cancel your order, but will deduct the original shipping fee charged to Family Cares along with any fees to intercept the package.
<G-vec00649-002-s156><deduct.abziehen><de> Autovermietungen ziehen oft den vollen Selbstbehalt eines Fahrzeugs ab und zahlen Ihnen später eine Rückerstattung, weil die Reparaturkosten niedriger waren als der Selbstbehalt, der abgezogen wurde, oder, wenn ein anderes Auto beteiligt war, wurde der andere Fahrer als schuldig angesehen.
<G-vec00649-002-s156><deduct.abziehen><en> Rental companies often deduct the full excess value of a vehicle and they later pay you a refund because the repair costs were lower than the excess that was deducted, or, if there was another car involved, the other driver was deemed to be at fault.
<G-vec00649-002-s157><deduct.abziehen><de> Wir ziehen einen Kredit (langcoin) für die Überprüfung einer Sprache ab.
<G-vec00649-002-s157><deduct.abziehen><en> For checking one language we deduct one credit (langcoin).
<G-vec00649-002-s158><deduct.abziehen><de> 10.2 Sobald Ihr Konto für inaktiv erklärt worden ist, sind wir dazu berechtigt, eine Aufrechterhaltungsgebühr zu verrechnen Beginnend mit dem letzten Tag der Schonfrist und danach alle dreißig (30) Tage, ziehen wir, entsprechend dem Plan für inaktive Konten, einen Betrag in Höhe der Gebühr für inaktive Konten von Ihrem Kontostand ab.
<G-vec00649-002-s158><deduct.abziehen><en> 10.2 Once your Account has been deemed inactive we will be entitled to charge you maintenance fee Inactive Account Fee. We may deduct an amount up to the Inactive Account Fee from your account balance commencing on the last day of the Grace Period and then every thirty (30) days thereafter in accordance with the Inactive Account Fee Schedule.
<G-vec00649-002-s159><deduct.abziehen><de> > Wir ziehen den Wert des Artikels automatisch von den restlichen Raten ab und berechnen die bevorstehenden Raten auf der Grundlage dieser Stornierung neu.
<G-vec00649-002-s159><deduct.abziehen><en> > We automatically deduct the item's value from the remaining instalments and recalculate your payments based on this cancellation.
<G-vec00649-002-s160><deduct.abziehen><de> Für Zahlungen in alle anderen Länder und bei Scheckzahlungen zieht die SVB 0,48 € von Ihrer Leistung ab.
<G-vec00649-002-s160><deduct.abziehen><en> In the case of all other countries, and for cheque payments, the SVB will deduct € 0.48 from your benefit.
<G-vec00649-002-s161><deduct.abziehen><de> Expedia Rewards zieht von Ihrem Konto jeweils die Anzahl an Punkten ab, die Sie für den teilnahmeberechtigten Kauf festgelegt haben.
<G-vec00649-002-s161><deduct.abziehen><en> Expedia Rewards will deduct from your Account balance the amount of points you elect to use toward your eligible purchase.
<G-vec00649-002-s162><deduct.abziehen><de> Wenn Sie in Großbritannien lohnsteuerpflichtig (PAYE - Pay As You Earn) arbeiten, wie zum Beispiel als Empfangsmitarbeiter im Hotel, als Krankenschwester oder Lehrer, zieht Ihr Arbeitgeber die Steuern von Ihrem Einkommen ab.
<G-vec00649-002-s162><deduct.abziehen><en> If you're a UK PAYE (Pay as You Earn) worker, such as a receptionist, nurse or teacher, your employer will deduct tax from your earnings.
<G-vec00649-002-s163><deduct.abziehen><de> Für Zahlungen in alle anderen Länder und bei Scheckzahlungen zieht die SVB 0,48 € von Ihrem Kindergeld ab.
<G-vec00649-002-s163><deduct.abziehen><en> In the case of all other countries, and for cheque payments, the SVB will deduct € 0.48 from your child benefit.
<G-vec00649-002-s164><deduct.abziehen><de> Vor allem bei Auslandsüberweisung zieht die Bank unter Umständen eine bestimmte Bearbeitungsgebühr vor der Überweisung an RaceChip ab.
<G-vec00649-002-s164><deduct.abziehen><en> Especially with foreign payment transfers, the bank may deduct a certain processing fee from the transfer amount to RaceChip.
<G-vec00649-002-s165><deduct.abziehen><de> Wenn Sie an einem Ort einkaufen, an dem keine Mehrwertsteuer anfällt, erkennt der Checkout-Prozess dies bei der Eingabe Ihrer Adressdaten und zieht die Mehrwertsteuer entsprechend ab.
<G-vec00649-002-s165><deduct.abziehen><en> If you are purchasing from a location where VAT does not apply, the checkout process will recognise this when your address details are entered and deduct VAT appropriately.
<G-vec00649-002-s020><subtract.abziehen><de> Wer damit, und der lässigen postmodernen Attitüde, die alles fröhlich und sarkastisch aufgreift und verwurstet, was gerade am musikalischen Wegesrand liegt, seine Schwierigkeiten hat, darf lockere 3 - 4 Punkte von der Bewertung abziehen.
<G-vec00649-002-s020><subtract.abziehen><en> Those, who have difficulties with the easygoing post-modern attitude, which cheerfully and sarcastically picks up and cobbles together everything that lies at the musical roadside, can easily subtract the rating about 3 – 4 points.
<G-vec00649-002-s021><subtract.abziehen><de> Wählen Sie die Volumenkörper aus, die Sie abziehen möchten.
<G-vec00649-002-s021><subtract.abziehen><en> Select the solids you wish to subtract.
<G-vec00649-002-s022><subtract.abziehen><de> Rein praktisch bedeutet das: Wenn Sie einen Motor in Ihr Gekko fx 26 einbauen, müssen Sie dessen Gewicht bei der möglichen Zuladung abziehen.
<G-vec00649-002-s022><subtract.abziehen><en> In practical terms, this means that if you install a motor in your Gekko fx 26, you have to subtract its weight from the possible payload.
<G-vec00649-002-s023><subtract.abziehen><de> Option zum Abziehen eines Rhino-Volumenkörpers von einer VisualARQ-Wand.
<G-vec00649-002-s023><subtract.abziehen><en> Option to subtract a Rhino solid from a VisualARQ wall.
<G-vec00649-002-s024><subtract.abziehen><de> Wenn wir uns ferner vorstellen, ein wie geringer Prozentsatz der Angeschuldigten (im Verhältnis zu den Propagandalügen über angebliche Verbrechen) seit 1945 verurteilt werden konnten und von ihnen diejenigen abziehen, welche bei Anwendung einwandfreier Rechtsverfahren gar nicht hätten verurteilt werden können, so staunt man über die Differenz.
<G-vec00649-002-s024><subtract.abziehen><en> If we consider, further, what a small percentage of accused have in fact been convicted since 1945 (in contrast to what one might expect in light of the mendacious propaganda about alleged crimes and atrocities), and we then subtract from this number those accused who could never have been convicted if the law had been applied correctly and as intended, then the difference is mind-boggling.
<G-vec00649-002-s025><subtract.abziehen><de> Mit der Funktion können Sie das Gewicht eines Behälters abziehen, um nur das Gewicht des Inhalts zu ermitteln.
<G-vec00649-002-s025><subtract.abziehen><en> Using the function, you can subtract the weight of a container to obtain the weight of just the contents.
<G-vec00649-002-s026><subtract.abziehen><de> Abziehen dagegen tue ich versteckte Belastungen und Risiken des Unternehmens, die ich als Unternehmer ja auch am besten weiß.
<G-vec00649-002-s026><subtract.abziehen><en> On the other hand, I will subtract hidden costs and risks of the enterprise. Being the entrepreneur myself, I will know best what these are.
<G-vec00649-002-s027><subtract.abziehen><de> Um eine Selektion von einer anderen abzuziehen, benutzt man dieselben Werkzeuge in Kombination mit "ctrl".
<G-vec00649-002-s027><subtract.abziehen><en> To subtract one selection from the other, you use the same tools in combination with "ctrl".
<G-vec00649-002-s030><subtract.abziehen><de> Wenn du keinen Tageskilometerzähler hast, dann ziehe den Anfangswert vom Endwert ab, um herauszufinden, wie weit du gefahren bist.
<G-vec00649-002-s030><subtract.abziehen><en> If you do not have a trip odometer, subtract your "Starting Mileage" from your current mileage to find out how far your traveled.
<G-vec00649-002-s033><subtract.abziehen><de> In diesem Fall wollen wir eine einfache Formel einsetzen um die 1990 Bevölkerungsdichte von der von 2000 abzuziehen.
<G-vec00649-002-s033><subtract.abziehen><en> In this case we want to enter a simple formula to subtract the 1990 population density from 2000.
<G-vec00649-002-s035><subtract.abziehen><de> Wenn Sie also die Radioaktivität in Blumenerde messen wollen, müssen Sie zuerst wissen, was für diesen Ort „normal“ ist und ihn dann vom Gesamtmesswert abziehen.
<G-vec00649-002-s035><subtract.abziehen><en> So when you wish to measure the radioactivity in some potting soil you must know what is "normal" for that spot first and then subtract it from the gross count.
<G-vec00649-002-s083><subtract.abziehen><de> Bei Bäumen mit dicker Rinde wie der Schwarzen Eiche ziehe 2,5 cm vom Radius ab.
<G-vec00649-002-s083><subtract.abziehen><en> For tree species with thick bark, such as black oak, subtract 1 in (2.5 cm) from the radius measurement.
<G-vec00649-002-s084><subtract.abziehen><de> Aufgabe: Zähle die senkrechten Holzlatten des Eingangstores ab dem Scharnier und ziehe 1 ab.
<G-vec00649-002-s084><subtract.abziehen><en> Question: Count the vertical wooden slats of the entrance gate from the hinge and subtract one.
<G-vec00649-002-s085><subtract.abziehen><de> Um die Auswirkung zu bestimmen, die die Inflation auf dein höheres Gehalt hat, ziehe einfach die Inflationsrate vom Prozentsatz deiner Gehaltserhöhung ab, den du in Teil 1 berechnet hast.
<G-vec00649-002-s085><subtract.abziehen><en> To determine the effect inflation has on your increased salary, simply subtract the rate of inflation from the increase percentage you calculated in Part 1.
<G-vec00649-002-s086><subtract.abziehen><de> Alle anderen Waffen reduzieren zuerst die Schilde auf null und ziehen danach erst Gesundheit ab.
<G-vec00649-002-s086><subtract.abziehen><en> All other weapons first reduce the shields to zero and only after that subtract health.
<G-vec00649-002-s087><subtract.abziehen><de> Sollte es Ihnen gelingt, werden Sie 6 auf dem Tisch haben, ziehen Sie vier, so dass Sie zwei auf der dritten Runde haben.
<G-vec00649-002-s087><subtract.abziehen><en> If you succeed you will have six on the game table, subtract four so you keep 2 on the third wager.
<G-vec00649-002-s088><subtract.abziehen><de> Sollte es Ihnen gelingt, werden Sie 6 auf dem Spieltisch haben, ziehen Sie vier, so dass Sie mit 2 am dritten Wette gelassen werden.
<G-vec00649-002-s088><subtract.abziehen><en> If you win you will hold 6 on the game table, subtract 4 so you are left with 2 on the third wager.
<G-vec00649-002-s089><subtract.abziehen><de> Um diese zu ermitteln, addieren Sie erst die Größe des Vaters und die Größe der Mutter, zählen Sie dann 13 cm hinzu, wenn Sie einen Jungen haben oder ziehen Sie 13 cm ab, wenn Sie ein Mädchen haben.
<G-vec00649-002-s089><subtract.abziehen><en> To calculate it, add a child's father’s height plus mother’s height together, then add five inches if you have a boy and subtract five inches if you have a girl. pide by two for an estimated height.
<G-vec00649-002-s090><subtract.abziehen><de> Ziehen Sie den gemessenen Wert des 30pF-Kondensators ab.
<G-vec00649-002-s090><subtract.abziehen><en> Subtract the measured value of the 30pF capacitor.
<G-vec00649-002-s091><subtract.abziehen><de> Nehmen Sie die Zahl '220 'und ziehen Sie es von Ihrem Alter.
<G-vec00649-002-s091><subtract.abziehen><en> Take the number '220 'and subtract your age from it.
<G-vec00649-002-s092><subtract.abziehen><de> Um diese Größe zu berechnen, nimmt man den Gesamtwert der erhaltenen Zahlungen, die man von Staatsbürgern oder ausländischen juristischen Personen erhalten hat und zieht den Gesamtwert an Zahlungen ab, die an ausländische juristische Personen für inländische Produktion getätigt wurden.
<G-vec00649-002-s092><subtract.abziehen><en> To calculate this, take the total payments received by domestic citizens from foreign entities and subtract the total payments sent to foreign entities for domestic production. Advertisement Score
<G-vec00942-002-s033><pull_out.abziehen><de> Entfernen sie die Treibstoffleitung und die Druckleitung, sie können diese einfach abziehen.
<G-vec00942-002-s033><pull_out.abziehen><en> Remove the fuel lines from the fuel tank, they will simply pull off.
<G-vec00942-002-s034><pull_out.abziehen><de> Spannen Sie den Nippel in den Schraubstock ein und spreizen Sie die einzelnen Drähte der Seele mit dem Schraubendreher auseinander, sodass sich der Nippel nicht mehr so leicht abziehen lässt – das macht die Lötstelle später stabil.
<G-vec00942-002-s034><pull_out.abziehen><en> Clamp the nipple in a vice and spread the individual wires of the core with the screwdriver so that the nipple is not as easy to pull off. This makes for a more robust soldering point later.
<G-vec00942-002-s035><pull_out.abziehen><de> Ein einfaches Handwerkzeug zur Unterstützung der Arbeiten an Steckverbindungen besteht aus einem Grundkörper mit einem offenen Kanal für die Aufnahme des Kabels, einer Buchse und einer Hülse zur Arretierung von Greifkrallen zum Abziehen von Kabelverbindungen.
<G-vec00942-002-s035><pull_out.abziehen><en> A simple hand tool for support of the connection and disconnection of plug couplings consists of an open channel in a base for the cable, a socket and a movable shell for the fixation of gripping claws to pull out a plug.
<G-vec00942-002-s036><pull_out.abziehen><de> 6) Die BLAUE Deckfolie am Klebestreifen anfassen und von der Schutzfolie abziehen.
<G-vec00942-002-s036><pull_out.abziehen><en> 6) Hold the BLUE cover film on the adhesive strips and pull off from the protective film.
<G-vec00942-002-s037><pull_out.abziehen><de> Per Knopfdruck lässt sich der Absatz/Mantel vom Kern abziehen.
<G-vec00942-002-s037><pull_out.abziehen><en> Via touch of a button you can pull of the heel/ coat from the core.
<G-vec00942-002-s038><pull_out.abziehen><de> MONTAGEANLEITUNGEN Achtung: Achtung: Vor der Durchführung irgendwelcher Arbeiten am motorisierten Sprühgerät immer erst den Motor ausschalten und den Kerzenstecker von der Zündkerze abziehen.
<G-vec00942-002-s038><pull_out.abziehen><en> ASSEMBLY INSTRUCTIONS CAUTION: Before performing any work on the power sprayer, always switch off the motor and pull the spark plug connectors off the spark plug.
<G-vec00942-002-s039><pull_out.abziehen><de> Die längere Schutzkappe abziehen.
<G-vec00942-002-s039><pull_out.abziehen><en> Pull off the longer protection cap.
<G-vec00942-002-s040><pull_out.abziehen><de> Durch die Verspannung werden jedoch die Klemmelemente so verklemmt, daß ein Abziehen der Teile des Implantates von der Halteeinrichtung stark erschwert oder gar unmöglich ist.
<G-vec00942-002-s040><pull_out.abziehen><en> However, the clamping elements are clamped due to the bracing such that it is very difficult or even impossible to pull off the parts of the implant from the holding means.
<G-vec00942-002-s041><pull_out.abziehen><de> Gegebenenfalls den unteren Sprüharm 23 nach oben abziehen.
<G-vec00942-002-s041><pull_out.abziehen><en> If necessary, pull the lower arm 23 upwards and lift it off.
<G-vec00942-002-s042><pull_out.abziehen><de> Schutzkappe abziehen.
<G-vec00942-002-s042><pull_out.abziehen><en> Pull off the cap.
<G-vec00942-002-s043><pull_out.abziehen><de> Es ist eine große Amp, abziehen können viele Töne.
<G-vec00942-002-s043><pull_out.abziehen><en> It's a great amp that can pull off many tones.
<G-vec00942-002-s044><pull_out.abziehen><de> Ich konnte einen von meiner Wange abziehen, aber er hinterließ kleine Rückstände.
<G-vec00942-002-s044><pull_out.abziehen><en> I was able to pull one off my cheek, but it left a little residue.
<G-vec00942-002-s045><pull_out.abziehen><de> Pads auf das geschlossene Augenlid legen, kurz einwirken lassen und nach unten abziehen.
<G-vec00942-002-s045><pull_out.abziehen><en> Place pad on closed eyelid, leave to work briefly and then pull downwards.
<G-vec00942-002-s046><pull_out.abziehen><de> Damit Sie in Zukunft Ihre Rollenware leicht und einfach abziehen können, bieten wir einen Bodenständer aus weiß lackier-tem Metall an.
<G-vec00942-002-s046><pull_out.abziehen><en> To let you easily pull off your rolls in future we offer a storage rack made of white painted metal.
<G-vec00942-002-s047><pull_out.abziehen><de> Das 24K Gold Augenpatch entfernen und die Maske von den äußeren Rändern her sanft abziehen.
<G-vec00942-002-s047><pull_out.abziehen><en> Remove the 24K gold eye patch and gently pull the mask off the outer edges.
<G-vec00942-002-s048><pull_out.abziehen><de> Ein weiterer Trick, den einige Casinos abziehen, ist es, die Vollendung der Bonus-Wettanforderungen auf bestimmte Spiele zu limitieren, und zwar in der Regel auf diejenigen, die einen sehr hohen Hausvorteil besitzen.
<G-vec00942-002-s048><pull_out.abziehen><en> Another trick some casinos pull is to limit the completion of bonus wagering requirements to certain games, typically those with a very high house edge.
<G-vec00942-002-s049><pull_out.abziehen><de> Service Rund um Ihren Extruder bieten wir Ihnen verschiedene Serviceleistungen an, wodurch Sie zum Beispiel frühzeitig den Verschleißzustand der Gehäuse erkennen, die Elemente schnell und sicher von den Kernwellen abziehen und Ihre Gehäuse effizient und kostengünstig reparieren lassen können.
<G-vec00942-002-s049><pull_out.abziehen><en> For all aspects of your extruder, we offer a variety of services that you can use, for example, to detect the level of wear on the housing at an early stage, pull off the elements quickly and safely from the shafts and have your housing repaired efficiently and cost-effectively.
<G-vec00942-002-s050><pull_out.abziehen><de> Zum Austausch einfach den Bürstenkopf abziehen und durch einen neuen ersetzen.
<G-vec00942-002-s050><pull_out.abziehen><en> To change, simply pull off used brush head and replace it with a new one.
<G-vec00942-002-s051><pull_out.abziehen><de> Der G2 ist völlig vielseitig und kann viele Looks und Styles abziehen.
<G-vec00942-002-s051><pull_out.abziehen><en> The G2 is completely versatile and can pull off many looks and styles.
<G-vec00981-002-s021><withhold.abziehen><de> Du sollst deine Hand nicht abziehen von deinem Sohn oder von deiner Tochter, sondern du sollst (sie) von Jugend auf lehren die Furcht Gottes.
<G-vec00981-002-s021><withhold.abziehen><en> Do not withhold your hand from your son or your daughter, but from their youth teach them the fear of God.
