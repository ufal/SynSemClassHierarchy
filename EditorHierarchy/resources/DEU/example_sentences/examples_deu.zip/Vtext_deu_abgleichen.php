<G-vec00719-002-s024><reconcile.abgleichen><de> Und drittens müssen Anleger ihre persönlichen Präferenzen kennen und diese mit den angebotenen Produkten abgleichen können.
<G-vec00719-002-s024><reconcile.abgleichen><en> And third, investors must know their own personal preferences and be able to reconcile them with the products on offer.
<G-vec00719-002-s025><reconcile.abgleichen><de> Mit der intuitiven Benutzeroberfläche von Synchronize Folders Beyond Compare können Sie Unterschiede in Ihren Daten automatisch abgleichen.
<G-vec00719-002-s025><reconcile.abgleichen><en> Synchronize Folders Beyond Compare's intuitive Folder Sync interface lets you reconcile differences in your data automatically.
<G-vec00719-002-s026><reconcile.abgleichen><de> Nachdem Sie alle Einträge auf dem Kontoauszug abgehakt haben, und die Differenz 0.00 ist, drücken Sie den Eintrag Fertig auf der Werkzeugleiste oder wählen den Eintrag Abgleichen → Fertig aus dem Menü.
<G-vec00719-002-s026><reconcile.abgleichen><en> When you have marked off all the items on the bank statement and the difference is 0.00, press the Finish button on the Toolbar or select Reconcile → Finish from the menu.
<G-vec00719-002-s027><reconcile.abgleichen><de> Hamel und Prahalad argumentieren, dass, um Erfolg zu erzielen, eine Firma ihren Zweck (Ziel) mit ihren Mitteln durch Strategische Absicht abgleichen muss.
<G-vec00719-002-s027><reconcile.abgleichen><en> Hamel and Prahalad argue that in order to achieve success, a company must reconcile its purpose (end) with its means through Strategic Intent.
<G-vec00719-002-s028><reconcile.abgleichen><de> Sie sollten eingehende Zahlungen regelmäßig mit Ihren eigenen Unterlagen abgleichen.
<G-vec00719-002-s028><reconcile.abgleichen><en> You should regularly reconcile incoming payments with your own records.
<G-vec00719-002-s029><reconcile.abgleichen><de> Eine Beschreibung hierzu finden Sie im Abschnitt "Konto mit einem Kontoauszug abgleichen" weiter oben.
<G-vec00719-002-s029><reconcile.abgleichen><en> This is described in the To Reconcile an Account to a Statement section above.
<G-vec00719-002-s034><reconcile.abgleichen><de> Wir ermöglichen es den Benutzern, jede Art von Daten auf Anforderung zu normalisieren, zu validieren und abzugleichen.
<G-vec00719-002-s034><reconcile.abgleichen><en> We empower users to normalize, validate and reconcile any type of data on demand.
<G-vec00719-002-s035><reconcile.abgleichen><de> Manchmal denke ich daran, Versuche zu machen meine Erfahrung abzugleichen, wie jetzt.
<G-vec00719-002-s035><reconcile.abgleichen><en> I sometimes think to make attempts to reconcile my experience, like now.
<G-vec00719-002-s043><reconcile.abgleichen><de> Zur Arbeitserleichterung können Sie die Stammdatenzuordnung einer Auswertungsvariante mit der Stammdatenzuordnung einer anderen Auswertungsvariante abgleichen.
<G-vec00719-002-s043><reconcile.abgleichen><en> For convenience purposes, you can reconcile the master files assignment of one analysis variant with the master files assignment of another.
