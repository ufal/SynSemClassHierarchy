<G-vec00001-001-s019><create.anlegen><de> Daher können Sie auch in der Produktakte der Anlage die Produktaktenposition für diese Baugruppe anlegen.
<G-vec00001-001-s019><create.anlegen><en> For this reason, you can also create the product file line for this assembly in the product file of the plant.
<G-vec00001-001-s020><create.anlegen><de> Landwirte können außerdem Blühstreifen anlegen, die zusätzliche Habitate frei von Düngemitteln und Pflanzenschutzmitteln schaffen.
<G-vec00001-001-s020><create.anlegen><en> Farmers can also create flower strips that create additional habitats free of fertilizers and pesticides.
<G-vec00001-001-s021><create.anlegen><de> Sie können jederzeit auch individuelle Einstellungen für Ihre Materialien anlegen und bestehende Parameter anpassen.
<G-vec00001-001-s021><create.anlegen><en> It is also possible to create custom settings for your materials and to adjust existing parameters at any time.
<G-vec00001-001-s022><create.anlegen><de> Für Gewinn- und Verlustrechnungen können sie verschiedene Auswertungsvarianten anlegen.
<G-vec00001-001-s022><create.anlegen><en> You can create various analysis variants for profit and loss statements.
<G-vec00001-001-s023><create.anlegen><de> Abgehörte Gespräche Ein Sicherheitsrisiko geht auch von der Ortung mobiler Geräten aus: Cyberkriminelle könnten laut BSI in Kombination mit anderen ausgespähten Informationen ein umfassendes Bewegungsprofil des Opfers anlegen.
<G-vec00001-001-s023><create.anlegen><en> Locating mobile devices can also pose a security risk: According to the BSI, cyber criminals can often combine these locations with other information they uncover to create a comprehensive profile of their victims' movements.
<G-vec00001-001-s024><create.anlegen><de> Die Funktionsverriegelungen für eine Datensatzart gelten zudem für die Hinterlegung von allgemein zugänglichen Informationen im InfoGuide: So kann ein Benutzer solche Informationen zum Fenster einer Datensatzart nur dann hinterlegen, wenn für ihn alle Bearbeitungsfunktionen (Anlegen, Ändern und Löschen) zum betreffenden Programm freigegeben sind.
<G-vec00001-001-s024><create.anlegen><en> The function securities for a record type also apply to the storage of generally accessible information in the InfoGuide: For instance, a user can only store information about the window of a record type if he is authorized to use all editing functions (create, change and delete) of the program concerned.
<G-vec00001-001-s025><create.anlegen><de> Sie können so viele Ordner und Unterordner anlegen, wie Sie benötigen, alle Ordner können Dateien enthalten.
<G-vec00001-001-s025><create.anlegen><en> You can create as many folders and subfolders as you need, and all folders can contain files.
<G-vec00001-001-s026><create.anlegen><de> Sie müssen in einem solchen Fall kein neues Projekt in Across anlegen, sondern können die nötigen Anpassun gen an dem bereits bestehenden Projekt vornehmen.
<G-vec00001-001-s026><create.anlegen><en> In this case, you do not need to create a new project in Across, but can adjust the existing project instead.
<G-vec00001-001-s027><create.anlegen><de> Um Kenhub zu nutzen musst Du ein Nutzerkonto anlegen (Nutzerkonto, Konto).
<G-vec00001-001-s027><create.anlegen><en> In order to use Kenhub you need to create an account (account).
<G-vec00001-001-s028><create.anlegen><de> 2.3 Wenn Sie sich für die Nutzung irgendeines Recruiter-Dienstes registrieren, müssen Sie ein Passwort anlegen, das sie geheim halten müssen, um Betrug zu verhindern.
<G-vec00001-001-s028><create.anlegen><en> 2.3 If you register to use any of the Recruiter Services you must create a password which, in order to prevent fraud, you must keep confidential.
<G-vec00001-001-s029><create.anlegen><de> Hierfür verwenden Sie die Option „Alias anlegen“ auf der Profilseite Ihrer Institution/Organisation im Erasmus+ OLS Lizenzmanagementsystem.
<G-vec00001-001-s029><create.anlegen><en> "You are able to do this by using the ""create alias"" function in your institution/organisation's profile page of the Erasmus+ OLS Licence Management System."
<G-vec00001-001-s030><create.anlegen><de> Bitte beachten Sie, dass Sie über die entsprechenden Rechte verfügen müssen, um eine neue Relation anlegen zu können.
<G-vec00001-001-s030><create.anlegen><en> Please note that you need to have the appropriate rights in order to create a new relation.
<G-vec00001-001-s031><create.anlegen><de> Grundlage dafür ist ein Software-Tool der EBD Group, mit dessen Hilfe die Nutzer eigene Profile anlegen und sich bereits im Vorfeld der Messe für Meetings in Hannover verabreden können.
<G-vec00001-001-s031><create.anlegen><en> There is no charge for using the service, which is powered by a special software tool developed by the EBD Group. This allows users to create their own online profile and schedule meetings at the show in advance.
<G-vec00001-001-s032><create.anlegen><de> Ihr richtiger Name wird automatisch ausgewählt, wenn Sie Ihr Ancestry-Konto anlegen.
<G-vec00001-001-s032><create.anlegen><en> Your real name is selected automatically when you create your Ancestry account.
<G-vec00001-001-s033><create.anlegen><de> Wenn du genau weisst, wie dein Formular aussieht, wirst du es sehr schnell anlegen können.
<G-vec00001-001-s033><create.anlegen><en> If you know exactly what your form looks like, you will be able to create it very quickly.
<G-vec00001-001-s034><create.anlegen><de> Bibliothekskonto anlegen Ihr Bibliothekskonto wird über diesen Link angelegt.
<G-vec00001-001-s034><create.anlegen><en> This link allows you to create a library account.
<G-vec00001-001-s035><create.anlegen><de> Sie können beliebig viele E-Mail-Adressen mit Ihrem Domainnamen anlegen.
<G-vec00001-001-s035><create.anlegen><en> You can create as many e-mail addresses as you like with your domain name.
<G-vec00001-001-s036><create.anlegen><de> Für die Datenausgabe auf Papier müssen Sie Steuercodes für die Ausgabegeräte anlegen.
<G-vec00001-001-s036><create.anlegen><en> For the data output on paper, you have to create control codes for the output devices.
<G-vec00001-001-s037><create.anlegen><de> Ausgangspunkt ist immer der Modell-Assistent, in dem Maschinen oder Feeder anlegen werden können.
<G-vec00001-001-s037><create.anlegen><en> The starting point is the model wizard where you can create machines or feeders.
<G-vec00001-001-s038><create.anlegen><de> Dies hilft dem Bediener auf einfachste Weise neue Bauteile anzulegen, Programme zu erstellen und die vielfältigsten Optimierungstools zu verwenden.
<G-vec00001-001-s038><create.anlegen><en> This helps to create the user in the simplest way new components to create programs and to use the most diverse Optimizer.
<G-vec00001-001-s039><create.anlegen><de> Beschreibung Diese Erweiterung stellt für alle Zahlungsarten im Shop zwei Gebührenmodule zur Verfügung, die es möglich macht, verschiedene Provisionen und Gebühren anzulegen.
<G-vec00001-001-s039><create.anlegen><en> Description This extension provides for all methods in the shop two charges modules, which makes it possible to create various commissions and fees.
<G-vec00001-001-s040><create.anlegen><de> Aus diesem Grund ist es nötig ein neues Konto anzulegen.
<G-vec00001-001-s040><create.anlegen><en> For this reason it is necessary to create a new account.
<G-vec00001-001-s041><create.anlegen><de> Die dritte Stufe (Bearbeiten) erlaubt dem Benutzer, bestehende Gruppen zu bearbeiten und neue Gruppen anzulegen.
<G-vec00001-001-s041><create.anlegen><en> The third stage (edit) allows the user to edit existing groups, and create new ones.
<G-vec00001-001-s042><create.anlegen><de> Der erste Fehler wird geworfen, wenn zu viele Threads innerhalb der JVM bestehen und nicht mehr genug Speicher zur Verfügung steht, um einen neuen nativen Thread anzulegen.
<G-vec00001-001-s042><create.anlegen><en> The first error is thrown if there are too many threads in the JVM and there is not enough memory left to create a new thread.
<G-vec00001-001-s043><create.anlegen><de> Klicken Sie einfach auf „Registrieren“ um ein neues Konto anzulegen.
<G-vec00001-001-s043><create.anlegen><en> Please click „Register now“ to create a new account.
<G-vec00001-001-s044><create.anlegen><de> "Unter anderen zählen hierzu die Möglichkeit, Projekte anzulegen und an mehreren Scripten gleichzeitig zu arbeiten, ein Script-Compiler, der Dir Fehler bereits während des Schreibens der Scripte anzeigt, sowie eine ""Suche und Ersetze""-Funktion, die es ermöglicht, jede Instanz einer Variablen in wenigen Augenblicken zu ersetzen."
<G-vec00001-001-s044><create.anlegen><en> Amongst these features are the possibility to create projects and to work on several different scripts at once, a script compiler making you aware of possible errors while you write your scripts, a 'find & replace function' allowing you to replace every instance of a given variable in moments, and many more.
<G-vec00001-001-s045><create.anlegen><de> Klicken Sie auf Neu, um ein neues Mailing anzulegen.
<G-vec00001-001-s045><create.anlegen><en> To create a new mailing, click Create .
<G-vec00001-001-s046><create.anlegen><de> Anmerkung: Sie benötigen das Zugriffsrecht Public-Spot-Assistent (Benutzer anlegen), um einen neuen Public Spot-Benutzer anzulegen.
<G-vec00001-001-s046><create.anlegen><en> Anmerkung: You need the permissions for the Public Spot Wizard, in order to create a new Public Spot user.
<G-vec00001-001-s047><create.anlegen><de> CIROS® Education bietet alle Funktionen von CIROS® Studio ohne die Möglichkeiten neue Modelle anzulegen und Robotersteuerungen anzubinden.
<G-vec00001-001-s047><create.anlegen><en> CIROS® Education offers all functions of CIROS® Studio, minus the capability to create new models or connect robot control systems.
<G-vec00001-001-s048><create.anlegen><de> Die JUWEL Terrassen ermöglichen es Ihnen den Bodengrund einfach und dauerhaft in verschiedenen Ebenen anzulegen und erzeugen so eine außerordentliche Tiefenwirkung.
<G-vec00001-001-s048><create.anlegen><en> The JUWEL terraces allow you to create varied aquarium floor levels easy and permanently, thereby creating an extraordinary illusion of depth.
<G-vec00001-001-s049><create.anlegen><de> Und wir haben unser Ziel erreicht, so viele nachhaltig bewirtschaftete Wälder zu schützen und neu anzulegen, wie wir brauchen, um unseren aktuellen Papierbedarf zu decken und Holzfasern für weitere Generationen zu erzeugen.
<G-vec00001-001-s049><create.anlegen><en> And we've reached our goal to protect and create enough sustainably managed forests around the world to cover our current paper use and produce fibre for generations.
<G-vec00001-001-s050><create.anlegen><de> Geben Sie Ihre E-Mail-Adresse an um ein Konto anzulegen.
<G-vec00001-001-s050><create.anlegen><en> Enter your e-mail address to create your account.
<G-vec00001-001-s051><create.anlegen><de> Durch die Aktivierung einer „ operativen Protokollierung “ können Sie mod_dav_svn veranlassen, eine gesonderte Protokolldatei anzulegen, die festhält, welche Art von Funktionen Ihre Clients auf höherer Ebene ausführen.
<G-vec00001-001-s051><create.anlegen><en> mod_dav_svn, however, can come to your aid. By activating an “ operational logging ” feature, you can ask mod_dav_svn to create a separate log file describing what sort of high-level operations your clients are performing.
<G-vec00001-001-s052><create.anlegen><de> "Es war nicht möglich ""Favoriten"" Ordner innerhalb des Kontextmenüs (rechte Maus) anzulegen, das Problem ist gelöst."
<G-vec00001-001-s052><create.anlegen><en> "It was not possible to create a ""Favorites"" folder via the context menu (right mouse): this is now solved."
<G-vec00001-001-s053><create.anlegen><de> "Klicke auf ""Hinzufügen"", um einen neuen Hersteller anzulegen."
<G-vec00001-001-s053><create.anlegen><en> "Click on ""Add"" to create a new manufacturer."
<G-vec00001-001-s054><create.anlegen><de> Wir empfehlen Ihnen, bei der Registrierung (die wahlweise vor oder während des Bestellvorganges erfolgt) ein Benutzerkonto anzulegen.
<G-vec00001-001-s054><create.anlegen><en> We encourage you to to create a user account when registering (you register either before or during the ordering process).
<G-vec00001-001-s055><create.anlegen><de> Wenn Sie beispielsweise eine Layoutspezifikation erstellen, können Sie auf die zur Ressource Volltonfarbe gehörende Schaltfläche klicken, um weitere Volltonfarben anzulegen.
<G-vec00001-001-s055><create.anlegen><en> For example, when creating a Layout Specification, you can click this button on the Spot Color Resource to create additional spot colors.
<G-vec00001-001-s056><create.anlegen><de> Ebenfalls ist es möglich, neue Dateien und Ordner anzulegen.
<G-vec00001-001-s056><create.anlegen><en> It also allows the user to create new files and folders.
<G-vec00290-002-s156><brace.anlegen><de> Danach sofort die Orthese anlegen und den Fuß in Bewegung halten.
<G-vec00290-002-s156><brace.anlegen><en> Then put the brace on straight away and keep your foot moving.
<G-vec00147-002-s037><invest.anlegen><de> Damit du dein Geld anlegen kannst, wie du es möchtest.
<G-vec00147-002-s037><invest.anlegen><en> So that you can invest your money the way you want.
<G-vec00147-002-s038><invest.anlegen><de> Damit Sie Ihr Freizügigkeitsguthaben gewinnbringend anlegen, nehmen Sie bestenfalls einen Anlagehorizont von mehreren Jahren ein.
<G-vec00147-002-s038><invest.anlegen><en> You can use an investment horizon of several years to invest your vested benefits profitably.
<G-vec00147-002-s039><invest.anlegen><de> Die finanziellen Mittler können ihre Mittel in Vermögensgütern, wie Immobilien, anlegen.
<G-vec00147-002-s039><invest.anlegen><en> Financial intermediaries may invest their funds in non-financial assets including real estate.
<G-vec00147-002-s040><invest.anlegen><de> Glücklicherweise können Ihnen die Schwankungen egal sein, wenn Sie das Geld über Jahrzehnte anlegen.
<G-vec00147-002-s040><invest.anlegen><en> Fortunately, you don't need to bother about the ever changing stock prices if you invest for twenty to thirty years.
<G-vec00147-002-s041><invest.anlegen><de> Mit dem Cash Deposit Konto für Firmenkunden können Sie überschüssige Liquidität, die Sie kurz-, mittel- bis langfristig nicht benötigen, sicher anlegen.
<G-vec00147-002-s041><invest.anlegen><en> With the Cash Deposit account for corporate clients, you can securely invest the surplus liquidity that you do not need in the short to medium to long term.
<G-vec00147-002-s042><invest.anlegen><de> Da wir ausschließlich in Indexaktien anlegen, werden Sie damit keinen Ärger haben.
<G-vec00147-002-s042><invest.anlegen><en> Because we solely invest in ETFs, you will not experience this.
<G-vec00147-002-s043><invest.anlegen><de> DE EN Mit dem Anlegen zu beginnen, das war noch nie so leicht.
<G-vec00147-002-s043><invest.anlegen><en> DE EN Starting to invest has never been so easy
<G-vec00147-002-s044><invest.anlegen><de> Ganz gleich, ob Sie nun kostengünstig im kleinen Rahmen werben oder Ihre Werbestrategie groß anlegen.
<G-vec00147-002-s044><invest.anlegen><en> No matter whether you advertise on a small scale or invest your advertising strategy cost-effectively.
<G-vec00147-002-s045><invest.anlegen><de> Bevor Sie sich für eine Anlage entscheiden, ist es wichtig, dass Sie sich Gedanken dazu machen, wie lange Sie Ihr Geld anlegen möchten – beziehungsweise wann Sie das angelegte Geld wieder brauchen.
<G-vec00147-002-s045><invest.anlegen><en> Before deciding on an investment, it’s important to consider how long you wish to invest for or when you will need to get back the money you have invested.
<G-vec00147-002-s046><invest.anlegen><de> Wenn Sie anlegen, ist es am besten, den Markt genau zu beobachten und die Risiken richtig einzuschätzen.
<G-vec00147-002-s046><invest.anlegen><en> When you invest, you are best advised to carefully monitor the market and properly assess the risks.
<G-vec00147-002-s047><invest.anlegen><de> Die Zukunft nähert sich in einem raschen Tempo, und es ist an der Zeit, darüber nachzudenken, wie wir unser Kapital so anlegen können, dass es sowohl für uns als auch für die nächsten Generationen von Nutzen ist.
<G-vec00147-002-s047><invest.anlegen><en> The future is happening at a rapid pace, and it is time to think about how to invest our funds in a way that is useful to ourselves as well as to the next generations.
<G-vec00147-002-s048><invest.anlegen><de> Der Fonds kann bis zu 10 % seines Vermögens in offenen Investmentfonds anlegen.
<G-vec00147-002-s048><invest.anlegen><en> The fund may invest up to 10% of its assets in open-ended investment funds.
<G-vec00147-002-s049><invest.anlegen><de> Je länger Sie anlegen können, desto interessanter wird es.
<G-vec00147-002-s049><invest.anlegen><en> The longer you're able to invest, the better the prospects.
<G-vec00147-002-s050><invest.anlegen><de> Voraussetzung: Sie können zwischen 10 und 15 Jahren anlegen – eine Belehnung ist möglich.
<G-vec00147-002-s050><invest.anlegen><en> The prerequisite: you must invest for between 10 and 15 years – policy loans are possible.
<G-vec00147-002-s051><invest.anlegen><de> Sie können Ihr Wechselgeld mit einem individuellen Girokonto oder mit einem gemeinsamen Girokonto anlegen, wenn Sie miteinander verheiratet sind.
<G-vec00147-002-s051><invest.anlegen><en> You can invest spare change on an individual current account, or on a joint account if you are married.
<G-vec00147-002-s052><invest.anlegen><de> Da Sie nicht alles auf einmal anlegen, brauchen Sie sich keine Gedanken über den richtigen Moment zum Einsteigen zu machen.
<G-vec00147-002-s052><invest.anlegen><en> Because you don't invest all your savings in one go, you don't have to worry about when the right time is to invest.
<G-vec00147-002-s053><invest.anlegen><de> Anlagenbanken erhalten Ihre Daten nur, wenn Sie dort Geld anlegen und dürfen diese Daten nicht zu Werbemaßnahmen oder anderen Zwecken verwenden.
<G-vec00147-002-s053><invest.anlegen><en> Investment banks will only receive your data if you invest money there and they may not use this data for advertising or other purposes.
<G-vec00147-002-s054><invest.anlegen><de> Kleiner Wermutstropfen: Aufgrund ihrer Größe kann die „Azzam“ nur in einigen, speziellen Mega-Yacht-Häfen anlegen – Monaco, Puerto Portals (Mallorca) sowie die Costa Smeralda (Sardinien) sind jedoch selbstverständlich vorbereitet auf die Ankunft der größten Motoryacht der Welt.
<G-vec00147-002-s054><invest.anlegen><en> Small drawback: Because of their size, the "Azzam" only in a few, specific megayacht marinas invest - Monaco, Puerto Portals (Mallorca) and the Costa Smeralda (Sardinia), however, are of course prepared for the arrival of the largest motor yacht in the world.
<G-vec00147-002-s055><invest.anlegen><de> Bitcoin kaufen und anlegen: Bis zu 4,3% p.a.
<G-vec00147-002-s055><invest.anlegen><en> Buy and Invest in Bitcoin: Generate up to 4.3% p.a.
<G-vec00147-002-s056><invest.anlegen><de> Ein KBC-Anlageplan bietet die Möglichkeit, einen Betrag zeitlich gestreut, automatisch und zu festen Zeitpunkten anzulegen.
<G-vec00147-002-s056><invest.anlegen><en> An investment plan is a way to invest a certain amount automatically, spread over time and at specific intervals.
<G-vec00147-002-s057><invest.anlegen><de> Doch Bismarck übersah den wirtschaftlichen Aspekt: Frankreichs Bürgertum verfügte über Kapital und suchte nach lohnenden Möglichkeiten, es anzulegen.
<G-vec00147-002-s057><invest.anlegen><en> But Bismarck was overlooking the economic aspect: The French bourgeoisie had capital at their disposal and they were looking for opportunities to invest it.
<G-vec00147-002-s058><invest.anlegen><de> Den Verdacht, dass dieser Schritt gegen besseres Wissen wegen der anstehenden Abstimmung über die Gold-Initiative (20 % in Gold anzulegen) hinausgezögert wurde, kann allein das SNB-Direktorium ausräumen.
<G-vec00147-002-s058><invest.anlegen><en> Only the SNB Governing Board can dispel the doubts that this step was delayed against better knowledge because of the upcoming vote on the Gold Initiative (the demand to invest 20% in gold).
<G-vec00147-002-s059><invest.anlegen><de> Was Anleger vor allem nervös macht, ist eine mögliche Abschwächung des Renminbi mit der Folge, dass chinesische Anleger Vertrauen in ihre Landeswährung verlieren und nach Wegen suchen, ihr Geld außerhalb Chinas anzulegen, und so eine abwärts gerichtete Spirale in Gang setzen.
<G-vec00147-002-s059><invest.anlegen><en> Nervousness The main reason for investors to get nervous, is the prospect of a weakening renminbi, causing Chinese investors to lose confidence in the national currency and looking for ways to invest their money outside of China, triggering a downward spiral.
<G-vec00147-002-s060><invest.anlegen><de> Sie werden eine Möglichkeit finden, Geld im Ausland anzulegen.
<G-vec00147-002-s060><invest.anlegen><en> You will find a good way to invest money abroad.
<G-vec00147-002-s061><invest.anlegen><de> So haben wir, auf mein großes Vergnügen, einen Partner gewonnen, der bereit ist, alle seine Kräfte in Wissenschaft, Kultur und Kunst Serbien anzulegen und besonders die „Botschafter“ des Wissens – unsere Genies – hervorzuheben.
<G-vec00147-002-s061><invest.anlegen><en> That is how we, to my great satisfaction, have won a partner ready to invest all its potentials in science, culture and art in Serbia with special attention to ‘the ambassadors’ of knowledge – young geniuses.
<G-vec00147-002-s062><invest.anlegen><de> Schon immer gab es das Märchen von den soliden Finanzmärkten, Darlehen und Aktiendepots, schon immer wurde behauptet, dass es sicher ist, sein Geld in Aktien anzulegen, während man eine Hypothek auf sein Haus aufnimmt.
<G-vec00147-002-s062><invest.anlegen><en> There has always existed a general tale about the financial markets, loans and savings in shares claiming that these systems are sound and that it is safe to invest your money in shares to mortgage your house.
<G-vec00147-002-s063><invest.anlegen><de> Durch die deutliche Flächenausweitung für die Produktion in diesem Bereich ergab sich die Möglichkeit, gezielte Düngungsversuche in dem Betrieb anzulegen.
<G-vec00147-002-s063><invest.anlegen><en> The significant expansion in available space for production in this sector offered the company the opportunity to invest in targeted fertilisation trials.
<G-vec00147-002-s064><invest.anlegen><de> Dies wird zunehmend auch von internationalen institutionellen Investoren genutzt, um mit Hilfe der KanAm Gruppe als Fonds-, Portfolio- und Asset Manager ihr Vermögen in deutsche, europäische und amerikanische Immobilien anzulegen.
<G-vec00147-002-s064><invest.anlegen><en> Increasingly, international institutional investors take advantage of this by engaging KanAm Group as fund, portfolio and asset managers to invest their assets in German, European and American real estate.
<G-vec00147-002-s065><invest.anlegen><de> Direkte Investments sind die unmittelbarste Möglichkeit, Geld nach ethisch nachhaltigen Aspekten anzulegen.
<G-vec00147-002-s065><invest.anlegen><en> Direct investments are the most immediate option to invest money according to ethically sustainable aspects.
<G-vec00147-002-s066><invest.anlegen><de> Robo-Advisor in heute bekannter Form traten in Deutschland erstmals im Jahr 2013 auf und bieten Kunden eine einfachere sowie preiswertere Möglichkeit Geld anzulegen.
<G-vec00147-002-s066><invest.anlegen><en> Robo-advisors in today’s known form occurred in the UK in 2008 for the first time and provided customers with a simple and inexpensive way to invest money.
<G-vec00179-002-s019><create.anlegen><de> Auswertungsvarianten anlegen Für Liquiditätsprognosen können sie verschiedene Auswertungsvarianten anlegen.
<G-vec00179-002-s019><create.anlegen><en> Creating analysis variants You can create various analysis variants for cash forecasts.
<G-vec00179-002-s020><create.anlegen><de> Wenn Sie eine FEDERATED-Tabelle anlegen, erzeugt der Server eine Tabellen-Formatdatei im Datenbankverzeichnis.
<G-vec00179-002-s020><create.anlegen><en> When you create a FEDERATED table, the server creates a table format file in the database directory.
<G-vec00179-002-s021><create.anlegen><de> Wir können mit Hilfe von Satelliten, mit Fächersonar oder seismischen Wellen eine Karte der Meeresbodenmorphologie anlegen, die bis auf den halben Meter genau ist.
<G-vec00179-002-s021><create.anlegen><en> OK, we can use satellites, digital sonar and seismic profiling to create a map of seabed morphology that's accurate to within half a metre.
<G-vec00179-002-s022><create.anlegen><de> Puppet kann verschiedene Admin Aufgaben, wie beispielsweise das Anlegen eines Users, das Ändern von Konfigurationsdateien oder Softwareinstallationen auf ganz unterschiedlichen Servern durchführen, sogar wenn diese Server unterschiedliche Betriebssysteme ausführen.
<G-vec00179-002-s022><create.anlegen><en> Puppet is capable of various administrative tasks (eg. create users, modify configuration files or install software) on different servers even if these servers run on different operating systems.
<G-vec00179-002-s023><create.anlegen><de> Ihr Warenkorb wird automatisch bei der Anmeldung enthalten sein oder ein Konto anlegen.
<G-vec00179-002-s023><create.anlegen><en> Your shopping cart will automatically be included on login or create an account.
<G-vec00179-002-s024><create.anlegen><de> Damit taugt es eher nicht, wenn du einen Minigarten anlegen willst, dessen Standort du öfter wechseln möchtest.
<G-vec00179-002-s024><create.anlegen><en> This means that isn't suitable if you want to create a mini garden which you want to move about regularly.
<G-vec00179-002-s025><create.anlegen><de> Für das Anlegen dieses Profils speichern und analysieren wir die unserseits gesammelten pers?nlichen Daten über Sie, inklusive: - Ihrem Namen, Geburtsdatum und Ihrer E-Mail-Adresse.
<G-vec00179-002-s025><create.anlegen><en> To create this profile, we will store and analyse the personal data we have collected about you, including: - your name, date of birth and e-mail address.
<G-vec00179-002-s026><create.anlegen><de> Weitere Informationen dazu finden Sie unter Anlegen und Ändern des Dokumentenordnerpfades.
<G-vec00179-002-s026><create.anlegen><en> For more information see Create and change the document folder path.
<G-vec00179-002-s027><create.anlegen><de> Die Definition der gesamten Videotabelle können Sie übers Backend für jedes Produkt per Hand pflegen, Sie können aber auch eine Excel Datei mit allen notwendigen Daten anlegen und diese mit der Datenbank synchronisieren.
<G-vec00179-002-s027><create.anlegen><en> You can manually maintain the definition of the entire video table for each product via the backend, but you can also create an Excel file with all the necessary data and synchronize it with the database.
<G-vec00179-002-s028><create.anlegen><de> Falls sie eine Sicherheitskopie Ihrer DVD's anlegen wollen ist der Free DVD Decrypter sicher eine gute Wahl um Ihre DVD's schnell und vor allem einfach auf die Festplatte zu rippen.
<G-vec00179-002-s028><create.anlegen><en> If you want to create a backup of your DVD's, Free DVD Decrypter is a good choice to rip your DVD's fast, and above all easy to handle, to the hard disk.
<G-vec00179-002-s029><create.anlegen><de> 1 Einfach eigene Liga anlegen, Mitspieler hinzufügen und losspielen.
<G-vec00179-002-s029><create.anlegen><en> Howto 1 Just create a league, add players and start playing.
<G-vec00179-002-s030><create.anlegen><de> Nutzer können optional ein Nutzerkonto anlegen, indem sie insbesondere ihre Bestellungen einsehen können.
<G-vec00179-002-s030><create.anlegen><en> Users can opt to create their own user account, in particular for viewing their orders.
<G-vec00179-002-s031><create.anlegen><de> Sie können sich natürlich weitere Dateien mit speziellen Einstellungen anlegen.
<G-vec00179-002-s031><create.anlegen><en> Of course, you can create additional files with special settings.
<G-vec00179-002-s032><create.anlegen><de> Neue Produkte können Sie im Administratorbereich des Euroweb Onlineshops anlegen.
<G-vec00179-002-s032><create.anlegen><en> New products are available in the administrative area of the Euroweb create online shops.
<G-vec00179-002-s033><create.anlegen><de> Anlegen einer Erinnerung • Copyright 1999-2019 © InLoox GmbH.
<G-vec00179-002-s033><create.anlegen><en> Create a reminder • Copyright 1999-2019 © InLoox, Inc.
<G-vec00179-002-s034><create.anlegen><de> ' Neuen Querschnitt aus Bibliothek anlegen.
<G-vec00179-002-s034><create.anlegen><en> ' Create new cross-section from library.
<G-vec00179-002-s035><create.anlegen><de> Über die Aktion „Teamroom erzeugen“ können Sie einen neuen Teamroom anlegen und wenn gewünscht in einem Schritt Zugriffsrechte festlegen.
<G-vec00179-002-s035><create.anlegen><en> Via the “Create Teamroom” action, you can create a new Teamroom and if desired grant access rights in one step.
<G-vec00179-002-s036><create.anlegen><de> Mit Document Builder können Sie Dokumente schnell und einfach anlegen und zur Verfügung stellen.
<G-vec00179-002-s036><create.anlegen><en> Document Builder eliminates the need for these and empowers users to create and produce documents effortlessly.
<G-vec00179-002-s037><create.anlegen><de> Wenn in Ihrem Ausgabebetrieb eine Druckmaschine mit ganz bestimmten Anforderungen steht, sollten Sie eine Job Jackets Datei anlegen, in der die Anforderungen dieser Maschine für Ihre Kunden erfasst sind (und die Kunden auf diese Weise beim Erfüllen der Anforderungen unterstützen).
<G-vec00179-002-s037><create.anlegen><en> If you are an output provider and you have a particular press with particular requirements, you might create a Job Jackets file that captures that press's requirements for your customers (and thus helps them to avoid exceeding those requirements).
<G-vec00179-002-s038><create.anlegen><de> In diesem Zusammenhang sind wir berechtigt, Nutzerprofile anzulegen, um personalisierte Angebote erstellen zu können.
<G-vec00179-002-s038><create.anlegen><en> In this context, we are entitled to create user profiles in order to create personalized offers.
<G-vec00179-002-s039><create.anlegen><de> Bevor es in die konkrete Planung geht ist es hilfreich, Ideen zu sammeln und eine Wunschliste für das Traumhaus anzulegen.
<G-vec00179-002-s039><create.anlegen><en> Before you start planning, it is helpful to collect ideas and create a wish list for your dream home.
<G-vec00179-002-s040><create.anlegen><de> Die Experten werden gebeten, wöchentlich einen Bericht per Mail an den Förderverein zu schicken und eine Stundendokumentation vor Ort anzulegen.
<G-vec00179-002-s040><create.anlegen><en> The experts are asked to send a weekly report by mail to our Association and invest one hour on-site to create documentation.
<G-vec00179-002-s042><create.anlegen><de> Werden Sie Mitglied bei Hyatt Gold Passport, unserem weltweiten Treueprogramm, um ein Expedientenprofil anzulegen und Zugriff auf exklusive Angebote und Ressourcen für Reiseagenturen zu erhalten.
<G-vec00179-002-s042><create.anlegen><en> Join Hyatt Gold Passport, our global loyalty program, to create a travel agent profile and access exclusive travel agent offers and resources.
<G-vec00179-002-s043><create.anlegen><de> Wenn Sie sich dazu entscheiden, Slots mit echtem Geld zu spielen und ein Konto im Casino anzulegen, spielt es keine Rolle, ob Sie Echtgeld einzahlen oder nicht, Sie sollten auf jeden Fall die Optionen für neue Spieler herausfinden.
<G-vec00179-002-s043><create.anlegen><en> When you decide to play slots for real money and you create a casino account, whether you are ready to make a real money deposit or not, you should explore your new player promotion options.
<G-vec00179-002-s044><create.anlegen><de> Du kannst einen neuen Link auf irgendeiner Seite irgendwo einfügen und diesen neuen Link anklicken, um eine neue Seite anzulegen.
<G-vec00179-002-s044><create.anlegen><en> You can create a link on another page, then click the link you just inserted, to create the new page:
<G-vec00179-002-s045><create.anlegen><de> Die Buchführung App bietet die Möglichkeit mehrere "Bücher" anzulegen.
<G-vec00179-002-s045><create.anlegen><en> The accounting app offers the possibility to create several "books".
<G-vec00179-002-s046><create.anlegen><de> Um einen neuen Partner anzulegen, klicken mit der rechten Maustaste Sie auf den entsprechenden Partnertyp (Handelspartner / Systempartner / Vorlagepartner) und wählen sie im Kontextmenü Erstellen aus.
<G-vec00179-002-s046><create.anlegen><en> To create a new partner, right-click on the corresponding partner type (commercial partner / system partner / template partner) and select Create from the context menu.
<G-vec00179-002-s047><create.anlegen><de> Copy-Paste des Inhalts eines bestehenden Templates sind erforderlich, um ein neues Template anzulegen.
<G-vec00179-002-s047><create.anlegen><en> Copy-paste of the existing template’s content required to create a new template.
<G-vec00179-002-s048><create.anlegen><de> Bitte registrieren oder loggen Sie sich ein, um neue interessante Unternehmensmeldungen anzulegen.
<G-vec00179-002-s048><create.anlegen><en> Please login or register to create new interesting company news.
<G-vec00179-002-s049><create.anlegen><de> Sehr sinnvoll ist es, Testempfänger anzulegen.
<G-vec00179-002-s049><create.anlegen><en> It is very useful to create some test recipients.
<G-vec00179-002-s050><create.anlegen><de> Durch Klicken auf „Anmelden“ stimmen Sie zu, dass Ihre E-Mail-Adresse genutzt wird, um Ihr Benutzerkonto anzulegen und zu verwalten, und wenn Sie dies ankreuzen, auch, um Ihnen die Newsletter von Aveda und Informationen zu den Produkten, Veranstaltungen und Angeboten von Aveda zu schicken.
<G-vec00179-002-s050><create.anlegen><en> How do we use your data? By clicking subscribe, you accept that your email address will be used to create and manage your user account and if you elect, to send Aveda newsletters and information about Aveda products, events and offers.
<G-vec00179-002-s051><create.anlegen><de> Sie haben die Möglichkeit, sich für bestimmte auf unserer Webseite bereitgestellte Dienste zu registrieren und damit ein Benutzerprofil anzulegen.
<G-vec00179-002-s051><create.anlegen><en> You have the possibility to register for certain services provided on our website and to create a user profile.
<G-vec00179-002-s052><create.anlegen><de> Sie haben die Möglichkeit, bis zu 200 Aktivitäten anzulegen, die drei Jahre lang gespeichert werden.
<G-vec00179-002-s052><create.anlegen><en> You can create up to 200 activities, which are retained for three years.
<G-vec00179-002-s053><create.anlegen><de> Die integrierte Projekt- und Nutzerverwaltung ermöglicht es gezielt Projekte für spezifische Nutzergruppen oder Gebiete anzulegen und Nutzern zuzuweisen.
<G-vec00179-002-s053><create.anlegen><en> The integration of project and management makes it possible to create projects for specific user groups or organizations in a customized manner and to assign resources & users.
<G-vec00179-002-s054><create.anlegen><de> Letzteres erfolgt ganz unkompliziert, wer Inhalte über Uploaded mit seinem sozialen Umfeld teilen will, braucht lediglich einen kostenlosen Account anzulegen.
<G-vec00179-002-s054><create.anlegen><en> The latter is done quite easily: those who want to use Uploaded to share content with their social environment only need to create a free account.
<G-vec00179-002-s055><create.anlegen><de> Um einen optimalen Überblick über alle Aufgaben zu erhalten sowie deren effizienten Ablauf gewährleisten zu können, bietet der KundenMeister die Möglichkeit, verschiedene Arten von Aufgaben anzulegen.
<G-vec00179-002-s055><create.anlegen><en> In order to get an optimal overview of all tasks as well as to ensure their efficient operation, the KundenMeister offers the possibility to create different types of tasks.
<G-vec00179-002-s056><create.anlegen><de> Um eine neue Erinnerung anzulegen, führen Sie einen der folgenden Schritte aus und wählen dann einen Erinnerungstyp aus der Liste.
<G-vec00179-002-s056><create.anlegen><en> To create a new alarm, do one of the following, and then select the type of alarm from the list which appears.
<G-vec00179-002-s475><create.anlegen><de> Legen Sie dort ein Textfeld an.
<G-vec00179-002-s475><create.anlegen><en> Create a text area on this page.
<G-vec00179-002-s476><create.anlegen><de> Rufen Sie Anruflisten ab und lassen Sie sich diese in Ihrer Callcenter-Software anzeigen; oder legen Sie neue Deals an, basierend auf Personen, die eines Ihrer Website-Formulare ausgefüllt haben.
<G-vec00179-002-s476><create.anlegen><en> Pull call lists and make them appear in your call center software, or even create new deals based on someone who fills out a form on your website.
<G-vec00179-002-s477><create.anlegen><de> Legen Sie ein neues TwinCAT System-Manager-Projekt an, wählen Sie als Zielsystem den CX und lassen Sie nach dessen Hardware suchen.
<G-vec00179-002-s477><create.anlegen><en> Create a new TwinCAT System Manager project, select the CX as the target system, and search for the associated hardware.
<G-vec00179-002-s478><create.anlegen><de> Mit den AppLinks können Sie direkt aus Ihrem Client Aktionen starten: Legen Sie eine neue Verkaufschance an, eine Telefonnotiz, einen Termin oder öffnen Sie den Kontaktdatensatz in der Originalquelle.
<G-vec00179-002-s478><create.anlegen><en> With AppLinks you can launch actions directly from your client: create a new opportunity, a call alert, a meeting or open the contact data in the original source.
<G-vec00179-002-s479><create.anlegen><de> Route ändern: Um die Route zu ändern Allersdorf im Burgenland-Henndorf im Burgenland, verschieben Sie einfach das Symbol für Ankunft und / oder Abfahrt oder legen Sie Zwischenziele an.
<G-vec00179-002-s479><create.anlegen><en> Change route: To change the route Dogwood, KY-Pole Cat Crossing, WI simply move the arrival and / or departure icon, or create intermediate locations.
<G-vec00179-002-s480><create.anlegen><de> Route ändern: Um die Route zu ändern Angath-Schwoich, verschieben Sie einfach das Symbol für Ankunft und / oder Abfahrt oder legen Sie Zwischenziele an.
<G-vec00179-002-s480><create.anlegen><en> Change route: To change the route Steyr-Schwoich simply move the arrival and / or departure icon, or create intermediate locations.
<G-vec00179-002-s481><create.anlegen><de> Legen Sie ein Geschäftskonto an und wählen Sie bei 'Kundentyp' 'geschäftlich' aus.
<G-vec00179-002-s481><create.anlegen><en> Create a business account and select 'commercial' under 'customer type'.
<G-vec00179-002-s482><create.anlegen><de> Ihre Lieblings-Tools, -Plug-ins und -Samples jederzeit griffbereit: Legen sie Sammlungen mit Farbcodes an und greifen Sie im Browser direkt darauf zu.
<G-vec00179-002-s482><create.anlegen><en> Keep your go-to devices, plug-ins and samples close at hand: create color-coded collections and access them instantly in the browser.
<G-vec00179-002-s483><create.anlegen><de> Legen Sie bei Bedarf Benutzergruppen an.
<G-vec00179-002-s483><create.anlegen><en> If required, create user groups.
<G-vec00179-002-s484><create.anlegen><de> Legen Sie dann einen Generischen Ereignisbehandler an.
<G-vec00179-002-s484><create.anlegen><en> Then create a Generic event handler.
<G-vec00179-002-s485><create.anlegen><de> Route ändern: Um die Route zu ändern Aarau-Agarone, verschieben Sie einfach das Symbol für Ankunft und / oder Abfahrt oder legen Sie Zwischenziele an.
<G-vec00179-002-s485><create.anlegen><en> Change route: To change the route Lees Mill, NH-Timonium, MD simply move the arrival and / or departure icon, or create intermediate locations.
<G-vec00179-002-s486><create.anlegen><de> Bitte legen Sie die Druckdatei Ihrer Visitenkarten mit 2 mm Beschnitt an jeder zu beschneidenden Seite der Visitenkarten an.
<G-vec00179-002-s486><create.anlegen><en> Please create the print file for your Folded cards with a 1/8 Inch bleed on each side due to be cut.
<G-vec00179-002-s487><create.anlegen><de> Legen Sie fest, wo die Tabelle angelegt werden soll.
<G-vec00179-002-s487><create.anlegen><en> How to create a pivot table.
<G-vec00179-002-s488><create.anlegen><de> Legen Sie ganz einfach OWA-Richtlinien fest, die speziell auf die Bedürfnisse Ihrer OWA-Nutzer zugeschnitten sind.
<G-vec00179-002-s488><create.anlegen><en> Easily create OWA policies specifically tailored to the needs of your OWA users.
<G-vec00179-002-s489><create.anlegen><de> Legen Sie nun mit Neu ein neues VBA-Projekt an.
<G-vec00179-002-s489><create.anlegen><en> Create a new VBA project with New.
<G-vec00179-002-s490><create.anlegen><de> Legen Sie ganz einfach maßgeschneiderte Lernportale für unterschiedliche Benutzer des erweiterten Unternehmensumfelds an, und integrieren Sie diese in Drittanbietersysteme.
<G-vec00179-002-s490><create.anlegen><en> Create customized learning portals for different users across extended enterprise and integrate with 3rd-party systems.
<G-vec00179-002-s491><create.anlegen><de> Legen Sie neue Artikel für Ihre Webseite an.
<G-vec00179-002-s491><create.anlegen><en> Create new articles for your web page.
<G-vec00179-002-s492><create.anlegen><de> Legen Sie Vorlagen für ihre typischen Projekte an.
<G-vec00179-002-s492><create.anlegen><en> Create templates for your most common projects.
<G-vec00179-002-s493><create.anlegen><de> Auswertefenster Legen Sie eine neue Konfiguration an Die Informationen die in jedem Auswerteblock eintreffen, werden im zugehörigen Auswertefenster dargestellt.
<G-vec00179-002-s493><create.anlegen><en> Evaluation windows Create a new configuration The information arriving at each evaluation block is displayed in the block's evaluation window.
<G-vec00179-002-s399><set_up.anlegen><de> Bereits bei der Entwicklung, Auswahl der Materialien und Lieferanten sowie den Herstellungsprozessen legen wir höchste Maßstäbe unter Berücksichtigung ökonomischer, ökologischer, umweltverträglicher, energiebezogener und arbeitssicherheitsrelevanter Aspekte an.
<G-vec00179-002-s399><set_up.anlegen><en> In the development, selection of materials and suppliers, as well as in the manufacturing processes already, we set high standards in consideration of economical, ecological, environmentally compatible, energy-related and occupational safety aspects.
<G-vec00179-002-s400><set_up.anlegen><de> Wenn die jungen Leute meinen, sie könnten leichtfertig über diejenigen urteilen, die durch das Feuer gegangen und deren Haare im Dienst des Herrn grau geworden sind, um den Herrn kennen zu lernen, und sie könnten sie als altmodisch beiseite legen, dann ist dies ein trauriger Tag für die Zukunft.
<G-vec00179-002-s400><set_up.anlegen><en> If young people suppose they can think lightly of those who have gone through the fires and grown grey-headed in the service of God, in learning to know the Lord, and that such can be set aside as back numbers, that is a sorry day for the future.
<G-vec00179-002-s401><set_up.anlegen><de> Legen Sie durch die Nutzung der hereO Family App Sicherheitszonen für jedes Familienmitglied fest.
<G-vec00179-002-s401><set_up.anlegen><en> Set Safe-Zones for any family member using the hereO Family App.
<G-vec00179-002-s402><set_up.anlegen><de> Grossen Wert legen wir auf gegenseitige solidarische Unterstützung mit GenossInnen anderer Regionen.
<G-vec00179-002-s402><set_up.anlegen><en> We set a high value on solidarity with comrades in other regions.
<G-vec00179-002-s403><set_up.anlegen><de> In der Backstage-Ansicht verwalten Sie Ihre Dateien und legen Ihre Programm- und Notizbuchoptionen fest.
<G-vec00179-002-s403><set_up.anlegen><en> The Backstage view is where you manage your files and set your program and notebook options.
<G-vec00179-002-s404><set_up.anlegen><de> 11 11 So scannen Sie auf einen Computer e Legen Sie den Dateityp zum Speichern in einem Ordner fest.
<G-vec00179-002-s404><set_up.anlegen><en> How to scan to a computer e Set the file type for saving to a folder.
<G-vec00179-002-s405><set_up.anlegen><de> Kontaktlinsenspezialisten legen die Gebühren für die Kontaktlinsen fest, die sie verkaufen.
<G-vec00179-002-s405><set_up.anlegen><en> Doctors' offices set the fees for the contact lenses that they sell.
<G-vec00179-002-s406><set_up.anlegen><de> Bitte legen Sie ein Benutzerkonto an um die Foreninhalte zu sehen.
<G-vec00179-002-s406><set_up.anlegen><en> Please create and set a menu for the main navigation.
<G-vec00179-002-s407><set_up.anlegen><de> In jeder Runde legen die Spieler Preise für ihre Plättchen fest und binden so zunächst Kapital.
<G-vec00179-002-s407><set_up.anlegen><en> In each round players set the prices for their tiles and commit their own funds to them.
<G-vec00179-002-s408><set_up.anlegen><de> In Zusammenarbeit mit Ihrem Händler legen Sie den Aufbau des Berichts fest – zugeschnitten auf die Struktur und die Schwerpunktbereiche Ihres Unternehmens.
<G-vec00179-002-s408><set_up.anlegen><en> Hit your targets Working with your dealer, you set the structure of the report according to your organization’s framework and focus areas.
<G-vec00179-002-s409><set_up.anlegen><de> Dabei legen die Jungs ein Wahnsinns Tempo vor.
<G-vec00179-002-s409><set_up.anlegen><en> The guys set thereby a mind-blowing pace.
<G-vec00179-002-s410><set_up.anlegen><de> Innerbetrieblich und in der Beziehung zu unseren Kunden legen wir besonderen Wert auf ein ehrliches und verlässliches Miteinander.
<G-vec00179-002-s410><set_up.anlegen><en> Internally and in relation with our customers we set main value on honest and reliable cooperation.
<G-vec00179-002-s411><set_up.anlegen><de> Dabei legen wir besonderen Wert auf die fachliche und persönliche Betreuung und Umsetzung.
<G-vec00179-002-s411><set_up.anlegen><en> In doing so, we set great value on professional and individual consulting and implementation.
<G-vec00179-002-s412><set_up.anlegen><de> Die angebotenen Produkte sind gedacht für Konsumenten, die Wert auf das Außergewöhnliche legen.
<G-vec00179-002-s412><set_up.anlegen><en> The provided products are meant to customers who set a high value on the extraordinary.
<G-vec00179-002-s413><set_up.anlegen><de> Ein Muss für mobile DJs, die auf Hochzeiten oder dergleichen ihre Kunst darbieten und dabei auf eine kompakte, leicht zu transportierende und leuchtstarke Lichtanlage Wert legen.
<G-vec00179-002-s413><set_up.anlegen><en> A must-have for mobile DJs, who perform their art on weddings or as the case may be, and do set value on a compact, easily transported and highly luminous light set.
<G-vec00179-002-s414><set_up.anlegen><de> In der Nachhaltigkeitsstrategie legen Sie den geplanten Beitrag fest.
<G-vec00179-002-s414><set_up.anlegen><en> You set out your planned contribution in a sustainability strategy.
<G-vec00179-002-s415><set_up.anlegen><de> Die Prinzipien von SA 8000 legen ein explizites Managementsystem dar, sodass Sie die Arbeits- und Gesundheitsrisiken und -schwächen eines Unternehmens untersuchen und kontrollieren können.
<G-vec00179-002-s415><set_up.anlegen><en> The principles of SA 8000 set out an explicit management system so that you can examine and control an organisation’s occupational health risks and vulnerabilities.
<G-vec00179-002-s416><set_up.anlegen><de> Legen Sie Zeilen- und Absatzabstand auf der Registerkarte Einzüge und Abstände im Dialogfeld " Absatz " (Registerkarte "Start ").
<G-vec00179-002-s416><set_up.anlegen><en> You set line and paragraph spacing on the Indents and Spacing tab of the Paragraph dialog box (Home tab).
<G-vec00179-002-s417><set_up.anlegen><de> Wir legen Wert auf eine solide Geschäftsbasis und haben mit insgesamt 22 Ländern eine breite Länderabdeckung, die nicht nur in der deutschen Leasing-Branche ihresgleichen sucht, sondern auch in der Sparkassen-Finanzgruppe das breiteste Ländernetz darstellt.
<G-vec00179-002-s417><set_up.anlegen><en> We set great store by a solid business base, our broad international presence in 22 countries is unrivalled both in the German leasing industry and in the Sparkassen-Finanzgruppe.
