<G-vec00037-002-s019><write.aufschreiben><de> Um konzentriert zu bleiben, solltest du deine Ziele aufschreiben.
<G-vec00037-002-s019><write.aufschreiben><en> To stay focused, you need to write down your goals.
<G-vec00037-002-s020><write.aufschreiben><de> Sie müssen den Namen und das Passwort aufschreiben, und geben Sie Ihre E-Mail-Adresse.
<G-vec00037-002-s020><write.aufschreiben><en> You will need to write down the name and password, and provide your e-mail address.
<G-vec00037-002-s021><write.aufschreiben><de> Schießt dem Nutzer eine Frage durch den Kopf, kann er sie innerhalb weniger Augenblicke aufschreiben und direkt abschicken, anstatt sich einen freien Zeitslot für einen Telefontermin suchen zu müssen.
<G-vec00037-002-s021><write.aufschreiben><en> If the user has a question in his mind, he can write it down and send it directly within a few moments instead of having to find a free time slot for a telephone appointment.
<G-vec00037-002-s022><write.aufschreiben><de> Sie können eine Hotelbewertung aufschreiben, die auf dieser Webseite erscheinen wird, wenn Sie für Ihren Nogradgardony-Aufenthalt Ihr Zimmer über das Hotelstart-System reserviert haben und Gast irgendeines unserer Partnerhotels waren.
<G-vec00037-002-s022><write.aufschreiben><en> You can only write hotel reviews that will appear on this website if you have booked your Nogradgardony accommodation with HotelStart and have been the guest of one of our partner hotels.
<G-vec00037-002-s023><write.aufschreiben><de> Ich kann ihnen ein paar Sequenzen aufschreiben, wenn Sie wollen.
<G-vec00037-002-s023><write.aufschreiben><en> I can write down some sequences for you.
<G-vec00037-002-s024><write.aufschreiben><de> Wir sollten aufschreiben, wie wir Jesus zeigen wollen, dass wir ihn lieb haben.
<G-vec00037-002-s024><write.aufschreiben><en> We were supposed to write how we would show Jesus we love Him.
<G-vec00037-002-s025><write.aufschreiben><de> Sie können eine Hotelbewertung aufschreiben, die auf dieser Webseite erscheinen wird, wenn Sie für Ihren Balatonfüred-Aufenthalt Ihr Zimmer über das Hotelstart-System reserviert haben und Gast irgendeines unserer Partnerhotels waren.
<G-vec00037-002-s025><write.aufschreiben><en> You can only write hotel reviews that will appear on this website if you have booked your Balatonfured accommodation with HotelStart and have been the guest of one of our partner hotels.
<G-vec00037-002-s026><write.aufschreiben><de> Dafür brauchen Sie ein Maßband, Kugelschreiber und Zettel, auf dem Sie das Ergebnis der Messung aufschreiben können.
<G-vec00037-002-s026><write.aufschreiben><en> All you need is a measuring tape or some sort of string which you can place next to the ruler: a pen and paper to write down the data.
<G-vec00037-002-s027><write.aufschreiben><de> Auch an diesem Ort können Sie Erfahrungen mit der Krankheit, Gedanken, Sorgen, Bitten und Hoffnungen aufschreiben.
<G-vec00037-002-s027><write.aufschreiben><en> You can write down experiences concerning the illness, as well as your thoughts, concerns, prayers and hopes.
<G-vec00037-002-s028><write.aufschreiben><de> Wenn du Schwierigkeit hast, einen unlogischen Satz zu finden, kannst du auch ein Paradox aufschreiben.
<G-vec00037-002-s028><write.aufschreiben><en> If you have difficulty writing an illogical sentence, you can write a paradox.
<G-vec00037-002-s029><write.aufschreiben><de> Sie können eine Hotelbewertung aufschreiben, die auf dieser Webseite erscheinen wird, wenn Sie für Ihren Balatonszemes-Aufenthalt Ihr Zimmer über das Hotelstart-System reserviert haben und Gast irgendeines unserer Partnerhotels waren.
<G-vec00037-002-s029><write.aufschreiben><en> You can only write hotel reviews that will appear on this website if you have booked your Balatonszemes accommodation with HotelStart and have been the guest of one of our partner hotels.
<G-vec00037-002-s030><write.aufschreiben><de> Da es schwierig ist, sich an alle Passwörter zu erinnern, und Sie sie niemals aufschreiben sollten, könnte ein Passwortmanager helfen, Ihre Passwörter sicher zu verwalten.
<G-vec00037-002-s030><write.aufschreiben><en> Since it’s difficult to remember all your passwords and you should never write them down, consider using a password manager to securely manage all your passwords.
<G-vec00037-002-s031><write.aufschreiben><de> Es wäre zu lange, wenn ich alles Erlebte aufschreiben würde.
<G-vec00037-002-s031><write.aufschreiben><en> It would take too long to write down all… Read more
<G-vec00037-002-s032><write.aufschreiben><de> Du kannst Dich natürlich auch von einem erwachsenen, zum Beispiel von Deiner Mutti helfen lassen, die alles aufschreiben wird, was Du mir sagen möchtest.
<G-vec00037-002-s032><write.aufschreiben><en> You can of course use the help of an adult, for example your mum, who will write down everything you want to say to me.
<G-vec00037-002-s033><write.aufschreiben><de> Nun da du dein Hauptthema aufgeschrieben hast, kannst du die Unterthemen drum herum aufschreiben.
<G-vec00037-002-s033><write.aufschreiben><en> Now that you've written your main topic, you can write down the subtopics around it.
<G-vec00037-002-s034><write.aufschreiben><de> Sie können eine Hotelbewertung aufschreiben, die auf dieser Webseite erscheinen wird, wenn Sie für Ihren Garabonc-Aufenthalt Ihr Zimmer über das Hotelstart-System reserviert haben und Gast irgendeines unserer Partnerhotels waren.
<G-vec00037-002-s034><write.aufschreiben><en> You can only write hotel reviews that will appear on this website if you have booked your Garabonc accommodation with HotelStart and have been the guest of one of our partner hotels.
<G-vec00037-002-s035><write.aufschreiben><de> Wer in Berlin unterwegs ist, sollte die Begleitservice Berlin Nummer aufschreiben.
<G-vec00037-002-s035><write.aufschreiben><en> Anyone traveling in Berlin, the escort service Berlin should write number.
<G-vec00037-002-s036><write.aufschreiben><de> Wow, dachte ich, das ist so gut, das vergesse ich nie mehr, das kann ich später aufschreiben.
<G-vec00037-002-s036><write.aufschreiben><en> Wow, I thought, that is so good I'll never forget it, so I'll write it down later.
<G-vec00037-002-s037><write.aufschreiben><de> Sie können eine Hotelbewertung aufschreiben, die auf dieser Webseite erscheinen wird, wenn Sie für Ihren Miskolc-Aufenthalt Ihr Zimmer über das Hotelstart-System reserviert haben und Gast irgendeines unserer Partnerhotels waren.
<G-vec00037-002-s037><write.aufschreiben><en> You can only write hotel reviews that will appear on this website if you have booked your Miskolc accommodation with HotelStart and have been the guest of one of our partner hotels.
<G-vec00037-002-s038><write.aufschreiben><de> Versuchen Sie nicht, Ihr Passwort irgendwo aufzuschreiben und es mit irgendjemandem zu teilen.
<G-vec00037-002-s038><write.aufschreiben><en> Don’t attempt to write your password any place and share it with anybody.
<G-vec00037-002-s039><write.aufschreiben><de> Das einzige, was er finden konnte, war eine Serviette, also rief er seine Mutter an, um die Zahlen aufzuschreiben, damit er sie später spielen konnte.
<G-vec00037-002-s039><write.aufschreiben><en> The only thing that he could find was a napkin, so he called his mother to write down the numbers so that he could play them later.
<G-vec00037-002-s040><write.aufschreiben><de> Ich selbst erhielt mit neun Jahren meine erste Klavierstunde am Privatmusiklehrer-Seminar von Dr. Hoch’s Konservatorium, und nachdem ich die Notenschrift beherrschte – ich kann mich nicht erinnern, sie „erlernt“ zu haben – begann ich auch schon, innerlich Gehörtes aufzuschreiben.
<G-vec00037-002-s040><write.aufschreiben><en> I myself had my first piano lessons at age nine at the private music teacher’s seminar of Dr. Hoch’s Conservatory, and as soon as I had mastered musical notation – I cannot remember having “learned” it – I began to write down what I heard in my head.
<G-vec00037-002-s041><write.aufschreiben><de> Dass viele, viele von Ihnen den Mut finden, sich hinzusetzen und einen Artikel, eine Beobachtung, eine Geschichte oder einen Gedanken für uns aufzuschreiben.
<G-vec00037-002-s041><write.aufschreiben><en> That many, many of you find the courage to sit down to write an article, an observation, a story or a thought for us.
<G-vec00037-002-s042><write.aufschreiben><de> Es ist sehr wichtig für die Sahaja Yogis, sich hinzusetzen und aufzuschreiben, was die Welt braucht, und was getan werden muss.
<G-vec00037-002-s042><write.aufschreiben><en> It’s very important for Sahaja yogis to sit down and write down what the world needs, and what is to be done.
<G-vec00037-002-s043><write.aufschreiben><de> Zum Entstehungsprozess bemerkt der Komponist: „Es war wie eine blitzartige Vision - so ist das Ganze sofort vor meinen Augen gestanden und ich habe es nur aufzuschreiben gebraucht, so, als ob es mir diktiert worden wäre.“[1] Die Idee, einen mittelalterlichen Hymnus als Vorlage für die neue Sinfonie zu nehmen, kam Mahler in seinem Feriendomizil in Maiernigg am Wörthersee, wo ihm ein katholisches Messbuch in die Hände fiel.
<G-vec00037-002-s043><write.aufschreiben><en> He told Specht that having chanced on the Veni creator hymn, he had a sudden vision of the complete work: "I saw the whole piece immediately before my eyes, and only needed to write it down as though it were being dictated to me."[12]
<G-vec00037-002-s044><write.aufschreiben><de> Aus diesem Grund entwickelte die Kommunalverwaltung das „Wohnungs-Entscheidungs-Toolkit“ für ältere Menschen, ein Schritt-für-Schritt-Ratgeber, der den Betroffenen dabei hilft, das Pro und Kontra der für sie verfügbaren Möglichkeiten aufzuschreiben und gegeneinander abzuwägen.
<G-vec00037-002-s044><write.aufschreiben><en> As a result, the local government developed the Housing Decision ToolKit for Older People, a step-by-step guide that helps residents write and review the pros and cons of the options available to them.
<G-vec00037-002-s045><write.aufschreiben><de> In BSC Designer verwenden Sie Initiativen (vielleicht sollten Sie sie auf der Karte ausblenden), um Ihre Erwartungen an KPIs aufzuschreiben.
<G-vec00037-002-s045><write.aufschreiben><en> In BSC Designer: use Initiatives (you might want to make it invisible on the map) to write down your expectations about KPIs.
<G-vec00037-002-s046><write.aufschreiben><de> Zu diesem Anlass wurde der rotarische Autor David Forward beauftragt, eine Geschichte der Foundation aufzuschreiben.
<G-vec00037-002-s046><write.aufschreiben><en> To commemorate this momentous occasion, we commissioned Rotary member and author David Forward to write the definitive history of our Foundation.
<G-vec00037-002-s047><write.aufschreiben><de> Es macht Spaß seine Gedanken aufzuschreiben und öffentlich los zu werden, Ideen zu teilen oder "Inspirationsquelle" zu sein.
<G-vec00037-002-s047><write.aufschreiben><en> It's fun to write down my thoughts and to get rid of public, to share ideas or inspiration.
<G-vec00037-002-s048><write.aufschreiben><de> In den ganz frühen Tagen des Islam lag die Betonung auf dem auswendig lernen, bald jedoch haben diejenigen, die des Lesens und Schreibens mächtig waren, angefangen, die Worte des Qur´an auf allem, was möglich war, aufzuschreiben.
<G-vec00037-002-s048><write.aufschreiben><en> In the very early days of Islam the emphasis was on memorization, however soon, those who had mastered the art of reading and writing began to write down the words of Quran on whatever writing material available.
<G-vec00037-002-s049><write.aufschreiben><de> Ich habe dann begonnen, meine Erinnerungen und die meiner Kolleginnen und Kollegen aufzuschreiben.
<G-vec00037-002-s049><write.aufschreiben><en> I started to write down my memories and memories of my friends.
<G-vec00037-002-s050><write.aufschreiben><de> Denke daran, lobende und ermutigende Worte aufzuschreiben.
<G-vec00037-002-s050><write.aufschreiben><en> Remember to write words of encouragement and celebration.
<G-vec00037-002-s051><write.aufschreiben><de> Sobald sich die Geschwornen etwas von dem Schreck erholt hatten, umgeworfen worden zu sein, und nachdem ihre Tafeln und Tafelsteine gefunden und ihnen zurückgegeben worden waren, machten sie sich eifrig daran, die Geschichte ihres Unfalles aufzuschreiben, alle außer der Eidechse, welche zu angegriffen war, um etwas zu thun; sie saß nur mit offnem Maule da und starrte die Saaldecke „Nichts!“ sagte Alice.
<G-vec00037-002-s051><write.aufschreiben><en> As soon as the jury had a little recovered from the shock of being upset, and their slates and pencils had been found and handed back to them, they set to work very diligently to write out a history of the accident, all except the Lizard, who seemed too much overcome to do anything but sit with its mouth open, gazing up into the roof of the court.
<G-vec00037-002-s052><write.aufschreiben><de> Sobald sich die Geschwornen etwas von dem Schreck erholt hatten, umgeworfen worden zu sein, und nachdem ihre Tafeln und Tafelsteine gefunden und ihnen zurückgegeben worden waren, machten sie sich eifrig daran, die Geschichte ihres Unfalles aufzuschreiben, alle außer der Eidechse, welche zu angegriffen war, um etwas zu thun; sie saß nur mit offnem Maule da und starrte die Saaldecke an.
<G-vec00037-002-s052><write.aufschreiben><en> As soon as the jury had a little recovered from the shock of being upset, and their slates and pencils had been found and handed back to them, they set to work very diligently to write out a history of the accident, all except the Lizard, who seemed too much overcome to do anything but sit with its mouth open, gazing up into the roof of the court.
<G-vec00037-002-s053><write.aufschreiben><de> Es kann sicherer sein, deine Passwörter an einem sicheren Ort aufzuschreiben, als überall das gleiche zu benutzen.
<G-vec00037-002-s053><write.aufschreiben><en> Also, it can be better to write down your passwords in a secure place rather than use the same one everywhere.
<G-vec00037-002-s054><write.aufschreiben><de> Zu Beginn werden die Teilnehmer aufgefordert, Ihre individuellen Themen aufzuschreiben, für die sie sich an dem Tag verantwortlich erklären.
<G-vec00037-002-s054><write.aufschreiben><en> Initially, the participants are asked to write down their individual topics for which they agree to be responsible for that day.
<G-vec00037-002-s055><write.aufschreiben><de> Der Kunde sieht sich oft in Zeitnot und hat schon genug Zeit investiert, seine Lösung aufzuschreiben.
<G-vec00037-002-s055><write.aufschreiben><en> The client is often pressed for time, already having invested enough time to write down their solution.
<G-vec00037-002-s056><write.aufschreiben><de> Ein gutes System ist kurzfristige, mittelfristige und langfristige Ziele aufzuschreiben.
<G-vec00037-002-s056><write.aufschreiben><en> A good system is to write short, medium, and long-term goals.
