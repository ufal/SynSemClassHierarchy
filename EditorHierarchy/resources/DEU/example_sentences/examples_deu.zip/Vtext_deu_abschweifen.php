<G-vec00227-002-s212><wander.abschweifen><de> Vielleicht schweifen Deine Gedanken ab, dann wirst Du es irgendwann bemerken und OHNE DICH DAFÜR ZU VERURTEILEN zu dem METTA Gedanken zurückkehren.
<G-vec00227-002-s212><wander.abschweifen><en> Maybe your thoughts wander, then you will notice it sometime and WITHOUT YOU TO PAY FOR thoughts return to the Metta.
<G-vec00227-002-s213><wander.abschweifen><de> Basieren sie doch alle auf dem menschlichen Körper und seinen Möglichkeiten sich auszudrücken…meine Gedanken schweifen ab… und werden durch das intensive Atemgeräusch zurückgeholt: Das Paar tanzt nebeneinander.
<G-vec00227-002-s213><wander.abschweifen><en> They are, after all, all based on the human body and the ways it expresses itself … my thoughts wander … and are then brought back by the intense sound of breathing as the couple dance next to each other, separately.
<G-vec00849-002-s033><deviate.abschweifen><de> Herr, lasse unsere Herzen nicht abschweifen, nachdem Du uns rechtgeleitet hast, und schenke uns Erbarmen von Dir aus.
<G-vec00849-002-s033><deviate.abschweifen><en> [Who say], "Our Lord, let not our hearts deviate after You have guided us and grant us from Yourself mercy.
<G-vec00849-002-s167><deviate.abschweifen><de> Sollten Ihre Gedanken davon abschweifen, stoppen Sie mit dieser Übung, atmen tief durch und beginnen wieder von vorn.
<G-vec00849-002-s167><deviate.abschweifen><en> If your thoughts deviate from the subject, stop the exercise, take a deep breath and try again.
<G-vec00849-002-s206><deviate.abschweifen><de> Dieses Smartphone hat mir schon von Anfang an sehr gefallen, obwohl die Mehrheit der Parameter schien, vom Hauptmarkttrend abzuschweifen.
<G-vec00849-002-s206><deviate.abschweifen><en> This smartphone was to my liking from the very beginning, though the majority of parameters seems to deviate from the main market trend.
<G-vec00849-002-s031><stray.abschweifen><de> Die Lampen strahlen ein sehr weiches Licht aus, sodass Sie mit Ihren Gedanken regelmäßig abschweifen werden, während Sie diese Lampe betrachten und das einzigartige Kunsthandwerk bewundern, das diese Tischlampe ausmacht.
<G-vec00849-002-s031><stray.abschweifen><en> The lamps emit a very soft light so that your eyes will regularly stray while you look directly at the lamp to enjoy this unique piece of craftsmanship with which these table lamps are made.
