<G-vec00486-002-s020><postpone.absagen><de> Leider müssen wir alle für dieses Semester geplanten Veranstaltungen, Länderabende und Exkursionen absagen.
<G-vec00486-002-s020><postpone.absagen><en> Due to the spread of the Coronavirus SARS-CoV-2 we are forced to cancel or postpone our events which were planned for this semester.
<G-vec00198-002-s122><cancel.absagen><de> Der Veranstalter behält sich das Recht vor, bei Absage eines Trainers aus welchem Grund auch immer einen Ersatz zu organisieren.
<G-vec00198-002-s122><cancel.absagen><en> Should a teacher cancel for whatever reason, the event organizer reserves the right to find a replacement teacher.
<G-vec00198-002-s123><cancel.absagen><de> Wenn ich krank werde und absage, dann sind noch viel mehr Leute enttäuscht.
<G-vec00198-002-s123><cancel.absagen><en> If I get sick and have to cancel, then even more people are disappointed.
<G-vec00198-002-s124><cancel.absagen><de> - Bei Absage einer festen Buchung wird die Caparra-Zahlung immer als Stornogebühr rückbehalten.
<G-vec00198-002-s124><cancel.absagen><en> - If you cancel your confirmed booking, the Caparra payment is always retained as a cancellation fee.
<G-vec00198-002-s125><cancel.absagen><de> ■ Bei einer Absage innerhalb der letzten Woche vor Anreise stellen wir Ihnen 90% des Reisepreises in Rechnung, bei vorzeitiger Abreise 100%.
<G-vec00198-002-s125><cancel.absagen><en> ■ When you cancel during the last week before you arrive we will invoice you 90 % of the cost of your booking, on early departure 100%.
<G-vec00198-002-s126><cancel.absagen><de> Wir behalten uns eine kurzfristige Absage bei zu geringer Teilnehmerzahl vor.
<G-vec00198-002-s126><cancel.absagen><en> We reserve the right to cancel at short notice in the event of insufficient participants.
<G-vec00198-002-s127><cancel.absagen><de> Wenn Sie Fragen zur Verwendung von "Absage in letzter Minute" haben, gehen Sie zu "Häufig gestellte Fragen (FAQs) zu dieser Karte" zur Erläuterung der Verwendung.
<G-vec00198-002-s127><cancel.absagen><en> If you have any questions regarding how to use "Last Minute Cancel," go to "FAQs Related To This Card" for clarification on its usage.
<G-vec00198-002-s128><cancel.absagen><de> Das Zukunftsforum könnte nicht in der gewohnten Qualität und Lebendigkeit stattfinden, daher haben wir uns zur Absage entschlossen.
<G-vec00198-002-s128><cancel.absagen><en> The Future Forum wouldn´t have the quality and vitality expected, so we have decided to cancel!
<G-vec00198-002-s129><cancel.absagen><de> Bei einer Absage innerhalb der letzten 7 Tage vor Urlaubsantritt, bei Nichtanreise, verspäteter Anreise oder vorzeitiger Abreise wird die Gesamtsumme für die gesamte gebuchte Zeit in Rechnung gestellt.
<G-vec00198-002-s129><cancel.absagen><en> Should you cancel within the last 7 days before holiday start, or in case of non-arrival, late arrival or early departure, we will charge you the total amount for the entire stay period you booked
<G-vec00198-002-s130><cancel.absagen><de> Bei Absage von mehr als 4 Wochen vor dem Anreisetermin fallen keine Gebühren an.
<G-vec00198-002-s130><cancel.absagen><en> If you cancel more than 4 weeks before the arrival date are no room charges.
<G-vec00198-002-s131><cancel.absagen><de> Von Ihren Kunden genutzte Gutscheine berechnen wir auch im Falle der Absage Ihrer Messebeteiligung.
<G-vec00198-002-s131><cancel.absagen><en> We will also charge vouchers that your clients used in case you cancel your participation How to manage redeemed vouchers
<G-vec00198-002-s132><cancel.absagen><de> Bei einer Absage oder Verschiebung des Termins für die eine Vorauszahlung in Form eines Gutscheines getätigt wurde, gelten dieselben Bedingungen, d.h. der Gutscheinwert wird entsprechend gemindert.
<G-vec00198-002-s132><cancel.absagen><en> The same conditions apply if a voucher has been used to pay in advance for an appointment that you then cancel or postpone, i.e. the value of the voucher will be reduces accordingly. Meeting your needs
<G-vec00198-002-s133><cancel.absagen><de> Sie können Meetings direkt über eine Kontaktseite in Salesforce planen, aktualisieren, absagen und starten.
<G-vec00198-002-s133><cancel.absagen><en> You can schedule, update, cancel and start meetings directly from a contact page in Salesforce.
<G-vec00198-002-s134><cancel.absagen><de> Bei Vorliegen höherer Gewalt oder Umständen, welche die Durchführung verunmöglichen, erheblich erschweren oder gefährden, kann RailAway AG die Reise absagen.
<G-vec00198-002-s134><cancel.absagen><en> RailAway AG may cancel the charter booking in the event of force majeure or circumstances making it impossible, very difficult or dangerous to complete the trip.
<G-vec00198-002-s135><cancel.absagen><de> Da mussten wir den Rest der Tour absagen.
<G-vec00198-002-s135><cancel.absagen><en> We had to cancel the rest of the tour.
<G-vec00198-002-s136><cancel.absagen><de> Liegen bis 14 Tage vor Trainingsbeginn nicht genügend verbindliche Anmeldungen vor, kann LOYTEC das Training absagen.
<G-vec00198-002-s136><cancel.absagen><en> If there are not enough registrations received 14 days before the start of the training, LOYTEC can cancel the training.
<G-vec00198-002-s137><cancel.absagen><de> Sollten Sie absagen wollen, bitte lassen Sie es uns baldmöglichst wissen, da es eine 300 Euro Gebühr für verspätete Absagte gibt (weniger als 5 Stunden vor dem Date).
<G-vec00198-002-s137><cancel.absagen><en> If you wish to cancel, please let us know as soon as possible because there is a fine of 300 euros for late cancellations (less than five hours before the appointment).
<G-vec00198-002-s138><cancel.absagen><de> Auch als Forschende erleben wir derzeit einen Wandel in China: Während wir vor ein paar Jahren noch mit einem gewissen Optimismus in die Zukunft sahen, was eine wachsende Meinungsfreiheit angeht, so erleben eine Reihe von Kolleginnen und Kollegen nun, dass ihnen die Archive vor der Nase zugemacht werden, Feldforschung unmöglich wird und Interviewpartnerinnen und -partner aus Angst Termine absagen.
<G-vec00198-002-s138><cancel.absagen><en> Even as researchers we are currently experiencing a change in China: although just a few years ago we looked to the future with a certain optimism as regards a growing freedom of opinion, a number of colleagues are now finding that archives are shut in their face, field research is becoming impossible, and interview partners cancel appointments out of fear.
<G-vec00198-002-s139><cancel.absagen><de> Falls Sie einmal absagen müssen, tun Sie das bitte 48 Stunden vorher.
<G-vec00198-002-s139><cancel.absagen><en> If you ever need to cancel an appointment, I ask you to do so with 48 hours notice.
<G-vec00198-002-s140><cancel.absagen><de> Sie können Ihre Reservation bis 7 Tage vor der Abgabe ohne Stormierungsgebühren absagen.
<G-vec00198-002-s140><cancel.absagen><en> You can cancel your reservations 7 days before the pick up date and in that case there is no cancellation fee.
<G-vec00198-002-s141><cancel.absagen><de> Unter normalen Umständen würdest du deiner Freundin absagen und sie auf einen anderen Tag vertrösten.
<G-vec00198-002-s141><cancel.absagen><en> Under normal circumstances, you’d cancel your girlfriend and you on a different day stall.
<G-vec00198-002-s142><cancel.absagen><de> Sie können einige oder alle Sitzungen eines Webinars jederzeit absagen.
<G-vec00198-002-s142><cancel.absagen><en> You can cancel some or all sessions in a webinar at any time.
<G-vec00198-002-s143><cancel.absagen><de> Aufgrund von Gesundheitsproblemen musste ich meine Reise nach London, wo ich meine Tochter Maya besuchen wollte, absagen und deshalb auch meine Reise nach Berlin.
<G-vec00198-002-s143><cancel.absagen><en> Due to health reasons I had to cancel my trip to London to visit my daughter, Maya, and subsequently, Berlin.
<G-vec00198-002-s144><cancel.absagen><de> Eine Woche vorher musste ich die Bandprobe absagen.
<G-vec00198-002-s144><cancel.absagen><en> A week before, I’d had to cancel band practice.
<G-vec00198-002-s145><cancel.absagen><de> Können die Bergbahnen ihren Betrieb wegen Sturm definitiv nicht aufrechterhalten, müssen wir die Übernachtung absagen.
<G-vec00198-002-s145><cancel.absagen><en> If the lifts are unable to run due to a storm then we have to cancel your booking.
<G-vec00198-002-s146><cancel.absagen><de> Daher muss er auf Anraten seines Meisters seine Auslandsreisen absagen.
<G-vec00198-002-s146><cancel.absagen><en> Now aged 93, and on the advice of his Master, he regrets that he has to cancel his overseas tours for the time being.
<G-vec00198-002-s147><cancel.absagen><de> Wird die Mindestteilnehmerzahl des Gruppenkurses unterschritten, darf unser Institut wegen der erhöhten Effektivität des Kurses die Wochenstundenzahl reduzieren oder den betreffenden Kurs insgesamt absagen.
<G-vec00198-002-s147><cancel.absagen><en> If a class does not have the minimum number of participants required, our institution may reduce the number of lessons per week or cancel the course all together.
<G-vec00198-002-s148><cancel.absagen><de> Absagen von Veranstaltungen Sie können eine zuvor erstellte Veranstaltung absagen und den Teilnehmern eine E-Mail-Benachrichtigung über die Absage senden.
<G-vec00198-002-s148><cancel.absagen><en> Cancel events You can cancel an event that you previously created and send participants an email informing them about the cancelation.
<G-vec00198-002-s150><cancel.absagen><de> Wenn Sie vor 7 Tagen absagen, erhalten Sie die Kaution zurück.
<G-vec00198-002-s150><cancel.absagen><en> If you cancel before 7 days, we’ll return the deposit.
<G-vec00198-002-s151><cancel.absagen><de> Die Festivals der britischen Inseln wurden vom schlechten Wetter stark beeinträchtigt - die traurigste Angelegenheit dort wurde die Continental Ceilidh in Schottland, bei der das Wetter und die niedrigen Besucherzahlen zu Absagen von Konzerten führen musste.
<G-vec00198-002-s151><cancel.absagen><en> Crossing over to the British Isles, the bad weather has been a problem for several festivals - the sadest affair was the Continental Ceilidh in Scotland, that suffered that much that the organisers had to cancel some concerts.
<G-vec00198-002-s183><cancel.absagen><de> Aufgrund der durch den Taifun verursachten Lage war im Vorfeld überlegt worden, die Veranstaltung kurzfristig noch abzusagen.
<G-vec00198-002-s183><cancel.absagen><en> Due to the situation caused by the typhoon, it was considered in advance to cancel at short notice the event.
<G-vec00198-002-s184><cancel.absagen><de> Nach sehr langem und intensivem Ringen mit der öffentlichen Meinung und trotz der rechtlichen Unbedenklichkeit, die dem RMV von Ordnungsamt, Polizei und dem Verfassungsschutz bestätigt wurde, wurden wir gezwungen den Auftritt von PESTE NOIRE abzusagen.
<G-vec00198-002-s184><cancel.absagen><en> After a long and intense night with the public opinion and despite the fact that there is nothing unlawful going on, as connfirmed to the RMV by the offce of public order, the police and the Federal Offce for the Protection of the Constitution, we are forced to cancel the appearance of Peste Noire because of the public’s demand.
<G-vec00198-002-s185><cancel.absagen><de> Wir behalten uns vor den Kurs kurzfristig abzusagen, sollten sich nicht genügend Teilnehmer anmelden.
<G-vec00198-002-s185><cancel.absagen><en> We reserve the right to cancel the course at short notice if there are not enough participants registered.
<G-vec00198-002-s186><cancel.absagen><de> Um eine Verbreitung dieser sehr ansteckenden Infektionskrankheit zu vermeiden sehen wir uns gezwungen, die June Show abzusagen.
<G-vec00198-002-s186><cancel.absagen><en> To prevent the spread of this highly contagious infectious disease we are forced to cancel the June show.
<G-vec00198-002-s187><cancel.absagen><de> Sollte diese bis 4 Wochen vor Beginn des Kurses nicht erreicht sein, behalten wir uns vor, den Kurs abzusagen.
<G-vec00198-002-s187><cancel.absagen><en> Should this minimum not be reached up to 4 weeks before the start of the workshop, we reserve the right to cancel the course.
<G-vec00198-002-s188><cancel.absagen><de> Zeiträume für Familie im Voraus festzulegen wird es schwer machen, in letzter Minute abzusagen und hilft dabei, diese Zeit felsenfest zu bestimmen.
<G-vec00198-002-s188><cancel.absagen><en> Scheduling this time with family in advance will make it hard to cancel at the last minute and helps set that time in stone.
<G-vec00198-002-s189><cancel.absagen><de> Die Elternvereinigung behält sich das Recht vor, einen Kurs deswegen abzusagen.
<G-vec00198-002-s189><cancel.absagen><en> The Parents Association reserves the right to cancel a course should this number not be achieved.
<G-vec00198-002-s190><cancel.absagen><de> Wir bitten Sie daher, Termine im Falle einer Verhinderung mindestens 6 Stunden vorher abzusagen.
<G-vec00198-002-s190><cancel.absagen><en> We would therefore ask that in the event of any inability to attend that you cancel at least 6 hours beforehand.
<G-vec00198-002-s191><cancel.absagen><de> Der Anbieter hält sich das Recht vor, die Tour je nach Wetterbedingungen zu ändern oder abzusagen.
<G-vec00198-002-s191><cancel.absagen><en> The company reserves the right to amend or cancel the tour depending on weather conditions.
<G-vec00198-002-s192><cancel.absagen><de> Der Veranstalter hat das Recht eine Veranstaltung aufgrund zu geringer Ausstellerbeteiligung abzusagen.
<G-vec00198-002-s192><cancel.absagen><en> The organizer has the right to cancel an event due to low number of exhibitors.
<G-vec00198-002-s193><cancel.absagen><de> Angeblich drohte Hitler, die Olympischen Spiele abzusagen.
<G-vec00198-002-s193><cancel.absagen><en> Allegedly Hitler threatened to cancel the Olympic Games.
<G-vec00198-002-s194><cancel.absagen><de> Cosa Travel ist berechtigt, Ihre Reise abzusagen, wenn Sie durch Handlungen oder Unterlassungen dazu berechtigten Anlass geben.
<G-vec00198-002-s194><cancel.absagen><en> Cosa Travel is entitled to cancel your trip if you give justified reason through acts or omissions.
<G-vec00198-002-s195><cancel.absagen><de> Da der Beschwerdegegner eine mündliche Verhandlung nur für den Fall beantragt hatte, daß die Beschwerde nicht aufgrund der Schriftsätze der Beteiligten zurückgewiesen werden könne, wäre die Kammer dann in der Lage gewesen, die mündliche Verhandlung abzusagen.
<G-vec00198-002-s195><cancel.absagen><en> Since the respondent had requested oral proceedings only in case a decision to dismiss the appeal could not be made having regard to the written submissions of the parties, the board would then have been able to cancel the oral proceedings.
<G-vec00198-002-s196><cancel.absagen><de> > INTERSPIRO behält sich das Recht vor nicht besetzte Seminare oder Seminare aus wichtigem Grunde abzusagen.
<G-vec00198-002-s196><cancel.absagen><en> > INTERSPIRO reserves the right to cancel seminars which are not occupied or seminars for important reasons.
<G-vec00198-002-s197><cancel.absagen><de> Im Falle, dass einer oder mehrere Teilnehmer die oben genannten Anforderungen nicht erfüllen, behält sich der Führer aus Sicherheitsgründen das Recht vor, die Tour jederzeit abzusagen oder zu unterbrechen.
<G-vec00198-002-s197><cancel.absagen><en> In the event that one or more participants do not comply with the above mentioned requirements, the guide - for safety reasons - reserves the right to cancel or interrupt the tour at any time.
<G-vec00198-002-s198><cancel.absagen><de> Sollte eine derartige Preiserhöhung 10% übersteigen, ist der Kunde berechtigt, die Reise/Veranstaltung abzusagen, ohne dass ihm dafür eine Stornierungsgebühr entsteht, vorausgesetzt, die Absage erfolgt schriftlich und geht innerhalb von 8 Tagen nachdem wir die Preiserhöhung bekanntgegeben haben bei uns ein.
<G-vec00198-002-s198><cancel.absagen><en> Should this price increase exceed the10% threshold than the customer has the right to cancel the tour/event without any obligation to pay a cancellation charge, provided this is done in writing and within 8 days after our price increase announcement.
<G-vec00198-002-s199><cancel.absagen><de> Unter Berücksichtigung des Rechts Ihnen die Profilprüfung zu verweigern und/oder diese im Falle von Nichtübereinstimmungen abzusagen, sowie unter Berücksichtigung der Veröffentlichung von uns aller entsprechenden Daten, stellt sich die Aktualität des Zustands der Glaubwürdigkeit Ihres Benutzerkontos nach Ablauf einiger Zeit nach der Profilprüfung — als Gegenstand zur angemessenen Sorge für Sie und Ihre Partner dar.
<G-vec00198-002-s199><cancel.absagen><en> Taking into account our right to deny you the Profile verification and/or to cancel it in case of detection of any discrepancies and also with due regard for our notifications of all the corresponding dates, the actuality of your account status some time after the expiration of your Profile verification is the subject of reasonable concern for you and your counterparties.
<G-vec00198-002-s200><cancel.absagen><de> Es fiel uns nicht leicht, die Messe abzusagen, doch die Gesundheit und der Schutz unserer Mitarbeiter, Kunden, Lieferanten und deren Angehörigen hat oberste Priorität und liegt uns sehr am Herzen.
<G-vec00198-002-s200><cancel.absagen><en> It was not easy for us to cancel the exhibition, but the health and protection of our employees, customers, suppliers and their families is our top priority and is very close to our hearts.
<G-vec00198-002-s201><cancel.absagen><de> Wir bitten alle, die Besucher*innen aus Risikogebieten erwarten, den Gastaufenthalt abzusagen.
<G-vec00198-002-s201><cancel.absagen><en> We kindly ask everyone expecting visitors from risk areas to cancel those stays.
<G-vec00942-002-s024><forsake.absagen><de> Jesus sagt zu ihm: "Freund, du stimmst meinem Wort über die Notwendigkeit, deine Sünde zu bekennen und ihr abzusagen, zu.
<G-vec00942-002-s024><forsake.absagen><en> Jesus says to him, "Friend, you agreed with my word about the need to confess and forsake your sins.
<G-vec00942-002-s026><renounce.absagen><de> Und wenn dieser Bruder nicht bereit ist, auf die Brüder oder die Gemeinde zu hören und der Sünde abzusagen, dann sei er uns "wie ein Heide und Zöllner".
<G-vec00942-002-s026><renounce.absagen><en> And if this brother is not prepared to listen to the church and renounce his sin, then he should be to us "as a Gentile and a tax collector".
