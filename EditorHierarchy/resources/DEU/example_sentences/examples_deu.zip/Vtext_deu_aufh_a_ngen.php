<G-vec00081-001-s036><suspend.aufhängen><de> Beschreibung Set mit zwei speziellen Befestigungsgurten zum Aufhängen von Hängematten.
<G-vec00081-001-s036><suspend.aufhängen><en> Description Set with two special fixing belts to suspend hammocks.
<G-vec00081-001-s037><suspend.aufhängen><de> Wir werden dorthin bekommen tworoschnuju die Masse ausgießen., Nachdem die Molke abgeflossen ist, werden wir den Mull fest zubinden und werden wir über der Muschel aufhängen, damit die Reste abflossen.
<G-vec00081-001-s037><suspend.aufhängen><en> After serum flew down, we will strong tie a gauze and we will suspend over a sink that the remains flew down.
<G-vec00081-001-s038><suspend.aufhängen><de> Noch versicherten sie mich, was es, die Decke aufhängen und ohne Hilfe von den Fachkräften kann.
<G-vec00081-001-s038><suspend.aufhängen><en> Still they assured me what to suspend a ceiling it is possible and without the aid of experts.
<G-vec00081-001-s039><suspend.aufhängen><de> Wenn Sie von ihnen die Nachkommenschaft bekommen wollen, muss man im März-April (der Periode der Paarung) zu sadku das hölzerne Häuschen mit der Öffnung aufhängen und, in ihn ein wenig Heus legen.
<G-vec00081-001-s039><suspend.aufhängen><en> If you want to receive from them posterity, in March-April (the pairing period) it is necessary to suspend to a cage a wooden lodge with an opening and to put in it a little hay.
<G-vec00081-001-s040><suspend.aufhängen><de> Die fertigen Rahmen von den Händen am Tag Heiligen Walentin kann man auf den Tisch stellen oder, auf die Wand aufhängen.
<G-vec00081-001-s040><suspend.aufhängen><en> Ready framework the hands for St. Valentine's Day can be put on a table or to suspend on a wall.
<G-vec00081-001-s041><suspend.aufhängen><de> Die Äpfel kann man und in die festen Plastiktüten auf 3 kg einpacken, und dann, vom Spagat zubinden und, aufhängen.
<G-vec00081-001-s041><suspend.aufhängen><en> Apples can be packed and into strong plastic bags on 3 kg, and then to stick a twine and to suspend.
<G-vec00081-001-s042><suspend.aufhängen><de> Mit den enthaltenen 2 m Stahlseilen können Sie die JBL LED Leuchten überall so aufhängen, wie Sie es möchten.
<G-vec00081-001-s042><suspend.aufhängen><en> With the enclosed 2 m long steel cords you can suspend the JBL LED lights any way you want.
<G-vec00081-001-s053><suspend.aufhängen><de> "Man muss die dicke und fettige saure Sahne nehmen (solche, damit ""der Löffel stand»), sie in dicht cholschtschowyj den Sack oder den die etwas Schichten zusammengelegten Mull zu gießen und, für die Nacht aufzuhängen, die Kapazität für das Abfließen der Flüssigkeit ersetzt."
<G-vec00081-001-s053><suspend.aufhängen><en> "It is necessary to take dense and fat sour cream (such that ""the spoon stood""), to pour it in a dense linen bag or the gauze put in some layers and to suspend for the night, having substituted capacity for liquid running off."
<G-vec00081-001-s054><suspend.aufhängen><de> Aber wenn Sie den ebenen Fußboden haben wollen, so ist es vollkommen möglich, sie zur an der Decke gefestigten Richtenden aufzuhängen.
<G-vec00081-001-s054><suspend.aufhängen><en> But if you wish to have an equal floor quite probably to suspend it to the directing fixed on a ceiling.
<G-vec00081-001-s055><suspend.aufhängen><de> die Kleinen Erzeugnisse, zum Beispiel, die hölzernen Griffe, kann man einfach auf etwas Sekunden in die Dose mit dem Nitrolack senken, dann, herausnehmen, geben den Überschüssen des Lackes abzufließen und, zu legen oder, das Erzeugnis auf prossuschku aufzuhängen.
<G-vec00081-001-s055><suspend.aufhängen><en> Small products, for example wooden handles, it is possible to lower simply for some seconds in bank with a nitrovarnish, then to take out, allow to surpluses of a varnish to flow down and put or suspend a product on drying.
<G-vec00081-001-s056><suspend.aufhängen><de> Aufzuhängen, oder, ausziehbar zu machen, es ist ein beliebiges Türleinen, die Ausnahme - die Tür mit dem Oberteil in Form vom Bogen möglich.
<G-vec00081-001-s056><suspend.aufhängen><en> To suspend, or to make sliding, any door cloth, an exception - a door with top in the form of an arch is possible.
<G-vec00486-002-s040><suspend.aufhängen><de> Mit dieser Schnur kannst du das gesamte Windspiel aufhängen, wenn du sie lang genug machst.
<G-vec00486-002-s040><suspend.aufhängen><en> This thread, if you chose to make it long enough, can be used to suspend the entire chime.
<G-vec00486-002-s041><suspend.aufhängen><de> “Während es ein Verfahren gibt, um die Bänder zu schneiden, die den Penis aufhängen, liefert diese Operation nur eine Illusion von Länge.
<G-vec00486-002-s041><suspend.aufhängen><en> “While there is a procedure to cut the ligaments that suspend the penis, this operation only provides an illusion of length.
<G-vec00486-002-s042><suspend.aufhängen><de> Man kann sie hinstellen, hinlegen oder aufhängen.
<G-vec00486-002-s042><suspend.aufhängen><en> You can place it on something, lay it down or suspend it.
<G-vec00486-002-s043><suspend.aufhängen><de> Eine Reklamation kann die Käuferberechtigungen, die aus der Nichtübereinstimmung der Ware mit dem Vertrag heraus gehen, weder ausschließen, noch begrenzen und aufhängen.
<G-vec00486-002-s043><suspend.aufhängen><en> The complaint does not exclude, limit or suspend the Buyer's rights under the non-conformity.
<G-vec00486-002-s044><suspend.aufhängen><de> Schon bald ziehen wir ein knappes Dutzend neugieriger Helfer an, die mit uns die Pappmaché-Luftballons, die bemalten und beklebten Plastikflaschen und die Stoffstücke an langen Drähten zwischen den Bäumen in der Mitte und den Strassenlaternen am Rande des Platzes aufhängen.
<G-vec00486-002-s044><suspend.aufhängen><en> Soon we have attracted about a dozen curious people. With their help, we tie the papier-mâché balloons, painted and decorated plastic bottles, and the pieces of fabric to long wires we suspend between the trees at the edge of the square and the street lights in its middle.
<G-vec00486-002-s045><suspend.aufhängen><de> Sie können die Wiege drinnen aufhängen oder auch draußen an einem Baum.
<G-vec00486-002-s045><suspend.aufhängen><en> You can suspend the cradle indoors, or outside from a tree.
<G-vec00551-002-s050><hang.aufhängen><de> Die Schlaufe am Einstieg dient zum einen dem erleichterten Anziehen des Schuhs, daran kann er aber auch mit einem Karabiner am Gurt aufgehängt oder mit dem zweiten Schuh verbunden werden, so dass er bei Mehrseillängentouren oder als Sicherungsscuh stets gut aufbewahrt ist.
<G-vec00551-002-s050><hang.aufhängen><en> The loops around the opening enable the shoes to be pulled on easily, and they can also be used to hang the shoes from a carabiner on the belt, or to join both the shoes together, making them well suited to multi-pitch tours or as safety shoes.
<G-vec00551-002-s051><hang.aufhängen><de> An seiner praktischen Schnur kann der Schwamm nach der Verwendung zum Trocknen aufgehängt werden.
<G-vec00551-002-s051><hang.aufhängen><en> A useful string allows you to hang up the sponge after use to let it dry.
<G-vec00551-002-s052><hang.aufhängen><de> Die tragbare Metalllaterne kann als Taschenlampe, der vertikale Aufzug als Laterne verwendet und an einem Baum oder anderen Gegenständen aufgehängt werden.
<G-vec00551-002-s052><hang.aufhängen><en> Metal portable lantern can be used as a flashlight, vertical lift as a lantern and can be hang it on tree or others.
<G-vec00551-002-s053><hang.aufhängen><de> Für eine Feier mit Superhelden oder Prinzessinnen die leuchtend auf dem Tisch stehen oder aufgehängt werden.
<G-vec00551-002-s053><hang.aufhängen><en> For a party of superheroes or princesses standing as lights on the table or to hang.
<G-vec00551-002-s054><hang.aufhängen><de> Zur Erinnerung an dieses einzigartige Werk ließ das Theater jedoch ein Foto des Vorhangs im Format 306 x 430 cm drucken, das im Foyer aufgehängt wird.
<G-vec00551-002-s054><hang.aufhängen><en> To recall this unique work, the theatre has printed a 306 x 430 cm photograph of the curtain that will hang in the foyer.
<G-vec00551-002-s055><hang.aufhängen><de> Sie können horizontal oder vertikal aufgehängt werden.
<G-vec00551-002-s055><hang.aufhängen><en> You can hang it either horizontally or vertically.
<G-vec00551-002-s056><hang.aufhängen><de> In den dafür vorgesehenen Löchern kann die Leinwand sowohl horizontal als auch vertikal aufgehängt werden.
<G-vec00551-002-s056><hang.aufhängen><en> By using the holes provided at the back, you can easily hang up the canvas both horizontally and vertically.
<G-vec00735-002-s057><hang.aufhängen><de> Set aus 3 Engeln aus weißem Kunstharz, Höhe 5cm, zum Aufhängen Set aus 3 Engeln aus weißem...
<G-vec00735-002-s057><hang.aufhängen><en> Set of 3 angels made of white resin, height 5cm, to hang up Set of 3 angels made of white resin,...
<G-vec00735-002-s058><hang.aufhängen><de> Ein einfaches Stoffband läuft einmal rund um den Spiegel und formt dabei außerdem eine Schlaufe, mit der sich der Spiegel am mitgelieferten Messinghaken aufhängen lässt.
<G-vec00735-002-s058><hang.aufhängen><en> A simple fabric ribbon surrounds the mirror and sets it a side with a buckle to allow you to hang it on a brass hook (included).
<G-vec00735-002-s059><hang.aufhängen><de> Mit unserem Bohrungs-Service kannst Du Dein Material präzise vorbohren lassen, damit Du es aufhängen, befestigen oder mit anderen Materialien verbinden kannst.
<G-vec00735-002-s059><hang.aufhängen><en> Our drilling service will pre-drill holes in your materials so you can hang, attach or join them with other materials.
<G-vec00735-002-s060><hang.aufhängen><de> In einem Schlafzimmer findet man nur 3 Regale um die Sachen hinzulegen, nichts zum Aufhängen und im anderen Schlafzimmer einen kleinen halben Schrank zum Hängen.
<G-vec00735-002-s060><hang.aufhängen><en> In one bedroom you will find only 3 shelves to lay the things, nothing to hang and in the other bedroom a small half cupboard to hang.
<G-vec00735-002-s061><hang.aufhängen><de> Regale über dem Bett zum Aufhängen sind nicht zu empfehlen, ebenso scharfe Ecken.
<G-vec00735-002-s061><hang.aufhängen><en> Shelves above the bed to hang is not recommended, as well as use sharp corners.
<G-vec00735-002-s062><hang.aufhängen><de> Er ist transportfähig, deswegen können Sie ihn sehr nah am Arbeitsplatz aufhängen.
<G-vec00735-002-s062><hang.aufhängen><en> It is very portable, so you can hang it near where you are working.
<G-vec00735-002-s063><hang.aufhängen><de> Darüber hinaus eignen sie sich zum Aufhängen von Mitteilungen, Warnungen, Telefonlisten etc.
<G-vec00735-002-s063><hang.aufhängen><en> In addition, they can also be used to hang notices, warnings, telephone lists, etc.
<G-vec00735-002-s064><hang.aufhängen><de> Die Küche ist komplett ausgestattet und auf dem Balkon kann man sogar die Wäsche aufhängen.
<G-vec00735-002-s064><hang.aufhängen><en> The kitchen is fully equipped and on the balcony you can even hang the laundry.
<G-vec00735-002-s065><hang.aufhängen><de> Ob Sie sie zu Hause im Flur, im Wohnzimmer, im Schlafzimmer oder in der Küche aufhängen oder in einer professionellen Umgebung wie Restaurants, Hotels, Büros oder Geschäften.
<G-vec00735-002-s065><hang.aufhängen><en> Whether you hang them at home in the hallway, living room, bedroom or kitchen, or in a professional environment such as restaurants, hotels, offices or shops.
<G-vec00735-002-s066><hang.aufhängen><de> Als die jüngste im Quartett, durfte Susy immer hochsteigen und die Quilts aufhängen.
<G-vec00735-002-s066><hang.aufhängen><en> As the youngest of the four, Susy got volunteered to climb up and down the ladder and hang the quilts.
<G-vec00735-002-s067><hang.aufhängen><de> Verwenden Sie es zum Aufhängen von Jacken,...
<G-vec00735-002-s067><hang.aufhängen><en> Use it to hang up your jackets, clothes and to store your everyday...
<G-vec00735-002-s068><hang.aufhängen><de> Einfach mit unseren Acrylfarben oder Deco Pens bemalen (nicht enthalten), mit Futter füllen und Aufhängen.
<G-vec00735-002-s068><hang.aufhängen><en> Decorate with acrylic paint or Deco pens, then add food and hang using the hook.
<G-vec00735-002-s069><hang.aufhängen><de> Man hat einen großen Schrank im Zimmer, in dem man sehr gut Kleidung aufhängen kann.
<G-vec00735-002-s069><hang.aufhängen><en> It has a large closet in the room where you can hang clothes very well.
<G-vec00735-002-s070><hang.aufhängen><de> Vielleicht gefällt Ihnen auch Großes gewölbtes Herz zum Aufhängen in weißen, feuerfesten Papierzellen mit einem...
<G-vec00735-002-s070><hang.aufhängen><en> You might also like Large domed heart, in white fireproof paper cells, 30 cm in diameter, to hang
<G-vec00735-002-s071><hang.aufhängen><de> Der Konsolentisch im skandinavischen Stil hat links einen Griff, an dem Sie eine Handtasche oder einen Rucksack aufhängen können.
<G-vec00735-002-s071><hang.aufhängen><en> The console table in Scandinavian style has a handle on the left, where you can hang a purse or a backpack.
<G-vec00735-002-s072><hang.aufhängen><de> Um unsere anderen 11 x 14 Frames anzuzeigen, klicken Sie Um unsere anderen 1 x 1 flache Frames anzuzeigen, klicken Sie Eine elegante, einfache, handgefertigte 11 "X 14" Bilderrahmen; fertig zum Aufhängen, wird es jedes Bild passen, das 11 x 14 (oder kleiner) ist.
<G-vec00735-002-s072><hang.aufhängen><en> To see our other 1x1 Flat shop_search A sleek, simple, handcrafted 11" X 14" picture frame; ready to hang, it will fit any picture that is 11x14 (or smaller).
<G-vec00735-002-s073><hang.aufhängen><de> Trotz dem vor wenigen Stunden abgesandten Telegramms über die Unzulässigkeit des inneren Kampfes „in diesem schrecklichen Augenblick“ schickte der halb und halb wieder in seine Rechte eingesetzte Kornilow zwei Mann zu Kaledin mit der Bitte um „Nachdruck“ und empfahl gleichzeitig Krymow: „Falls die Situation es erlaubt, handeln Sie selbständig im Geist der Ihnen von mir erteilten Instruktion.“ Der Geist der Instruktion war: Die Regierung stürzen und die Sowjetmitglieder aufhängen.
<G-vec00735-002-s073><hang.aufhängen><en> In spite of the telegram sent a few hours earlier about the impermissibility of inner conflict “at this terrible moment,” Kornilov, half-way restored to his rights, sent two men to Kaledin with a request “to bring pressure to bear” and at the same time suggested to Krymov: “If circumstances permit, act independently in the spirit of my instructions to you.” The spirit of those instructions was: Overthrow the government and hang the members of the Soviet.
<G-vec00735-002-s074><hang.aufhängen><de> Diese bezaubernde Mini Vase von Ib Laursen verleiht Ihrem Zuhause eine dekorative Note, egal wo Sie sie aufhängen.
<G-vec00735-002-s074><hang.aufhängen><en> This adorable Mini Vase from Ib Laursen will add a decorative touch to your home, no matter where you hang it.
<G-vec00735-002-s075><hang.aufhängen><de> Unsere Metallkleiderbügel im runden Design, die vor allem zum Aufhängen von T-Shirts, Tops, Pullover oder Strickwaren dienen, bringen Ordnung in jeden Kleiderschrank.
<G-vec00735-002-s075><hang.aufhängen><en> Our rounded metallic hangers are used primarily to hang up t-shirts, tops, pullovers or knitwear and keep any wardrobe neat and tidy.
<G-vec00735-002-s092><hang.aufhängen><de> Es gab Aufrufe, den Kaiser aufzuhängen und "Deutschland zu quetschen, bis seine Pips quietschten".
<G-vec00735-002-s092><hang.aufhängen><en> There were calls to hang the Kaiser and to “squeeze Germany until its pips squeaked”.
<G-vec00735-002-s093><hang.aufhängen><de> Ein paar Tage vor dem Mondneujahr 2014 versuchte ich, einen Vorhang aufzuhängen, konnte aber nicht die Vorhangstange erreichen.
<G-vec00735-002-s093><hang.aufhängen><en> A few days before the 2014 Lunar New Year I tried to hang up a curtain but was unable to reach the curtain rod.
<G-vec00735-002-s094><hang.aufhängen><de> Ein besonders dekorativer Hingucker für jedes Zimmer ist mit Sicherheit auch der niedliche Schmuckbaum von Sindibaba, der mit seinen verzweigten Ästen viel Platz bietet, um sämtliche Schmuckstücke und Accessoires aufzuhängen.
<G-vec00735-002-s094><hang.aufhängen><en> Another particularly decorative eyecatcher for every room is definitely the cute jewelry tree by Sindibaba which has branches that provide plenty of space to hang up all your jewelry and accessories.
<G-vec00735-002-s095><hang.aufhängen><de> Das bedeutet, dass die Tapete aus einer Mischung von Textil- und Papierfasern besteht, wodurch sie haltbarer und leichter aufzuhängen wird.
<G-vec00735-002-s095><hang.aufhängen><en> This means that the wallpaper is made of a mix of textile and paper fibres, which makes it more durable and easier to hang.
<G-vec00735-002-s096><hang.aufhängen><de> Häufig werden die Gäste in Schildern gebeten, Handtücher, die sie wiederverwenden wollen, aufzuhängen.
<G-vec00735-002-s096><hang.aufhängen><en> A guest will often notice cards in the bathroom requesting to hang bath towels they are willing to re-use.
<G-vec00735-002-s097><hang.aufhängen><de> Viele Eltern behaupten, es sei unmöglich, Ihre Kinder dazu zu bringen, beim Heimkommen ihre Jacken aufzuhängen.
<G-vec00735-002-s097><hang.aufhängen><en> Many parents claim that it's impossible to get their kids to hang up their coats when they come home.
<G-vec00735-002-s098><hang.aufhängen><de> An der Schraube ist eine praktische Öffnung angebracht, die groß genug ist, um Gewichte und/oder andere Gegenstände daran aufzuhängen.
<G-vec00735-002-s098><hang.aufhängen><en> A handy opening is attached to the screw, which is large enough to hang weights and/or other objects on it.
<G-vec00735-002-s099><hang.aufhängen><de> Verwende Kleber, Schrauben, Bilderhaken, und so weiter, um dein Board aufzuhängen.
<G-vec00735-002-s099><hang.aufhängen><en> Use glue/screws/hangers/etc. to hang your board.
<G-vec00735-002-s100><hang.aufhängen><de> In solch einem Fall ist es notwendig, eine Toilette in dem Teil des Raumes zu installieren, wo die Deckenhöhe ihr Minimum erreicht, und helle Farben für die Dekoration auszuwählen, und auch - um in der Toilette einen großen Spiegel aufzuhängen: das wird helfen, den Raum optisch zu erweitern.
<G-vec00735-002-s100><hang.aufhängen><en> In such a case, it is necessary to install a toilet in the part of the room where the ceiling height reaches its minimum, and choose light colors for decoration, and also - to hang in the restroom a large mirror: this will help visually expand the space.
<G-vec00735-002-s101><hang.aufhängen><de> Aufrollbare Gummibänder werden häufig verwendet, um verschiedene Arten von Regalen zu binden und Gestelle aufzuhängen.
<G-vec00735-002-s101><hang.aufhängen><en> Roll up rubber tie downs are often used to tie various types of shelves and to hang racks.
<G-vec00735-002-s102><hang.aufhängen><de> Die Kerben erlauben, alle Arten von Kleidungsstücken mit Hosenträgern aufzuhängen.
<G-vec00735-002-s102><hang.aufhängen><en> The notches allow to hang all kinds of garments with suspenders.
<G-vec00735-002-s103><hang.aufhängen><de> Desweiteren besitzt die Wohnung 2 Toiletten, und eine große Dusche, mit Waschmaschine und Möglichkeit um Wäsche aufzuhängen.
<G-vec00735-002-s103><hang.aufhängen><en> Furthermore the flat has 2 toilets, and a large shower, hang with washing machine and possibility to wash.
<G-vec00735-002-s104><hang.aufhängen><de> SpongeBob und Patrick arbeiten freiwillig als Wächter im Museum, während Thaddäus unbemerkt versucht, sein Gemälde aufzuhängen.
<G-vec00735-002-s104><hang.aufhängen><en> SpongeBob and Patrick volunteer as guards at the museum, while Squidward attempts to hang his painting unnoticed.
<G-vec00735-002-s105><hang.aufhängen><de> Hohe Decken und ausreichend große Fenster ermöglichen es Ihnen, den originalen Kronleuchter aufzuhängen oder viel helles Licht zu platzieren und die Fensterbänke zu zusätzlichen Plätzen für Essen oder Arbeiten zu machen.
<G-vec00735-002-s105><hang.aufhängen><en> High ceilings and large enough windows allow you to hang the original chandelier or place a lot of bright lights, and turn the sills into additional places for food or work.
<G-vec00735-002-s106><hang.aufhängen><de> Für die Verbesserung der Schalldämmung wäre es wünschenswert zwischen zwei Türen, die Gardinen aus dem dicken Stoff aufzuhängen, die man beim Aufmachen der Türen zur Seite verschieben kann.
<G-vec00735-002-s106><hang.aufhängen><en> For sound insulation improvement it is desirable to hang up between two doors curtains from a thick fabric which at opening of doors can be removed aside.
<G-vec00735-002-s107><hang.aufhängen><de> Die Hakenleiste bietet die Möglichkeit weitere Kleidungsstücke aufzuhängen.
<G-vec00735-002-s107><hang.aufhängen><en> The hook bar offers the possibility to hang up further garments.
<G-vec00735-002-s108><hang.aufhängen><de> Befestigungen am Mauerwerk Es ist nicht erlaubt, Löcher in die Wände oder die Decke zu bohren oder Gegenstände aufzuhängen.
<G-vec00735-002-s108><hang.aufhängen><en> It is not allowed to drill into the walls and the ceiling to hang something up or to attach a lamp.
<G-vec00735-002-s109><hang.aufhängen><de> Mit vorinstallierten Haken oder Haltern, über die du Verlängerungskabel und Lichterketten drapieren kannst, wird es viel leichter, die Beleuchtung aufzuhängen.
<G-vec00735-002-s109><hang.aufhängen><en> Pre-installed hooks or holders over which to drape the extension cord(s) and the light strings will make it much easier to hang your lights.
<G-vec00735-002-s110><hang.aufhängen><de> Der Wunsch, den Innenraum lebendiger zu gestalten, erlaubt es, an der Mittelwand eines mittelgroßen Raumes ein Foto mit einer hellen Blume aufzuhängen, Regale für Musikgeräte aus farbigem, transparentem Kunststoff zu hängen oder in der Mitte des Schlafzimmers farbige Familienfotos in flachen, geschwungenen Glas- oder Metallrahmen anzuordnen .
<G-vec00735-002-s110><hang.aufhängen><en> The desire to make the interior more alive allows you to hang on the central wall of a medium-sized room a photo with a bright flower, hang shelves for musical equipment made of colored transparent plastic, or put on the fireplace in the center of the bedroom colored family photos in flat, curved glass or metal frames .
