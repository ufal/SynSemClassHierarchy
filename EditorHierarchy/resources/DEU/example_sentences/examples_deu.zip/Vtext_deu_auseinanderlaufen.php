<G-vec00849-002-s031><diverge.auseinanderlaufen><de> Viele Frauen, die geboren werden, haben eine Gesichtsdiastase, wenn die Bauchmuskeln beginnen, entlang der weißen Linie des Abdomens auseinander zu laufen.
<G-vec00849-002-s031><diverge.auseinanderlaufen><en> Many women who give birth face diastasis when the abdominal muscles begin to diverge along the white line of the abdomen.
<G-vec00849-002-s034><diverge.auseinanderlaufen><de> Sie können auch bitten, Ihre Arme nach vorne zu strecken und die Augen zu schließen, wenn die Hände selbst auseinanderlaufen oder zur Seite fallen - dies kann auch ein Zeichen für einen Schlaganfall sein.
<G-vec00849-002-s034><diverge.auseinanderlaufen><en> You can also ask to stretch your arms forward and close your eyes, if the hands themselves begin to diverge or fall to one side - this may also be a sign of a stroke.
<G-vec00849-002-s035><diverge.auseinanderlaufen><de> Reklamelicht: Lichtsäule, dann dreimal blinken, auseinanderlaufen.
<G-vec00849-002-s035><diverge.auseinanderlaufen><en> Advertising light: flashing light column, then three times, diverge.
