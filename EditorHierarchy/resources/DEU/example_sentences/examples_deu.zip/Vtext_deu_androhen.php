<G-vec00252-002-s026><threaten.androhen><de> Wenn du einem Kind Dinge androhst, die dann nicht passieren, wie zum Beispiel, dass es nie wieder fern sehen darf, wenn es sein Zimmer nicht aufräumt, dann wird dein Kind merken, dass du nicht wirklich das meinst, was du sagst.
<G-vec00252-002-s026><threaten.androhen><en> If you threaten your child with things that won't happen, like saying that your child will never get to watch TV again if he doesn't clean his/her room, then the child will see that you don't really mean what you say.
<G-vec00252-002-s027><threaten.androhen><de> So bring uns doch her, was du uns androhst, wenn du zu den Wahrhaftigen geh?rst.“ 23.
<G-vec00252-002-s027><threaten.androhen><en> Then bring upon us that wherewith you threaten us, if you are of the truthful.
