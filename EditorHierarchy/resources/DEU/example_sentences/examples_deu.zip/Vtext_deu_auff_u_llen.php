<G-vec00407-001-s019><replenish.auffüllen><de> Bei der Planung ist zu berücksichtigen, dass in öffentlichen Bädern die Kinderbecken regelmäÃ ig abgelassen und mit Frischwasser aufgefüllt werden müssen.
<G-vec00407-001-s019><replenish.auffüllen><en> In designing public pools you must keep in eye on the kids pool to empty the pool regularly and replenish it with fresh water.
<G-vec00407-001-s023><replenish.auffüllen><de> Kühlmittel prüfen und auffüllen.
<G-vec00407-001-s023><replenish.auffüllen><en> Check and replenish coolant fluid.
<G-vec00407-001-s024><replenish.auffüllen><de> COR-Performance Whey ist eine optimale Proteinquelle, wenn Sie nach einem Training schlanke Muskeln aufbauen, Nährstoffe auffüllen und Ihre Naschkatzen verwöhnen wollen - ohne Schuldgefühle.
<G-vec00407-001-s024><replenish.auffüllen><en> COR-Performance Whey is an optimal source of protein when you’re looking to maintain lean muscle, replenish nutrients after a workout, and indulge your sweet tooth--guilt-free.
<G-vec00407-001-s025><replenish.auffüllen><de> Kurze Ausdauer-Läufe (wie zum Beispiel 5-km-Läufe) leeren nicht die Glykogenspeicher – ein Auffüllen während des Laufs (zum Beispiel mit isotonischen Sportgetränken) oder nach dem Lauf ist also nicht nötig.
<G-vec00407-001-s025><replenish.auffüllen><en> Short endurance runs (like 5K runs) do not deplete our glycogen stores – so you don't need to replenish them during your run (for example, with isotonic sports drinks) or after the run.
<G-vec00407-001-s026><replenish.auffüllen><de> Mit Downloads-on-Demand können Sie Ihr Konto jederzeit auffüllen, um zusätzliche Bilder herunterzuladen.
<G-vec00407-001-s026><replenish.auffüllen><en> With On Demand Downloads, you may replenish your account at any time in order to download additional images.
<G-vec00407-001-s027><replenish.auffüllen><de> Die Banane hat fünf Funktionen: Energie auffüllen, Magenschleimhaut schützen, den Blutdruck senken, den Darm befeuchten und den Schlaf fördern.
<G-vec00407-001-s027><replenish.auffüllen><en> The banana has five functions: replenish energy, protect gastric mucosa, lower blood pressure, moisten the intestines, and help sleep.
<G-vec00407-001-s028><replenish.auffüllen><de> Lava Lake, aus dem der Meisterschmied herauskommt,Kann mit Feuigkeiten der Resistenz gegen Feuer und Zaubersprüche, die die Gesundheit auffüllen, überwunden werden.
<G-vec00407-001-s028><replenish.auffüllen><en> Lava Lake, from which the Master Blacksmith comes out,can be overcome with potions of resistance to fire and spells that replenish health.
<G-vec00407-001-s029><replenish.auffüllen><de> Es kommt nur in Chlorella und enthält eine einzigartige Mischung der stärksten Wirkstoffe der Natur, die Ihren Körper ernähren und auffüllen.
<G-vec00407-001-s029><replenish.auffüllen><en> It is only found in chlorella and it contains a unique mixture of nature's most potent agents that nourish and replenish your body.
<G-vec00407-001-s030><replenish.auffüllen><de> Sie werden mit dem geänderten Formblatt9004 sofort informiert und zum Auffüllen des Kontos aufgefordert.
<G-vec00407-001-s030><replenish.auffüllen><en> You will be immediately informed with amended Form 9004 and invited to replenish the account.
<G-vec00407-001-s031><replenish.auffüllen><de> Sie müssen Ihre Glykogenspeicher auffüllen.
<G-vec00407-001-s031><replenish.auffüllen><en> You need to replenish your glycogen stores.
<G-vec00407-001-s033><replenish.auffüllen><de> Yandex-Geld: Wie man benutzt, wie man das Konto auffüllt und wie man Geld aus dem Yandex-Geldbeutel abzieht.
<G-vec00407-001-s033><replenish.auffüllen><en> Yandex Money: how to use, how to replenish the account and how to withdraw money from the Yandex purse.
<G-vec00407-001-s045><replenish.auffüllen><de> In Bezug auf Putins Reden vom Samstag sagte Trump, Russland habe nicht 24 ukrainische Seefahrer und gefälschte Anti-Fälscher freigelassen, die während des Vorfalls gefangengenommen worden seien, und die drei beschlagnahmten ukrainischen Marineschiffe nicht aufgefüllt.
<G-vec00407-001-s045><replenish.auffüllen><en> Trump, referring to Putin's speeches on Saturday, said Russia had not released 24 Ukrainian seafarers and anti-counterfeiters captured during the incident and did not replenish the three Ukrainian naval vessels seized.
<G-vec00407-001-s050><replenish.auffüllen><de> Kreditkartenkonto Ihrer Bank aufzufüllen.
<G-vec00407-001-s050><replenish.auffüllen><en> credit card account replenish your bank.
<G-vec00407-001-s051><replenish.auffüllen><de> Aber während des Laufens wird Glykogen schnell verbraucht und hat keine Zeit, seine Reserven aufzufüllen, so dass Sie sich an Körperfett wenden müssen.
<G-vec00407-001-s051><replenish.auffüllen><en> But while running, glycogen is quickly consumed and does not have time to replenish its reserves, so you have to turn to body fat.
<G-vec00407-001-s052><replenish.auffüllen><de> Wir hoffen, unsere Gäste für einen längeren Aufenthalt aufzufüllen.
<G-vec00407-001-s052><replenish.auffüllen><en> We hope to replenish our guests for a longer stay.
<G-vec00407-001-s053><replenish.auffüllen><de> Um Munition aufzufüllen und das Schiff zu reparieren, muss der Spieler Raumstationen benutzen.
<G-vec00407-001-s053><replenish.auffüllen><en> To replenish ammunition and repair the ship, player has to use space stations.
<G-vec00407-001-s054><replenish.auffüllen><de> Wenn nach einer Stunde Sie noch sein Innenvolumen aufzufüllen müssen – Sie können alle ihre Lieblingsspeisen Essen.
<G-vec00407-001-s054><replenish.auffüllen><en> If after an hour you still need to replenish his inner volume – You can eat any of their favorite foods.
<G-vec00407-001-s055><replenish.auffüllen><de> Sie müssen eine leichte Feuchtigkeitscreme nach dem Waschen zu helfen aufzufüllen Regel anwenden und nähren die Haut.
<G-vec00407-001-s055><replenish.auffüllen><en> You must usually apply a light moisturizer after washing to aid replenish and nourish the skin.
<G-vec00407-001-s056><replenish.auffüllen><de> Dies ist aufgrund der Tatsache, dass die Hoden nicht in der Lage, die Menge an Sperma beim Sex ejakuliert aufzufüllen.
<G-vec00407-001-s056><replenish.auffüllen><en> This is because of the fact that your testicles will not be able to replenish the amount of sperm ejaculated during sex.
<G-vec00407-001-s057><replenish.auffüllen><de> Es ist genug, auf einem Grundstück zu holen und auf die Bedürfnisse der Region und dem Haus und dem Tank nach Bedarf entsprechende Reserven von Gas darin aufzufüllen.
<G-vec00407-001-s057><replenish.auffüllen><en> It's enough to pick up and set on a plot corresponding to the needs of the area and the house and the tank as needed to replenish reserves of gas in it.
<G-vec00407-001-s058><replenish.auffüllen><de> B. beim Wandern oder Rad fahren kannst du CLIF Bar auch während der Einheiten zu dir nehmen, um dein Hungergefühl zu sättigen und deine Kohlenhydratspeicher aufzufüllen.
<G-vec00407-001-s058><replenish.auffüllen><en> hiking or cycling, you can take CLIF Bar also during the units to saturate your hunger and replenish your glycogen stores.
<G-vec00407-001-s059><replenish.auffüllen><de> Der sicherste Weg, die Energie des ätherischen Körpers wiederherzustellen und aufzufüllen, ist Nahrung und frische Luft.
<G-vec00407-001-s059><replenish.auffüllen><en> The surest way to restore and replenish the energy of the etheric body is food and fresh air.
<G-vec00407-001-s060><replenish.auffüllen><de> Die Mischung dieser Zutatenliste in der besten Dosierung werden Sie Haar Schuppen Nährstoffe, verbessern die Haare, niedriger Haarausfall, damit Sie erhöhen das Selbstvertrauen helfen aufzufüllen.
<G-vec00407-001-s060><replenish.auffüllen><en> The mix of these ingredients list in the best dosage will help you replenish hair shed nutrients, enhance the hair, lower hair loss to make you raise the self-confidence.
<G-vec00407-001-s061><replenish.auffüllen><de> Vergessen Sie nicht, die Kohlenhydrate aufzufüllen.
<G-vec00407-001-s061><replenish.auffüllen><en> Don’t forget to replenish the carbohydrates.
<G-vec00407-001-s062><replenish.auffüllen><de> Es bringt Gewinn an den Fiskus des Landes, um ihre persönlichen Geldbeutel aufzufüllen und untergraben die Wirtschaft die anderen kriegführenden.
<G-vec00407-001-s062><replenish.auffüllen><en> It brings profit to the treasury of the country, to replenish their personal wallets and undermine the economy the other belligerent.
<G-vec00407-001-s063><replenish.auffüllen><de> Um diese Lager aufzufüllen wurden 31 Schiffsreisen gemacht, vermutlich hauptsächlich Kohle von den USA.
<G-vec00407-001-s063><replenish.auffüllen><en> To replenish these stocks, 31 voyages were made by KTA-ships, probably mainly with coal from the USA.
<G-vec00407-001-s064><replenish.auffüllen><de> Denn wie man hört, gibt es auf Ibiza Leute, die sich im Sommer jeden Tag viele Wassertankfüllungen anliefern lassen, einfach nur, um ihre Gärten zu bewässern oder ihre Pools und Springbrunnen aufzufüllen.
<G-vec00407-001-s064><replenish.auffüllen><en> We have heard stories of people in large villas on Ibiza buying many truckloads of fresh water every day in the summer just to water their gardens, fill their pools and replenish their fountains.
<G-vec00407-001-s065><replenish.auffüllen><de> Es ist in der Lage, die Wachstumsfaktor der Neben verdünnten und aufzufüllen Samen zu aktivieren, so dass Mehrfacheinspritzung Sand mehrere Orgasmen zu bringen; es kann auch generateand aufzufüllen Samen schnell nach dem Geschlechtsverkehr fatigueand Schaden so vermeiden zu Nieren aus Mangel an Samen geführt hat; seine Potenz dauert so lange wie 120hrs Orientierung Menge: vorzeitige Ejakulation, verlieren die Spermien, schwache Spermien, die sexuelle Funktion obsacle das sexuelle Verlangen abklingt, ist der Penis kurz und klein Das Sex Produkt die Gesamtbilanz des menschlichen Körpers regulieren kann, die besondere Rolle des Körpers stark zu nähren.
<G-vec00407-001-s065><replenish.auffüllen><en> It is able to activate the growth factor of adrenal dilute and replenish semen, thus bringing multiple injection sand multiple climaxes; it can also generateand replenish semen quickly after the intercourse thus avoiding fatigueand damage to kidney resulted from lack of semen; its potency lasts as long as 120hrs Orientation crowd: premature ejaculation, lose the sperm, weak sperm, sexual function obsacle the sexual desire dies down, the Penis is short and small The Sex product is capable of regulating the overall balance of the human body, the special role of nourishing the body strong. Particularly applicable to the body due to kidney deficiency caused by weak persons.
<G-vec00407-001-s067><replenish.auffüllen><de> Standardkonto Beim Öffnen ist es notwendig, es für 100 Euro aufzufüllen, die Kosten für den Service pro Monat beginnen bei 20 Euro.
<G-vec00407-001-s067><replenish.auffüllen><en> Standard account. When opening it is necessary to replenish it for 100 euros, the cost of service per month starts from 20 euros.
<G-vec00407-001-s068><replenish.auffüllen><de> Deshalb, um die Temperatur der Spieler zu senken und gleichzeitig das Budget aufzufüllen, an der Grenze zu Slowenien, Frankreich, Schweiz und Monte Carlo betreibt mehrere Casinos.
<G-vec00407-001-s068><replenish.auffüllen><en> Therefore, to reduce the temperature of players and at the same time to replenish the budget, on the border with Slovenia, France, Switzerland and Monte Carlo operates several casinos.
<G-vec00407-001-s079><replenish.auffüllen><de> Das bedeutet, dass Marathonläufer ständig ihre Energiespeicher auffüllen müssen.
<G-vec00407-001-s079><replenish.auffüllen><en> This means that marathon runners constantly need to replenish their energy stores.
<G-vec00407-001-s157><replenish.auffüllen><de> Und es ist besser, die Schildkrötenküche mit Bohnen, reichhaltigem pflanzlichem Eiweiß, aufzufüllen.
<G-vec00407-001-s157><replenish.auffüllen><en> And it is better to replenish the turtle kitchen with beans, rich vegetable protein.
<G-vec00407-001-s191><replenish.auffüllen><de> Sex: Vermeiden Sie Sex jeden Tag und geben Sie Ihre Hoden etwas Zeit, um die Menge der Spermien während des vorherigen Sex Begegnung verloren aufzufüllen.
<G-vec00407-001-s191><replenish.auffüllen><en> Sex: Avoid having sex every day and give your testicles some time to replenish the amount of sperm lost during the previous sex encounter.
<G-vec00407-001-s192><replenish.auffüllen><de> Dies ist aufgrund der Tatsache, dass, wenn Sie ejakulieren, müssen die Hoden etwas Zeit, um die Menge der Spermien ausgeworfen aufzufüllen.
<G-vec00407-001-s192><replenish.auffüllen><en> This is because of the fact that once you ejaculate, your testicles need some time to replenish the amount of sperm ejected.
<G-vec00407-001-s193><replenish.auffüllen><de> Wir bieten unseren Kunden eine breite Palette von Möglichkeiten, um Ihr Konto aufzufüllen: von Zahlungssystemen bis Banküberweisungen.
<G-vec00407-001-s193><replenish.auffüllen><en> We offer our clients a wide range of ways to replenish their accounts - from electronic payment systems to wire transfers.
<G-vec00407-001-s194><replenish.auffüllen><de> Gegen Ende des Trojanischen Krieges landeten die Pelineis aus Peloponnes in Skioni auf Kassadra, um ihre Vorräte aufzufüllen.
<G-vec00407-001-s194><replenish.auffüllen><en> The Pelineis from Peloponnese disembarked in Skioni on Kassadra at the end of the Trojan War to replenish their supplies.
<G-vec00407-001-s195><replenish.auffüllen><de> Einmal im Jahr und anderthalb ist es besser, einen Mini-Kurs mit Pillen oder Injektionen zu machen, um das Vitamin aufzufüllen.
<G-vec00407-001-s195><replenish.auffüllen><en> Once a year and a half it is better to make a mini-course of pills or injections to replenish the vitamin.
<G-vec00407-001-s196><replenish.auffüllen><de> Erstens, Glücksspiel ist ein Weg, um die Staatskasse aufzufüllen, der wirtschaftliche Nutzen aus der Existenz dieser Institutionen war offensichtlich, daher begann ein neues Casino erscheinen.
<G-vec00407-001-s196><replenish.auffüllen><en> First, gambling is a way to replenish the state treasury, the economic benefit from the existence of these institutions was evident, therefore, began to appear new casino.
<G-vec00407-001-s200><replenish.auffüllen><de> Wenn Ihr Blatt nach dem Ausspielen weniger als drei Karten umfasst, müssen Sie es sofort durch Ziehen aus dem Stapel auffüllen, sodass Sie wieder drei Karten haben.
<G-vec00407-001-s200><replenish.auffüllen><en> If after playing you have fewer than three cards in your hand, you must immediately replenish your hand by drawing from the stock so that you have three cards again.
<G-vec00407-001-s215><replenish.auffüllen><de> Es wird neue Revolutionäre geben, die unsere Lücken wieder auffüllen und vergrößern werden.
<G-vec00407-001-s215><replenish.auffüllen><en> There will be new revolutionaries who will replenish and enlarge our gaps.
<G-vec00407-001-s216><replenish.auffüllen><de> "Ein weiterer Vorteil der Registrierung ist, dass Sie nur erhalten ein Profil, wo Sie können wieder Auffüllen, Token für die private Kommunikation mit ""Runetkami""."
<G-vec00407-001-s216><replenish.auffüllen><en> "Another advantage of registration is that you just receive a profile where you can replenish tokens for private communication with ""Runetkami""."
<G-vec00407-001-s217><replenish.auffüllen><de> Waldgräber pflanzen häufig Bäume am Grab, so dass der Körper das Wachstum nähren und wieder auffüllen kann.
<G-vec00407-001-s217><replenish.auffüllen><en> Woodland burial sites often plant trees on the site of the grave, allowing the body to nourish and replenish growth.
<G-vec00407-001-s218><replenish.auffüllen><de> Nach einiger Zeit werden die Nährstoffe aufgebraucht und Sie können den Nährstoffspeicher im Boden mit flüssigem Dünger (JBL Ferropol) wieder auffüllen.
<G-vec00407-001-s218><replenish.auffüllen><en> After a while the nutrients will be used up and you can replenish the nutrient reservoir in the soil with a liquid fertiliser (JBL Ferropol).
<G-vec00407-001-s219><replenish.auffüllen><de> Dort erreichen die Sommertemperaturen 45 Grad und die Arbeiter müssen dehydrieren, die verlorenen Salze wieder auffüllen und füttern, ohne sich einer starken Verdauung unterziehen zu müssen.
<G-vec00407-001-s219><replenish.auffüllen><en> There, summer temperatures reach 45 degrees and workers need to rehydrate, replenish lost salts, and feed without having to undergo heavy digestion.
<G-vec00407-001-s220><replenish.auffüllen><de> Herr Chimanikire sagte, die Regierung hatte eine Verantwortung dafür, dass das Land aus seiner Mineralien profitierten, da sie nicht wieder auffüllen einmal ausgenutzt.
<G-vec00407-001-s220><replenish.auffüllen><en> Mr Chimanikire said the Government had a responsibility to ensure that the country benefited from its minerals since they did not replenish once exploited.
<G-vec00407-001-s222><replenish.auffüllen><de> Versorgung geschützt und wieder aufzufüllen Anfragen und organisieren.
<G-vec00407-001-s222><replenish.auffüllen><en> Protected and replenish requests and organize supply .
<G-vec00407-001-s223><replenish.auffüllen><de> Spirulina in der Früh kann den Bedarf des Körpers an Vitamin B-Gruppe wieder aufzufüllen, so dass man eine energetische Tag.
<G-vec00407-001-s223><replenish.auffüllen><en> Spirulina in the morning can replenish the body's need of vitamin B group, enabling one to have an energetic day.
<G-vec00407-001-s224><replenish.auffüllen><de> Arzt am Besten GLEICH hilft wieder aufzufüllen, die den GLEICHEN Ebenen und fördern eine gesunde Stimmung.
<G-vec00407-001-s224><replenish.auffüllen><en> Doctor's Best SAM-e helps replenish your SAM-e levels and promote a healthy mood.
<G-vec00407-001-s225><replenish.auffüllen><de> Während das Land ist nicht zu erwarten, jemals seinen Ruf als Ort für Feiern Südafrikaner wieder aufzufüllen, da es nun auch für andere Alternativen näher zu Hause sind für sie Freude in abzuleiten, ist der Ausbau eine lange Strecke Tourismus-Geschäft wird angeordnet.
<G-vec00407-001-s225><replenish.auffüllen><en> While the country is not expected to ever replenish its reputation as a destination for partying South Africans, as there are now other alternatives closer to home for them to derive pleasure in, the expansion of a long distance tourism business is being arranged.
<G-vec00407-001-s226><replenish.auffüllen><de> Die Kombination dieser Inhaltsstoffe in der idealen Dosis wird sicherlich helfen Sie Haar Schuppen Nährstoffe, verbessern die Haare, niedriger Verlust der Haare wieder aufzufüllen, um Ihnen das Selbstvertrauen zu machen steigern.
<G-vec00407-001-s226><replenish.auffüllen><en> The combination of these ingredients in the ideal dose will certainly assist you replenish hair shed nutrients, enhance the hair, lower loss of hair to make you boost the self-confidence.
<G-vec00407-001-s227><replenish.auffüllen><de> Es ist auch sehr notwendig, dass Sie so viel Wasser wie möglich wieder aufzufüllen Abbau der Lagerbestände von Flüssigkeit in Ihrem Körper zu trinken verloren durch Schweiß.
<G-vec00407-001-s227><replenish.auffüllen><en> Also, it is you need to drink more water than the capacity to replenish the stock reduction of body fluids lost through sweat.
<G-vec00407-001-s228><replenish.auffüllen><de> Wie Sie Rake, erstellen Sie kostenlos natürlicher Dünger; die trockenen Blätter zerfallen ein wenig hilft, Nährstoffe, um den Boden für eine grünere, volleren Rasen nächsten Jahr wieder aufzufüllen.
<G-vec00407-001-s228><replenish.auffüllen><en> As you rake, you are creating free natural fertilizer; the dry leaves crumble a little, helping to replenish nutrients to the soil for a greener, fuller lawn next year.
<G-vec00407-001-s229><replenish.auffüllen><de> Vorteile Her BCAA's Features SUSTAMINE®: eine Kombination der Aminosäuren L-Alanin und L-Glutamin zu helfen, Ihren Körper rehydrieren, wieder aufzufüllen und wiederherzustellen, Fördert das Wachstum, Protein Synthese, Leistung & Kraft, Fördert die Verbesserte Regeneration, verfügt über full-Haut, Haare und Nägel recoveryRichtungen von Her BCAA's Mischen Sie 1...
<G-vec00407-001-s229><replenish.auffüllen><en> Benefits ofHer BCAA's Features SUSTAMINE®: a combination of the amino acids L-Alanine and L-Glutamine to help your body rehydrate, replenish and recover, Promotes Growth, Protein Synthesis, Performance & Strength, Promotes Enhanced Recovery, Features full Skin, Hair and Nails recoveryDirections ofHer BCAA's Mix 1 scoop with 10 oz of water and drink it before, during...
<G-vec00407-001-s230><replenish.auffüllen><de> Wichtig ist dabei nur, den Flüssigkeitsverlust danach wieder aufzufüllen.
<G-vec00407-001-s230><replenish.auffüllen><en> It is important only to replenish the fluid loss afterwards.
<G-vec00407-001-s231><replenish.auffüllen><de> Die Kombination dieser Zutaten in der richtigen Dosierung werden Sie Haar verloren Nährstoffe, die Stärkung der Haare, Haarausfall reduzieren helfen, wieder aufzufüllen, um Ihnen das Vertrauen, machen zu erhöhen.
<G-vec00407-001-s231><replenish.auffüllen><en> The combination of these ingredients in the right dosage will help you replenish hair lost nutrients, strengthen the hair, reduce hair loss to make you increase the confidence.
<G-vec00407-001-s232><replenish.auffüllen><de> Im Vergleich zu dem Jungbrunnen, gettting genug HGH, wenn Sie alt werden alle Ihre schwachen Zellen wieder aufzufüllen.
<G-vec00407-001-s232><replenish.auffüllen><en> In comparison to the fountain of youth, gettting enough HGH when you are old will replenish all your weak cells.
<G-vec00407-001-s233><replenish.auffüllen><de> Natürlich hilft dieses Gemüse dabei, den Körper Ihres Kindes, Ihre Vitamine und andere nützliche Substanzen wieder aufzufüllen, wie oben erwähnt.
<G-vec00407-001-s233><replenish.auffüllen><en> Of course, this vegetable will help replenish the child's body and your vitamins and other beneficial substances, as mentioned above.
<G-vec00407-001-s234><replenish.auffüllen><de> Unser Ziel ist es, Sie gehen zurück in die Natur für unsere Gäste wieder aufzufüllen, wodurch es ideal für die Schaffung eines Ortes der Erfrischung und Erneuerung.
<G-vec00407-001-s234><replenish.auffüllen><en> Our goal is to walk you back to nature to replenish our guests, making it ideal for creating a place of refreshment and renewal.
<G-vec00407-001-s235><replenish.auffüllen><de> Dies wird dazu beitragen, den Körper wieder aufzufüllen benötigte Energie am nächsten Tag.
<G-vec00407-001-s235><replenish.auffüllen><en> This will help the body replenish the energy needed for the next day.
<G-vec00407-001-s236><replenish.auffüllen><de> ...auch wieder aufzufüllen Ernährung, wie sie gesünder ungesättigten Fettsäuren.
<G-vec00407-001-s236><replenish.auffüllen><en> ...and nuts can also replenish nutrition, as they contain healthier unsaturated fat.
<G-vec00407-001-s237><replenish.auffüllen><de> It 's All-Inclusive-Programm entwickelt, um Giftstoffe leicht zu entfernen, Nährstoffe wieder aufzufüllen und helfen Ihnen sicher Schuppen giftig Fett, Pfund und Zoll in die gesündeste Art und Weise möglich.
<G-vec00407-001-s237><replenish.auffüllen><en> This all-inclusive program designed to easily remove toxins, replenish nutrients and will help you safely shed toxic fat, pounds and inches in a healthy way possible.
<G-vec00407-001-s238><replenish.auffüllen><de> Nach dem Wasservergnügen ist es Zeit, die verbrannten Kalorien wieder aufzufüllen.
<G-vec00407-001-s238><replenish.auffüllen><en> After the aquatic attractions it is time to replenish burnt calories.
<G-vec00407-001-s239><replenish.auffüllen><de> ...auch wieder aufzufüllen Ernährung, wie sie gesünder...
<G-vec00407-001-s239><replenish.auffüllen><en> ...and nuts can also replenish nutrition, as they contain healthier...
<G-vec00407-001-s240><replenish.auffüllen><de> Oder engagiert und vermisst ihren Lieblingssport außerhalb der Ausbildung, und ersetzt sie mit Sportspielen.Collections Online Spiele heute wieder aufzufüllen Sports für sämtliche Sportarten.
<G-vec00407-001-s240><replenish.auffüllen><en> Or engaged and misses her favorite sport outside of training, replacing them with the sports games.Collections Online games today replenish Sports for any and all sports.
<G-vec00316-002-s038><fill.auffüllen><de> Balance-Ausgleichsprothesen wurden speziell dafür entwickelt, nahezu jede durch Operation oder Strahlung entstandene Asymmetrie der Brust aufzufüllen und zu kaschieren.
<G-vec00316-002-s038><fill.auffüllen><en> Balance partial shapers are designed specifically to fill, cover and conceal almost any breast asymmetry created by surgery or radiation.
<G-vec00316-002-s039><fill.auffüllen><de> Um unsere Wassersäcke aufzufüllen steuern wir deshalb gezielt Siedlungen oder Restaurants an.
<G-vec00316-002-s039><fill.auffüllen><en> In order to fill our water bags, we are targeting settlements or restaurants. Yup!
<G-vec00316-002-s040><fill.auffüllen><de> Behandlungen mit Restylane Filler und Restylane Skinbooster eignen sich, das Feuchtigkeitsgleichgewicht der Haut wieder herzustellen und störende Falten und Linien aufzufüllen.
<G-vec00316-002-s040><fill.auffüllen><en> Restylane treatments can be a useful tool to restore the skin's hydration levels or fill out unwanted wrinkles and folds.
<G-vec00316-002-s041><fill.auffüllen><de> Der natürliche Heilungsprozess der Haut hilft sowohl dabei Narben, feine Linien und ein unregelmäßiges Hautbild aufzufüllen und zu glätten als auch vergrößerte Poren zu verkleinern.
<G-vec00316-002-s041><fill.auffüllen><en> The skin’s natural repair process helps fill in and smooth out scars, fine lines and uneven texture while also shrinking enlarged pores.
<G-vec00316-002-s042><fill.auffüllen><de> Und das ist ein großer Teil davon, was all diese ungesunden Gewohnheiten zu kompensieren versuchen, die Zeit aufzufüllen.
<G-vec00316-002-s042><fill.auffüllen><en> And this is a large part of what all these unhealthy habits are trying to compensate, to fill up the time.
<G-vec00316-002-s043><fill.auffüllen><de> Wenn Sie eine Region löschen, können Sie die in der Spur nachfolgenden Regionen verschieben, um den links durch die gelöschte Region entstandenen leeren Platz aufzufüllen.
<G-vec00316-002-s043><fill.auffüllen><en> When you delete a region, you can move the regions that follow in the track to fill in the empty space left by the deleted region.
<G-vec00316-002-s044><fill.auffüllen><de> AccuGrade zeigt genau, wo zu arbeiten und wie viel abzutragen oder aufzufüllen ist – sodass keine Absteckarbeiten und Kontrollen mehr erforderlich sind.
<G-vec00316-002-s044><fill.auffüllen><en> AccuGrade indicates precisely where to work and how much to cut or fill – eliminating staking and checking.
<G-vec00316-002-s045><fill.auffüllen><de> Als im Laufe des Krieges die Zahl der Freiwilligen nicht mehr ausreichte um die Verluste aufzufüllen musste auch in Großbritannien die Wehrpflicht eingeführt werden.
<G-vec00316-002-s045><fill.auffüllen><en> As during the war, the number of volunteers was no longer sufficient to fill the losses in the United Kingdom conscription had to be introduced.
<G-vec00316-002-s046><fill.auffüllen><de> Hilft sofort Gesichtslinien und -falten aufzufüllen.
<G-vec00316-002-s046><fill.auffüllen><en> Immediately helps fill facial lines and wrinkles.
<G-vec00316-002-s047><fill.auffüllen><de> Haferflocken mit Früchten zum Frühstück, Vollkornbrot mit deinem liebsten Aufstrich oder Kartoffeln aus dem Ofen – es gibt unendlich viele Möglichkeiten, deinen Energievorrat aufzufüllen.
<G-vec00316-002-s047><fill.auffüllen><en> Oatmeal with fruit for breakfast, wholemeal bread with your favorite spread, or oven potatoes - there are endless possibilities to fill your energy reserve.
<G-vec00316-002-s048><fill.auffüllen><de> Wird von „Stabilisieren, Kanten synthetisieren“ verwendet und steuert bei Frames, wie weit der Synthetisierungsvorgang in der Zeit vorwärts und zurück geht, um fehlende Pixel aufzufüllen.
<G-vec00316-002-s048><fill.auffüllen><en> Used by Stabilize, Synthesize Edges framing, controls how far backward and forward in time the synthesis process goes to fill in any missing pixels.
<G-vec00316-002-s049><fill.auffüllen><de> 5 Gewinnlinien auf 5 Walzen im regulären Spiel, machen es dir möglich dein Twistkonto aufzufüllen.
<G-vec00316-002-s049><fill.auffüllen><en> Five paylines across five reels in the regular game provide you with the perfect chance to fill up your Twist account.
<G-vec00316-002-s050><fill.auffüllen><de> Sollten Sie erste Anzeichen einer Erkältung spüren, ist es also empfehlenswert, sofort den Vitamin C-Speicher aufzufüllen und nicht locker zu lassen, bis die Erkältung hoffentlich schnell überstanden ist.
<G-vec00316-002-s050><fill.auffüllen><en> If you notice the first signs of a cold, it is therefore a good idea to fill up the vitamin C reservoir immediately and not to give up until you have hopefully recovered quickly from the cold.
<G-vec00316-002-s051><fill.auffüllen><de> Gemäß den Lehren der vorliegenden Erfindung wird die Reihe von Erstebenen-Aluminiummetallleitungen 220 deponiert, um die Reihe von Gräben 210 bis auf die oberste Fläche 219 der ersten Oxidschicht 208 aufzufüllen.
<G-vec00316-002-s051><fill.auffüllen><en> According to the teachings of the present invention the number of first level aluminum metal lines 220, is deposited to fill the number of trenches 210 to the top surface 219 of the first oxide layer 208.
<G-vec00316-002-s052><fill.auffüllen><de> Eine Wasserversorgung wird innerhalb 20m angefordert und ideal wird 4-6 Stunden angefordert, um das Pool aufzufüllen.
<G-vec00316-002-s052><fill.auffüllen><en> A water supply will be required within 20m and ideally 4-6 Hours is required to fill up the pool.
<G-vec00316-002-s053><fill.auffüllen><de> Geschickte Spieler können mehrere Rollen oder Korkenzieher in einem Sprung durchführen, eine gute Strategie, um die Nitroanzeige ihres Wagens schnell aufzufüllen.
<G-vec00316-002-s053><fill.auffüllen><en> Skilled players can perform several rolls or spins in a single jump, which is a solid strategy to quickly fill their car's nitro bar.
<G-vec00316-002-s054><fill.auffüllen><de> Ab 1942 wurde es kritisch, und ab 1943 mussten Männer in die SS gezwungen werden, um die SS-Korps "aufzufüllen".
<G-vec00316-002-s054><fill.auffüllen><en> Since 1942 it was critical for the SS, and since 1943 men had to be forced into SS to "fill up" the SS corps.
<G-vec00316-002-s055><fill.auffüllen><de> An dem Punkt an dem es wichtig wird, uns selbst wieder aufzufüllen kann nichts Neues eintreten, bis wir willentlich alles entlassen was uns nicht länger dient, vollkommen und ganz und gar in die Vergangenheit.
<G-vec00316-002-s055><fill.auffüllen><en> At the point where it becomes important to fill ourselves up again, nothing new can enter until we willingly release everything that no longer serves us, fully and completely into the past.
<G-vec00316-002-s056><fill.auffüllen><de> Ein Teil der Cenoten durchläuft folgenden Lebenszyklus: Wasser löst aus dem Kalkstein eine unterirdische Höhle; ein kleiner Teil der Decke stürzt ein; weitere Teile der Decke stürzen nach und ein schachtartiges rundes Loch mit steilen Wänden entsteht; Vegetation fällt in die Cenote und beginnt sie langsam aufzufüllen, bis eine trockene Cenote entsteht.
<G-vec00316-002-s056><fill.auffüllen><en> Most cenotes run through the following life cycle: Water dissolves an underground cavern; a small part of the ceiling collapses creating an opening; more of the ceiling collapses and a round hole with steep walls emerges; vegetation falls into the cenote and the hole slowly starts to fill until the cenote becomes dry.
<G-vec00577-002-s038><fill_out.auffüllen><de> Balance-Ausgleichsprothesen wurden speziell dafür entwickelt, nahezu jede durch Operation oder Strahlung entstandene Asymmetrie der Brust aufzufüllen und zu kaschieren.
<G-vec00577-002-s038><fill_out.auffüllen><en> Balance partial shapers are designed specifically to fill, cover and conceal almost any breast asymmetry created by surgery or radiation.
<G-vec00577-002-s039><fill_out.auffüllen><de> Um unsere Wassersäcke aufzufüllen steuern wir deshalb gezielt Siedlungen oder Restaurants an.
<G-vec00577-002-s039><fill_out.auffüllen><en> In order to fill our water bags, we are targeting settlements or restaurants. Yup!
<G-vec00577-002-s040><fill_out.auffüllen><de> Behandlungen mit Restylane Filler und Restylane Skinbooster eignen sich, das Feuchtigkeitsgleichgewicht der Haut wieder herzustellen und störende Falten und Linien aufzufüllen.
<G-vec00577-002-s040><fill_out.auffüllen><en> Restylane treatments can be a useful tool to restore the skin's hydration levels or fill out unwanted wrinkles and folds.
<G-vec00577-002-s041><fill_out.auffüllen><de> Der natürliche Heilungsprozess der Haut hilft sowohl dabei Narben, feine Linien und ein unregelmäßiges Hautbild aufzufüllen und zu glätten als auch vergrößerte Poren zu verkleinern.
<G-vec00577-002-s041><fill_out.auffüllen><en> The skin’s natural repair process helps fill in and smooth out scars, fine lines and uneven texture while also shrinking enlarged pores.
<G-vec00577-002-s042><fill_out.auffüllen><de> Und das ist ein großer Teil davon, was all diese ungesunden Gewohnheiten zu kompensieren versuchen, die Zeit aufzufüllen.
<G-vec00577-002-s042><fill_out.auffüllen><en> And this is a large part of what all these unhealthy habits are trying to compensate, to fill up the time.
<G-vec00577-002-s043><fill_out.auffüllen><de> Wenn Sie eine Region löschen, können Sie die in der Spur nachfolgenden Regionen verschieben, um den links durch die gelöschte Region entstandenen leeren Platz aufzufüllen.
<G-vec00577-002-s043><fill_out.auffüllen><en> When you delete a region, you can move the regions that follow in the track to fill in the empty space left by the deleted region.
<G-vec00577-002-s044><fill_out.auffüllen><de> AccuGrade zeigt genau, wo zu arbeiten und wie viel abzutragen oder aufzufüllen ist – sodass keine Absteckarbeiten und Kontrollen mehr erforderlich sind.
<G-vec00577-002-s044><fill_out.auffüllen><en> AccuGrade indicates precisely where to work and how much to cut or fill – eliminating staking and checking.
<G-vec00577-002-s045><fill_out.auffüllen><de> Als im Laufe des Krieges die Zahl der Freiwilligen nicht mehr ausreichte um die Verluste aufzufüllen musste auch in Großbritannien die Wehrpflicht eingeführt werden.
<G-vec00577-002-s045><fill_out.auffüllen><en> As during the war, the number of volunteers was no longer sufficient to fill the losses in the United Kingdom conscription had to be introduced.
<G-vec00577-002-s046><fill_out.auffüllen><de> Hilft sofort Gesichtslinien und -falten aufzufüllen.
<G-vec00577-002-s046><fill_out.auffüllen><en> Immediately helps fill facial lines and wrinkles.
<G-vec00577-002-s047><fill_out.auffüllen><de> Haferflocken mit Früchten zum Frühstück, Vollkornbrot mit deinem liebsten Aufstrich oder Kartoffeln aus dem Ofen – es gibt unendlich viele Möglichkeiten, deinen Energievorrat aufzufüllen.
<G-vec00577-002-s047><fill_out.auffüllen><en> Oatmeal with fruit for breakfast, wholemeal bread with your favorite spread, or oven potatoes - there are endless possibilities to fill your energy reserve.
<G-vec00577-002-s048><fill_out.auffüllen><de> Wird von „Stabilisieren, Kanten synthetisieren“ verwendet und steuert bei Frames, wie weit der Synthetisierungsvorgang in der Zeit vorwärts und zurück geht, um fehlende Pixel aufzufüllen.
<G-vec00577-002-s048><fill_out.auffüllen><en> Used by Stabilize, Synthesize Edges framing, controls how far backward and forward in time the synthesis process goes to fill in any missing pixels.
<G-vec00577-002-s049><fill_out.auffüllen><de> 5 Gewinnlinien auf 5 Walzen im regulären Spiel, machen es dir möglich dein Twistkonto aufzufüllen.
<G-vec00577-002-s049><fill_out.auffüllen><en> Five paylines across five reels in the regular game provide you with the perfect chance to fill up your Twist account.
<G-vec00577-002-s050><fill_out.auffüllen><de> Sollten Sie erste Anzeichen einer Erkältung spüren, ist es also empfehlenswert, sofort den Vitamin C-Speicher aufzufüllen und nicht locker zu lassen, bis die Erkältung hoffentlich schnell überstanden ist.
<G-vec00577-002-s050><fill_out.auffüllen><en> If you notice the first signs of a cold, it is therefore a good idea to fill up the vitamin C reservoir immediately and not to give up until you have hopefully recovered quickly from the cold.
<G-vec00577-002-s051><fill_out.auffüllen><de> Gemäß den Lehren der vorliegenden Erfindung wird die Reihe von Erstebenen-Aluminiummetallleitungen 220 deponiert, um die Reihe von Gräben 210 bis auf die oberste Fläche 219 der ersten Oxidschicht 208 aufzufüllen.
<G-vec00577-002-s051><fill_out.auffüllen><en> According to the teachings of the present invention the number of first level aluminum metal lines 220, is deposited to fill the number of trenches 210 to the top surface 219 of the first oxide layer 208.
<G-vec00577-002-s052><fill_out.auffüllen><de> Eine Wasserversorgung wird innerhalb 20m angefordert und ideal wird 4-6 Stunden angefordert, um das Pool aufzufüllen.
<G-vec00577-002-s052><fill_out.auffüllen><en> A water supply will be required within 20m and ideally 4-6 Hours is required to fill up the pool.
<G-vec00577-002-s053><fill_out.auffüllen><de> Geschickte Spieler können mehrere Rollen oder Korkenzieher in einem Sprung durchführen, eine gute Strategie, um die Nitroanzeige ihres Wagens schnell aufzufüllen.
<G-vec00577-002-s053><fill_out.auffüllen><en> Skilled players can perform several rolls or spins in a single jump, which is a solid strategy to quickly fill their car's nitro bar.
<G-vec00577-002-s054><fill_out.auffüllen><de> Ab 1942 wurde es kritisch, und ab 1943 mussten Männer in die SS gezwungen werden, um die SS-Korps "aufzufüllen".
<G-vec00577-002-s054><fill_out.auffüllen><en> Since 1942 it was critical for the SS, and since 1943 men had to be forced into SS to "fill up" the SS corps.
<G-vec00577-002-s055><fill_out.auffüllen><de> An dem Punkt an dem es wichtig wird, uns selbst wieder aufzufüllen kann nichts Neues eintreten, bis wir willentlich alles entlassen was uns nicht länger dient, vollkommen und ganz und gar in die Vergangenheit.
<G-vec00577-002-s055><fill_out.auffüllen><en> At the point where it becomes important to fill ourselves up again, nothing new can enter until we willingly release everything that no longer serves us, fully and completely into the past.
<G-vec00577-002-s056><fill_out.auffüllen><de> Ein Teil der Cenoten durchläuft folgenden Lebenszyklus: Wasser löst aus dem Kalkstein eine unterirdische Höhle; ein kleiner Teil der Decke stürzt ein; weitere Teile der Decke stürzen nach und ein schachtartiges rundes Loch mit steilen Wänden entsteht; Vegetation fällt in die Cenote und beginnt sie langsam aufzufüllen, bis eine trockene Cenote entsteht.
<G-vec00577-002-s056><fill_out.auffüllen><en> Most cenotes run through the following life cycle: Water dissolves an underground cavern; a small part of the ceiling collapses creating an opening; more of the ceiling collapses and a round hole with steep walls emerges; vegetation falls into the cenote and the hole slowly starts to fill until the cenote becomes dry.
<G-vec00577-002-s038><fill_up.auffüllen><de> Balance-Ausgleichsprothesen wurden speziell dafür entwickelt, nahezu jede durch Operation oder Strahlung entstandene Asymmetrie der Brust aufzufüllen und zu kaschieren.
<G-vec00577-002-s038><fill_up.auffüllen><en> Balance partial shapers are designed specifically to fill, cover and conceal almost any breast asymmetry created by surgery or radiation.
<G-vec00577-002-s039><fill_up.auffüllen><de> Um unsere Wassersäcke aufzufüllen steuern wir deshalb gezielt Siedlungen oder Restaurants an.
<G-vec00577-002-s039><fill_up.auffüllen><en> In order to fill our water bags, we are targeting settlements or restaurants. Yup!
<G-vec00577-002-s040><fill_up.auffüllen><de> Behandlungen mit Restylane Filler und Restylane Skinbooster eignen sich, das Feuchtigkeitsgleichgewicht der Haut wieder herzustellen und störende Falten und Linien aufzufüllen.
<G-vec00577-002-s040><fill_up.auffüllen><en> Restylane treatments can be a useful tool to restore the skin's hydration levels or fill out unwanted wrinkles and folds.
<G-vec00577-002-s041><fill_up.auffüllen><de> Der natürliche Heilungsprozess der Haut hilft sowohl dabei Narben, feine Linien und ein unregelmäßiges Hautbild aufzufüllen und zu glätten als auch vergrößerte Poren zu verkleinern.
<G-vec00577-002-s041><fill_up.auffüllen><en> The skin’s natural repair process helps fill in and smooth out scars, fine lines and uneven texture while also shrinking enlarged pores.
<G-vec00577-002-s042><fill_up.auffüllen><de> Und das ist ein großer Teil davon, was all diese ungesunden Gewohnheiten zu kompensieren versuchen, die Zeit aufzufüllen.
<G-vec00577-002-s042><fill_up.auffüllen><en> And this is a large part of what all these unhealthy habits are trying to compensate, to fill up the time.
<G-vec00577-002-s043><fill_up.auffüllen><de> Wenn Sie eine Region löschen, können Sie die in der Spur nachfolgenden Regionen verschieben, um den links durch die gelöschte Region entstandenen leeren Platz aufzufüllen.
<G-vec00577-002-s043><fill_up.auffüllen><en> When you delete a region, you can move the regions that follow in the track to fill in the empty space left by the deleted region.
<G-vec00577-002-s044><fill_up.auffüllen><de> AccuGrade zeigt genau, wo zu arbeiten und wie viel abzutragen oder aufzufüllen ist – sodass keine Absteckarbeiten und Kontrollen mehr erforderlich sind.
<G-vec00577-002-s044><fill_up.auffüllen><en> AccuGrade indicates precisely where to work and how much to cut or fill – eliminating staking and checking.
<G-vec00577-002-s045><fill_up.auffüllen><de> Als im Laufe des Krieges die Zahl der Freiwilligen nicht mehr ausreichte um die Verluste aufzufüllen musste auch in Großbritannien die Wehrpflicht eingeführt werden.
<G-vec00577-002-s045><fill_up.auffüllen><en> As during the war, the number of volunteers was no longer sufficient to fill the losses in the United Kingdom conscription had to be introduced.
<G-vec00577-002-s046><fill_up.auffüllen><de> Hilft sofort Gesichtslinien und -falten aufzufüllen.
<G-vec00577-002-s046><fill_up.auffüllen><en> Immediately helps fill facial lines and wrinkles.
<G-vec00577-002-s047><fill_up.auffüllen><de> Haferflocken mit Früchten zum Frühstück, Vollkornbrot mit deinem liebsten Aufstrich oder Kartoffeln aus dem Ofen – es gibt unendlich viele Möglichkeiten, deinen Energievorrat aufzufüllen.
<G-vec00577-002-s047><fill_up.auffüllen><en> Oatmeal with fruit for breakfast, wholemeal bread with your favorite spread, or oven potatoes - there are endless possibilities to fill your energy reserve.
<G-vec00577-002-s048><fill_up.auffüllen><de> Wird von „Stabilisieren, Kanten synthetisieren“ verwendet und steuert bei Frames, wie weit der Synthetisierungsvorgang in der Zeit vorwärts und zurück geht, um fehlende Pixel aufzufüllen.
<G-vec00577-002-s048><fill_up.auffüllen><en> Used by Stabilize, Synthesize Edges framing, controls how far backward and forward in time the synthesis process goes to fill in any missing pixels.
<G-vec00577-002-s049><fill_up.auffüllen><de> 5 Gewinnlinien auf 5 Walzen im regulären Spiel, machen es dir möglich dein Twistkonto aufzufüllen.
<G-vec00577-002-s049><fill_up.auffüllen><en> Five paylines across five reels in the regular game provide you with the perfect chance to fill up your Twist account.
<G-vec00577-002-s050><fill_up.auffüllen><de> Sollten Sie erste Anzeichen einer Erkältung spüren, ist es also empfehlenswert, sofort den Vitamin C-Speicher aufzufüllen und nicht locker zu lassen, bis die Erkältung hoffentlich schnell überstanden ist.
<G-vec00577-002-s050><fill_up.auffüllen><en> If you notice the first signs of a cold, it is therefore a good idea to fill up the vitamin C reservoir immediately and not to give up until you have hopefully recovered quickly from the cold.
<G-vec00577-002-s051><fill_up.auffüllen><de> Gemäß den Lehren der vorliegenden Erfindung wird die Reihe von Erstebenen-Aluminiummetallleitungen 220 deponiert, um die Reihe von Gräben 210 bis auf die oberste Fläche 219 der ersten Oxidschicht 208 aufzufüllen.
<G-vec00577-002-s051><fill_up.auffüllen><en> According to the teachings of the present invention the number of first level aluminum metal lines 220, is deposited to fill the number of trenches 210 to the top surface 219 of the first oxide layer 208.
<G-vec00577-002-s052><fill_up.auffüllen><de> Eine Wasserversorgung wird innerhalb 20m angefordert und ideal wird 4-6 Stunden angefordert, um das Pool aufzufüllen.
<G-vec00577-002-s052><fill_up.auffüllen><en> A water supply will be required within 20m and ideally 4-6 Hours is required to fill up the pool.
<G-vec00577-002-s053><fill_up.auffüllen><de> Geschickte Spieler können mehrere Rollen oder Korkenzieher in einem Sprung durchführen, eine gute Strategie, um die Nitroanzeige ihres Wagens schnell aufzufüllen.
<G-vec00577-002-s053><fill_up.auffüllen><en> Skilled players can perform several rolls or spins in a single jump, which is a solid strategy to quickly fill their car's nitro bar.
<G-vec00577-002-s054><fill_up.auffüllen><de> Ab 1942 wurde es kritisch, und ab 1943 mussten Männer in die SS gezwungen werden, um die SS-Korps "aufzufüllen".
<G-vec00577-002-s054><fill_up.auffüllen><en> Since 1942 it was critical for the SS, and since 1943 men had to be forced into SS to "fill up" the SS corps.
<G-vec00577-002-s055><fill_up.auffüllen><de> An dem Punkt an dem es wichtig wird, uns selbst wieder aufzufüllen kann nichts Neues eintreten, bis wir willentlich alles entlassen was uns nicht länger dient, vollkommen und ganz und gar in die Vergangenheit.
<G-vec00577-002-s055><fill_up.auffüllen><en> At the point where it becomes important to fill ourselves up again, nothing new can enter until we willingly release everything that no longer serves us, fully and completely into the past.
<G-vec00577-002-s056><fill_up.auffüllen><de> Ein Teil der Cenoten durchläuft folgenden Lebenszyklus: Wasser löst aus dem Kalkstein eine unterirdische Höhle; ein kleiner Teil der Decke stürzt ein; weitere Teile der Decke stürzen nach und ein schachtartiges rundes Loch mit steilen Wänden entsteht; Vegetation fällt in die Cenote und beginnt sie langsam aufzufüllen, bis eine trockene Cenote entsteht.
<G-vec00577-002-s056><fill_up.auffüllen><en> Most cenotes run through the following life cycle: Water dissolves an underground cavern; a small part of the ceiling collapses creating an opening; more of the ceiling collapses and a round hole with steep walls emerges; vegetation falls into the cenote and the hole slowly starts to fill until the cenote becomes dry.
<G-vec00984-002-s027><populate.auffüllen><de> Bei einigen desktop boards müssen Sie die Speichersteckplätze in einer bestimmten Reihenfolge auffüllen.
<G-vec00984-002-s027><populate.auffüllen><en> Some desktop boards require you to populate the memory slots in a certain order.
<G-vec00984-002-s028><populate.auffüllen><de> Wenn Sie eine Publikation erstellen, wird der Unternehmensinformationssatz, den Sie zuletzt verwendet haben, zum Auffüllen der neuen Publikation verwendet.
<G-vec00984-002-s028><populate.auffüllen><en> When you create a publication, the business information set that you have used most recently is used to populate the new publication.
<G-vec00984-002-s029><populate.auffüllen><de> Mit Hilfe dieser Anwendung kann man die Datenbank-Produktionsumgebung simulieren und unterschiedliche DB2-Datenbankentabellen mit Testdaten gleichzeitig auffüllen, Tabellen und Felder für die Erstellung der Daten definieren, Wertebereiche setzten oder DB2-Textfelder durch Maskierung erstellen, Wertelisten manuell definieren oder diese aus SQL-Abfragen erstellen, Erstellungsparameter für jedes Feldtyp festlegen und eine Vielzahl von weiteren Features zum Generieren von DB2 -Testdaten auf einfache und direkte Weise verwenden.
<G-vec00984-002-s029><populate.auffüllen><en> The utility can help you to simulate the database production environment and allows you to populate several DB2 database tables with test data simultaneously, define tables and fields for generating data, set value ranges, generate DB2 char fields by mask, define lists of values manually or select them from SQL queries, set generation parameters for each field type and has many other features to generate DB2 test data in a simple and direct way.
<G-vec00984-002-s030><populate.auffüllen><de> Der Scanvorgang hilft beim Auffüllen Ihrer verlorenen Daten.
<G-vec00984-002-s030><populate.auffüllen><en> The scanning process will help populate your lost data.
<G-vec00984-002-s031><populate.auffüllen><de> Dies ist die Datenquelle, oftmals eine Excel-Kalkulationstabelle, die zum Auffüllen der Informationen in der E-Mail-Nachricht verwendet wird.
<G-vec00984-002-s031><populate.auffüllen><en> This is the data source, often an Excel spreadsheet, that is used to populate information in the email message.
<G-vec00984-002-s032><populate.auffüllen><de> Dies ist die Datenquelle, die zum Auffüllen von Informationen in den Buchstaben verwendet wird.
<G-vec00984-002-s032><populate.auffüllen><en> This is the data source that is used to populate information in the letter.
<G-vec00984-002-s033><populate.auffüllen><de> Die Routingtabelle mit der Routinglogik für ausgehende Anrufe, die vom Server für Nummern einer Nebenstellenanlage oder eines Telefonfestnetzes (Public Switched Telephone Network, PSTN) verwendet wird, wird mit diesen Routen aufgefüllt.
<G-vec00984-002-s033><populate.auffüllen><en> These routes populate the routing table, which embodies the outbound call routing logic that is followed by the server PBX and public switched telephone network (PSTN) numbers.
<G-vec00984-002-s034><populate.auffüllen><de> Wenn der Benutzername vorhanden ist, wird es aufgefüllt, wie Sie den Benutzernamen eingeben.
<G-vec00984-002-s034><populate.auffüllen><en> If the username exists, it will populate as you're typing in the Username.
<G-vec00984-002-s035><populate.auffüllen><de> Die CSV wird hochgeladen, um die HITs (Human Intelligence Tasks) aufzufüllen und auszuführen.
<G-vec00984-002-s035><populate.auffüllen><en> The CSV is uploaded to populate and run the HITs (Human Intelligence Tasks).
<G-vec00984-002-s036><populate.auffüllen><de> Dieses Dokument enthält die Daten, die verwendet werden, um Informationen in dem Brief aufzufüllen.
<G-vec00984-002-s036><populate.auffüllen><en> This document contains the data that is used to populate information on the letter.
<G-vec01171-002-s019><fill.auffüllen><de> Ansonsten gibt es leider auch nichts Neues zu berichten, ich sehne mich nach warmen Wetter und würde liebend gerne mal wieder verreisen, aber dafür muss ich erstmal die Reisekasse wieder auffüllen und das geht nun mal nicht von heute auf morgen.
<G-vec01171-002-s019><fill.auffüllen><en> Otherwise, unfortunately, there is nothing new to report, I long for warm weather and would love to travel again, but first I have to fill up the travel fund again and that’s not going from one day to the next.
<G-vec01171-002-s020><fill.auffüllen><de> Verwenden Sie zum Auffüllen niemals Leitungswasser, diese enthält Salze und beeinträchtigt die Batteriefunktion.
<G-vec01171-002-s020><fill.auffüllen><en> Never use tap water to fill, it contains salts and degrade your battery's function.
<G-vec01171-002-s021><fill.auffüllen><de> Wenn wir das Zhuan Falun routinemäßig lernen, ohne im Geist und Herzen rein zu sein, können wir uns oftmals nicht mit dem Fa assimilieren und können unsere Körper in anderen Dimensionen nicht mit dem Fa auffüllen.
<G-vec01171-002-s021><fill.auffüllen><en> When we routinely study Zhuan Falun without a pure mind and heart, oftentimes we can´t assimilate ourselves to the Fa and cannot fill up our bodies in other dimensions with the Fa.
<G-vec01171-002-s022><fill.auffüllen><de> Kaffee-Eiswürfel in ein 300 ml-Glas geben und mit 250 ml Milch auffüllen.
<G-vec01171-002-s022><fill.auffüllen><en> Fill a 10 oz. glass with the coffee ice cubes and add 1 cup of milk.
<G-vec01171-002-s023><fill.auffüllen><de> Da wir doch schon wieder in Holland waren, musste ich einkaufen gehen und meinen Vorrat des Sommergetränks auffüllen.
<G-vec01171-002-s023><fill.auffüllen><en> As we'd been in Holland again, I had to go shopping and fill up my summer drink supply.
<G-vec01171-002-s024><fill.auffüllen><de> Auffüllen von „Lücken“ zwischen Regionen (abhängig vom Grau- oder Farbwert) oder Trennen überlappender Regionen.
<G-vec01171-002-s024><fill.auffüllen><en> Fill gaps between regions (depending on gray value or color) or split overlapping regions.
<G-vec01171-002-s025><fill.auffüllen><de> Alles in einen Topf mit Gemüsebrühe auffüllen, bis das Gemüse bedeckt ist.
<G-vec01171-002-s025><fill.auffüllen><en> Put all the ingredients together into a pot and fill it up with vegetable broth, so that it's all merely covered in it.
<G-vec01171-002-s026><fill.auffüllen><de> Egal, ob Sie ein Bauteil aushöhlen und mit einer Leichtbaustruktur auffüllen, ein Bauteil in eine Gitterstruktur umwandeln oder funktionale Oberflächen erzeugen möchten: Der anwenderfreundliche Assistent in unserem Strukturenmodul führt Sie durch jeden Schritt in diesem Arbeitsgang.
<G-vec01171-002-s026><fill.auffüllen><en> Whether you wish to hollow a part and fill it with a lightweight structure; convert a part to a lattice structure or create functional surfaces, the easy-to-use wizard in our Structures Module will guide you through every step of the way.
<G-vec01171-002-s027><fill.auffüllen><de> Wir nennen dies den "Management Werkzeugkoffer“, den unsere Studierenden vom ersten Tag des Studiums an in die Hand nehmen und in den kommenden sechs Semestern sukzessive auffüllen.
<G-vec01171-002-s027><fill.auffüllen><en> We call this the "management toolkit," which our students take in their hands from the first day of the programme and successively fill up in the following six semesters.
<G-vec01171-002-s028><fill.auffüllen><de> Die offene Menge ist die Menge, die zum Auffüllen des Auslösebestands benötigt wird.
<G-vec01171-002-s028><fill.auffüllen><en> The open quantity is the quantity that is required to fill the trigger point.
<G-vec01171-002-s029><fill.auffüllen><de> Hier können Sie Trinkwasser auffüllen und Grauwasser bequem ablassen.
<G-vec01171-002-s029><fill.auffüllen><en> Here you can fill up on drinking water and drain gray water comfortably.
<G-vec01171-002-s030><fill.auffüllen><de> Der Dispositionsvorschlag wird zum Auffüllen des Lagerbestands generiert.
<G-vec01171-002-s030><fill.auffüllen><en> The MRP suggestion is generated to fill the stock.
<G-vec01171-002-s031><fill.auffüllen><de> Wenn Sie jedoch Ihren großen Teller gegen einen kleinen austauschen und alles auffüllen, sind Sie mit der Größe der Diät vollkommen zufrieden.
<G-vec01171-002-s031><fill.auffüllen><en> But, if you change your large plate to a small one and fill it all up, you will be completely satisfied with the size of the diet.
<G-vec01171-002-s032><fill.auffüllen><de> Der Grund dafür ist, dass sich die Sole besonders gut für Verwendung in den Salzgrotten zum Auffüllen der Gradierwerke, in Wellness-Anlagen als Badewasser und in den Salzräumen und Salzkabinen zum Vernebeln eignet.
<G-vec01171-002-s032><fill.auffüllen><en> The reason for this is that the brine is particularly well suited for use in the salt caves to fill the salt works in wellness facilities as bath water and salt in the salt rooms and cabins for misting.
<G-vec01171-002-s033><fill.auffüllen><de> Den Verdampfer vorsichtig bis zum unteren Ende des Destillatablaufstutzens (4) auffüllen.
<G-vec01171-002-s033><fill.auffüllen><en> carefully fill the evaporator up to the lower edge of the distillate drain tube (4)
<G-vec01171-002-s034><fill.auffüllen><de> Apfel, Rote Beete, Honig, Ingwer und Zitronensaft miteinander pürieren/mixen und mit Mineralwasser auffüllen.
<G-vec01171-002-s034><fill.auffüllen><en> Puree the apple, beetroot, honey, ginger and lemon juice and fill up with mineral water.
<G-vec01171-002-s035><fill.auffüllen><de> In der Grube anfallendes Abraummaterial dient zum Auffüllen von Hohlräumen.
<G-vec01171-002-s035><fill.auffüllen><en> All material excavated in the mine is used to fill up cavities.
<G-vec01171-002-s036><fill.auffüllen><de> Oder, wenn es die Zeit erlaubt, mit Aquariumsilikon auffüllen.
<G-vec01171-002-s036><fill.auffüllen><en> Or, if time permits, fill with aquarium silicone.
<G-vec01171-002-s037><fill.auffüllen><de> Das Allerbeste ist übrigens, dass man das leegefischte Glas ganz einfach nochmal mit geschnippeltem Gemüse auffüllen kann.
<G-vec01171-002-s037><fill.auffüllen><en> The best thing is that you can easily fill up the emptied jar with veggies again.
