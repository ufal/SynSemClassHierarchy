<G-vec00599-002-s019><crumble.abbröckeln><de> Die Wände sind an vielen Stellen feucht, wodurch auch die Farbe zum Teil abbröckelt.
<G-vec00599-002-s019><crumble.abbröckeln><en> The walls are damp in many places, causing the color to crumble at certain areas.
<G-vec00599-002-s020><crumble.abbröckeln><de> Der Gloss ist natürlich nicht cremig, aber das sind andere langanhaltende Lippenstifte auch nicht und müssen sogar oft mit einem beiliegenden Gloss nachgefettet werden damit die Farbe nicht abbröckelt.
<G-vec00599-002-s020><crumble.abbröckeln><en> This gloss is of course not creamy at all, but other long lasting lipssticks neither are and with most other long lasting lip sticks you will have to re-moist them with a special balm or gloss so that they won’t dry out and crumble.
