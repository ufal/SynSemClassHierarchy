<G-vec00296-002-s017><halve.aufschneiden><de> Vor dem Backen mit Hagelsalz bestreuen, nach dem Backen aufschneiden und mit Käse, Wurst oder Lachs und Salat belegen.
<G-vec00296-002-s017><halve.aufschneiden><en> Sprinkle with pretzel salt before baking or halve and fill with cheese, cold meat or salmon and salad after baking.
