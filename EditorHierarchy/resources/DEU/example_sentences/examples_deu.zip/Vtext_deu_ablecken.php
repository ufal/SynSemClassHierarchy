<G-vec00828-002-s023><lick.ablecken><de> Des weiteren muss die Grand elegante Dame ihrer Herrin die Latexstiefel ablecken.
<G-vec00828-002-s023><lick.ablecken><en> Furthermore, the grand elegant lady of her mistress lick the latex boots.
<G-vec00828-002-s024><lick.ablecken><de> Um seine Schmach noch mehr zu erhhen benetzt Goddess Gloria Joschis dreckige Hnde und fordert ihn auf ihre Fe sauber zu wischen noch bevor er seine Finger ablecken kann.
<G-vec00828-002-s024><lick.ablecken><en> To humiliate him even further Goddess Gloria wets his dirty hands. Before he can lick up the drops she orders him to clean her foot with his wet hands.
<G-vec00828-002-s025><lick.ablecken><de> Du mußt meine Socken und Tunrschuhe riechen, ablecken und ganz genau ansehen.
<G-vec00828-002-s025><lick.ablecken><en> You have to sniff, lick and watch my shoes and socks closely.
<G-vec00828-002-s026><lick.ablecken><de> Er muss die Seiten ablecken, die Spitze der Stiefeln mit den Lippen blasen und die Absätze lutschen.
<G-vec00828-002-s026><lick.ablecken><en> He must the top the boots lick the sides off, blow and suck the heels with the lips.
<G-vec00828-002-s027><lick.ablecken><de> Er muss ihre Fußsohlen ablecken, die Fersen küssen und ihre Zehen lutschen, damit auch der Dreck von ihren schönen Füssen weg ist.
<G-vec00828-002-s027><lick.ablecken><en> He has to lick her soles, heel kiss and suck her toes, so that the dirt is gone from her beautiful feet.
<G-vec00828-002-s028><lick.ablecken><de> Der Diktator darf eine Karte ablecken und sie an seine Stirn kleben.
<G-vec00828-002-s028><lick.ablecken><en> The dictator is allowed to lick a card and stick it to his forehead.
<G-vec00828-002-s066><lick.ablecken><de> Die Dosis wie unter Abschnitt 4.9 beschrieben an einer Körperstelle auftragen, von der die Katze sie nicht ablecken kann.
<G-vec00828-002-s066><lick.ablecken><en> Apply the dose to an area where the cat cannot lick it off, as described in section 4.9.
<G-vec00828-002-s183><lick.ablecken><de> Mit deiner Sklavenzunge wirst du alles ablecken.
<G-vec00828-002-s183><lick.ablecken><en> You'll lick everything clean with your slave tongue.
<G-vec00828-002-s185><lick.ablecken><de> Sie spuckt kräftig auf den Boden, drückt das Sklavengesicht nach unten und lässt es von ihm direkt ablecken.
<G-vec00828-002-s185><lick.ablecken><en> She spits on the floor and presses his slave face right next to it? so he can lick it up!
