<G-vec00254-002-s029><sway.aufschaukeln><de> Für eine sichere Fahrt verhindert der serienmäßige AKSSpurstabilisator Schlingerbewegungen und damit auch das gefährliche Aufschaukeln des Gespannes.
<G-vec00254-002-s029><sway.aufschaukeln><en> For a safe journey, the series AKS stabiliser eliminates swerving motions and thereby the dangerous sway of the vehicle.
<G-vec00298-002-s096><swell.aufschaukeln><de> Bei einer Beschädigung des Datenstroms oder des JPEG-Headers, kann es vorkommen, dass die Farbwerte sich aufschaukeln und den zulässigen Farbraum verlassen.
<G-vec00298-002-s096><swell.aufschaukeln><en> If the data stream or the JPEG header is damaged, it can happen that the color values swell and leave the permitted color space.
