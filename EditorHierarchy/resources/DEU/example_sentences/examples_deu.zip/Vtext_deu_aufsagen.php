<G-vec00690-002-s022><recite.aufsagen><de> Lassen Sie die Kinder noch einmal Moroni 10:5 aufsagen, und fordern Sie sie auf, diese Schriftstelle auch zu Hause zu wiederholen.
<G-vec00690-002-s022><recite.aufsagen><en> Have the children recite Moroni 10:5 again, and encourage them to share it with their families.
<G-vec00690-002-s023><recite.aufsagen><de> Kira kann ein Gedicht aufsagen, ein Lied singen und sogar tanzen, aber nur auf ihre eigene Art, im Kinderwagen sitzend.
<G-vec00690-002-s023><recite.aufsagen><en> Kira can recite the poem, sing a song and even dance, but only in her own way, sitting in a stroller.
<G-vec00690-002-s024><recite.aufsagen><de> Ich sagte: „Dann werde ich sie nie aufsagen.
<G-vec00690-002-s024><recite.aufsagen><en> I said, "Then I won't recite any more.
<G-vec00690-002-s025><recite.aufsagen><de> In meinen Dorf gibt es einen Falun Gong Praktizierenden, der zu mir sagte, "Du sollst ‚Falun Gong ist gut’ aufsagen.
<G-vec00690-002-s025><recite.aufsagen><en> In my village there is a Falun Dafa practitioner who told me, "You should recite Falun Dafa is good, 'Truthfulness, Compassion, Forbearance' is good.
<G-vec00690-002-s026><recite.aufsagen><de> Auch kann der Ehemann das Ärzteteam immer wieder aufsagen: Es kommt oft vor, dass eine Frau die Muttersprache besser wahrnimmt und den Anweisungen klarer folgt.
<G-vec00690-002-s026><recite.aufsagen><en> Also, the husband can repeatedly recite the team of doctors: it often happens that a woman perceives the native voice better and follows the instructions more clearly.
<G-vec00690-002-s027><recite.aufsagen><de> Ein Gedicht aufsagen oder ein/mehrere Gstanzl singen.
<G-vec00690-002-s027><recite.aufsagen><en> Recite a poem or sing one or more songs.
<G-vec00690-002-s029><recite.aufsagen><de> Der es fertigbrachte, mit seiner alten Stimme vor 12 000 Menschen ein Gedicht aufzusagen, und alle waren still.
<G-vec00690-002-s029><recite.aufsagen><en> by robby » With his old voice he managed to recite a poem in front of a crowd of 12000 and the hall went quiet.
<G-vec00690-002-s030><recite.aufsagen><de> Die mit Äxten und Messern bewaffneten Angreifer hielten auf der Suche nach Nichtmuslimen Fahrzeuge auf der Straße an und zwangen die Insassen muslimische Gebete aufzusagen.
<G-vec00690-002-s030><recite.aufsagen><en> Armed with machetes and knives the aggressors stopped cars looking for Christians and made people recite Muslim prayers to prove their identity.
<G-vec00690-002-s031><recite.aufsagen><de> Da ich keine Verbrechen begangen hatte, weigerte ich mich, die Gefängnisregeln aufzusagen.
<G-vec00690-002-s031><recite.aufsagen><en> Because I did not commit any crimes, I refused to recite the prison regulations.
<G-vec00690-002-s032><recite.aufsagen><de> Nach drei Runden fühlten sie sich inspiriert und begannen zu schreiben und Gedichte aufzusagen, um ihren literarischen Fähigkeiten Ausdruck zu verleihen.
<G-vec00690-002-s032><recite.aufsagen><en> After three rounds, inspiration struck them. They began to write and recite poems to show off their literary skills.
<G-vec00690-002-s035><recite.aufsagen><de> tweet e-mail Stellen Sie sich vor, Sie hätten im Kindergarten die Monatsnamen nicht auswendig aufgesagt; sondern stattdessen den Jahresverlauf über den Himmel erfahren, indem Sie beobachteten, welche Sterne am Morgen aufgehen.
<G-vec00690-002-s035><recite.aufsagen><en> tweet e-mail Imagine you didn't recite the names of the months in kindergarten; instead you learned about the year through the sky, watching the morning stars rise.
<G-vec00690-002-s036><recite.aufsagen><de> Stellen Sie sich vor, Sie hätten im Kindergarten die Monatsnamen nicht auswendig aufgesagt; sondern stattdessen den Jahresverlauf über den Himmel erfahren, indem Sie beobachteten, welche Sterne am Morgen aufgehen.
<G-vec00690-002-s036><recite.aufsagen><en> Imagine you didn't recite the names of the months in kindergarten; instead you learned about the year through the sky, watching the morning stars rise.
<G-vec00690-002-s037><recite.aufsagen><de> Sie konnte unzählige Gedichte und sämtliche Strophen einer Reihe alter Volkslieder auswendig aufsagen.
<G-vec00690-002-s037><recite.aufsagen><en> She could recite a great number of poems by heart and knew all the verses of many old broadsheet ballads.
<G-vec00690-002-s038><recite.aufsagen><de> Er konnte das ganze Buch auswendig aufsagen.
<G-vec00690-002-s038><recite.aufsagen><en> He could recite the entire book.
<G-vec00690-002-s041><recite.aufsagen><de> Ich lade Sie noch mal ein, über das Wort Gottes nachzudenken, damit Sie sich nicht darauf beschränken, es wie Papageien aufzusagen ohne etwas davon zu begreifen.
<G-vec00690-002-s041><recite.aufsagen><en> Once more I invite you to meditate very well on the word of God, and do not merely recite it like parrots without understanding anything.
<G-vec00690-002-s060><recite.aufsagen><de> Bitten Sie jemand, den vierten Glaubensartikel aufzusagen.
<G-vec00690-002-s060><recite.aufsagen><en> Invite a class member to recite the fourth article of faith.
<G-vec00690-002-s112><recite.aufsagen><de> Gedichte aus dem Stegreif aufzusagen, das wäre was.
<G-vec00690-002-s112><recite.aufsagen><en> To recite poems out of the blue, that would be cool!
<G-vec00690-002-s114><recite.aufsagen><de> Und wir schämen uns, wenn wir uns bewusst werden, dass unser Lebensstil das verleugnet hat und verleugnet, was wir mit unserer Stimme aufsagen.
<G-vec00690-002-s114><recite.aufsagen><en> We feel shame when we realize that our style of life has denied, and continues to deny, the words we recite.
<G-vec00957-002-s048><suck.aufsagen><de> Sobald man sie betäubt hat, muss man sie also nur noch aufsagen.
<G-vec00957-002-s048><suck.aufsagen><en> Once you get them stunned, all you have to do is suck them up.
