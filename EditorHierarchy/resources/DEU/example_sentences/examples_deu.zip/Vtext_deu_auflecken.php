<G-vec00828-002-s036><lick.auflecken><de> Egal wann, wo und wie viel die Ladys rotzen, er wird es auflecken.
<G-vec00828-002-s036><lick.auflecken><en> No matter when, where, and how much the ladies spits, he will lick it up.
<G-vec00828-002-s037><lick.auflecken><de> Joschi muss alles auflecken.
<G-vec00828-002-s037><lick.auflecken><en> Joschi must lick up everything.
