<G-vec00869-002-s020><stare.anstarren><de> Nun, Ihr könnt Euch vor mich stellen und mich anstarren, wie Ihr es gerade tut.
<G-vec00869-002-s020><stare.anstarren><en> Well, you could stand there like you're doing now and just stare at me.
<G-vec00869-002-s021><stare.anstarren><de> Auf dem Balkon kann man stundenlang sitzen und den Fjord anstarren oder die Berge - das ist einmalig und reißt die sehr einfache Ausstattung des Hauses wieder raus.
<G-vec00869-002-s021><stare.anstarren><en> On the balcony you can sit for hours and stare at the fjord or the mountains - that is unique and tears the very simple equipment of the house out again.
<G-vec00869-002-s022><stare.anstarren><de> Offenbar, hat in diesem Punkt die magische Funktion des Auges gegen mich gearbeitet.Auf den Marktplätzen von Bissau und Kap Verde konnte ich sie mit Gleichberechtigung anstarren: Ich sehe sie, sie sah mich, sie weiß, dass ich sehe sie, sie wirft mir einen Blick zu, aber nur in einem Winkel, wo es noch möglich ist so zu tun, als ob er nicht mir galt, und am Ende der echte Blick, direkt, er dauerte ein Vierundzwanzigstel einer Sekunde, die Länge eines Filmframes.
<G-vec00869-002-s022><stare.anstarren><en> Apparently, the magical function of the eye was working against me there. It was in the marketplaces of Bissau and Cape Verde that I could stare at them again with equality: I see her, she saw me, she knows that I see her, she drops me her glance, but just at an angle where it is still possible to act as though it was not addressed to me, and at the end the real glance, straightforward, that lasted a twenty-fourth of a second, the length of a film frame.
<G-vec00869-002-s023><stare.anstarren><de> Paulus musste ihn, während er sprach, anstarren um den Glauben des Mannes wahrzunehmen.
<G-vec00869-002-s023><stare.anstarren><en> Paul had to stare at him while he spoke to perceive the man's faith.
<G-vec00869-002-s024><stare.anstarren><de> Diese können sehr hilfreich und weniger ermüdend sein, als wenn Sie alle anstarren und versuchen, alles in Einklang zu bringen.
<G-vec00869-002-s024><stare.anstarren><en> These can be quite helpful and less tiresome than having everyone stare at you while trying to get everything in line.
<G-vec00869-002-s025><stare.anstarren><de> Fakt ist jedoch, dass Hunde es verstehen wenn wir sie anknurren, anstarren, uns groß machen oder mit dem Körper blocken.
<G-vec00869-002-s025><stare.anstarren><en> It is, however, a fact that dogs understand when we snarl at them or stare at them, when we make ourselves big or block them with our body.
<G-vec00869-002-s026><stare.anstarren><de> Du musst die Menschen nicht anstarren, aber du musst einen guten Blickkontakt zu Menschen herstellen, wenn du mit ihnen sprichst und ihnen zuhörst.
<G-vec00869-002-s026><stare.anstarren><en> You don’t need to stare at people, but you do need to make good eye contact with people when you are talking and listening to them.
<G-vec00869-002-s027><stare.anstarren><de> Ich konnte sie nur mit fassungsloser Überraschung anstarren.
<G-vec00869-002-s027><stare.anstarren><en> I could only stare at her in stupid surprise.
<G-vec00869-002-s028><stare.anstarren><de> Twitter-Nutzer Wenn ich sehe, wie manche Männer Frauen anstarren und wie schlecht sie sich benehmen, glaube ich nicht, dass Vergewaltigungen und Belästigungen in diesem Land jemals zurückgehen werden.
<G-vec00869-002-s028><stare.anstarren><en> When I see some men stare & misbehave with women on a Delhi Metro I don't think rapes and assaults are going to ever reduce in this land!
<G-vec00869-002-s029><stare.anstarren><de> Zum 3 x einen Blog besuchen und immer die selbe Seite anstarren ist nicht gerade spannend.
<G-vec00869-002-s029><stare.anstarren><en> 3 x visit your blog and always stare at the same page is not exactly exciting.
<G-vec00869-002-s030><stare.anstarren><de> Für den bizarren, bittersüßen Rest der Geschichte werde ich David Troupes mit großen Augen eine Weile wortlos anstarren, sollte ich ihm jemals begegnen.
<G-vec00869-002-s030><stare.anstarren><en> What follows is so bizarre and bittersweet that, should I ever happen upon David Troupes, I will stare at him wordless and wide-eyed for a while.
<G-vec00869-002-s031><stare.anstarren><de> Wegen den Kommilitonen, die sich neben mich setzen und mich 90 Minuten lang einfach nur anstarren.
<G-vec00869-002-s031><stare.anstarren><en> Because of the fellow students who sit next to me and just stare at me for 90 minutes.
<G-vec00869-002-s032><stare.anstarren><de> "Wenn mich anstarren Enttäuschungen in Gesicht und ich sehe nicht ein Hoffnungsschimmer, wende ich mich an Bhagavad Gita.
<G-vec00869-002-s032><stare.anstarren><en> "When disappointments stare me in face & I see not one ray of hope, I turn to Bhagavad-Gita.
<G-vec00869-002-s033><stare.anstarren><de> Schau sie dir doch an, wie sie mich anstarren, deine feinen Herren Freunde.
<G-vec00869-002-s033><stare.anstarren><en> Look how they stare at me, those fine gentlemen friends.
<G-vec00869-002-s034><stare.anstarren><de> Wenn derjenige dich kalt und leer anstarrt, um dich einzuschüchtern und es ihm nicht leid tut, dass du nervös wirst, dann hast du es wahrscheinlich mit einem Soziopathen zu tun.
<G-vec00869-002-s034><stare.anstarren><en> If the person uses a cold, blank stare to intimidate you, and shows no remorse for your nervousness, you are probably dealing with a sociopath. Part 2
<G-vec00869-002-s035><stare.anstarren><de> „Nein, ich hab mir selbst geholfen!“, meinte ich leise, was dazu führte, dass er mich mit offenem Mund anstarrte.
<G-vec00869-002-s035><stare.anstarren><en> "No, I helped myself!" I corrected softly, causing him to stare at me with his mouth open, dropping his mask a little bit more.
<G-vec00869-002-s036><stare.anstarren><de> Wenn man Zeit hat, das Monster anzustarren, sieht man, wie billig der ganze Effekt ist.
<G-vec00869-002-s036><stare.anstarren><en> If you have time to stare at the monster, you see how cheap the whole effect is.
<G-vec00869-002-s037><stare.anstarren><de> Dunkle Höhlen scheinen den Betrachter wie Augen anzustarren und sorgen zusätzlich für kalte Schauer beim Anblick des Halloween-Skulls, dessen Mund wie für ein fieses Lachen geöffnet scheint.
<G-vec00869-002-s037><stare.anstarren><en> Dark caves seem to stare at the viewer like eyes and additionally cause cold showers when looking at the Halloween skull, whose mouth seems to be open for a nasty laugh.
<G-vec00869-002-s038><stare.anstarren><de> Achte darauf sie nicht ständig anzustarren.
<G-vec00869-002-s038><stare.anstarren><en> Make sure you don't stare at her constantly.
<G-vec00869-002-s039><stare.anstarren><de> Hilf ihm, Frauen anzustarren, ohne erwischt zu werden.
<G-vec00869-002-s039><stare.anstarren><en> Your task is to help him stare his way through to women without getting caught.
<G-vec00869-002-s040><stare.anstarren><de> Menschen, die unter Schlaflosigkeit leiden, wissen sehr gut, wie es ist, plötzlich in Mitten der Nacht aufzuwachen und stundenlang die Decke anzustarren, in der Hoffnung wieder einschlafen zu können.
<G-vec00869-002-s040><stare.anstarren><en> People who suffer from insomnia know very well what it’s like to wake up all of a sudden in the middle of the night and stare at the ceiling for hours trying to get back to sleep.
<G-vec00869-002-s084><stare.anstarren><de> Bei anderer Gelegenheit, wenn seine stoischen Performances von den Behörden gnädigerweise [wenngleich häufig verständnislos] toleriert wurden, waren es Passanten, die durch seine Präsenz irritiert wurden und in ihrem zielgerichtete Vorüberschreiten innehielten, um ihn anzustarren und herauszufinden, was genau hier eigentlich vor sich ging.
<G-vec00869-002-s084><stare.anstarren><en> On other occasions, where his stoic performances were graciously [even if often uncomprehendingly] tolerated by the authorities, it was the passersby who became engaged by his presence, interrupting their purposive passage to stare and inquire in an attempt to establish what exactly was going on.
<G-vec00869-002-s089><stare.anstarren><de> Und die mit den bunten Vögel bemalten Wände des Lokals sind so wunderschön, die könnte man stundenlang anstarren.
<G-vec00869-002-s089><stare.anstarren><en> And the with colorful birds painted walls of the location are so beautiful, you can stare at them for hours.
<G-vec00869-002-s092><stare.anstarren><de> Nichts zu tun als meine Frau anzustarren und zu versuchen sie zu irritieren.
<G-vec00869-002-s092><stare.anstarren><en> Nothing to do but stare at the wife and try not to irritate her.
<G-vec00869-002-s112><stare.anstarren><de> Als sie sah wie Dash sie anstarrte, schluckte Pinkie den Bissen schnell herunter.
<G-vec00869-002-s112><stare.anstarren><en> Noticing Dash’s stare, Pinkie quickly gulped the morsel down. “What?”
