<G-vec00503-002-s020><plead.anklopfen><de> Es verging ja kaum ein Monat, wo nicht irgendjemand angeblich anklopfte, um Aufnahme im Deutschen Reich zu finden.
<G-vec00503-002-s020><plead.anklopfen><en> Hardly a month passed in which somebody didn't allegedly plead to be incorporated into the German Empire.
<G-vec01035-002-s032><knock.anklopfen><de> An jede Tür werden Meine Boten anklopfen, denn Ich sende sie voraus, so daß Ich geöffnete Türen finde, wenn Ich Selbst komme zu euch.
<G-vec01035-002-s032><knock.anklopfen><en> My messengers will knock on every door, for I send them ahead, so that I find opened doors, when I myself come to you.
<G-vec01035-002-s033><knock.anklopfen><de> Eine weitere Tür zum Anklopfen in Sydney.
<G-vec01035-002-s033><knock.anklopfen><en> Another door to knock on in Sydney.
<G-vec01035-002-s034><knock.anklopfen><de> Wir werden auf jeden Fall wieder bei Andreas und Silvia anklopfen bei unserem nächsten Aufenthalt.
<G-vec01035-002-s034><knock.anklopfen><en> We will knock definitely be back at Andrew and Silvia on our next visit.
