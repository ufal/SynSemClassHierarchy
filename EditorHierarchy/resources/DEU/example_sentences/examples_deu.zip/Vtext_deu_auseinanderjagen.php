<G-vec00910-002-s030><disperse.auseinanderjagen><de> Danach gab es keine Demo mehr, es gab nichts mehr zum Auseinanderjagen.
<G-vec00910-002-s030><disperse.auseinanderjagen><en> By then, there was no demonstration at all, nothing to disperse.
