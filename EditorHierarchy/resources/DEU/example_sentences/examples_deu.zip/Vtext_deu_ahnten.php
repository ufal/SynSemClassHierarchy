<G-vec00345-001-s022><reckon.ahnten><de> Sie ahnten nichts von der grossartigen Energie, die die russische Arbeiterklasse aus ihrer Eigenschaft als Sektion des europäischen Proletariats zog.
<G-vec00345-001-s022><reckon.ahnten><en> They did not reckon with the formidable energy which the Russian working class drew from its position as a section of the European proletariat.
