<G-vec00942-002-s020><forsake.abkehren><de> {T}: Unerhörte Reichtümer erwarten jene, die sich vom Trubel der Welt abkehren, um die geheimen, stillen Orte zu suchen.
<G-vec00942-002-s020><forsake.abkehren><en> Untold riches await those who forsake the bustling world to search the secret, silent places.
