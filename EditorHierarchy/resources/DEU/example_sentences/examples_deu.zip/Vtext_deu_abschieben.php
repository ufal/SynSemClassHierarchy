<G-vec00555-002-s017><deport.abschieben><de> Als überraschend die Polizei auftauchte, um ihn zu abzuschieben, wollte der Flüchtling im Falle einer Festnahme Selbstmord begehen und versuchte, aus dem fünften Stockwerk des Hauses zu springen.
<G-vec00555-002-s017><deport.abschieben><en> As the police came surprisingly to deport him this morning, This refugee wanted to take suicide in case of any arrest, by trying to jump down from the fifth floor of the building.
<G-vec00555-002-s020><expel.abschieben><de> Im November verabschiedete das Kabinett eine Verordnung, nach der die Regierung bis Ende des Jahres 2015 1,6 Millionen Ausländer abschieben kann, die „sich illegal im Iran aufhalten“.
<G-vec00555-002-s020><expel.abschieben><en> In November 2012, the Iranian cabinet of ministers issued a regulation allowing the government to expel 1.6 million foreigners “illegally residing in Iran” by the end of 2015.
<G-vec00942-002-s083><relinquish.abschieben><de> Er schiebt seine Verantwortung oder Autorität nicht an seine Frau ab.
<G-vec00942-002-s083><relinquish.abschieben><en> He does not relinquish responsibility or authority to his wife.
