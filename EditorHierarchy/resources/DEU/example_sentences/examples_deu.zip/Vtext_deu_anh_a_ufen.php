<G-vec00443-001-s066><accumulate.anhäufen><de> Zur Jagd nach Maximalprofit braucht der Kapitalismus den Faschismus, um den Reichtum bis ins Gigantische vermehren und anhäufen zu können - bis zu dem endgültigen Punkt, wo der Kapitalismus sich selber vernichtet (»Es ist dies die Aufhebung der kapitalistischen Produktionsweise innerhalb der kapitalistischen Produktionsweise selbst und damit ein sich selbst aufhebender Widerspruch« [Karl Marx, Das Kapital, Bd.
<G-vec00443-001-s066><accumulate.anhäufen><en> "To hunt for maximum profit, capitalism needs fascism in order to increase and accumulate wealth to the gigantic - to the final point where capitalism destroys itself (""It is the abolition of capital as private property within the framework of the capitalist mode of production itself."""
<G-vec00443-001-s067><accumulate.anhäufen><de> Je weiter hinauf es einer von ihnen geschafft hatte, umso mehr Pfründen konnte er anhäufen.
<G-vec00443-001-s067><accumulate.anhäufen><en> The higher one of them had climbed the more benefices he could accumulate.
<G-vec00443-001-s068><accumulate.anhäufen><de> In diesem Falle wird die geschlechtliche Zuchtwahl, welche von einem im höchsten Grade der Veränderung ausgesetzten Elemente abhängt, nämlich von dem Geschmacke oder der Bewunderung des Weibchens, neue Far-benschattirungen oder andere Verschiedenheiten gefunden haben, auf welche sie wirken und welche sie anhäufen konnte; und da geschlechtliche Zuchtwahl beständig in Wirksamkeit ist, so würde es, — nach dem, was wir von den Resultaten der unbewussten Zuchtwahl seitens des Menschen in Bezug auf domesticirte Thiere wissen, — eine überraschende Thatsache sein, wenn Thiere, welche getrennte Bezirke bewohnen, welche sich niemals kreuzen und hierdurch ihre neuerlich erlangten Charactere verschmelzen können, nicht nach einem genügenden Zeiträume verschiedenartig modificirt würden.
<G-vec00443-001-s068><accumulate.anhäufen><en> In this case sexual selection, which depends on an element liable to change—the taste or admiration of the female—will have had new shades of colour or other differences to act on and accumulate; and as sexual selection is always at work, it would (from what we know of the results on domestic animals of man's unintentional selection), be surprising if animals inhabiting separate districts, which can never cross and thus blend their newly-acquired characters, were not, after a sufficient lapse of time, differently modified.
<G-vec00443-001-s069><accumulate.anhäufen><de> """Es ist zweifellos ungerecht, dass ein paar Privilegierte weiterhin Güter im Übermaß anhäufen und verfügbare Ressourcen vergeuden, während Massen von Menschen im Elend leben - an der untersten Überlebensgrenze."
<G-vec00443-001-s069><accumulate.anhäufen><en> """It is manifestly unjust that a privileged few should continue to accumulate excess goods, squandering available resources, while masses of people are living in conditions of misery at the very lowest level of subsistence."
<G-vec00443-001-s070><accumulate.anhäufen><de> Das Unbewusste selbst hat dieses Symbol (der Shri Lakshmi) für uns hervorgebracht, damit wir verstehen, dass Reichtümer nicht für Menschen gedacht sind, die Reichtümer anhäufen wollen.
<G-vec00443-001-s070><accumulate.anhäufen><en> 34:27 This symbol was given to us through the unconscious itself has prepared this symbol for us to understand that riches are not with the people who accumulate money.
<G-vec00443-001-s071><accumulate.anhäufen><de> Das Volk von ́Ad glaubte, ähnlich wie die Leute heutzutage, dass der Sinn des Lebens im Anhäufen von Reichtum, Ansehen und Besitz besteht.
<G-vec00443-001-s071><accumulate.anhäufen><en> The people of Aad, much like many people today, believed that the purpose of life was to accumulate wealth, prestige, and possessions.
<G-vec00443-001-s072><accumulate.anhäufen><de> Die ungezügelte Gier der KPC übertrifft sogar noch die der herkömmlichen bösartigen Sekten, die einfach nur Vermögen anhäufen.
<G-vec00443-001-s072><accumulate.anhäufen><en> The CCP’s wild ambition far surpasses that of the ordinary evil cults who simply accumulate money.
<G-vec00443-001-s073><accumulate.anhäufen><de> In einer Umgebung ohne räumliche Struktur, wie etwa im Blut, können sich genetische Veränderungen relativ schnell ausbreiten und anhäufen.
<G-vec00443-001-s073><accumulate.anhäufen><en> In an environment without any spatial structure, for example in the blood, genetic mutations can propagate and accumulate relatively fast.
<G-vec00443-001-s074><accumulate.anhäufen><de> Sie sollten sich hier und jetzt hauptsächlich auf das Anhäufen von Chips konzentrieren.
<G-vec00443-001-s074><accumulate.anhäufen><en> Your objective should be to accumulate chips – staying at or above the average stack.
<G-vec00443-001-s002><amass.anhäufen><de> Eine dritte Tatsache ist, dass das Ergebnis heute nicht erhöht und es ist schwieriger, Eigentum anhäufen heute als in der Zeit unserer Väter.
<G-vec00443-001-s002><amass.anhäufen><en> A third fact is that earnings today are not increasing and it is more difficult to amass property today than in the time of our fathers.
<G-vec00443-001-s003><amass.anhäufen><de> Weil es eine Menge Menschen gibt, die das Geheimnis des Kapitalismus kennen — dass man eine Menge Geld anhäufen kann - durch das Unterdrücken oder Ausbeuten oder Manipulieren von Anderen (wie den 99 Prozent der Weltbevölkerung, die sich nur 4 Prozent des Reichtums der Welt teilen).
<G-vec00443-001-s003><amass.anhäufen><en> Because there are a lot of people who know the secret of capitalism — that you can amass a lot of money by oppressing or exploiting or manipulating others (like the 99 percent of the world's population who shares only 4 percent of the world's wealth).
<G-vec00443-001-s004><amass.anhäufen><de> Das Zeichen der Hass auf dieser Welt ist, dass man nicht anhäufen weiß nichts davon, außer für Rückstellungen und was Sie brauchen, um sicher mit in das Jenseits zu gelangen.
<G-vec00443-001-s004><amass.anhäufen><en> "The sign of hatred for this world is that you do not amass any of it except for provisions and what you need to arrive safely with in the Everlasting Life."""
<G-vec00443-001-s075><accumulate.anhäufen><de> Es ist notwendig damit sich das Wasser vom Kondensat oder dem Begießen der Farben unter dem Fensterrahmen nicht anhäufte, und floss ab.
<G-vec00443-001-s075><accumulate.anhäufen><en> It is necessary in order that water from condensate or watering of flowers did not accumulate under a window frame, and flew down.
<G-vec00443-001-s076><accumulate.anhäufen><de> Es wird damit sich das Medikament auf der hinteren Wand die Schlücke nicht anhäufte, und geriet sofort in die Lungen.
<G-vec00443-001-s076><accumulate.anhäufen><en> It becomes in order that medicine did not accumulate on a back wall of a throat, and got at once to lungs.
<G-vec00443-001-s112><accumulate.anhäufen><de> Yahennis Penthouse lag hoch genug, um ihnen ein spektakuläres Panorama zu bieten, und Gideon fragte sich kurz, mit welchen Mitteln es einem Geschöpf, dessen Lebensspanne derart kurz war, wohl gelingen mochte, einen solchen Reichtum anzuhäufen – und dann wischte der Anblick Ghirapurs seine Gedanken fort.
<G-vec00443-001-s112><accumulate.anhäufen><en> Yahenni's penthouse was tall enough to offer them a spectacular view, and Gideon marveled briefly at how any being could accumulate such wealth in so short a life—just before the sight of Ghirapur stole away his thoughts.
<G-vec00443-001-s113><accumulate.anhäufen><de> Die Menge destruktiver Handlungen jedoch, die dieser Kaufmann begangen hat, während er von Land zu Land reiste, um diesen Reichtum anzuhäufen, mag enorm sein.
<G-vec00443-001-s113><accumulate.anhäufen><en> In terms of the amount of destructive actions this merchant has done to accumulate this wealth as he traveled from country to country, it may be enormous.
<G-vec00443-001-s114><accumulate.anhäufen><de> Wir sind so damit beschäftigt glücklich zu sein und uns gut zu fühlen und wir arbeiten hart daran, Geld anzuhäufen und machen uns damit zur Zielscheibe von Dieben.
<G-vec00443-001-s114><accumulate.anhäufen><en> We are so concerned with being happy and comfortable, and working hard to accumulate money, that we set ourselves up as targets for thieves.
<G-vec00443-001-s115><accumulate.anhäufen><de> In dem Buch De arte bene moriendi – Von der Kunst, selig zu sterben – zum Beispiel rät er als sichere Richtschnur für ein gutes Leben und auch für ein gutes Sterben, oft und ernsthaft daran zu denken, daß man vor Gott Rechenschaft ablegen muss für seine Taten und seine Lebensweise, und danach zu streben, keine Reichtümer auf Erden anzuhäufen, sondern mit Einfachheit und Liebe zu leben, um Güter im Himmel zu schaffen.
<G-vec00443-001-s115><accumulate.anhäufen><en> In his book De arte bene moriendi — the art of dying a good death — for example, he points out as a reliable norm for a good life and also for a good death regular and serious meditation that should account to God for one’s actions and one’s way of life, and seek not to accumulate riches on this earth but rather to live simply and charitably in such a way as to lay up treasure in Heaven.
<G-vec00443-001-s116><accumulate.anhäufen><de> In diesem System ist der einzige Weg für die übrige Welt Vermögenswerte und Reserven in US-Dollar anzuhäufen und für die USA ein Außenhandelsdefizit zu fahren.
<G-vec00443-001-s116><accumulate.anhäufen><en> Under this system, the only way for the rest of the world to accumulate dollar assets and reserves is for the US to run an external deficit.
<G-vec00443-001-s117><accumulate.anhäufen><de> »Bei Goldman... wurde die Idee des Commodity Index Fund geboren, womit sie tatsächlich in der Lage waren, gewaltige Mengen Bargeld für sich selbst anzuhäufen...
<G-vec00443-001-s117><accumulate.anhäufen><en> With Goldman... the idea of the Commodity Index Fund was born, so they were actually able to accumulate tremendous amounts of cash for themselves...
<G-vec00443-001-s118><accumulate.anhäufen><de> Solange ein jeder danach trachtet, für sich anzuhäufen, wird es niemals Gerechtigkeit geben.
<G-vec00443-001-s118><accumulate.anhäufen><en> As long as everyone seeks to accumulate for themselves, there will be no justice.
<G-vec00443-001-s119><accumulate.anhäufen><de> Ressourcen anzuhäufen und zu verschwenden ist nur in einer Gesellschaft ein Selektionsvorteil, in der die Ressourcen nicht unter allen gleich aufgeteilt werden.
<G-vec00443-001-s119><accumulate.anhäufen><en> The ability to accumulate and overconsume resources is a reproductive advantage only in a society where resources are not equitably shared.
<G-vec00443-001-s120><accumulate.anhäufen><de> Der Pfad Kilesas anzuhäufen ist leicht – weil uns unsere Neigungen zum Narren halten und uns denken lassen es sei leicht.
<G-vec00443-001-s120><accumulate.anhäufen><en> The path to accumulate defilement is easy — because our preferences fool us into thinking it's easy.
<G-vec00443-001-s008><amass.anhäufen><de> Der Aktionsplan besteht darin, genügend Beweise anzuhäufen, um diese Verbrecher zu verhaften.
<G-vec00443-001-s008><amass.anhäufen><en> The plan of action has been to amass enough evidence to arrest these criminals.
<G-vec00443-001-s009><amass.anhäufen><de> """Das war seine beste Präsenz auf dem Eis"", bestätigte Therrien, der sah auch Verteidiger Greg Pateryn anzuhäufen drei Assists in der Nacht und Goalie Zachary Fucale Anschlag 13 von 15 Schüssen in Relief Starter Peter Budaj."
<G-vec00443-001-s009><amass.anhäufen><en> “That was his best presence on the ice,” confirmed Therrien, who also saw defenseman Greg Pateryn amass three assists on the night and goaltender Zachary Fucale stop 13 of 15 shots in relief of starter Peter Budaj.
<G-vec00443-001-s010><amass.anhäufen><de> 6) Lass es nicht zu deinem Ziel im Leben werden, weltlichen Gewinn anzuhäufen und Gott wird dich lieben.
<G-vec00443-001-s010><amass.anhäufen><en> 6) Don't let your focus in this life be to amass worldly gain and God will love you.
<G-vec00443-001-s011><amass.anhäufen><de> Von einem solchen Menschen konnte wahrlich gesagt werden, daß er wiedergeboren und wiederbelebt war, denn vor seinem Glauben an Gott und vor dem Bekenntnis zu Seiner Manifestation hatte er sein Herz an die Dinge der Welt gehängt, an irdischen Besitz, an Weib und Kind, Speise und Trank und dergleichen, so daß all sein Sinnen und Trachten Tag und Nacht nur darauf gerichtet war, Reichtum anzuhäufen und sich die Mittel für Genuß und Vergnügen zu verschaffen.
<G-vec00443-001-s011><amass.anhäufen><en> Of him it could be truly said that he was reborn and revived, inasmuch as previous to his belief in God and his acceptance of His Manifestation, he had set his affections on the things of the world, such as attachment to earthly goods, to wife, children, food, drink, and the like, so much so that in the daytime and in the night-season his one concern had been to amass riches and procure for himself the means of enjoyment and pleasure.
<G-vec00443-001-s012><amass.anhäufen><de> An dem prächtigen gehorteten Gold im thrakischen Gebiet ist erkennbar, dass deren Adel in der Lage war, beträchtliche Reichtümer anzuhäufen.
<G-vec00443-001-s012><amass.anhäufen><en> From the many magnificent gold hordes recovered in Thracian territory, it is apparent that nobility was able to amass more than significant wealth.
<G-vec00443-001-s013><amass.anhäufen><de> Jeder tut alles, um Geld anzuhäufen.
<G-vec00443-001-s013><amass.anhäufen><en> Everyone does everything to amass money .
<G-vec00443-001-s156><accumulate.anhäufen><de> Solche irdischen Herrscher tragen luxuriöse Kleidung und scharfe Schwerter; sie sind nicht mit einfachem Essen zufrieden; sie häufen zuviel Vermögen für sich selbst an.
<G-vec00443-001-s156><accumulate.anhäufen><en> Such earthly rulers wear luxurious clothes and sharp swords, they are not satisfied with simple food, they accumulate too much wealth for themselves.
<G-vec00443-001-s157><accumulate.anhäufen><de> Wenn wir nicht nur Dinge und Geschehnisse und Ereignisse kennenlernen, sondern dieses auch mit dem Ziel tun, etwas daraus zu lernen, dann häufen wir Verstehen an.
<G-vec00443-001-s157><accumulate.anhäufen><en> When we not only experience things and happenings and events, but when we do so with the aim to learn from them, then we accumulate understanding.
<G-vec00443-002-s118><accumulate.anhäufen><de> (15) je nach ihren Handlungen häufen Gläubige Verdienst oder Schuld an, die mit einem moralischen System von Belohnung und Bestrafung verbunden sind.
<G-vec00443-002-s118><accumulate.anhäufen><en> (o) according to their performance, believers accumulate merit or demerit to which a moral economy of reward and punishment is attached.
<G-vec00443-002-s119><accumulate.anhäufen><de> Viele Business Traveller häufen über Jahre zahlreiche Bonusmeilen bei Vielfliegerprogrammen an.
<G-vec00443-002-s119><accumulate.anhäufen><en> Many business travellers accumulate countless bonus miles through frequent flyer programs over the years.
<G-vec00443-002-s014><amass.anhäufen><de> Es ist nicht der Reichtum den ich anhäufe, aber die Leben, die ich dadurch berühren kann.
<G-vec00443-002-s014><amass.anhäufen><en> It’s not the wealth I amass, but the lives that I can touch through it, that is precious – the world maybe different because I was important in the life of one single child.
<G-vec00443-002-s020><hoard.anhäufen><de> Wir können sicher ein weiteres ausuferndes Abenteuer in der Postapokalypse vertragen, besonders mit vielen Dungeons zum Durchqueren, Monstern zum Verprügeln, Plattformen zum Erklimmen und Loot zum Anhäufen.
<G-vec00443-002-s020><hoard.anhäufen><en> We’re most likely due for another sprawling post-apocalyptic adventure, featuring a lot of dungeons to crawl, monsters to whip, platforms to clamber over and loot to hoard.
<G-vec00443-002-s029><pile_up.anhäufen><de> Ihr Ziel ist es, alle Karten in vier Haufen anhäufen, jeder Stapel muss den gleichen Farbe haben und gehen von Ass bis König.
<G-vec00443-002-s029><pile_up.anhäufen><en> Your objective is to pile all the cards up in four piles, each pile must have the same suit and go from Ace to King.
<G-vec00443-002-s030><pile_up.anhäufen><de> Sie wissen nicht einmal, dass es Sünde ist, bis die Sünden, die sie begehen, sich immer mehr anhäufen und zu einem hohen, starken Turm werden.
<G-vec00443-002-s030><pile_up.anhäufen><en> They do not even know that it is sin until the sins they commit pile higher and higher, and becomes a tall strong tower.
<G-vec00443-002-s031><pile_up.anhäufen><de> Ihr seht ja, wie sie sich anhäufen.
<G-vec00443-002-s031><pile_up.anhäufen><en> You see how they pile up?"
<G-vec00443-002-s032><pile_up.anhäufen><de> Aber Vorsicht, lassen Sie sich nicht die Murmeln anhäufen oder du wirst...
<G-vec00443-002-s032><pile_up.anhäufen><en> But beware, don't let the marbles pile up or you'll...
<G-vec00443-002-s033><pile_up.anhäufen><de> Speicherung: Gespeichert im trockenen und geprüften inneren Lagerraum, direktes Tageslicht verhindern, etwas anhäufen und niederlegen.
<G-vec00443-002-s033><pile_up.anhäufen><en> Storage: Stored in the dry and ventilated inside storeroom, prevent direct sunlight, slightly pile and put down.
<G-vec00443-002-s034><pile_up.anhäufen><de> Wenn sich all deine Verpflichtungen anhäufen, können diese beginnen, unausführbar zu scheinen.
<G-vec00443-002-s034><pile_up.anhäufen><en> When all your responsibilities pile up, it can start to seem impossible.
<G-vec00443-002-s014><stockpile.anhäufen><de> Der erste Spieler, der auf eine Fundgrube seltener Edelsteine stößt, könnte diese beispielsweise für einen guten Zweck spenden oder sie für seine eigenen Zwecke anhäufen.
<G-vec00443-002-s014><stockpile.anhäufen><en> The first player to find a rich seam of rare gemstones could happily donate their new-found riches to good causes, or choose to stockpile the precious metal for their own needs.
<G-vec00157-002-s029><pile_on.anhäufen><de> Ihr Ziel ist es, alle Karten in vier Haufen anhäufen, jeder Stapel muss den gleichen Farbe haben und gehen von Ass bis König.
<G-vec00157-002-s029><pile_on.anhäufen><en> Your objective is to pile all the cards up in four piles, each pile must have the same suit and go from Ace to King.
<G-vec00157-002-s030><pile_on.anhäufen><de> Sie wissen nicht einmal, dass es Sünde ist, bis die Sünden, die sie begehen, sich immer mehr anhäufen und zu einem hohen, starken Turm werden.
<G-vec00157-002-s030><pile_on.anhäufen><en> They do not even know that it is sin until the sins they commit pile higher and higher, and becomes a tall strong tower.
<G-vec00157-002-s031><pile_on.anhäufen><de> Ihr seht ja, wie sie sich anhäufen.
<G-vec00157-002-s031><pile_on.anhäufen><en> You see how they pile up?"
<G-vec00157-002-s032><pile_on.anhäufen><de> Aber Vorsicht, lassen Sie sich nicht die Murmeln anhäufen oder du wirst...
<G-vec00157-002-s032><pile_on.anhäufen><en> But beware, don't let the marbles pile up or you'll...
<G-vec00157-002-s033><pile_on.anhäufen><de> Speicherung: Gespeichert im trockenen und geprüften inneren Lagerraum, direktes Tageslicht verhindern, etwas anhäufen und niederlegen.
<G-vec00157-002-s033><pile_on.anhäufen><en> Storage: Stored in the dry and ventilated inside storeroom, prevent direct sunlight, slightly pile and put down.
<G-vec00157-002-s034><pile_on.anhäufen><de> Wenn sich all deine Verpflichtungen anhäufen, können diese beginnen, unausführbar zu scheinen.
<G-vec00157-002-s034><pile_on.anhäufen><en> When all your responsibilities pile up, it can start to seem impossible.
<G-vec00157-002-s120><pile_on.anhäufen><de> Als sich die Hulk Sichtungen häufen begibt sich die Reporterin Jackie McGee auf die Suche nach dem grünen Koloss.
<G-vec00157-002-s120><pile_on.anhäufen><en> As the Hulk sightings pile up, reporter Jackie McGee goes in search of the green colossus.
<G-vec00157-002-s121><pile_on.anhäufen><de> Die Kosten von all dieser Zerstörung häufen sich immer höher mit jedem Monat, der vergeht.
<G-vec00157-002-s121><pile_on.anhäufen><en> The costs from all this destruction pile up ever higher with each passing month.
<G-vec00157-002-s122><pile_on.anhäufen><de> Wenn sich jedoch andere überfüllte Dateien von anderen deinstallierten Dateien häufen, treten Probleme auf.
<G-vec00157-002-s122><pile_on.anhäufen><en> However, if other cluttered files from other uninstalled files will pile up then you will have a problem.
<G-vec00157-002-s123><pile_on.anhäufen><de> Doch unter all diesen kulinarischen Gaben aus Stall und Acker gehörte Sauerkraut zu den favorisierten Köstlichkeiten unserer Küche, vor allem für den Förster, einen hagestolzen und jähzornigen Alten mit spiegelnder Glatze, dessen strenge Züge nur dann Milde zeigten, wenn er sich eine Portion Sauerkraut auf seinen Teller häufen konnte.
<G-vec00157-002-s123><pile_on.anhäufen><en> Among all the delicious bounty from barn and field, sauerkraut was the most favored delicacy in our cuisine, above all for the forester, a proud, angry old man whose head was smooth as a mirror. His forbidding mien softened only when he was able to pile a serving of sauerkraut on his plate.
<G-vec00157-002-s124><pile_on.anhäufen><de> Schnell sammeln und häufen sich diese kleinen Papierfetzen auf dem Schreibtisch, dem Esstisch oder im Portemonnaie.
<G-vec00157-002-s124><pile_on.anhäufen><en> These little scraps of paper quickly gather and pile up on the desk, dining table or in the wallet.
<G-vec00157-002-s125><pile_on.anhäufen><de> „ … häufen sich auch die Verbildlichungen des (Themas).
<G-vec00157-002-s125><pile_on.anhäufen><en> “ … also the depictions of the (theme) pile up.
<G-vec00157-002-s126><pile_on.anhäufen><de> Häufen Sie das ganze Büromaterial an einer Stelle.
<G-vec00157-002-s126><pile_on.anhäufen><en> Put all the office supplies in a pile.
<G-vec00157-002-s127><pile_on.anhäufen><de> Unser touristisch attraktives Schweizer Landschaftsbild wird verkommen, Erdrutsche werden sich häufen, Skipisten (Alpweiden) werden verbuschen.
<G-vec00157-002-s127><pile_on.anhäufen><en> Our touristically attractive Swiss landscape will degenerate, landslides will pile up, ski slopes (alpine pastures) will fumble.
<G-vec00157-002-s128><pile_on.anhäufen><de> In Hungerjahren und sonstigen Notzeiten erflehen sie von ihren Verwandten und Freunden leihweise einige Maß Getreide, um sich zunächst einmal ein paar Tage durchzuschlagen; ihre Schulden häufen sich wie die Last auf dem Rücken der Zugochsen, Diese Gruppe der armen Bauern stellt den elendsten Teil der Bauernschaft dar; die ist für revolutionäre Propaganda überaus empfänglich.
<G-vec00157-002-s128><pile_on.anhäufen><en> In hard times they piteously beg help from relatives and friends, borrowing a few tou or sheng of grain to last them a few days, and their debts pile up like loads on the backs of oxen. They are the worst off among the peasants and are highly receptive to revolutionary propaganda.
<G-vec00710-002-s057><accumulate.anhäufen><de> Ich habe eindeutig zu wenig Stricknadeln, ich kann nicht mal UFOs anhäufen, weil ich manchmal nur ein Paar Nadeln habe.
<G-vec00710-002-s057><accumulate.anhäufen><en> I have clearly not enough knitting needles, I can not even accumulate UFOs, because sometimes I have only one pair of needles.
<G-vec00710-002-s058><accumulate.anhäufen><de> Es ist zu Ihrem Vorteil, weil ich nicht möchte, dass sie eine weitere Sünde begehen und noch mehr Karma anhäufen.“ In der Zwischenzeit blickte ich ihn intensiv an, sendete aufrichtige Gedanken aus, um all das Böse aufzulösen.
<G-vec00710-002-s058><accumulate.anhäufen><en> It's for your benefit, because I don't want to see you commit another sin and accumulate more karma." Meanwhile, I looked at him intently, sending forth righteous thoughts to disintegrate all the evil.
<G-vec00710-002-s060><accumulate.anhäufen><de> 3.1 Kunden dürfen keine Boni anhäufen: Jeder Bonus muss erst vollständig umgesetzt werden, bevor ein Spieler einen weiteren Bonus einlösen kann.
<G-vec00710-002-s060><accumulate.anhäufen><en> 3.1 Players may not accumulate bonuses: Each bonus must be used in its entirety before any additional bonuses can be issued.
<G-vec00710-002-s061><accumulate.anhäufen><de> Man kann nicht enorme Kraft anhäufen und sie dann für einen großen Zweck konzentrieren.
<G-vec00710-002-s061><accumulate.anhäufen><en> You Cannot accumulate enormous power and then concentrate it for a great purpose.
<G-vec00710-002-s062><accumulate.anhäufen><de> Da Fett sich im Blutstrom anhäufen kann und die Reinheit deines Blutes beeinflusst, sollte man dies so wenig wie möglich zu sich nehmen.
<G-vec00710-002-s062><accumulate.anhäufen><en> Since fats can accumulate in your bloodstream and impact the purity of your blood, it’s best to limit them to small quantities.
<G-vec00710-002-s063><accumulate.anhäufen><de> Um zu verhindern, dass diese Ausschüsse erneut Macht anhäufen, verfügte der Konvent, dass ein Viertel der Ausschußpositionen jeden Monat neu besetzt wird.
<G-vec00710-002-s063><accumulate.anhäufen><en> Wary that these committees might again accumulate power, the Convention decreed that one-quarter of committee positions would be turned over each month.
<G-vec00710-002-s064><accumulate.anhäufen><de> Denn die nächste Folge der jüngsten globalen Finanzkrise wird ein steigendes Länderrisiko sein, insbesondere in Industrieländern, die massive Haushaltsdefizite haben und hohe öffentliche Schuldenberge anhäufen, indem sie private finanzielle Verluste verstaatlichen, um das Wirtschaftswachstum wieder anzukurbeln.
<G-vec00710-002-s064><accumulate.anhäufen><en> For the next installment of the recent global financial crisis will be rising sovereign risk, especially in advanced economies that run massive budget deficits and accumulate large stocks of public debt as they socialize private financial losses in order to revive economic growth.
<G-vec00710-002-s065><accumulate.anhäufen><de> VERLÄNGERT: CALL FOR ENTRIES: »SPIEL DES LEBENS — Reichtümer anhäufen durch das Sammeln von Geld und Lebensstil-Karten.
<G-vec00710-002-s065><accumulate.anhäufen><en> Interessant: Was ist HANT? Accumulate wealth by collecting money and lifestyle cards.
<G-vec00710-002-s094><accumulate.anhäufen><de> Wettbewerb, Neid, das Bedürfnis besser zu sein als der andere, das Bedürfnis Wohlstand anzuhäufen, die Notwendigkeit eines Staates, all das, so wird uns gesagt, seien dem Menschen innewohnende Elemente, die genauso grundlegend wären wie das Bedürfnis nach Essen und Sexualität.
<G-vec00710-002-s094><accumulate.anhäufen><en> Competition, greed, the need to do better than the next man, the desire to accumulate wealth, the need for the state - these, we are told, are inherent in human nature, as basic as the need for food or the sexual drive.
<G-vec00710-002-s096><accumulate.anhäufen><de> Sonderregelungen: Das Messer und die Gabel zum Verzehr von Fisch dürfen nicht zum Verzehr von Fleisch oder Käse verwendet werden; Es ist nicht ratsam, zu viel Essen in der Schüssel anzuhäufen; beim Trinken, Bier trinken und dann Wein trinken.
<G-vec00710-002-s096><accumulate.anhäufen><en> Special regulations: The knife and fork for eating fish should not be used to eat meat or cheese; it is not advisable to accumulate too much food in the dish; when drinking, drink beer and then drink wine.
<G-vec00710-002-s099><accumulate.anhäufen><de> Wenn wir übermäßig die Intensität des Work-Outs vergrößern, wird sich die vergrößerte Menge der reaktiven Sauerstoffarten anfangen anzuhäufen in Ihrem Körper, was zu oxydativen Stress und Organismusstörungen führen kann.
<G-vec00710-002-s099><accumulate.anhäufen><en> Moderate exercise affects our health, but if training becomes harder, greater amounts of reactive oxygen species (ROS) begin to accumulate in the body causing the so called oxidative stress and disturbing the balance of our body.
<G-vec00710-002-s100><accumulate.anhäufen><de> Die Farbe ist das Handwerkzeug des Zeichners und so ist es notwendig, über sie Wissen anzuhäufen.
<G-vec00710-002-s100><accumulate.anhäufen><en> color is the hand tool of the artist and so it is necessary to accumulate knowledge about them.
<G-vec00710-002-s214><accumulate.anhäufen><de> “Je mehr solcher Mutationen sich anhäufen, desto größer wird die Gefahr, dass die verfügbaren Medikamente und Impfstoffe nicht mehr wirken“, betont Günter Mayer.
<G-vec00710-002-s214><accumulate.anhäufen><en> “The more such mutations accumulate, the greater the risk that the available drugs and vaccines will no longer work,” Günter Mayer emphasizes.
<G-vec00710-002-s215><accumulate.anhäufen><de> Außerdem kann sich Stress anhäufen und langfristig negative Auswirkungen auf die psychische Gesundheit haben.
<G-vec00710-002-s215><accumulate.anhäufen><en> In addition, stress can accumulate and produce a long-term negative effect on mental health.
<G-vec00710-002-s216><accumulate.anhäufen><de> Dies findet statt, wenn sich virale Proteine bei einem Prozess namens Knospung unter der Zellmembran anhäufen (a).
<G-vec00710-002-s216><accumulate.anhäufen><en> It occurs when viral proteins accumulate under the cell membrane in a process called budding (a).
<G-vec00710-002-s217><accumulate.anhäufen><de> Wenn ich nicht lange schwanger werden könnte, würde ich es versuchen und der Schmerz würde sich anhäufen.
<G-vec00710-002-s217><accumulate.anhäufen><en> If I could not get pregnant long, I would try, and the pain would accumulate.
<G-vec00710-002-s218><accumulate.anhäufen><de> - Unerwünschte Dateien und Verknüpfungen löschen: OneSafe PC Cleaner findet und löscht Junkdateien und Verknüpfungen, die sich im Laufe der Zeit auf dem computer anhäufen und beträchtlichen Speicherplatz belegen.
<G-vec00710-002-s218><accumulate.anhäufen><en> - Delete unwanted files and shortcuts: OneSafe PC Cleaner finds and deletes junk files and shortcuts that accumulate on your computer over time, taking up space on your hard drive.
<G-vec00841-002-s029><pile.anhäufen><de> Ihr Ziel ist es, alle Karten in vier Haufen anhäufen, jeder Stapel muss den gleichen Farbe haben und gehen von Ass bis König.
<G-vec00841-002-s029><pile.anhäufen><en> Your objective is to pile all the cards up in four piles, each pile must have the same suit and go from Ace to King.
<G-vec00841-002-s030><pile.anhäufen><de> Sie wissen nicht einmal, dass es Sünde ist, bis die Sünden, die sie begehen, sich immer mehr anhäufen und zu einem hohen, starken Turm werden.
<G-vec00841-002-s030><pile.anhäufen><en> They do not even know that it is sin until the sins they commit pile higher and higher, and becomes a tall strong tower.
<G-vec00841-002-s031><pile.anhäufen><de> Ihr seht ja, wie sie sich anhäufen.
<G-vec00841-002-s031><pile.anhäufen><en> You see how they pile up?"
<G-vec00841-002-s032><pile.anhäufen><de> Aber Vorsicht, lassen Sie sich nicht die Murmeln anhäufen oder du wirst...
<G-vec00841-002-s032><pile.anhäufen><en> But beware, don't let the marbles pile up or you'll...
<G-vec00841-002-s033><pile.anhäufen><de> Speicherung: Gespeichert im trockenen und geprüften inneren Lagerraum, direktes Tageslicht verhindern, etwas anhäufen und niederlegen.
<G-vec00841-002-s033><pile.anhäufen><en> Storage: Stored in the dry and ventilated inside storeroom, prevent direct sunlight, slightly pile and put down.
<G-vec00841-002-s034><pile.anhäufen><de> Wenn sich all deine Verpflichtungen anhäufen, können diese beginnen, unausführbar zu scheinen.
<G-vec00841-002-s034><pile.anhäufen><en> When all your responsibilities pile up, it can start to seem impossible.
