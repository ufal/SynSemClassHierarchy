<G-vec00298-002-s024><widen.aufweiten><de> Risse aufweiten und anschließend alle Fehlstellen mit der Gipsspachtelmasse ALPOL AG S19 oder ALPOL AG S20 verfüllen.
<G-vec00298-002-s024><widen.aufweiten><en> Widen scratches and cracks and then patch all chipped areas with ALPOL AG S19 or ALPOL AG S20 gypsum putty.
