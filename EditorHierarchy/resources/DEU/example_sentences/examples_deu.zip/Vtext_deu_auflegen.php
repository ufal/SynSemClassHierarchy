<G-vec00502-002-s036><lay.auflegen><de> Dort Stoff oder Papier verteilen und die Rohmaterialien in einer dünnen Schicht auflegen.
<G-vec00502-002-s036><lay.auflegen><en> There, spread the fabric or paper, and on top lay the raw materials in a thin layer.
<G-vec00502-002-s037><lay.auflegen><de> Deshalb bitte ich Dich, o Gott, daß Du uns heute Abend so salbst, daß, wem immer wir dann die Hände auflegen, er geheilt ist; nicht, weil wir es sind, sondern weil wir Deinem Gebot Folge leisten.
<G-vec00502-002-s037><lay.auflegen><en> So I pray, God, that You'll so anoint us tonight that whoever we lay our hands on, may they be healed; not because it's us, but because it's following Your commandment.
<G-vec00502-002-s038><lay.auflegen><de> 5:7 Ihr sollt dem Volk nicht mehr Stroh sammeln und geben, daß sie Ziegel bisher gemacht haben, sollt ihr ihnen gleichwohl auflegen und nichts mindern; denn sie gehen müßig, darum schreien sie und sprechen: Wir wollen hinziehen und unserm Gott opfern.
<G-vec00502-002-s038><lay.auflegen><en> 5:8 And the tale of the bricks, which they did make in time past, all of you shall lay upon them; all of you shall not diminish ought thereof: for they be idle; therefore they cry, saying, Let us go and sacrifice to our God.
<G-vec00502-002-s039><lay.auflegen><de> Er kann mit wenigen Handgriffen aufgebaut werden, wobei keinerlei Werkzeug benötigt wird: die vier Gestellteile werden ineinandergesteckt und durch Auflegen der Tischplatte fixiert.
<G-vec00502-002-s039><lay.auflegen><en> It can be mounted in a few seconds without the use of any tools - Simply arrange the four legs and then lay the table board on top to put it all together.
<G-vec00502-002-s040><lay.auflegen><de> 17 Die Zeichen aber, die folgen werden denen, die da glauben, sind diese: In meinem Namen werden sie Dämonen austreiben, in neuen Zungen reden, 18 Schlangen mit den Händen hochheben, und wenn sie etwas Tödliches trinken, wird's ihnen nicht schaden; Kranken werden sie die Hände auflegen, so wird's gut mit ihnen.
<G-vec00502-002-s040><lay.auflegen><en> And these signs will accompany those who believe: In my name they will cast out demons, they will speak with new tongues, they will take up serpents, and drink deadly things, and it will not hurt them. They will lay hands on the sick and they will be healed.
<G-vec00502-002-s041><lay.auflegen><de> Im Alter von 19 Jahren wurde ich Christin und las in der Bibel, daß man den Kranken die Hände auflegen kann und es wird besser mit ihnen werden (MARKUS 16:18).
<G-vec00502-002-s041><lay.auflegen><en> I became a Christian when I was nineteen years old, and read in the Bible that you can lay hands on the sick and they shall recover (MARK 16:18).
<G-vec00502-002-s042><lay.auflegen><de> Ohne großes Aufheben werden sie in die Krankenhäuser, Heime und Straßen gehen, den Kranken die Hände auflegen und unglaubliche Heilungswunder erleben.
<G-vec00502-002-s042><lay.auflegen><en> Without fanfare they will go into hospitals, homes, the streets, and will lay hands on the sick and see incredible miracles of healing.
<G-vec00502-002-s043><lay.auflegen><de> Das Band einfach ablängen, das Klebeband auflegen, flach halten, um Falten zu vermeiden.
<G-vec00502-002-s043><lay.auflegen><en> Simply pull the tape to length, lay the tape, ensure its flat to avoid creases and youre done.
<G-vec00502-002-s044><lay.auflegen><de> Und durch die, die zum Glauben gekommen sind, werden folgende Zeichen geschehen: In meinem Namen werden sie Dämonen austreiben; sie werden in neuen Sprachen reden; wenn sie Schlangen anfassen oder tödliches Gift trinken, wird es ihnen nicht schaden; und die Kranken, denen sie die Hände auflegen, werden gesund werden.
<G-vec00502-002-s044><lay.auflegen><en> "And these signs will follow those who believe: "In My name they will cast out demons; they will speak with new tongues; they will take up serpents; and if they drink anything deadly, it will by no means hurt them; they will lay hands on the sick and they will recover."
<G-vec00502-002-s045><lay.auflegen><de> Den Knoblauch ebenfalls in einer gleichmäßigen Schicht auflegen.
<G-vec00502-002-s045><lay.auflegen><en> Lay out the garlic in an even layer.
<G-vec00555-002-s036><lay_off.auflegen><de> Dort Stoff oder Papier verteilen und die Rohmaterialien in einer dünnen Schicht auflegen.
<G-vec00555-002-s036><lay_off.auflegen><en> There, spread the fabric or paper, and on top lay the raw materials in a thin layer.
<G-vec00555-002-s037><lay_off.auflegen><de> Deshalb bitte ich Dich, o Gott, daß Du uns heute Abend so salbst, daß, wem immer wir dann die Hände auflegen, er geheilt ist; nicht, weil wir es sind, sondern weil wir Deinem Gebot Folge leisten.
<G-vec00555-002-s037><lay_off.auflegen><en> So I pray, God, that You'll so anoint us tonight that whoever we lay our hands on, may they be healed; not because it's us, but because it's following Your commandment.
<G-vec00555-002-s038><lay_off.auflegen><de> 5:7 Ihr sollt dem Volk nicht mehr Stroh sammeln und geben, daß sie Ziegel bisher gemacht haben, sollt ihr ihnen gleichwohl auflegen und nichts mindern; denn sie gehen müßig, darum schreien sie und sprechen: Wir wollen hinziehen und unserm Gott opfern.
<G-vec00555-002-s038><lay_off.auflegen><en> 5:8 And the tale of the bricks, which they did make in time past, all of you shall lay upon them; all of you shall not diminish ought thereof: for they be idle; therefore they cry, saying, Let us go and sacrifice to our God.
<G-vec00555-002-s039><lay_off.auflegen><de> Er kann mit wenigen Handgriffen aufgebaut werden, wobei keinerlei Werkzeug benötigt wird: die vier Gestellteile werden ineinandergesteckt und durch Auflegen der Tischplatte fixiert.
<G-vec00555-002-s039><lay_off.auflegen><en> It can be mounted in a few seconds without the use of any tools - Simply arrange the four legs and then lay the table board on top to put it all together.
<G-vec00555-002-s040><lay_off.auflegen><de> 17 Die Zeichen aber, die folgen werden denen, die da glauben, sind diese: In meinem Namen werden sie Dämonen austreiben, in neuen Zungen reden, 18 Schlangen mit den Händen hochheben, und wenn sie etwas Tödliches trinken, wird's ihnen nicht schaden; Kranken werden sie die Hände auflegen, so wird's gut mit ihnen.
<G-vec00555-002-s040><lay_off.auflegen><en> And these signs will accompany those who believe: In my name they will cast out demons, they will speak with new tongues, they will take up serpents, and drink deadly things, and it will not hurt them. They will lay hands on the sick and they will be healed.
<G-vec00555-002-s041><lay_off.auflegen><de> Im Alter von 19 Jahren wurde ich Christin und las in der Bibel, daß man den Kranken die Hände auflegen kann und es wird besser mit ihnen werden (MARKUS 16:18).
<G-vec00555-002-s041><lay_off.auflegen><en> I became a Christian when I was nineteen years old, and read in the Bible that you can lay hands on the sick and they shall recover (MARK 16:18).
<G-vec00555-002-s042><lay_off.auflegen><de> Ohne großes Aufheben werden sie in die Krankenhäuser, Heime und Straßen gehen, den Kranken die Hände auflegen und unglaubliche Heilungswunder erleben.
<G-vec00555-002-s042><lay_off.auflegen><en> Without fanfare they will go into hospitals, homes, the streets, and will lay hands on the sick and see incredible miracles of healing.
<G-vec00555-002-s043><lay_off.auflegen><de> Das Band einfach ablängen, das Klebeband auflegen, flach halten, um Falten zu vermeiden.
<G-vec00555-002-s043><lay_off.auflegen><en> Simply pull the tape to length, lay the tape, ensure its flat to avoid creases and youre done.
<G-vec00555-002-s044><lay_off.auflegen><de> Und durch die, die zum Glauben gekommen sind, werden folgende Zeichen geschehen: In meinem Namen werden sie Dämonen austreiben; sie werden in neuen Sprachen reden; wenn sie Schlangen anfassen oder tödliches Gift trinken, wird es ihnen nicht schaden; und die Kranken, denen sie die Hände auflegen, werden gesund werden.
<G-vec00555-002-s044><lay_off.auflegen><en> "And these signs will follow those who believe: "In My name they will cast out demons; they will speak with new tongues; they will take up serpents; and if they drink anything deadly, it will by no means hurt them; they will lay hands on the sick and they will recover."
<G-vec00555-002-s045><lay_off.auflegen><de> Den Knoblauch ebenfalls in einer gleichmäßigen Schicht auflegen.
<G-vec00555-002-s045><lay_off.auflegen><en> Lay out the garlic in an even layer.
<G-vec00735-002-s076><hang.auflegen><de> Wenn Sie irgendwelche Zweifel haben, können Sie jederzeit auflegen und die offiziell bekannte Nummer eines Unternehmens verwenden, um sie zurückzurufen oder um eine Lösung der Angelegenheit in ihrem Büro zu bitten.
<G-vec00735-002-s076><hang.auflegen><en> If you have any doubts, you can always hang up and use a company’s officially known number to call them back or ask to resolve the matter in their office.
<G-vec00735-002-s077><hang.auflegen><de> Nachdem er mehrmals im Wankdorf Club auflegen durfte, nahm das Label "Cosmic Studios“ ihn unter mündlichen Vertrag.
<G-vec00735-002-s077><hang.auflegen><en> After he was allowed to hang up several times in the Wankdorf Club, took the label "Cosmic Studios' him oral contract.
<G-vec00735-002-s078><hang.auflegen><de> Wenn Sie eine obszöne Anruf erhalten - auflegen, nicht reagieren.
<G-vec00735-002-s078><hang.auflegen><en> If you receive an obscene phone call - hang up, don't react.
<G-vec00735-002-s079><hang.auflegen><de> Wenn der Anruf beendet ist, müssen Sie mit dem Hörer wieder auflegen.
<G-vec00735-002-s079><hang.auflegen><en> When the call is finished, you have to hang up using the handset.
<G-vec00735-002-s080><hang.auflegen><de> Der Drucksensor erleichtert auch das Abspielen, Pausieren oder Überspringen von Titeln sowie das Annehmen oder Auflegen von Telefonaten.
<G-vec00735-002-s080><hang.auflegen><en> The force sensor also makes it easy to play, pause or skip tracks, and answer or hang up phone calls.
<G-vec00735-002-s081><hang.auflegen><de> Bis zu 300 Stunden Stand-by (2) Anruf aus, den Anruf annehmen, den Anruf abweisen,den Anruf auflegen.
<G-vec00735-002-s081><hang.auflegen><en> Up to 300 hours standby Call out, call answer, call reject, call hang up.
<G-vec00735-002-s082><hang.auflegen><de> Anruf annehmen: In diesem Feld können Sie einen Hotkey für "Anruf annehmen" und "auflegen" zuweisen.
<G-vec00735-002-s082><hang.auflegen><en> Answer call: In this field you can assign a hotkey for "Answer call" and "Hang up".
<G-vec00735-002-s083><hang.auflegen><de> Wenn der Anruf zu Ende ist, tippe auf den roten Telefonhörer zum Auflegen.
<G-vec00735-002-s083><hang.auflegen><en> When your call is over, tap the red phone button to hang up.
<G-vec00735-002-s084><hang.auflegen><de> Gequält von den Gedanken nicht Auflegen zu können, arbeitete es in ihr.
<G-vec00735-002-s084><hang.auflegen><en> Tormented by the thought of not being able to hang up, it worked for her.
<G-vec00735-002-s085><hang.auflegen><de> Wählen Sie Auflegen aus, oder drücken Sie STRG+EINGABETASTE.
<G-vec00735-002-s085><hang.auflegen><en> Select Hang Up or press Ctrl+Enter.
<G-vec00735-002-s086><hang.auflegen><de> Mein Vorgang ist eine unermüdliche Wiederholung von: Druck des veränderten Fotos, auflegen und befeuchten.
<G-vec00735-002-s086><hang.auflegen><en> My process is a tireless repetition of: print the altered photo, hang up and moisten.
<G-vec00735-002-s087><hang.auflegen><de> Tipp: Um Ihr Mikrofon stummzuschalten oder die Stummschaltung aufzuheben, drücken Sie Umschalt + Befehl + M. Zum Auflegen drücken Sie Umschalt + Befehl + E.
<G-vec00735-002-s087><hang.auflegen><en> Tip: To mute or unmute your microphone, press Shift+Command+M. To hang up, press Shift+Command+E.
<G-vec00735-002-s088><hang.auflegen><de> Als dann die Wende kam und die ersten Discos und Clubs eröffneten, ging es dann richtig los - jede Woche Freitag bis Samstag auflegen.
<G-vec00735-002-s088><hang.auflegen><en> When then came the turn and opened the first discos and clubs, it went really begins - every week hang Friday to Saturday.
<G-vec00735-002-s089><hang.auflegen><de> Sobald Sie auflegen wird der Anrufer durchgestellt.
<G-vec00735-002-s089><hang.auflegen><en> When you hang up, the caller will then be transferred.
<G-vec00735-002-s090><hang.auflegen><de> Zum Auflegen halten Sie zwei Sekunden lang das rote Symbol oder die Down-Taste gedrückt, die sich an der Seite des Uhrengehäuses befindet.
<G-vec00735-002-s090><hang.auflegen><en> To hang up, press the red icon at the bottom on the side of the watch casing for 2 seconds
<G-vec00735-002-s091><hang.auflegen><de> Wenn dein Anruf vorüber ist, tippe zum Auflegen auf den roten Telefonhörer.
<G-vec00735-002-s091><hang.auflegen><en> When your call is over, tap the red phone button to hang up.
