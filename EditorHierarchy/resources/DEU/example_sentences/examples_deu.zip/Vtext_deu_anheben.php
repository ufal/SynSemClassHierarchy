<G-vec00169-001-s019><raise.anheben><de> Wärmepumpen benötigen eine Wärmequelle, deren Temperaturniveau sie auf ein in Gebäuden nutzbares Niveau anheben.
<G-vec00169-001-s019><raise.anheben><en> Heat pumps require a heat source whose temperature level they raise to a useful level in buildings.
<G-vec00169-001-s020><raise.anheben><de> Sie können dann anheben, indem sie eine Wette von ihren Selbst setzen.
<G-vec00169-001-s020><raise.anheben><en> They can then Raise by placing a bet of their own.
<G-vec00169-001-s021><raise.anheben><de> „Wir machen weiterhin gute Fortschritte, doch wir müssen die Messlatte anheben, um die traditionellen chinesischen Kampfkünste und die Moral vollständig wiederzubeleben.
<G-vec00169-001-s021><raise.anheben><en> """We continue to make good progress, but we must raise the bar in order to completely revive the traditional Chinese martial arts and morality."
<G-vec00169-001-s022><raise.anheben><de> Er und jeder möglicher andere Spieler muss entweder jetzt benennen oder anheben, um in das Spiel zu bleiben.
<G-vec00169-001-s022><raise.anheben><en> He and any other player now has to either Call or Raise to stay into the game.
<G-vec00169-001-s023><raise.anheben><de> Wenn Sie Ihre hintere Ferse beim Zurückgehen anheben, gibt es eine geringfügige Verzögerung der Rückwärtsbewegung Ihres Rumpfes.
<G-vec00169-001-s023><raise.anheben><en> If you raise your back heel as you step back, there is a slight delay in the backwards movement of your torso.
<G-vec00169-001-s024><raise.anheben><de> nach (oder einig Zeit vor) secreting selbst weg d neu Königin wegwerfen ihr Flügel, sie werden nie fliegen wieder und sie sein Ernährungs- valueless, und redigests ihr groß Brust- Flug Muskel wie dies haben dienen ihr einzeln Zweck in Leben und sein jetzt mehr verwenden wie ein Nahrung Reserve für d nächst Monat, während dies Zeit sie werden anheben ihr erst Brut von Arbeiter ohne eating ein einzeln Mahlzeit.
<G-vec00169-001-s024><raise.anheben><en> After (or some times before) secreting herself away the new queen discards her wings, she will never fly again and they are nutritionally valueless, and redigests her large thoracic flight muscles as these have served their single purpose in life and are now more use as a food reserve for the next few months, during this time she will raise her first brood of workers without eating a single meal.
<G-vec00169-001-s025><raise.anheben><de> Neben der Betätigung der Bremsen wird sie auch für das Öffnen der Türen, die Ansteuerung der Luftfederung, der Sandungsanlage, sowie zum Anheben des Pantographen (Stromabnehmer) oder zur Betätigung der Scheibenwischer verwendet.
<G-vec00169-001-s025><raise.anheben><en> As well as operating the brakes, it is also used to open the doors, powering the air suspension, the sanding unit as well as to raise the pantographs and powering the windscreen wipers.
<G-vec00169-001-s026><raise.anheben><de> "2007-03-29 17:57:04 - ""moderne"" Diäten und Ergänzungen Für die Mehrheit einen Leuten, die nicht ihre eigenen Nahrungsmittel anheben, können Diäten in den Vitaminen und in den Mineralien unzulänglich sein."
<G-vec00169-001-s026><raise.anheben><en> "2007-03-29 17:57:04 - ""modern"" diets and supplements For the majority of people who don't raise their own foods, diets can be deficient in vitamins and minerals."
<G-vec00169-001-s027><raise.anheben><de> Ein besonders nützliches Feature der BERNINA 950 Industrial ist der eingebaute Kniehebel-Nähfusslifter, mit dem sich der Nähfuss anheben lässt, ohne dass Sie die Hände von Ihrem Nähgut nehmen müssen.
<G-vec00169-001-s027><raise.anheben><en> An especially handy feature of the BERNINA 950 Industrial is the built-in, knee-lever-operated presser-foot lifter which lets you raise the presser foot without having to take your hands off your project.
<G-vec00169-001-s028><raise.anheben><de> """Viele Rohstoffe konnten im März gÃ1⁄4nstiger eingekauft werden, während die Nachfrage stark genug war, um den zweiten Monat in Folge die Verkaufspreise leicht anheben zu können."
<G-vec00169-001-s028><raise.anheben><en> """Companies were able to purchase many commodities at more affordable prices in March, while demand was strong enough for them to raise output prices slightly for the second month running."
<G-vec00169-001-s029><raise.anheben><de> Der Patient muss sich hinlegen und seine Beine anheben, um den Druck zu normalisieren.
<G-vec00169-001-s029><raise.anheben><en> The patient must lie down and raise his legs to normalize the pressure.
<G-vec00169-001-s030><raise.anheben><de> Die bereits veröffentlichten Bet anheben Falten erhielt starke Kritiken und Lob von der Poker-Community, und beide ultimative Beat-und Zeichnen Toten scheinen die gleiche Liebe zum Detail, dass Poker Spieler, wenn sie gehen, um einen Film ernst zu nehmen sind, erfordern.
<G-vec00169-001-s030><raise.anheben><en> The already released Bet Raise Fold received strong reviews and praise from the poker community, and both Ultimate Beat and Drawing Dead appear to have the same attention to detail that poker players require if they are going to take a film seriously.
<G-vec00169-001-s031><raise.anheben><de> Nikotin kann den Serumlipidspiegel anheben, kleine Blutgefäße verstopfen und zum Herzinfarkt führen.
<G-vec00169-001-s031><raise.anheben><en> Nicotine can raise blood lipid levels, obstruct small blood vessels, and cause heart attacks.
<G-vec00169-001-s032><raise.anheben><de> Vorteile der JBL Wasseraufbereiter Schnelles Anheben des pH-Wertes, Stabilisierung durch Erhöhung der Karbonathärte.
<G-vec00169-001-s032><raise.anheben><en> Benefits of the JBL water conditioners Raise the pH value fast, stabilise by increasing the carbonate hardness.
<G-vec00169-001-s033><raise.anheben><de> Sicherlich würde mehr TV-Präsent das Profil der Band in England anheben.
<G-vec00169-001-s033><raise.anheben><en> Surely more tv exposure would raise the band's profile in the UK.
<G-vec00169-001-s034><raise.anheben><de> Bei Treffen mit der Nestlé-Konzernleitung zu Gleichstellungsfragen hatte die IUL Nestlé immer wieder darauf hingewiesen, dass es seine globalen Standards auf dem Gebiet des Mutterschutzes zumindest auf das Niveau des IAO-Übereinkommens 183 anheben müsse.
<G-vec00169-001-s034><raise.anheben><en> In meetings with Nestlé corporate management on gender issues, the IUF had consistently pointed out to Nestlé that there was a need to raise its global standards on the issue of maternity protection at least to the level of ILO Convention 183.
<G-vec00169-001-s035><raise.anheben><de> Sie liebt es, wenn Sie sie Töne nachahmen.Ihr Baby kann ihren Kasten jetzt möglicherweise anheben, von ihr Arme gestützt, wenn sie auf ihrem Magen liegt.
<G-vec00169-001-s035><raise.anheben><en> She loves it when you imitate her sounds.Your baby can now perhaps raise her chest, supported by her arms, when she lies on her stomach.
<G-vec00169-001-s036><raise.anheben><de> Durch diese gemeinsame Meditation wollen wir aktiv die positive Schwingungsfrequenz weltweit anheben.
<G-vec00169-001-s036><raise.anheben><en> With this united meditation we want to actively raise the positive vibrations around the world.
<G-vec00169-001-s037><raise.anheben><de> Sollte diese Schlussfolgerung korrekt sein, würde eine DHEA-Ersatztherapie nicht nur den DHEA-Blutwert anheben, sondern auch die Mengen an Freiem Testosteron.
<G-vec00169-001-s037><raise.anheben><en> If this conclusion is correct, then DHEA replacement therapy would not only raise the blood level of DHEA, but also the level of free testosterone.
<G-vec00169-001-s038><raise.anheben><de> Da sie in vielen Bereichen inzwischen Weltmonopolstellungen erreicht hat, kann sie niemand hindern, die Preise für Gold, Diamanten, Kupfer, Zink, Eisenerz, Wasser, Saatgut oder Energie um 10, 20 oder 30% anzuheben und auf diese Weise die gesamte Weltbevölkerung zu Sonderabgaben heranzuziehen.
<G-vec00169-001-s038><raise.anheben><en> In many areas they have reached already world monopolies, and nobody can prevent them to raise the prices for gold, diamonds, copper, zinc, iron ore, water, seeds, or energy by 10, 20 or 30%!
<G-vec00169-001-s039><raise.anheben><de> Wenn Sie mit einer Bodenprobe den pH-Wert Ihrer Rasenfläche selbst bestimmen können, so düngen Sie zur pH-Anhebung 60 Gramm/Quadratmeter Kalk, um den pH um den Wert 0,5 anzuheben.
<G-vec00169-001-s039><raise.anheben><en> If you are able to determine the pH value of your lawn yourself with a soil probe, add 60 grammes of lime per square metre to raise the pH value by 0.5.
<G-vec00169-001-s040><raise.anheben><de> Rubrik: Normale Nachrichten, Startseite Der Gründer von Mercury, Carl E. Kiekhaefer hat seinen ersten Motor im Jahr 1939 gebaut und war dabei fest entschlossen, die Standards bei Marine Motoren ganz wesentlich anzuheben.
<G-vec00169-001-s040><raise.anheben><en> Mercury founder E. Carl Kiekhaefer sold his first outboard engine in 1939, determined to raise engine standards throughout the marine world.
<G-vec00169-001-s041><raise.anheben><de> Wenn die Börse dann hinuntergeht, müssen die japanischen Bänke hasten, um Kapital anzuheben, um BIS Standard eines 8-Prozent-Verhältnisses des Kapitals zu den Verbindlichkeiten zu entsprechen.
<G-vec00169-001-s041><raise.anheben><en> If the stock market goes down then the Japanese banks must scurry to raise capital to meet BIS standard of an 8 percent ratio of capital to liabilities.
<G-vec00169-001-s042><raise.anheben><de> Ihr Finanzangebot für Geschäftskunden ist darauf ausgerichtet, die lokale Güterproduktion zu stärken, Arbeitsplätze zu schaffen, die lokale Innovationskraft zu steigern und ökologische Standards anzuheben.
<G-vec00169-001-s042><raise.anheben><en> The banks' financing offer for business clients is intended to support local production, create jobs, boost local innovation and raise ecological standards.
<G-vec00169-001-s043><raise.anheben><de> Dies würde die US-Zentralbank zwingen, die Leitzinsen deutlicher als vom Markt erwartet anzuheben, was die Binnennachfrage unmittelbar schwächen würde.
<G-vec00169-001-s043><raise.anheben><en> This would force the Federal Reserve to raise federal funds rates more sharply than expected by the market, which would directly weaken domestic demand.
<G-vec00169-001-s044><raise.anheben><de> Antworten auf Leserfragen Der US-Präsident kann zwar die Geldpolitik nicht unmittelbar bestimmen, jedoch ergibt sich aus seinen Äußerungen, dass Trump Druck auf die US-Notenbank ausüben könnte, die Zinsen anzuheben – was dem wahrscheinlichen Plan der Fed bereits vor der Wahl entsprechen dürfte.
<G-vec00169-001-s044><raise.anheben><en> While the president cannot directly impact monetary policy, it appears from his rhetoric that [Donald] Trump may put pressure on the Federal Reserve (Fed) to raise rates—which actually seemed to be the Fed's likely path even before the election.
<G-vec00169-001-s045><raise.anheben><de> Kirchen kamen zu ihm, um zu sehen, wenn er ihnen helfen würde, Geld anzuheben; Auktionatoren kamen zu ihm, ihn zu veranlassen, für Landverkäufe zu spielen, um Bewerber anzuziehen; vaudeville Bucher kamen mit Angeboten, Touren zu spielen, die von Boston zu Florida reichten; Schulhausbetriebsleiter kamen zu ihm, um um ein Erscheinen zu bitten, um zu helfen, Bücher in den Tiefstand-gerissenen ländlichen Bezirken zu kaufen.
<G-vec00169-001-s045><raise.anheben><en> Churches came to him to see if he would help them raise money; auctioneers came to him to get him to play for country sales to attract bidders; vaudeville bookers came with offers to play tours that ranged from Boston to Florida; schoolhouse superintendents came to him asking for a show to help buy books in Depression-wracked rural districts.
<G-vec00169-001-s046><raise.anheben><de> Denn auf eurem Weg zum Aufstieg solltet ihr bestrebt sein, eure Eigenschwingung anzuheben.
<G-vec00169-001-s046><raise.anheben><en> As with your path to Ascension you should be aiming to raise your vibrations.
<G-vec00169-001-s047><raise.anheben><de> Für die feste Stabilität der Knöchel, der Beine und der Taille, anders ausgedrückt, um eine Grundlage für Stabilität zu schaffen, kann ich eine sehr einfache aber wirkungsvolle Methode empfehlen: wenn man beginnt, die Pistole anzuheben, sollte man sich leicht auf den Zehen erheben und sich dann ohne sich zurückzulehnen wieder zurücksenken.
<G-vec00169-001-s047><raise.anheben><en> For the firm stabilization of the ankles, legs and waist, in other words, to create a basis for stability, I can recommend a very simple but effective method: when you start to raise the pistol, raise yourself slightly on your toes and then lower yourself without leaning back.
<G-vec00169-001-s048><raise.anheben><de> Er unterstützt direkt und indirekt eine Reihe von Organisationen und Individuen, die versuchen, den Standard des russischen Kapitalismus, der Zivilgesellschaft und der Demokratie anzuheben.
<G-vec00169-001-s048><raise.anheben><en> He gives direct and indirect support to a range of organisations and individuals that are trying to raise the standards of Russian capitalism, civil society and democracy.
<G-vec00169-001-s049><raise.anheben><de> Deshalb ist es in manchen Fällen ratsam mit einem zusätzlichen Schnitt die Augenbrauen und das Stirn anzuheben(Facelift im oberen Gesichtsbereich und Augenbrauenanhebung).
<G-vec00169-001-s049><raise.anheben><en> Therefore, it is advisable in some cases with an additional section to raise the eyebrows and the forehead (Upper facelift and eyebrow lifting).
<G-vec00169-001-s050><raise.anheben><de> Es ist nicht leicht, das Bewusstsein der Menschen anzuheben; denn es sieht aus, als ob es da (nur) eine ganz kleine Entfernung zu überwinden gilt – aber das ist nicht so.
<G-vec00169-001-s050><raise.anheben><en> It's not easy to raise the awareness of people; because looks [like] there's a very little of distance of crossing over, but it's not so. It's not.
<G-vec00169-001-s051><raise.anheben><de> Der Haushaltsvorstand ist sofort ein Verwalter der regelmäßigen Verhältnisse innerhalb der Familie, ein Versorger der ökonomischen Nahrung, ein Lehrer der Sprache und Kultur, und anderer arbeitet notwendig, Kinder zu stützen und anzuheben.
<G-vec00169-001-s051><raise.anheben><en> The head of household is, at once, an administrator of orderly relationships within the family, a provider of economic sustenance, a teacher of language and culture, and a provider of other functions necessary to support and raise children.
<G-vec00169-001-s052><raise.anheben><de> „Diaverum verfolgt das Ziel, das Qualitätsniveau in der von uns geleisteten Krankenpflege ständig anzuheben und die bestmöglichen medizinischen Ergebnisse für alle unsere Patienten zu erreichen.
<G-vec00169-001-s052><raise.anheben><en> “The aim of Diaverum is to constantly raise the level of quality in the care that we deliver and to generate the best possible medical outcomes for all our patients.
<G-vec00169-001-s053><raise.anheben><de> Mit diesem Ausgangspunkt begann L. Ron Hubbard eine Untersuchung der zugrunde liegenden Prinzipien, welche die Stufe eines Wesens auf der Skala bestimmen – und stellte somit die Mittel zur Verfügung, diese Stufe anzuheben .
<G-vec00169-001-s053><raise.anheben><en> With this as his point of departure, L. Ron Hubbard commenced an investigation into the underlying principles monitoring a being's level on the scale—thus providing the means to raise it.
<G-vec00169-001-s054><raise.anheben><de> Jedoch um den Topf zu irgendeiner großer Größe sogar mit dem höchsten Paar auf dem schlechten Plumpsen anzuheben (das Plumpsen hat nicht Ihre Hand verbessert), sollte man Selbst-überzeugt auch spielen.
<G-vec00169-001-s054><raise.anheben><en> However, to raise the pot to some large size even with the highest pair on the bad Flop (the Flop has not improved your hand), one should play too self-confidently.
<G-vec00169-001-s055><raise.anheben><de> Halte den Fersenteil des Schuhs fest und versuche deine Ferse anzuheben.
<G-vec00169-001-s055><raise.anheben><en> Next, hold the back of the shoe and try to raise your heel.
<G-vec00169-001-s056><raise.anheben><de> Die adaptive air suspension ermöglicht es, die Trimmlage der Karosserie um bis zu 60 Millimeter anzuheben oder abzusenken.
<G-vec00169-001-s056><raise.anheben><en> The adaptive air suspension makes it possible to raise or lower the body's ride height by as much as 60 millimeters (2.36 in).
<G-vec00246-002-s019><raise.anheben><de> Damit wird die Logistik für Ihr Produkt minimiert und das Qualitätsniveau angehoben.
<G-vec00246-002-s019><raise.anheben><en> * We thus minimize the logistics for your product and raise the quality level.
<G-vec00246-002-s020><raise.anheben><de> Dadurch wird das Korn angehoben, trocknen lassen und dann erneut mit sehr feinem Schleifpapier (Körnung 600) leicht abgeschliffen.
<G-vec00246-002-s020><raise.anheben><en> This will raise the grain so allow to dry, then lightly sand once more using very fine sandpaper such as 600 grit.
<G-vec00246-002-s021><raise.anheben><de> Mit dem neuen Gesetz zur Jugendgerichtsbarkeit (JJ) soll der Standard von Kinderheimen und Waisenhäusern auf internationales Niveau angehoben werden, wie es die UNO vorschreibt.
<G-vec00246-002-s021><raise.anheben><en> New Juvenile Justice (JJ) Act intended to raise the standard of child homes and orphanages to international level as UNO prescribes.
<G-vec00246-002-s022><raise.anheben><de> Dies ist die Zeit, in der die natürlichen Energien unseres Planeten und Sonnensystems angehoben würden und alles Leben eine höhere Bewusstheit hinsichtlich unserer Verbundenheit und unserer Beziehung zum Vereinheitlichten Bewusstseinsfeld erlangen würde.
<G-vec00246-002-s022><raise.anheben><en> This is the time when the natural energies of our planet and solar system would raise and all life would experience a higher awareness of our connectedness and relationship to the Unified Field of Consciousness.
<G-vec00246-002-s023><raise.anheben><de> Nur 5,6% des gesamten Energieverbrauchs wird aus erneuerbaren Energiequellen gedeckt, wobei dieser Anteil bis 2010 auf 12% angehoben werden soll.
<G-vec00246-002-s023><raise.anheben><en> Only 5.6 % of the overall energy consumption is covered by renewable energy sources, with the intention to raise this quota to 12 % by 2010.
<G-vec00246-002-s024><raise.anheben><de> Produziert verbogenes Blech am Ende des Schneideprozesses: das Blech ist nicht mehr Flach und die äußeren Ränder sind leicht angehoben.
<G-vec00246-002-s024><raise.anheben><en> Bowing This effect results in a bowed sheet metal: the sheet metal is no longer flat as its edges raise from the plan.
<G-vec00246-002-s025><raise.anheben><de> Sie sind beispielsweise Teil des Konzeptes der „aktiven“ Motorhaube zur Erhöhung des Fußgängerschutzes, die im Kollisionsfall durch pyrotechnische Auslösung angehoben wird und so die Frontknautschzone weicher macht.
<G-vec00246-002-s025><raise.anheben><en> For example, they are part of a concept for an “active” bonnet to increase protection of pedestrians in the event of a collision by using pyrotechnic actuation to raise the bonnet, thereby softening the front crush zone.
<G-vec00246-002-s026><raise.anheben><de> Das Dach kann beim Laden angehoben werden, wodurch die volle, seitliche Ladehöhe benötigt werden kann.
<G-vec00246-002-s026><raise.anheben><en> The roof may be raise when loading, which provides full loading height from the side.
<G-vec00246-002-s027><raise.anheben><de> Daher möchten wir eure Meinung dazu hören, ob die Levelbegrenzung auf NOVA jetzt angehoben werden sollte, oder ob dies vielleicht zu einem späteren Zeitpunkt geschehen soll, wenn mehr von euch dieser Herausforderung gewachsen sein werden.
<G-vec00246-002-s027><raise.anheben><en> That's why we would like to learn your collective opinion on whether we should raise the level cap on NOVA now or wait for a better moment when more of you are ready for this transition.
<G-vec00246-002-s028><raise.anheben><de> Durch die Erhöhung des Muskelvolumens wird die Fettschicht angehoben, wodurch der Bauch noch konvexer und voluminöser wird.
<G-vec00246-002-s028><raise.anheben><en> Increasing in the volume of the muscle will raise the layer of fat, making the stomach look even more convex and bulky.
<G-vec00246-002-s029><raise.anheben><de> Wenn Sie Ihren Grenzwert auf 2.000 $ festlegen, erfolgt die Belastung solange weiterhin bei Erreichen des Abrechnungslimits, bis dieses mit der Zeit angehoben wird und Ihren Grenzwert von 2.000 $ erreicht hat.
<G-vec00246-002-s029><raise.anheben><en> You can set your limit at $2000, but we’ll continue to charge you when you reach the billing threshold until we raise the billing threshold over time and it reaches your limit of $2,000.
<G-vec00246-002-s030><raise.anheben><de> Wenn nach 90 Tagen keine Fortschritte bei der Strukturreform erzielt werden, werden die US-amerikanischen Zolltarife auf 25% angehoben werden, sagte die Pressesprecherin des Weißen Hauses, Sarah Huckabee Sanders, in einer Erklärung.
<G-vec00246-002-s030><raise.anheben><en> After 90 days, if there’s no progress on structural reform, the U.S. will raise those tariffs to 25%, White House Press Secretary Sarah Huckabee Sanders said in a statement.
<G-vec00246-002-s031><raise.anheben><de> So sollten die flachen Betonbrücken über dem Flüsschen angehoben werden, damit sich dort Geröll und Geäst nicht mehr stauen können.
<G-vec00246-002-s031><raise.anheben><en> They agreed to raise the flat concrete bridge over the river, so that debris and branches could no longer cause blockages there.
<G-vec00298-002-s038><lift.anheben><de> Der Drehbühneheber ist besonders in das Stadium installiert, um das Stadium anzuheben oder zu drehen, also wird er als anhebendes Stadium genannt.
<G-vec00298-002-s038><lift.anheben><en> The revolving stage lifter is specially installed in the stage to lift or rotate the stage, so it is called as lifting stage.
<G-vec00298-002-s039><lift.anheben><de> Für Anwendungen mit großen Baugruppen können mehrere Roboter synchronisiert werden, um ein großes Bauteil mithilfe kooperativer Bewegungssteuerung anzuheben oder einzubauen.
<G-vec00298-002-s039><lift.anheben><en> For large assembly applications, multiple robots can be synchronized to lift or assemble a large component using cooperative motion control.
<G-vec00298-002-s040><lift.anheben><de> Verbände mit Safetac® ermöglichen es Ihnen, den Verband anzuheben und zurück zu legen, ohne dass seine Klebeeigenschaften verloren gehen.
<G-vec00298-002-s040><lift.anheben><en> Safetac® technology allows you to lift and replace the dressing without adherent properties being lost.
<G-vec00298-002-s041><lift.anheben><de> ·Der Untertageparkautoaufzug kann benutzt werden, um Fracht mit den verschiedenen Niveaus anzuheben, die für die Fracht passend sind, die zwischen Treppe, vom Keller auf erstes Stockwerk oder auf zweiten Stock sich bewegt.
<G-vec00298-002-s041><lift.anheben><en> ·The underground parking car lift can be used to lift cargo with different levels, suitable for cargo moving between stairs, from basement to first floor, or to second floor.
<G-vec00298-002-s042><lift.anheben><de> In seiner Hauptfunktion, dem Absenken des Fußes (Anheben der Ferse im Stand), ist er in der Lage, das gesamte Körpergewicht mehrmals anzuheben.
<G-vec00298-002-s042><lift.anheben><en> In its main function, the lowering of the foot (heel raise in standing position), it is able to lift the entire body weight several times.
<G-vec00298-002-s043><lift.anheben><de> Der Aufzug der Struktur und der Arbeitsfläche kann ohne den Gebrauch anderer Ausrüstung erfolgt sein, ihn anzuheben.
<G-vec00298-002-s043><lift.anheben><en> The elevation of the structure and operating platform can be done without the use of other equipment to lift it.
<G-vec00298-002-s044><lift.anheben><de> Wir hatten für den Bau keine elektrischen Gerätschaften, keine Bauunternehmer oder Subunternehmer, die mitgeholfen haben, keine raffinierten Kräne, um die schweren Steine anzuheben.
<G-vec00298-002-s044><lift.anheben><en> We had no power equipment. No contractors or subcontractors were involved in the construction, no fancy cranes to lift up the heavy stones.
<G-vec00298-002-s045><lift.anheben><de> Diese Einheiten werden eingesetzt, um die Beine und Bootskörper von Bohrinseln, Hebeschiffen und Windradinstallationsschiffen anzuheben und abzusenken.
<G-vec00298-002-s045><lift.anheben><en> The units work in lifting and lowering legs and hulls of drilling and service jack up rigs, lift boats and windmill installation vessels.
<G-vec00298-002-s046><lift.anheben><de> Der Henkel ermöglicht Dir den Kopf anzuheben, ohne Dir die Finger zu verbrennen und verhindert, dass er von Deinem Tisch rollt.
<G-vec00298-002-s046><lift.anheben><en> The handle allows you to lift the bowl without burning your fingers and it prevents the bowl from rolling down your table.
<G-vec00298-002-s047><lift.anheben><de> Ein Vorschlag ist die Kreditvergabe zu reduzieren, hohe Beleihungswerte zu unterbinden oder gleich versuchen, die Zinsen anzuheben.
<G-vec00298-002-s047><lift.anheben><en> One proposal has been to reduce lending, prohibit high loan-to-value (LTV) ratios and/or immediately attempt to lift interest rates.
<G-vec00298-002-s048><lift.anheben><de> Jetzt ist es nicht mehr notwendig, die Düse anzuheben, um größere Krümel zu entfernen und eine herausragende Reinigungsleistung auf Ihren Hartböden zu erzielen.
<G-vec00298-002-s048><lift.anheben><en> Now there is no more need to lift the nozzle to remove bigger crumbs and ensure an exceptional clean of your hard floors.
<G-vec00298-002-s049><lift.anheben><de> Ziehe am Saugnapf, um das Display anzuheben und das iPhone zu öffnen.
<G-vec00298-002-s049><lift.anheben><en> Pull up on the suction cup to lift up the display and open the iPhone.
<G-vec00298-002-s050><lift.anheben><de> Außerdem kann Suspendierungs-Arbeitsbühne benutzt werden, um Dichte anzuheben.
<G-vec00298-002-s050><lift.anheben><en> Besides, Suspension Working Platform can be used to lift specific weight.
<G-vec00298-002-s051><lift.anheben><de> Versuchen Sie auf keinen Fall, die Anhängerkupplung ‚anzuheben‘, indem Sie schwere Objekte hinten in den Wohnwagen legen.
<G-vec00298-002-s051><lift.anheben><en> Please do not try to ‘lift’ the towbar by placing heavy items in the back of the caravan.
<G-vec00298-002-s052><lift.anheben><de> Mit dem neu entwickelten Sonderlastteil ist es möglich, einen Pkw, egal ob von vorn oder hinten, mittig zu unterfahren, beide Räder zu fixieren und das Fahrzeug zum Transport anzuheben.
<G-vec00298-002-s052><lift.anheben><en> Using the newly developed special fork configuration, one can slide the fork underneath a car from the front, back or in the middle, secure both wheels, and lift the vehicle to transport it.
<G-vec00298-002-s053><lift.anheben><de> Eine Kombination leichter Materialien und Bauweisen und ein ergonomischer Griff sorgen dafür, dass dieser Stromerzeuger leicht anzuheben und zu tragen ist.
<G-vec00298-002-s053><lift.anheben><en> A combination of lightweight materials and design, and an ergonomic handle make this generator easy to lift and carry. Sit comfortably
<G-vec00298-002-s054><lift.anheben><de> Da das Glas ein geringes Gewicht hat und der Kelch auf der Hand ruhen kann, ist nur eine geringe Greifkraft erforderlich, um das Glas anzuheben.
<G-vec00298-002-s054><lift.anheben><en> Because the glass weighs little and the chalice can rest on the hand, only little grip force is needed to lift the glass.
<G-vec00298-002-s055><lift.anheben><de> Bitte ihn/sie, die Daumen über Deinen Augenbrauen in der Mitte Deiner Stirn platzieren und die Daumen nach oben zur Haarlinie hin zu ziehen und dann anzuheben.
<G-vec00298-002-s055><lift.anheben><en> Have your friend place his thumbs above your eyebrows in the center of your forehead and draw the thumbs up toward the hairline, then lift.
<G-vec00298-002-s056><lift.anheben><de> Sie werden hauptsächlich in zwei Modellen hergestellt: faltbar(um Platz zu sparen und in Kofferraum und ähnlichen Räumen transportiert werden zu können) und starr .Viele der beiden Modelle werden aus ultraleichten Materialien hergestellt, wie z Aluminiumvon Flugzeugen und Carbon-Titan mit einer Kevlar-Beschichtung, um eine höhere Haltbarkeit und vor allem Leichtigkeit zu bieten, da der Benutzer es in der Lage sein sollte, es anzuheben und zu lagern, wodurch ein gewisses Maß an Autonomie und Autarkie erreicht wird.
<G-vec00298-002-s056><lift.anheben><en> They are manufactured in two models mainly - folding (to save space and be able to be transported in luggage racks and other similar rooms) and rigid . Many of both models are made of ultralight materials, such as aluminum aircraft and carbon titanium with a Kevlar coating to provide greater durability, and especially lightness, since its user should be able to lift and store it, thus achieving a certain degree of autonomy and self-sufficiency.
<G-vec01194-002-s019><lift.anheben><de> Den Teig anheben und behutsam über die Backform ziehen, so dass der dickere Rand des Teiges über die Backform hängt.
<G-vec01194-002-s019><lift.anheben><en> Lift the dough and stretch it over the mould so the thicker edge of the dough hangs down.
<G-vec01194-002-s020><lift.anheben><de> Während des Kurses Manual Handling (Manuelle Handhabung) lernen Sie innerhalb eines halben Tages, wie Sie Verletzungen vermeiden können und wie Sie schwere Geräte sicher anheben können.
<G-vec01194-002-s020><lift.anheben><en> During the Manual Handling Course you will learn within half a day how you can prevent injuries and how you can lift heavy equipment in a secure manner.
<G-vec01194-002-s021><lift.anheben><de> Anschließend die Karte ein wenig anheben und die Zecke rausschieben.
<G-vec01194-002-s021><lift.anheben><en> Then lift it a little bit and push out the tick.
<G-vec01194-002-s022><lift.anheben><de> Wenn Sie anfangen, Ihren Kasten auszubilden, müssen Sie entdecken, wieviel Gewicht Sie anheben müssen, um maximales Wachstum anzuregen.
<G-vec01194-002-s022><lift.anheben><en> When you begin training your chest, you'll need to discover how much weight you must lift to stimulate maximum growth.
<G-vec01194-002-s023><lift.anheben><de> Die Endorphine oder Chemikalien, die beim Sport freigesetzt werden, können sogar deine Stimmung anheben, wenn du dich niedergeschlagen fühlst.
<G-vec01194-002-s023><lift.anheben><en> The endorphins, or chemicals, released when you exercise may even lift your mood if you’re feeling down.
<G-vec01194-002-s024><lift.anheben><de> Gebrauchsanweisung Zum Spannen den Hebel anheben um die Verzahnung zu lösen und in die Ausgangsstellung ziehen.
<G-vec01194-002-s024><lift.anheben><en> For clamping, lift the lever to disengage the clamping device teeth and bring it back to start position.
<G-vec01194-002-s025><lift.anheben><de> Eines dieser Mittel sind BHs push up, die Ihre Brust anheben und somit an ihrem Volumen herzaubern.
<G-vec01194-002-s025><lift.anheben><en> One of these solutions is push up bras, which lift your breasts and seem to magically add to their volume.
<G-vec01194-002-s026><lift.anheben><de> Der HMS Safe Lock G2 Karabiner von SALEWA mit der 3-fach Verschlusstechnik ist erst durch "Anheben und Drehen" zu öffnen.
<G-vec01194-002-s026><lift.anheben><en> No More Lock G2 carabiner by SALEWA with a three-way locking technology can be opened after "lift and turn".
<G-vec01194-002-s027><lift.anheben><de> Der Bühnenaufzug, der das Anheben eines Autos oder anderer Werbeprodukte ermöglicht, ist ein einzigartiges Tool.
<G-vec01194-002-s027><lift.anheben><en> The stage lift, which allows a car or other promotional product, to be raised and tilted, is a unique feature.
<G-vec01194-002-s028><lift.anheben><de> Erste Schritte > Display zum Öffnen anheben.
<G-vec01194-002-s028><lift.anheben><en> > Lift to open the display panel.
<G-vec01194-002-s029><lift.anheben><de> Du kannst den Druckerwagen wie gezeigt mit einer Hand anheben, so dass du mit der anderen Hand besser an das Kabel herankommst.
<G-vec01194-002-s029><lift.anheben><en> You may need to lift the carriage up with one hand in order to reach the cable with the free hand as shown. Rota la
<G-vec01194-002-s030><lift.anheben><de> Mit der Gabel lässt sich der Ladungsträger untergreifen, anheben und in Querrichtung transportieren.
<G-vec01194-002-s030><lift.anheben><en> The fork can be inserted under the load carrier, lift it, and transport it in the transverse direction.
<G-vec01194-002-s031><lift.anheben><de> Wenn Sie die Hand nicht mehr in die Dorsalflexion bringen können, also die Hand nicht mehr anheben können, hängt die Hand nach unten.
<G-vec01194-002-s031><lift.anheben><en> If you cannot make dorsal flexion with your hand anymore, in other words: you can not lift the hand, the hand hangs down.
<G-vec01194-002-s032><lift.anheben><de> Fahren Sie fort, indem Sie Ihren Finger immer wieder anheben und langsam absenken und dabei die Position Ihres Fingers jeweils nur ein klein wenig ändern.
<G-vec01194-002-s032><lift.anheben><en> Continue to lift and rest your finger slowly, making small adjustments to the position of your finger each time.
<G-vec01194-002-s033><lift.anheben><de> ASUS ROG G751JY > Display zum Öffnen anheben.
<G-vec01194-002-s033><lift.anheben><en> ASUS ROG G751JY > Lift to open the display panel.
<G-vec01194-002-s034><lift.anheben><de> Schnitte können unter deinem Kinn auch gebildet werden, wenn du eine absackende Kieferlinie anheben möchtest.
<G-vec01194-002-s034><lift.anheben><en> Cuts may also be made under your chin, if you want to lift a sagging jaw line.
<G-vec01194-002-s035><lift.anheben><de> Darunter ein gegossener Aluminiumteller mit Slip-Mat, ein Stroboskop für die Geschwindigkeitsanzeige am Plattentellerrand, wählbaren Pitch-Anpassungsbereich, Start/Stopp-Knopf, ein Suchlicht für die Nadel, ein hydraulischer Hebel für das Anheben des Tonarms und eine Tonarmstütze mit Sperrfunktion, die den Tonarm während eines Transports sicher an ihrem Platz hält.
<G-vec01194-002-s035><lift.anheben><en> Additional DJ-friendly features including a damped cast-aluminum platter with stroboscopic speed markings and slip mat, an illuminated speed indicator and adjustable pitch control, a start/stop button, a removable stylus target light, a dedicated tone arm grounding lug, a hydraulically-damped lift lever and a locking tone arm rest that keeps the arm and cartridge in place during transport.
<G-vec01194-002-s036><lift.anheben><de> Zu Beginn musst du das Lautsprecherkabel mit einem Spudger anheben.
<G-vec01194-002-s036><lift.anheben><en> To begin removing the right speaker, lift the speaker wire with a screwdriver or spudger.
<G-vec01194-002-s037><lift.anheben><de> Sofern der Platz unter dem Tapelager für eine Lege- Klebevorrichtung (LKV, mould) benötigt wird, lassen sich diese Tischelemente einfach mittels Kran anheben und neben dem Tapeleger platzsparend aufstapeln.
<G-vec01194-002-s037><lift.anheben><en> If the position under the tape layer is needed for a mould, it is possible to lift the table elements simply by crane and to stack them up in a space-saving manner.
<G-vec01194-002-s032><raise.anheben><de> Beim Abspielen kann man das Tempo beliebig ändern, die Noten nach Bedarf transponieren (höher oder tiefer) und auch die Lautstärke einzelner Stimme anheben oder absenken.
<G-vec01194-002-s032><raise.anheben><en> For playing the music, you can change the tempo as desired, transpose the notes as required (higher or lower) and also raise or lower the volume of any instrument in the score.
<G-vec01194-002-s033><raise.anheben><de> Durch die horizontale Anordnung der Holzpaneele an den Wänden können Sie die Breite des Raumes optisch erhöhen, während die schmalen vertikalen Paneele die Decke anheben.
<G-vec01194-002-s033><raise.anheben><en> Horizontal placement of wooden panels on the walls allows you to visually increase the width of the room, while narrow vertical panels raise the ceiling.
<G-vec01194-002-s034><raise.anheben><de> Zur Behandlung wird dem Patienten ein Verband angelegt, dazu muss der Patient im Bett sein verletztes Bein um fünfzehn Zentimeter anheben.
<G-vec01194-002-s034><raise.anheben><en> For treatment, a bandage is applied to the patient, for this the patient needs to raise his injured leg by fifteen centimeters while lying in bed.
<G-vec01194-002-s035><raise.anheben><de> Gehen Sie in die Vergangenheit zurück, während Sie an Bord der Yacht der 1920er Jahre mit Teakholzboden und Open-Air-Decks an Bord gehen und ein mit Mimosen gefülltes Glas anheben, um im Big Apple zu brunchieren.
<G-vec01194-002-s035><raise.anheben><en> Go back in time as you board the 1920s style yacht with teak floors and open-air decks and raise a mimosa filled glass to brunch in the Big Apple.
<G-vec01194-002-s036><raise.anheben><de> Es wird zwangsläufig einige Augenbrauen anheben.
<G-vec01194-002-s036><raise.anheben><en> It is bound to raise some eyebrows.
<G-vec01194-002-s037><raise.anheben><de> Überschreitet der Zeitraum zwischen Vertragsabschluss und Vertragserfüllung vier Monate und erhöht sich der vom Hotel allgemein für derartige Leistungen berechnete Preis, so kann dieses den vertraglich vereinbarten Preis nach billigem Ermessen anheben.
<G-vec01194-002-s037><raise.anheben><en> If the period between conclusion and the fulfilment of the contract exceeds four months and if the price generally charged by the hotel for such services increases, the hotel may raise the contractually agreed price at his reasonable discretion. 4.
<G-vec01194-002-s038><raise.anheben><de> In seiner Hauptfunktion, dem Absenken des Fußes (Anheben der Ferse im Stand), ist er in der Lage, das gesamte Körpergewicht mehrmals anzuheben.
<G-vec01194-002-s038><raise.anheben><en> In its main function, the lowering of the foot (heel raise in standing position), it is able to lift the entire body weight several times.
<G-vec01194-002-s039><raise.anheben><de> Dank der intuitiven Joysticksteuerung des Fusion können Sie die Auflagefläche mühelos anheben und absenken, Ihre Ausgangsposition ändern und zurücksetzen, mithilfe der „Jog“-Funktion den Laserkopf bewegen und vieles mehr.
<G-vec01194-002-s039><raise.anheben><en> The intuitive joystick control on the Fusion allows you to easily raise and lower the table, move and reset your home position, use the jog feature to move the laser head, and much more.
<G-vec01194-002-s040><raise.anheben><de> Um die Intensität der Übung zu erhöhen, können Sie wie auf dem Foto auch beide Arme und beide Beine einige Zentimeter über dem Boden anheben.
<G-vec01194-002-s040><raise.anheben><en> To increase the intensity of the exercise, you can also raise both your arms and both legs a few centimeters off the ground, as in the photo.
<G-vec01194-002-s041><raise.anheben><de> Um beim Eingießen des Milchschaums den Espresso besser anheben zu können, ist eine leicht geweitete Form nach oben zu empfehlen.
<G-vec01194-002-s041><raise.anheben><en> To be able to raise the espresso better while pouring the milk froth we recommend a shape which is slightly wider towards the top.
<G-vec01194-002-s042><raise.anheben><de> Maschine anheben mit elektrohydraulischem Aggregat im Notbetrieb.
<G-vec01194-002-s042><raise.anheben><en> Electrohydraulic power pack to raise machine in emergency mode.
<G-vec01194-002-s043><raise.anheben><de> Sparsame Leute können die Laufzeit mit maximalen Energieeinsparungen auf fünf Stunden (305 Minuten) anheben (BatteryEater Reader).
<G-vec01194-002-s043><raise.anheben><en> Thrifty people might be able to raise the battery life to five hours (305 minutes) (BatteryEater Reader) on maximum energy saving settings.
<G-vec01194-002-s044><raise.anheben><de> Indem der Fahrer einen Knopf auf dem Armaturenbrett drückt, kann er die Achse bei Leerfahrten anheben.
<G-vec01194-002-s044><raise.anheben><en> By pushing a button on the dashboard, the driver can raise the axle when the truck is unloaded.
<G-vec01194-002-s045><raise.anheben><de> Und die nächste Version wird die Messlatte weiter anheben - mit einigen weiteren coolen Features.
<G-vec01194-002-s045><raise.anheben><en> And next version will raise the bar even more with some cool features.
<G-vec01194-002-s046><raise.anheben><de> Im Falle der Unrichtigkeit von Teilen und von Mangel, müssen Kunden Anspruch zu uns innerhalb 10 Tage vom Eingangsdatum von Waren anheben.
<G-vec01194-002-s046><raise.anheben><en> In case of incorrectness of parts and shortage, customers must raise claim to us within 10 days from the date of receipt of goods.
<G-vec01194-002-s047><raise.anheben><de> Wenn Sie beispielsweise Ihr Haar in Erweiterungen mit Ihrem Clip anheben möchten, können Sie bestimmte Streifen weglassen.
<G-vec01194-002-s047><raise.anheben><en> For example, if you want to raise your hair with your clip in extensions, you can omit certain strips.
<G-vec01194-002-s048><raise.anheben><de> Aus einer Tradingperspektive ist dies ein guter Punkt zum Reduzieren des Long-Engagements / zum Anheben schützender Stops – achten Sie hier auf eine mögliche Erschöpfung nach oben hin.
<G-vec01194-002-s048><raise.anheben><en> From a trading standpoint, a good spot to reduce long-exposure / raise protective stops – be on the lookout for possible topside exhaustion here.
<G-vec01194-002-s049><raise.anheben><de> Man kann bei einem Intel B365 Mainboard also keinen Multi erhöhen und derzeit sogar noch nicht mal den BCLK etwas anheben, um die CPU zu übertakten.
<G-vec01194-002-s049><raise.anheben><en> So you can’t increase a multi on an Intel B365 motherboard and currently you can’t even raise the BCLK a bit to overclock the CPU.
<G-vec01194-002-s050><raise.anheben><de> Das BENDER-Rad dient zum stufenlosen Anheben oder Absenken der Tonhöhe eines Klangs, während das MODULATION-Rad diesem Vibrato (Modulationseffekt) zugibt.
<G-vec01194-002-s050><raise.anheben><en> Using the Wheels (Bender, Modulation) bt The BENDER wheel can be use to seamlessly raise or lower the pitch of a sound, while the MODULATION wheel adds vibrato (modulation effect) to the sound.
<G-vec01194-002-s063><raise.anheben><de> Die neue Kommissionspräsidentin Ursula von der Leyen hat den klimapolitisch progressiven EP-Fraktionen im Vorfeld ihrer Wahl eine Initiative zugesagt, um das Ziel auf mindestens 50 Prozent anzuheben.
<G-vec01194-002-s063><raise.anheben><en> In the run up to her election, the new Commission President, Ursula von der Leyen, has promised the EP an initiative to raise the target to at least 50 per cent.
<G-vec01194-002-s064><raise.anheben><de> Bleibt ruhig und gelassen und helft mit, den allgemeinen Schwingungs-Level anzuheben, indem ihr eure Eigenschwingung hochhaltet und liebevolle Gedanken dorthin sendet, wo ihr Zwietracht oder Negativität beobachtet.
<G-vec01194-002-s064><raise.anheben><en> Keep calm and help to raise the vibrations by keeping your own steady, and send out loving thoughts where you find discord or negativity.
<G-vec01194-002-s065><raise.anheben><de> Das Opfer wird gezwungen den Oberkörper im rechten Winkel zu den Beinen nach vorn zu beugen und die Arme hinter dem Rücken anzuheben.
<G-vec01194-002-s065><raise.anheben><en> The victim is forced to bend his body at a right angle to the legs, and raise his arms behind his back.
<G-vec01194-002-s066><raise.anheben><de> Bei Ihnen zu Hause können Sie viele der gleichen Vorteile erhalten, indem Sie einen Hocker in der Nähe Ihrer Toilette platzieren, um Ihre Knie anzuheben, ein spezielles Hockgerät kaufen, um Ihre Toilette zu modifizieren, oder einfach auf Ihrer eigenen Toilette hocken.
<G-vec01194-002-s066><raise.anheben><en> In your home, you can get many of the same benefits by placing a stool near your toilet to raise your knees, purchasing a special squatting device to modify your toilet, or simply squatting on your own toilet.
<G-vec01194-002-s067><raise.anheben><de> JAC-Mitglieder arbeiten gemeinsam daran, ihre Partnernetzwerke dazu zu verpflichten, Transparenz zu fördern und aufzuzeigen, dass die Branche ihre Differenzen außen vor lassen kann, um CSR- und Nachhaltigkeitsstandards innerhalb der Lieferkette anzuheben.
<G-vec01194-002-s067><raise.anheben><en> JAC members collaborate in engaging their networks of trading partners to promote transparency and demonstrate that industry can put aside its differences to raise supply chain CSR and sustainability standards.
<G-vec01194-002-s068><raise.anheben><de> Der aufsichtsrechtliche und der Anlegerdruck hat ebenfalls dazu beigetragen, das Niveau der ESG-Angaben der Unternehmen in den Schwellenländern anzuheben.
<G-vec01194-002-s068><raise.anheben><en> Regulatory and investor pressures have also helped to raise the bar for corporate ESG disclosures in emerging markets.
<G-vec01194-002-s069><raise.anheben><de> Read more about Förderung der Bioabfallverwertung durch Kreislaufwirtschaftsgesetz und Erneuerbare-Energien-Das Ziel der EU, den Biokraftstoffanteil im Verkehr bis 2020 auf 10 % anzuheben, gehört zu den umstrittensten umweltpolitischen Entscheidungen der letzten Jahre.
<G-vec01194-002-s069><raise.anheben><en> Read more about Science-Policy Interface and the Role of Impact Assessment in the Case of Biofuels The EU target to raise the share of biofuels in transport to 10 % by 2020 remains one of the most controversial environmental policy decisions in recent years.
<G-vec01194-002-s070><raise.anheben><de> Die Grundidee ist einfach, eine Störung Markierungsfahne anzuheben, wenn etwas falsch geht.
<G-vec01194-002-s070><raise.anheben><en> The basic idea is simply to raise an error flag when something goes wrong.
<G-vec01194-002-s071><raise.anheben><de> Darüber hinaus hat die Notenbank angekündigt, die Zinsen wohl erst mit Ablauf des nächsten Sommers anzuheben, was sich stabilisierend sowohl auf den Euro also auch auf die Renditen der Bundesanleihen auswirken dürfte.
<G-vec01194-002-s071><raise.anheben><en> The bank has also confirmed it’s unlikely to raise interest rates until we’re through the summer of next year at least, keeping the euro and bund yields anchored for now.
<G-vec01194-002-s073><raise.anheben><de> Um es trotzdem gesellschaftsfähig zu machen und das Niveau anzuheben gehört eine gute Portion Mut und guter Geschmack.
<G-vec01194-002-s073><raise.anheben><en> In order to make it still socially acceptable and to raise the level you must have a good deal of courage and good taste.
<G-vec01194-002-s075><raise.anheben><de> Aufgrund der Erhöhung der Bettensteuer in 2017 sind wir leider gezwungen, den Preis entsprechend anzuheben.
<G-vec01194-002-s075><raise.anheben><en> Due to the increase in bed tax in 2017, we are forced to raise the price accordingly.
<G-vec01194-002-s076><raise.anheben><de> Eine solche Differenzierung hilft, die Decke optisch anzuheben und die Platzeinsparung zu beseitigen.
<G-vec01194-002-s076><raise.anheben><en> Such a differentiation will help visually raise the ceiling and eliminate the reduction of space.
<G-vec01194-002-s077><raise.anheben><de> Es ist Zeit, eure APM im Spiel anzuheben und geschaute Stunden in der Streamer-Statistik anzusammeln, damit ihr all diese zeitlich begrenzt verfügbaren Extras eurer Sammlung hinzufügen könnt.
<G-vec01194-002-s077><raise.anheben><en> It’s time to raise your APM in-game and rack up your hours watched on the streamer scoreboard so you can add all of these limited-time cosmetics to your collection.
<G-vec01194-002-s078><raise.anheben><de> Mit dieser alternativen Tastatur wischt man über die Buchstaben ohne den Finder anzuheben.
<G-vec01194-002-s078><raise.anheben><en> With this alternative keyboard you wipe over the letters without the Finder to raise.
<G-vec01194-002-s079><raise.anheben><de> Daher haben wir uns entschlossen, die Mindestspende auf 5 Euro anzuheben.
<G-vec01194-002-s079><raise.anheben><en> This is why we decided to raise the minimum donation amount to five euros.
<G-vec01194-002-s080><raise.anheben><de> Die Planung sah vor, das Bett der Orbe um zwei Meter anzuheben und mit einem Äquadukt unterhalb der Schleuse von Orbe über den Schifffahrtskanal auf die andere Seite zu leiten, um in einem getrennten Flussbett zum Neuenburgersee zu fließen.
<G-vec01194-002-s080><raise.anheben><en> The plan was to raise the bed of the Orbe by two metres and use an aqueduct below the Orbe lock to guide it across the shipping canal to the other side in order to flow in a separate river bed to Lake Neuchâtel.
<G-vec01194-002-s081><raise.anheben><de> Der Mann, der behauptet die Reinkarnation von Edgar Cayce zu sein, ist ein großer Lehrer, der niemals verpasst unsere Gedanken auf Dinge anzuheben, sodass wir aufwachen wollen.
<G-vec01194-002-s081><raise.anheben><en> The man who claims to be the reincarnation of Edgar Cayce is a great teacher who never fails to raise the thoughts toward things that make us want to wake up.
