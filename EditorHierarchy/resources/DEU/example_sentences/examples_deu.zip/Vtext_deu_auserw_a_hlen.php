<G-vec00228-002-s019><elect.auserwählen><de> Gottes heilige Engel sind „auserwählt“ – d.h. Gott hat sie gewählt.
<G-vec00228-002-s019><elect.auserwählen><en> God’s holy angels are “elect” – meaning that God has chosen them.
<G-vec00228-002-s020><elect.auserwählen><de> Auserwählt sind die, denen schöne Dinge nichts als Schönheit bedeuten.
<G-vec00228-002-s020><elect.auserwählen><en> They are the elect to whom beautiful things mean only beauty.
