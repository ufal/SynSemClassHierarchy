<G-vec01183-002-s047><disgust.anwidern><de> Hikari schweifte ab, als sie bemerkte, dass der Rotschopf die Ausstellungsstücke nicht mehr angewidert betrachtete, sondern eher so, als hätte sie einen Geist gesehen.
<G-vec01183-002-s047><disgust.anwidern><en> Hikari trailed off as she noticed that the redhead was no longer regarding the expositions with disgust, but rather looked like she had seen a ghost.
<G-vec01183-002-s048><disgust.anwidern><de> Er legte angewidert auf, er wollte den Rest nicht hören.
<G-vec01183-002-s048><disgust.anwidern><en> He hung up in disgust, not wanting to hear the rest.
<G-vec01183-002-s049><disgust.anwidern><de> Dieter Laser: Ich will nicht verhehlen, dass ich mich genauso wie viele Kritiker „angewidert abgewendet“ habe, als das Drehbuch bei mir zu Hause eintraf.
<G-vec01183-002-s049><disgust.anwidern><en> Dieter Laser: I don’t want to hide the fact that just like many blindfolded critics I „turned away in disgust“ when the script arrived at home.
