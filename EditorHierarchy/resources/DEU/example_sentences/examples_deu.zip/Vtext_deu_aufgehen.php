<G-vec00510-001-s133><rise.aufgehen><de> Ekliptik-Hub oder -Fallen wird an Hand beider Hemisphären bestimmt, die die Sonne zu weit im Süden oder Norden aufgehen oder untergehen vorfinden, wie in der 2006-Sonnenwende.
<G-vec00510-001-s133><rise.aufgehen><en> Ecliptic Rise or Drop is determined by both hemispheres finding the Sun rising and setting too far South or North, as in the 2006 Solstice.
<G-vec00510-001-s134><rise.aufgehen><de> Die Sonne wird jeden Tag aufgehen, aber eure Elektrogeräte und Hilfsmittel nicht unbedingt.
<G-vec00510-001-s134><rise.aufgehen><en> The sun will rise every day, but all your appliances and contrivances may not.
<G-vec00510-001-s135><rise.aufgehen><de> Legen Sie viel Mehl hinein, bevor Sie das Brot zum Aufgehen bringen, sonst klebt es leicht und entfernt das Design, das die Brote charakterisiert, die im Inneren gesäuert sind.
<G-vec00510-001-s135><rise.aufgehen><en> Put a lot of flour inside before placing the bread to rise otherwise it will stick slightly removing the design that characterizes the loaves leavened inside.
<G-vec00510-001-s136><rise.aufgehen><de> Es scheint, als würde das Konzept von Tradeforceone.de aufgehen und bereits erste Früchte tragen, da bei den bisher angesprochenen Brokern durchaus eine gewisse Akzeptanz erkennbar ist.
<G-vec00510-001-s136><rise.aufgehen><en> It seems, as if the concept of Tradeforceone.de rise and bear fruit already, as in the previously mentioned brokers quite some acceptance is evident.
<G-vec00510-001-s137><rise.aufgehen><de> In wenig Milch mit einem Löffel Zucker die Hefe verteilen, zudecken und aufgehen lassen.
<G-vec00510-001-s137><rise.aufgehen><en> Break the yeast into lukewarm milk with sugar. Cover it and let it rise.
<G-vec00510-001-s138><rise.aufgehen><de> Zugedeckt weitere 30-40 Minuten aufgehen lassen.
<G-vec00510-001-s138><rise.aufgehen><en> Leave to rise for another 30-40 minutes.
<G-vec00510-001-s139><rise.aufgehen><de> Den Teig in eine geölte Schüssel geben, mit Frischhaltefolie abdecken und an einem warmen Ort aufgehen lassen, bis er sich verdoppelt hat, (ca.
<G-vec00510-001-s139><rise.aufgehen><en> Turn dough into oiled bowl, cover with cling film, and leave in a warm place to rise until doubled, about 2 to 3 hours.
<G-vec00510-001-s140><rise.aufgehen><de> Streuen Sie die Gelatine in die 1/2 Tasse kaltes Wasser, Aufgehen lassen, In diesem Fall, lösen Sie Bain-Marie mit einem Löffel auf.
<G-vec00510-001-s140><rise.aufgehen><en> Sprinkle the gelatin in the 1/2 Cup cold water, Let it rise, When this happens, dissolve Bain-Marie moving with a spoon.
<G-vec00510-001-s141><rise.aufgehen><de> Der Prozess der Transformation des spezifisch personengebundenen Leninismus Rákosi's in seinen Stalinismus sollte weder für ihn noch für die Forschung ganz aufgehen können.
<G-vec00510-001-s141><rise.aufgehen><en> The process of the transformation of Rákosi's specifically personal Leninism in his Stalinism should no be able to rise neither for him nor for the research.
<G-vec00510-001-s142><rise.aufgehen><de> Wir hoffen, dass die Phase der Instabilität für unsere Nachbarländer in der ersehnten Freiheit und in Wohlstand mündet und dass eine vielversprechende Dämmerung über diesem Teil der Welt aufgehen möge.
<G-vec00510-001-s142><rise.aufgehen><en> We hope that from this period of instability will emerge the chance for the countries around us to find the freedom and prosperity for which they aspire, and that a promising dawn will rise over this part of the world.
<G-vec00510-001-s143><rise.aufgehen><de> tweet e-mail Stellen Sie sich vor, Sie hätten im Kindergarten die Monatsnamen nicht auswendig aufgesagt; sondern stattdessen den Jahresverlauf über den Himmel erfahren, indem Sie beobachteten, welche Sterne am Morgen aufgehen.
<G-vec00510-001-s143><rise.aufgehen><en> tweet e-mail Imagine you didn't recite the names of the months in kindergarten; instead you learned about the year through the sky, watching the morning stars rise.
<G-vec00510-001-s144><rise.aufgehen><de> In der 1/2 Tasse Wasser kalt ist, um die Gelatine-Hydrat, Aufgehen lassen, Dies geschieht beim Erhitzen Bain-Marie, mit einem Löffel zu verschieben, bis sich die Gelatine aufgelöst hat.
<G-vec00510-001-s144><rise.aufgehen><en> In the 1/2 Cup of water cold to hydrate the gelatin, Let it rise, This happens when heated Bain-Marie, move with a spoon until the gelatin is dissolved.
<G-vec00510-001-s145><rise.aufgehen><de> Die Sonne aufgehen und der Mond aufgeht sind wunderbar aus unserem Zimmer zu sehen.
<G-vec00510-001-s145><rise.aufgehen><en> The sun rise and the moon rise are wonderful to watch from our rooms.
<G-vec00510-001-s146><rise.aufgehen><de> Die Schüssel mit Frischhaltefolie abdecken und den Teig 30 Minuten an einem warmen Ort aufgehen lassen.
<G-vec00510-001-s146><rise.aufgehen><en> Cover the bowl with cling film and allow to rise in a warm place for around 30 minutes.
<G-vec00510-001-s147><rise.aufgehen><de> Der Teig sollte mindestens 1,5 mal aufgehen.
<G-vec00510-001-s147><rise.aufgehen><en> The dough should rise at least 1,5 times.
<G-vec00510-001-s148><rise.aufgehen><de> 45 damit ihr Söhne eures Vaters seid, der in den Himmeln ist; denn er läßt seine Sonne aufgehen über Böse und Gute und läßt regnen über Gerechte und Ungerechte.
<G-vec00510-001-s148><rise.aufgehen><en> 45 that ye may be [the] sons of your Father who is in [the] heavens; for he makes his sun rise on evil and good, and sends rain on just and unjust.
<G-vec00510-001-s149><rise.aufgehen><de> Den Teig in der Schüssel mit einem Tuch bedeckt an einem warmen Ort um das Doppelte aufgehen lassen.
<G-vec00510-001-s149><rise.aufgehen><en> Place the dough in the bowl, cover with a kitchen towel and let rise until doubled in a warm place.
<G-vec00510-001-s150><rise.aufgehen><de> - Und am nächsten Morgen lässt Gott seine Sonne wieder über Böse und Gute aufgehen.
<G-vec00510-001-s150><rise.aufgehen><en> - And on the following morning God causes the sun to rise on the evil and the good once more.
<G-vec00510-001-s151><rise.aufgehen><de> Bereiten Sie den Teig, aufgehen lassen, den Teig machen wir kleine runde Pfannkuchen, lassen Sie die Walze auf einer kleinen Treib .
<G-vec00510-001-s151><rise.aufgehen><en> Prepare the dough, let it rise, the dough we make small round pancakes, let the roller on a little leavening .
<G-vec00258-002-s068><arise.aufgehen><de> 4:2 Euch aber, die ihr meinen Namen fürchtet, soll aufgehen die Sonne der Gerechtigkeit und Heil unter desselbigen Flügeln; und ihr sollt aus-und eingehen und zunehmen wie die Mastkälber.
<G-vec00258-002-s068><arise.aufgehen><en> 4:2 And unto you that fear my name shall the Sun of righteousness arise with healing in his wings; and ye shall go forth and leap like fatted calves.
<G-vec00258-002-s069><arise.aufgehen><de> Ihr habt verstanden: Wenn der Morgenstern in eurem Herzen aufgehen soll, heißt das, dass er nicht schon immer dort war.
<G-vec00258-002-s069><arise.aufgehen><en> You have to understand: if the morning star must arise in your hearts it is because it is not always present there.
<G-vec00258-002-s070><arise.aufgehen><de> Aber euch, die ihr meinen Namen fürchtet, wird die Sonne der Gerechtigkeit aufgehen mit Heilung in ihren Flügeln.
<G-vec00258-002-s070><arise.aufgehen><en> But unto you that fear my name shall the Sun of righteousness arise with healing in his wings.
<G-vec00258-002-s071><arise.aufgehen><de> Maleachi 4:2 schildert ihn als die „Sonne der Gerechtigkeit“, die „mit Heilung in ihren Flügeln“ aufgehen wird.
<G-vec00258-002-s071><arise.aufgehen><en> In Malachi 4:2 he is described as “the Sun of Righteousness,” who will arise with “healing in his wings.”
<G-vec00258-002-s073><arise.aufgehen><de> 2Aber euch, die ihr meinen Namen fürchtet, wird die Sonne der Gerechtigkeit aufgehen mit Heilung in ihren Flügeln.
<G-vec00258-002-s073><arise.aufgehen><en> 2But unto you that fear my name shall the sun of righteousness arise with healing in its wings; and ye shall go forth, and gambol as calves of the stall.
<G-vec00258-002-s074><arise.aufgehen><de> 2 Euch aber, die ihr meinen Namen fürchtet, soll aufgehen die Sonne der Gerechtigkeit und Heil unter ihren Flügeln.
<G-vec00258-002-s074><arise.aufgehen><en> But unto you, who fear my name, the Sun of justice will arise, and health will be in his wings.
<G-vec00258-002-s075><arise.aufgehen><de> Dann wird euer Licht aufgehen wie die Mittagssonne.
<G-vec00258-002-s075><arise.aufgehen><en> Then your light shall arise like the noonday sun.
<G-vec00258-002-s077><arise.aufgehen><de> Euch aber, die ihr meinen Namen fürchtet, soll aufgehen die Sonne der Gerechtigkeit und Heil unter ihren Flügeln; und ihr sollt aus und eingehen und hüpfen wie die Mastkälber.
<G-vec00258-002-s077><arise.aufgehen><en> « But unto you that fear my name shall the sun of righteousness arise with healing in its wings; and ye shall go forth, and gambol as calves of the stall.
<G-vec00318-002-s019><merge.aufgehen><de> Im „Yoga Sandhya“ (Seite 112) wird empfohlen, dass ein Yogi, der die Yoga-Übungen ausführt, seine Ohren mit den Daumen verschließen und in sich den melodischen Weisen des chid-akash oder des geistigen Bereichs lauschen sollte, um dadurch sein Gemüt zu beruhigen und den Turya-Zustand zu erlangen, wodurch er dann in Avyakat aufgehen kann.
<G-vec00318-002-s019><merge.aufgehen><en> In Yog-Sandhya, *17 it is enjoined that a yogin, practcing yogic disciplines, ought to close his ears with the thumbs and listen within him to the musical strains of the Child-akash or mental horizon and thereby still the mind and attain the Turiya state and merge in the Avyakat.
<G-vec00318-002-s020><merge.aufgehen><de> Andere denken dann, dass die kleine Flamme (Seele) in der großen Flamme (Höchste Seele) aufgehen werde.
<G-vec00318-002-s020><merge.aufgehen><en> Others then think that the little flame (the soul) will merge into the big flame (the Supreme Soul).
<G-vec00318-002-s021><merge.aufgehen><de> In einer zehnminütigen Videoperformance erkundet er diesen theoretischen Ort, das Spezialgebiet seines Vaters, in dem sich die zeitlichen und räumlichen Dimensionen unendlich sind, in dem Leben und Tod in purer Unbegrenztheit aufgehen.
<G-vec00318-002-s021><merge.aufgehen><en> universes-in-universe.org He will explore this theoretical place, his father ’s field of expertise, in which temporal and spatial dimensions are infinite and in which life and death merge into pure infinity.
<G-vec00318-002-s022><merge.aufgehen><de> Zimmer und Suiten - Großzügig wohnen: Das familiär geführte KAISER SPA HOTEL ZUR POST verfügt heute über 170 komfortabel eingerichtete Hotelzimmer, die in einem Gebäudeensemble aufgehen.
<G-vec00318-002-s022><merge.aufgehen><en> Rooms and Suites - Spacious living: Today, the family-run KAISER SPA HOTEL ZUR POST has 170 comfortably furnished hotel rooms that merge into a group of buildings.
<G-vec00318-002-s023><merge.aufgehen><de> Sein Opus Magnum ist die gesamtheitliche Gestaltung des Red Bull Headquarters in Fuschl, wo Landschaft, Bauwerk und Skulptur in einem künstlerischen Ganzen aufgehen.
<G-vec00318-002-s023><merge.aufgehen><en> His magnum opus – the complete design of the Red Bull headquarters in Fuschl, where landscape, buildings and sculpture merge to form an artistic whole.
<G-vec00510-002-s022><sprout_up.aufgehen><de> Doch als Menschen tragen wir wahrscheinlich Samen der Güte in uns, die lange schon darauf warten aufzugehen, wenn die Umstände günstig sind.
<G-vec00510-002-s022><sprout_up.aufgehen><en> But as a people we probably harbor seeds of goodness that have lain for a long time waiting to sprout when the conditions are right.
