<G-vec00721-002-s026><burn.abbrennen><de> Wir haben jetzt wieder eine Entscheidung getroffen, von der ich nichts wusste, weil diese Entscheidung von den Mitgliedstaaten getroffen wurde, aber die Kommission wird jetzt dafür schuldig gemacht – wir haben jetzt vorgeschrieben, wie schnell Weihnachtskerzen abbrennen dürfen.
<G-vec00721-002-s026><burn.abbrennen><en> We have taken yet another decision – one I knew nothing about because the decision was taken by the Member States but the Commission will be blamed anyway – this time to lay down how fast Christmas candles should burn.
<G-vec00721-002-s027><burn.abbrennen><de> Da Cannabis viel schneller verbrennt, kann ein Joint auf einer Seite unregelmäßig abbrennen, wenn er nicht fest genug gedreht wurde.
<G-vec00721-002-s027><burn.abbrennen><en> Uneven joints often burn down one side if not packed tightly enough, as cannabis burns a lot quicker.
<G-vec00721-002-s028><burn.abbrennen><de> Eine gut gepflegte, fruchtbare Landschaft mit Feldern und Wäldern in Mischkultur, mit Bächen und Quellen, die während des ganzen Sommers fließen, würde nicht so einfach abbrennen.
<G-vec00721-002-s028><burn.abbrennen><en> A well-maintained lush landscape with mixed forests and fields, with springs and creeks flowing throughout the year would not burn down that easily.
<G-vec00721-002-s029><burn.abbrennen><de> Aber manchmal muss man auch einfach alles abbrennen.
<G-vec00721-002-s029><burn.abbrennen><en> But, sometimes you just gotta burn away as well.
<G-vec00721-002-s030><burn.abbrennen><de> Das bedeutete, dass diese Gebäude aus solidem Stein nicht abbrennen konnten und dass die Versorgung für die Stadt Charlotte Amalie garantiert war, sogar wenn die Apotheke Opfer einer Brandkatastrophe, eines Hurrikans oder beidem werden würde.
<G-vec00721-002-s030><burn.abbrennen><en> This meant that these rock-solid buildings could not burn down, and that Charlotte Amalie was therefore guaranteed supplies, even if the pharmacy fell victim to fire, hurricane or both. Foresighted employee policy
<G-vec00721-002-s031><burn.abbrennen><de> Das MAXXHEAT ist ein Mehrzweckwerkzeug und kann auch zum Abbrennen von Farbe verwendet werden.
<G-vec00721-002-s031><burn.abbrennen><en> The MAXXHEAT is a multi-purpose tool and can also be used to burn off paint.
<G-vec00721-002-s032><burn.abbrennen><de> Die dritte Stufe ist dann das Abbrennen der gerodeten Flächen.
<G-vec00721-002-s032><burn.abbrennen><en> The third phase is then to burn the cleared areas.
<G-vec00721-002-s033><burn.abbrennen><de> Die Räucherkegel werden an der Spitze angezündet, die Flamme dann ausblasen und auf einer feuerfesten Unterlage abbrennen.
<G-vec00721-002-s033><burn.abbrennen><en> The incense cones are lit at the top, then blow out the flame and burn on a fireproof surface.
